"""Evidence-bound UAV count decisions; no hidden optimum or new objective."""
from pathlib import Path
import json

import numpy as np

import protocol_v5 as protocol

SCHEMA = 'uav-bs-count-selection-v5'


def count_summary(data):
    protocol.validate_results(data)
    if data['config']['stage'] != 'count':
        raise ValueError('a count-stage result is required')
    rows = []
    previous = None
    for count in sorted(data['config']['counts']):
        runs = sorted((r for r in data['runs'] if r['scenario']['n_uav'] == count), key=lambda r:r['i'])
        row = dict(n_uav=count, n=len(runs))
        row['zero_TC_runs'] = sum(r['final_metrics']['TC'] == 0 for r in runs)
        row['zero_SAC_runs'] = sum(r['final_metrics']['SAC'] == 0 for r in runs)
        for metric in protocol.METRICS:
            values = np.array([protocol.metric_value(r, metric) for r in runs])
            row[metric + '_mean'] = float(values.mean()) if len(values) else None
            row[metric + '_sd'] = float(values.std(ddof=1)) if len(values) > 1 else None
            row[metric + '_median'] = float(np.median(values)) if len(values) else None
        row.update(previous_count=None, TC_gain_pp=None, F_improvement=None,
                   SASU_improvement_db=None, GASU_improvement_db=None, runtime_increase_percent=None)
        if runs and previous is not None and [r['i'] for r in runs] == previous[1]:
            before = previous[0]
            row.update(previous_count=before['n_uav'], TC_gain_pp=row['TC_mean'] - before['TC_mean'],
                       F_improvement=before['F_mean'] - row['F_mean'],
                       SASU_improvement_db=before['SASU_mean'] - row['SASU_mean'],
                       GASU_improvement_db=before['GASU_mean'] - row['GASU_mean'])
            if before['runtime_seconds_mean'] > 0:
                row['runtime_increase_percent'] = 100 * (row['runtime_seconds_mean'] / before['runtime_seconds_mean'] - 1)
        rows.append(row)
        previous = (row, [r['i'] for r in runs]) if runs else None
    return rows


def validate_selection(choice, allow_smoke=False, require_current=True):
    if not isinstance(choice, dict) or choice.get('schema_version') != SCHEMA:
        raise ValueError('invalid count selection')
    body = {key:value for key,value in choice.items() if key != 'selection_sha256'}
    if choice.get('selection_sha256') != protocol.digest(body):
        raise ValueError('count selection was changed')
    count = protocol.integer(choice['selected_count'], 'selected count', 1)
    if not isinstance(choice.get('reason'), str) or not choice['reason'].strip():
        raise ValueError('count selection requires a written scientific reason')
    source = Path(choice['count_result_path'])
    if not source.is_file() or protocol.file_digest(source) != choice['count_result_sha256']:
        raise ValueError('count evidence file is missing or changed')
    data = protocol.load_data(source, require_current=require_current)
    status = protocol.qualify(data)
    if data['config']['stage'] != 'count' or not status['complete'] or count not in data['config']['counts']:
        raise ValueError('selection requires a complete count experiment and a measured count')
    if choice.get('formal') is not status['qualified']:
        raise ValueError('selection qualification differs from its evidence')
    if not status['qualified'] and not allow_smoke:
        raise ValueError('nonformal count evidence cannot start a formal experiment')
    if choice.get('source_sha256') != data['provenance']['source_sha256']:
        raise ValueError('selected algorithm source mismatch')
    if require_current and data['provenance']['runtime'] != protocol.runtime_fingerprint():
        raise ValueError('runtime environment differs from the count-selection experiment')
    return data


def load_selection(path, allow_smoke=False, require_current=True):
    choice = json.loads(Path(path).read_text(encoding='utf-8'))
    validate_selection(choice, allow_smoke, require_current)
    return choice


def select_count(count_path, output_path, count, reason, allow_smoke=False):
    count_path, output_path = Path(count_path).resolve(), Path(output_path).resolve()
    data = protocol.load_data(count_path, require_current=True)
    status = protocol.qualify(data)
    if data['config']['stage'] != 'count' or not status['complete']:
        raise ValueError('complete count results are required before selection')
    if not status['qualified'] and not allow_smoke:
        raise ValueError('smoke/pilot evidence cannot be selected for formal experiments')
    if type(count) is not int or count not in data['config']['counts']:
        raise ValueError('selected count was not measured')
    if not isinstance(reason, str) or not reason.strip():
        raise ValueError('a nonempty scientific selection reason is required')
    choice = dict(schema_version=SCHEMA, selected_count=count, reason=reason.strip(),
                  formal=status['qualified'], created_utc=protocol.utc_now(),
                  count_result_path=str(count_path), count_result_sha256=protocol.file_digest(count_path),
                  source_sha256=data['provenance']['source_sha256'])
    choice['selection_sha256'] = protocol.digest(choice)
    validate_selection(choice, allow_smoke=allow_smoke)
    with protocol.directory_lock(output_path.parent):
        if output_path.exists():
            old = load_selection(output_path, allow_smoke)
            if (old['selected_count'], old['reason'], old['count_result_sha256']) == (count, reason.strip(), choice['count_result_sha256']):
                return old
            raise ValueError('a different selection is already recorded; use a new campaign directory')
        protocol.save_json(output_path, choice)
    return choice
