# Delivery and publication notes

This directory can be handed to the advisor as a whole. The GitHub repository uses this directory's content as its root, so `README.md`, `reproduce.py` and `.github/` sit at the repository root; do not mix in external paper PDFs or the DNA base-station planning code folder.

Added: CPU/CUDA pinned dependencies, general entry points, portable read-only re-checking, data verification manifests, figure copies and redraw entry points, Git configuration and a Windows CPU auto-check workflow. The original algorithms, model, experiment parameters, statistics functions and formal data keep their original bytes.

This round's verification is in [reproducibility/validation.md](reproducibility/validation.md). The older report `REPRODUCIBILITY_AUDIT_20261018.md` keeps the historical checks; its pre-publication items describe the state before this round of preparation.

Before publication the author still confirms:

1. License: not chosen yet per the author's request; add a LICENSE after confirming with the advisor together with [SOURCES.md](SOURCES.md).
2. Repository URL and formal paper citation info: no GitHub repository is created or uploaded yet; do not fabricate a DOI, authors or links.

The original JSON and provenance records contain the author's machine paths, which participate in the digests, so they are kept; the new tool does not depend on the old locations. The largest single file is about 18 MB, so Git LFS is not needed for file size.

`.github/workflows/reproduce.yml` can check installation, tests, statistics and the small-scale run after the repository is created; it has not run online, so it does not mean the GitHub check has passed.
