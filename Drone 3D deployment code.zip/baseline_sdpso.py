"""SDPSO (adapted): PSO, annealed guide, and greedy dimensional learning.

This is a deployment-domain adaptation of Yu et al. (2022), not a verbatim
reproduction. In particular, the annealing guide uses the CURRENT population
and is separate from the reporting archive. See docs/sdpso_implementation.md.
"""
import math

import numpy as np

from baseline_support import SearchBudget
from scenario import DEFAULT_SCENARIO


ALGORITHM_LABEL = "SDPSO (adapted)"
M_MIN = 0.0
M_MAX = 10.0
VELOCITY_FRACTION = 0.2


def update_stall_counts(counts, fitness, personal_best_fitness):
    """Reset consecutive stalls on strict improvement; ties count as stalls."""
    return np.where(
        np.asarray(fitness) < np.asarray(personal_best_fitness),
        0, np.asarray(counts, dtype=np.int64) + 1,
    )


def cool_temperature(temperature, progress):
    """Recursively apply Eq. (18)'s multiplier, using consumed FE progress."""
    return float(temperature) * (1.0 - float(np.clip(progress, 0.0, 1.0)))


def metropolis_accept(current_fitness, candidate_fitness, temperature, uniform):
    """Eq. (17) with a log-domain test that also handles cooling to zero."""
    difference = float(candidate_fitness) - float(current_fitness)
    if difference <= 0.0:
        return True
    if temperature <= 0.0:
        return False
    if uniform <= 0.0:
        return True
    # delta / T can overflow after many cooling steps; this equivalent
    # comparison uses multiplication and never evaluates exp(-delta / T).
    return difference < -float(temperature) * math.log(float(uniform))


def update_annealing_guide(guide, guide_fitness, positions, fitness,
                           temperature, progress, rng):
    """Update the current SA guide; return uphill-proposal/acceptance flags.

    Current-population sorting deliberately replaces the paper's historical
    personal-best sorting, whose best-only guard can make uphill moves inert.
    The selected rank's own cost determines its Metropolis probability.
    """
    order = np.argsort(fitness, kind="stable")
    best = int(order[0])
    if fitness[best] <= guide_fitness:
        return positions[best].copy(), float(fitness[best]), False, False
    progress = float(np.clip(progress, 0.0, 1.0))
    rank_count = 1 + int(math.floor(progress * (len(order) - 1)))
    candidate = int(order[int(rng.integers(rank_count))])
    accepted = metropolis_accept(
        guide_fitness, fitness[candidate], temperature, rng.random()
    )
    if accepted:
        return positions[candidate].copy(), float(fitness[candidate]), True, True
    return np.asarray(guide).copy(), float(guide_fitness), True, False


def dimensional_learning(position, fitness, guide, budget):
    """Algorithm 3: evaluate and greedily retain each coordinate replacement.

    Every trial, including an unchanged coordinate, consumes one evaluation.
    Each comparison uses the latest accepted state, and a partial final scan
    returns only evaluated changes when the remaining budget reaches zero.
    """
    current = np.asarray(position, dtype=np.float64).copy()
    current_fitness = float(fitness)
    trials = accepted = 0
    for dimension in range(len(current)):
        if budget.remaining == 0:
            break
        trial = current.copy()
        trial[dimension] = np.clip(
            guide[dimension], budget.lower[dimension], budget.upper[dimension]
        )
        trial_fitness, _ = budget.evaluate_one(trial)
        trials += 1
        if trial_fitness < current_fitness:
            current = trial
            current_fitness = float(trial_fitness)
            accepted += 1
    return current, current_fitness, trials, accepted


def run_sdpso(rng, priority, mode, n_p=50, max_fes=25000,
              scenario=DEFAULT_SCENARIO):
    """Run the declared SDPSO adaptation for exactly ``max_fes`` evaluations.

    PSO steps and all DLS trials share the same budget. Population passes may
    end partway through a particle's scan. The final result is the immutable
    best archive maintained by SearchBudget, never the current SA guide.
    """
    budget = SearchBudget(rng, priority, mode, n_p, max_fes, scenario)
    positions = rng.uniform(
        budget.lower, budget.upper, size=(budget.n_p, budget.dimension)
    )
    velocities = np.zeros_like(positions)
    fitness, _ = budget.evaluate(positions)
    personal_best = positions.copy()
    personal_fitness = fitness.copy()
    best_index = int(np.argmin(fitness))
    guide = positions[best_index].copy()
    guide_fitness = float(fitness[best_index])
    stalls = np.zeros(budget.n_p, dtype=np.int64)
    velocity_limit = VELOCITY_FRACTION * (budget.upper - budget.lower)
    # Scaling before std also avoids overflow for a finite but large objective.
    fitness_scale = max(1.0, float(np.max(np.abs(fitness))))
    temperature = max(1e-12, float(np.std(fitness / fitness_scale)) * fitness_scale)
    diagnostics = {
        "algorithm": ALGORITHM_LABEL,
        "implementation_version": "sdpso-deployment-v4",
        "pso_evaluations": 0,
        "dls_calls": 0,
        "dls_trials": 0,
        "dls_accepts": 0,
        "partial_dls_calls": 0,
        "uphill_guide_proposals": 0,
        "uphill_guide_moves": 0,
        "completed_passes": 0,
        "initial_temperature": temperature,
        "parameters": {
            "inertia_start": 0.9, "inertia_end": 0.4,
            "c1_start": 2.0, "c1_end": 0.4,
            "c2_start": 2.0, "c2_end": 0.4,
            "m_min": M_MIN, "m_max": M_MAX,
            "velocity_fraction": VELOCITY_FRACTION,
        },
    }
    n_updates = 0
    while budget.remaining:
        progress = budget.progress
        inertia = 0.9 - 0.5 * progress
        learning = 2.0 - 1.6 * progress
        threshold = progress * (M_MAX - M_MIN)
        complete_pass = True
        n_updates += 1
        for particle in range(budget.n_p):
            if budget.remaining == 0:
                complete_pass = False
                break
            r1, r2 = rng.random(2)
            velocities[particle] = np.clip(
                inertia * velocities[particle]
                + learning * r1 * (personal_best[particle] - positions[particle])
                + learning * r2 * (guide - positions[particle]),
                -velocity_limit, velocity_limit,
            )
            positions[particle] = np.clip(
                positions[particle] + velocities[particle], budget.lower, budget.upper
            )
            fitness[particle], _ = budget.evaluate_one(positions[particle])
            diagnostics["pso_evaluations"] += 1
            stalls[particle] = int(update_stall_counts(
                stalls[particle], fitness[particle], personal_fitness[particle]
            ))
            if stalls[particle] > threshold and budget.remaining:
                stalls[particle] = 0
                diagnostics["dls_calls"] += 1
                repaired, value, trials, accepted = dimensional_learning(
                    positions[particle], fitness[particle], guide, budget
                )
                positions[particle] = repaired
                fitness[particle] = value
                diagnostics["dls_trials"] += trials
                diagnostics["dls_accepts"] += accepted
                if trials < budget.dimension:
                    diagnostics["partial_dls_calls"] += 1
                    complete_pass = False
            if fitness[particle] < personal_fitness[particle]:
                personal_best[particle] = positions[particle].copy()
                personal_fitness[particle] = fitness[particle]
                stalls[particle] = 0
        if complete_pass:
            guide, guide_fitness, proposed, accepted = update_annealing_guide(
                guide, guide_fitness, positions, fitness, temperature,
                budget.progress, rng,
            )
            diagnostics["uphill_guide_proposals"] += int(proposed)
            diagnostics["uphill_guide_moves"] += int(accepted)
            temperature = cool_temperature(temperature, budget.progress)
            diagnostics["completed_passes"] += 1
    diagnostics["final_temperature"] = temperature
    diagnostics["final_guide_F"] = guide_fitness
    diagnostics["final_stall_counts"] = stalls.tolist()
    return budget.result(n_updates, diagnostics)
