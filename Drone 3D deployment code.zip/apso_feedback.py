"""APSO (Zhan et al., 2009) acceleration feedback, without inertia/ELS changes.

Equations 7-9, 11-12 and the four coefficient strategies are retained.
The caller supplies FSW deployment features and current-population fitness:
this permutation-invariant metric is an explicit adaptation of original ESE.
"""
import numpy as np
from scipy.spatial.distance import cdist

STATE_NAMES = {0: "unclassified", 1: "exploration", 2: "exploitation",
               3: "convergence", 4: "jumping_out"}


def evolutionary_factor(features, fitness):
    features, fitness = np.asarray(features, dtype=float), np.asarray(fitness, dtype=float)
    if features.ndim != 2 or fitness.shape != (len(features),):
        raise ValueError("features and current fitness must have matching population rows")
    if not np.isfinite(features).all() or not np.isfinite(fitness).all():
        raise ValueError("evolutionary state inputs must be finite")
    if len(features) < 3:
        return None
    distances = cdist(features, features, metric="euclidean").sum(axis=1) / (len(features)-1)
    low, high = float(distances.min()), float(distances.max())
    if high-low <= 1e-12 * max(1., high):
        return None
    return float(np.clip((distances[int(np.argmin(fitness))]-low)/(high-low), 0, 1))


def memberships(factor):
    f = float(factor)
    if not np.isfinite(f) or not 0 <= f <= 1:
        raise ValueError("evolutionary factor must lie in [0,1]")
    exploration = 5*f-2 if .4 < f <= .6 else 1. if .6 < f <= .7 else -10*f+8 if .7 < f <= .8 else 0.
    exploitation = 10*f-2 if .2 < f <= .3 else 1. if .3 < f <= .4 else -5*f+3 if .4 < f <= .6 else 0.
    convergence = 1. if f <= .1 else -5*f+1.5 if f <= .3 else 0.
    jumping = 0. if f <= .7 else 5*f-3.5 if f <= .9 else 1.
    return np.clip([exploration, exploitation, convergence, jumping], 0., 1.)


def classify_state(factor, previous_state=None):
    degrees = memberships(factor)
    active = tuple((np.flatnonzero(degrees > 1e-12)+1).tolist())
    if len(active) == 1 or previous_state not in (1, 2, 3, 4):
        return int(np.argmax(degrees))+1
    # Extend the paper's explicit S1/S2 example through its S1->S2->S3->S4 cycle.
    transitions = {
        (1, 2): {1: 1, 2: 2, 3: 2, 4: 1},
        (2, 3): {1: 2, 2: 2, 3: 3, 4: 3},
        (1, 4): {1: 1, 2: 1, 3: 4, 4: 4},
    }
    return transitions[active][previous_state]


class APSOFeedback:
    def __init__(self, rng, initial=2.0, step_min=.05, step_max=.1):
        if not np.isfinite([initial, step_min, step_max]).all() or not 1.5 <= initial <= 2. or not 0 < step_min <= step_max:
            raise ValueError("invalid feedback coefficient/step initialization")
        self.rng = rng
        self.c1 = self.c2 = float(initial)
        self.step_min, self.step_max = float(step_min), float(step_max)
        self.state = 0

    def step_factor(self, factor):
        if factor is None:
            return {"factor": None, "state": self.state, "state_name": STATE_NAMES[self.state],
                    "c1": self.c1, "c2": self.c2, "delta": 0., "degenerate": True}
        self.state = classify_state(factor, self.state)
        delta = float(self.rng.uniform(self.step_min, self.step_max))
        signs = {1: (1., -1.), 2: (.5, -.5), 3: (.5, .5), 4: (-1., 1.)}[self.state]
        pair = np.clip([self.c1 + signs[0]*delta, self.c2 + signs[1]*delta], 1.5, 2.5)
        if pair.sum() > 4.:
            pair *= 4./pair.sum()
        self.c1, self.c2 = map(float, pair)
        return {"factor": float(factor), "state": self.state, "state_name": STATE_NAMES[self.state],
                "c1": self.c1, "c2": self.c2, "delta": delta, "degenerate": False}

    def update(self, features, fitness):
        return self.step_factor(evolutionary_factor(features, fitness))
