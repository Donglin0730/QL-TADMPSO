# SAO-MPSO implementation and fixed-FE adaptation

Implementation: `experiments/baseline_saompso.py`.
Tests: `experiments/tests/test_saompso_v4.py`.
Entry point: `run_saompso(rng, priority, mode, n_p=50, max_fes=25000, scenario=DEFAULT_SCENARIO)`.

## Sources and reproduction status

The primary specification is Hu, Guo, Zhao and Houssein, **An adaptive snow
ablation-inspired particle swarm optimization with its application in geometric
optimization**, Artificial Intelligence Review (2024),
[DOI 10.1007/s10462-024-10946-5](https://link.springer.com/article/10.1007/s10462-024-10946-5).
The supplied PDF was checked against the publisher's mathematical expressions.
Relevant sections are 3.2 and 4.1-4.3; Algorithm 2 is on PDF page 19.

The publisher links an author-uploaded
[SAO-MPSO code archive](https://www.researchgate.net/publication/382144928_SAO-MPSO_Code),
DOI 10.13140/RG.2.2.20160.96002. The ResearchGate page identifies a 2.34 KB
`SAO-MP SO.rar` uploaded by Gang Hu. Its public download returned HTTP 403
during the 2026-09-18 source check; the archive was **not obtained or inspected**.
This implementation therefore must be described as a **paper-based
implementation with documented adaptations**, not a verified translation of
the SAO-MPSO authors' MATLAB code.

For the otherwise unspecified temperature expression, the original SAO
authors' public
[SAO.m](https://github.com/denglingyun123/SAO-snow-ablation-optimizer/blob/main/SAO.m)
was inspected. It specifies `Temp = exp(-progress)` and supports the elite
construction, floor-half leader count, ascending complementary group indices,
and increment-before-second-loop group transition used below. This is a
supplementary source for SAO, not the missing SAO-MPSO implementation. The
incomplete SAO-MPSO baseline bundled with the DNA paper was not reused.

## Implemented mechanisms

1. **Cubic initialization, Eq. (4.1).** Each coordinate receives one independent
   uniform seed in `(0, 1)`. The first particle uses these seeds; subsequent
   particles follow `z_next = 2.59 * z * (1 - z**2)`. Coordinates are mapped as
   `lower + z * (upper - lower)`. This is an actual recurrent chain, rather
   than one nonlinear transformation of independent random positions.
2. **Elite pool, Eqs. (3.5)-(3.7).** The four vectors are the archived global
   best, the second and third current population members by fitness, and the
   centroid of the best `floor(N/2)` current members. The centroid of the whole
   current population is a separate vector. Stable index sorting constructs
   the pool without reordering particles, velocities or personal memories.
3. **Brownian PSO, Eqs. (4.2)-(4.3).** With `A = (pbest-x) + (gbest-x) +
   (gbest-pbest)`, compute `v_new = B*w*v + F*R1*A`, then `x_new=x+v_new`.
   `B` is standard normal independently per coordinate. The printed three
   attraction terms are retained, although algebraically they sum to
   `2*(gbest-x)`.
4. **Snow exploration, Eq. (4.4).** Compute `x_new = elite + B *
   (R2*(gbest-x) + (1-R2)*(population_mean-x))`. Each particle independently
   selects one of the four elite vectors.
5. **Memory, Eq. (4.10).** Once `Nb=0`, perform an additional candidate phase.
   Each particle chooses snow exploration with probability 0.5; otherwise it
   uses `v_new=w*v + M*R1*A`, followed by `x_new=x+v_new`. There is no Brownian
   multiplier on the memory branch's inertia term. A snow update leaves the
   particle's stored velocity unchanged. Historical personal and global bests
   are updated only from evaluated candidates with strictly improved fitness.

## Parameters and progress

Let `p = (FEs_used - N) / (max_fes - N)` at the start of each candidate phase.
The fraction is clipped to `[0, 1]`; an initialization-only run does not enter
any update phase. This replaces the paper's iteration fraction `it/T`. The
same FE budget therefore controls the schedules even after iterations acquire
an additional memory evaluation phase.

| Quantity | Implemented expression |
| --- | --- |
| `c1`, Eq. (4.5) | `sin(3*pi*p) + 1.5` |
| `c2`, Eq. (4.5) | `cos(3*pi*p) + 1.5` |
| `c` | `c1 + c2` |
| `F`, Eq. (4.6) | `2 / (2 + log10(c) + abs(1 - sqrt(c)/2))` |
| `w`, Eq. (4.7) | `0.3*sin(2*pi*p) + 0.6` |
| `lambda`, Eq. (4.9) | `1 - log10(1 + 8*p)` |
| Current speed limit, Eq. (4.8) | `lambda * base_vmax` |
| `DD`, Eq. (3.9) | `0.35 + 0.25*(exp(p)-1)/(e-1)` |
| `Temp`, original SAO source | `exp(-p)` |
| `M`, Eq. (3.8) | `DD * Temp` |

The denominator in the constriction factor uses `sqrt(c)/2`, not
`sqrt(c/2)`. All logarithms denoted `lg` in the paper use base 10. The speed
multiplier uses 8, not 9, and retains a positive endpoint near 0.04576.
It scales the original constant limit rather than multiplying the previously
reduced limit repeatedly. No fixed 1000-iteration denominator is used.

## Group transition and evaluation accounting

`Na=floor(N/2)` and `Nb=N-Na` initially. Every outer iteration randomly selects
the `Na` PSO members; the complementary snow indices are ascending, consistent
with the original SAO source's `setdiff`. The following order follows
Algorithm 2:

1. Generate the `Na` Brownian PSO candidates using the current partition.
2. If `Na<N`, increment `Na` and decrement `Nb`.
3. Generate snow candidates for the first **new** `Nb` entries of the
   previously constructed complementary indices.
4. Evaluate the whole resulting population, including the unchanged remaining
   member during this transition; update fitness, personal bests and archive.
5. If the new `Nb=0`, generate and evaluate the additional memory population.

Thus, for `N=6`, first-phase PSO/snow/unchanged counts are `3/2/1`, `4/1/1`,
`5/0/1`, then `6/0/0`. The third iteration already has an additional full
memory phase. Afterward, each full iteration consumes `2*N` evaluations.
Neither population arrays nor personal-best arrays are sorted or compacted.

Algorithm 2 also prints an unconditional final evaluation after the optional
memory block. When `Nb>0`, that would duplicate an identical population with
no intervening candidate update. This implementation treats that printed call
as a cached no-op: it is omitted and **not charged**. This choice is explicit;
the implementation is not a literal call-for-call reproduction of both
printed evaluation lines. An unchanged particle within the first population
is still evaluated and charged, as described above.

Initialization consumes `N` FEs. Every subsequently evaluated row consumes
one FE, including candidates that do not improve fitness or remain unchanged
after clipping. The final result uses cached best metrics without evaluating
the best solution again. If the remaining budget is shorter than a candidate
phase, evaluate only the prefix in ascending stable particle-index order.
Only those rows are committed; unscored proposed positions and velocities do
not enter the population, personal memories, or best archive. The result
always consumes exactly `max_fes`, provided `max_fes>=N` and `N>=3`.

`n_updates` counts outer iterations entered, including a partial last
iteration. `history_fes` and `gF_history` report actual population-evaluation
boundaries, including initialization. Diagnostics contain actual phase
evaluation counts, candidate counts, FE positions, FE progress, the planned
and evaluated group sizes, unchanged-row counts, and evaluated counts of
both memory branches. Planned full-population updates are distinguished from
actually evaluated tail rows.

## Disclosed interpretation and deployment choices

These choices are required because the paper does not fully specify an
executable implementation and the author archive could not be inspected:

- **Cubic seed layout:** independent seeds per coordinate, recurrence across
  particles, no burn-in; the paper specifies the recurrence but not how to
  flatten or seed the population matrix.
- **Initial velocities:** zero, matching the experiment framework's starting
  convention; the SAO-MPSO paper does not explicitly specify them.
- **Base velocity:** `0.2*(upper-lower)` for each scenario coordinate. The
  paper refers to a constant standard-PSO maximum without supplying a usable
  deployment-specific value. This parameter was fixed before comparison;
  it is not an empirical result or a value recovered from the author code.
- **Velocity and position bounds:** clamp both PSO velocity updates, including
  the memory melting branch, symmetrically to the current velocity limit.
  Algorithm 2 explicitly prints the clamp only in its first velocity loop;
  applying the same limit in the memory loop is a disclosed consistent
  constraint choice. All candidate positions are clipped to scenario bounds
  before evaluation; velocities are not reset when position clipping occurs.
- **Random-variable scope:** `R1` and `R2`, elite selection, and the memory
  branch decision are scalar per particle; Brownian values are per coordinate.
  Section 3 defines `R1` on `[0,1]` and `R2` on `[-1,1]`; the latter range is
  retained for the `R2` notation in Eqs. (4.4) and (4.10), which do not restate
  it. The snow variant in original SAO Eq. (3.4) instead uses `R1`; this
  naming difference cannot be resolved against the inaccessible hybrid code.
- **Snapshots and refresh:** a phase uses synchronous population, global-best,
  elite and centroid snapshots. After a completed first phase, recompute
  those snapshots and the FE-based parameters for the memory phase. Fresh
  independent Brownian values are drawn for that additional phase. No extra
  evaluations are needed to refresh the elite pool or centroid.
- **Odd populations:** the initial snow group receives the extra member;
  even populations match the paper's equal halves. At least three particles
  are required for the two explicitly ranked elite members.
- **Budget adaptation:** FE progress, the fixed-index partial final phase and
  omission of the early duplicate no-op call replace an iteration-count
  stopping rule. These are stated protocol adaptations, not author-code
  equivalence claims.

## Verification

The tests were written first and observed to fail because the implementation
was absent. They cover hand-checked Cubic, constriction, velocity, snow and
memory equations; symmetric velocity bounds; stable particle identities;
the original elite construction; the actual group transition; both memory
branches; exact full and partial budgets; cached archive consistency;
reproducibility; and real deployment scenarios with 10, 20 and 30 UAVs.

Run: `python experiments/tests/test_saompso_v4.py`.
This targeted verification does not run the full experimental campaign.
