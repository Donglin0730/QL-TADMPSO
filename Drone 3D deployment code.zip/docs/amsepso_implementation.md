# AMSEPSO implementation and source decisions

Implementation scope: `baseline_amsepso.py`, its dedicated regression tests, and
this note. The baseline uses the shared `baseline_support.SearchBudget` and the
common UAV objective. No reference DNA implementation is reused.

Implementation sequence:

1. Verify paper equations, neighborhood/exemplar mechanisms, and GBPM with
   independent numerical fixtures; implement the tested primitives.
2. Test initialization, stagnation timing, accepted/rejected GBPM, and exact FE
   accounting with controlled objectives; implement the budgeted search loop.
3. Run the complete dedicated tests and a small real-scenario integration case;
   document every parameter and every decision where the paper is incomplete.

Primary source: Yang, Yu, and Huang, *Adaptive multistrategy ensemble particle
swarm optimization with Signal-to-Noise ratio distance metric*, Information
Sciences 612 (2022), 1066–1094, DOI 10.1016/j.ins.2022.07.165. Equations (6)–(18),
Algorithms 1–3, §§3.1–3.7, and Table 3 were inspected in the local original PDF.

## Parameters and source mapping

PDF page numbers below refer to the 29-page local PDF; journal page numbers are
given as well. Source equations take precedence over inconsistent prose or
table summaries. No parameter is tuned against the UAV results.

| Item | Implemented value or rule | Source / status |
| --- | --- | --- |
| Population | `n_p=50` by default | Common UAV comparison protocol; paper Table 3 uses `N=40`. Explicit adaptation. |
| Search budget | `max_fes=25000` by default | Common UAV protocol; paper §4.1 uses `10000*D`. Explicit adaptation. |
| Bounds / dimension | Supplied by the common deployment scenario | Problem-specific input, not an algorithm parameter. |
| Position initialization | Independent uniform draws within each coordinate's bounds | Algorithm 3 line 1 says random initialization; distribution specified here. |
| Initial velocity | Zero | Paper does not specify it; reproducible implementation convention, approved for this baseline. |
| Velocity cap | None | No cap is specified in Eqs. (15)–(17) or Table 3. |
| Inertia | `w=0.9-0.5*p` | Table 3, PDF p. 11 / journal p. 1076 gives 0.9 to 0.4; linear interpolation is explicit here. |
| Time coordinate | `p=(FEs-n_p)/(max_fes-n_p)`, clipped to [0,1], measured immediately before a population update | FE-normalized replacement for `T/Tmax`; all preceding GBPM evaluations count. |
| Singer polynomial | `F(r)=7.86*r-23.31*r^2+28.75*r^3-13.3*r^4` | Eq. (6), PDF p. 5 / journal p. 1070. |
| Singer recurrence | `r_next=mu*F(r)` | Eq. (7); the multiplier applies to the whole polynomial. |
| Singer multiplier | One `mu~U[0.9,1.08)` draw per run | Eq. (7) has time-independent `mu`; §3.1 calls it random. Sampling cadence is an explicit interpretation. |
| Singer initial state | One `r0~U[0,1)` draw; exact endpoints protected using machine epsilon | Eq. (7), with an explicit numerical safeguard. The first population update uses `r0`; one recurrence step precedes each subsequent update. |
| Acceleration | `c1=2.5-r*p`, `c2=0.5+r*p` | Eqs. (8)–(9), PDF p. 5 / journal p. 1070. |
| ESE metric | `var(pbest_i-anchor)/var(anchor)` across coordinates | Eqs. (10)–(11), PDF pp. 6–7 / journal pp. 1071–1072; raw coordinates, no normalization. |
| ESE anchors | Archived global best; worst personal best by objective | Algorithm 1 and §3.2; the paper does not separately define a current-position worst archive. The historical interpretation is explicit. |
| ESE exclusions | Index of best personal best and index of worst personal best | §3.7, PDF p. 10 / journal p. 1075, explicitly specifies `N-2` distances. |
| State threshold | `sigma=0.3*N` | §3.2 / Algorithm 1 and Table 3. `z=N_gw-N_gb`; exploration if `z>sigma`, exploitation if `z<-sigma`, otherwise balance. |
| Distance tie | Counts toward the global-best neighborhood | Algorithm 1 `if d_gb>d_gw ... else ...`; threshold endpoints belong to balance. |
| State-estimation cadence | Once after initialization, then only when `Stag_g>5` | Algorithm 3 lines 6 and 8–10, PDF p. 9 / journal p. 1074; strict greater-than. |
| Exploration exemplars | Own personal best plus best of the left/right ring neighbors | Eq. (15), §3.4; §3.7 explicitly compares left and right ends. Self is excluded from the social neighborhood. |
| Balance exemplars | Own personal best plus coordinatewise mean of all personal bests | Eqs. (14), (16), PDF p. 8 / journal p. 1073. |
| Exploitation exemplars | Stochastic elite exemplar plus coordinatewise mean of all personal bests | Eqs. (12)–(14), (17). |
| Elite selection | Top 20% of personal bests; uniformly choose two distinct elite indices, retain the better, then retain own personal best unless the winner strictly improves it | Eqs. (12)–(13), §3.3. One tournament per particle per exploitation update. |
| Velocity random terms | Independent `U[0,1)` draws per particle and coordinate, separately for cognitive and social terms | Eqs. (15)–(17) specify random terms but do not specify their granularity; this conventional vector interpretation is documented. It does not inherit another algorithm's scalar convention. |
| Population updates | Synchronous: all exemplars use the previous personal-best population | Algorithm 3 updates/evaluates all particles before updating bests. |
| GBPM | Select one coordinate uniformly; add a standard-normal draw times that coordinate's full bound width; clip that coordinate | Eq. (18), Algorithm 2, PDF pp. 8–9 / journal pp. 1073–1074. |
| GBPM acceptance | Strictly improve the global archive; retain cached candidate metrics | Algorithm 2 lines 8–11. An accepted perturbation is not inserted into an unrelated particle or personal best. |
| Boundary handling | Coordinatewise clipping of proposed particle positions; stored velocity is retained | Eq. (2) plus scenario feasibility convention; GBPM clipping is expressly specified by Algorithm 2. |

## Resolved omissions and inconsistencies

1. **Acceleration table:** Table 3 reports `c2=1.5 -> 2.5`, contradicting both
   Eq. (9) and the accompanying text, which start `c2` at 0.5. The implementation
   follows the equations. The source statement that coefficients reach 1.5 is a
   description of the envelope: the actual value depends on `r`, so no forced
   endpoint or extra factor of two is introduced.

2. **The printed Singer map does not preserve the unit interval throughout the
   printed parameter interval.** For example, `r=0.324, mu=1.08` gives
   `1.0054102366863358`, and subsequent values can diverge. The exact polynomial
   remains unchanged. A mapped value that is nonfinite or outside `(0,1)` is
   replaced with a fresh uniform seed, clamped to `[eps,1-eps]` only to avoid the
   absorbing endpoints. `singer_restarts` records these repairs. There is no
   unconditional clipping or substitution of a logistic map.

3. **Zero-variance SNR anchors:** the source ratio can be undefined. This
   implementation uses `0` when both numerator and denominator are zero, and
   positive infinity when the denominator is zero but numerator is positive.
   Thus it never produces NaN in this case. Two infinite distances follow the
   source's `else` tie rule. The variance uses NumPy's population convention;
   choosing the same sample-variance convention in numerator and denominator
   would give the same ratio for `D>1`.

4. **Best/worst identity and ties:** exclusion is by particle index, preserving
   the source's `N-2` count even when different particles share coordinates.
   The first minimum and last maximum personal-best indices are excluded. They
   are distinct on a flat objective when `N>1`. After an accepted GBPM, the
   separate global archive is the best anchor, and the best personal-best
   particle remains the excluded population representative. The paper does not
   specify an alternative GBPM-to-particle identity transfer.

5. **Stagnation bookkeeping:** any strict global improvement in a round,
   including GBPM, resets stagnation to zero. Otherwise each completed
   population update increments it. After an unsuccessful GBPM, stagnation is
   not reset: Algorithm 2 resets it only on success, so Algorithm 3 can trigger
   ESE/GBPM again in the next round. This follows the pseudocode even though the
   rough complexity discussion describes a spacing of `Stagmax` iterations.

6. **Small populations and noninteger elite counts:** use
   `min(N,max(2,ceil(0.2*N)))` elite members so the distinct-member tournament is
   defined. A single-particle swarm uses its sole member. These conventions
   affect only nonstandard sizes; the protocol's `N=50` uses exactly 10 elites
   and the source's `N=40` uses exactly eight.

## FE accounting and return contract

Every real objective call passes through `SearchBudget`: initialization costs
`N`, each evaluated particle costs one, and each GBPM attempt costs one even if
it is rejected, clipped to a previously seen point, or does not move. The source
pseudocode omits the GBPM FE increment and uses `FEs <= MaxFEs`; following those
literally would violate the comparison budget. The loop therefore runs only
while budget remains and never exceeds `max_fes`.

A final remainder smaller than `N` evaluates only the leading particles in
fixed index order. Their personal bests are updated and untouched particles keep
their previous positions/velocities. The last update may therefore be partial;
`n_updates` counts population-update batches, including that partial batch, and
`partial_update_size` identifies it. If one evaluation remains when GBPM is due,
GBPM consumes it and the loop ends without any population update. The final
solution and metrics are read from the archive; there is no final reevaluation.

`FEs` rather than the number of population updates drives inertia and
acceleration schedules. This is an explicit adaptation needed because
successful/unsuccessful GBPM changes the number of extra evaluations and hence
the number of full generations possible under a fixed budget. Population
updates start at progress zero, and the schedule's analytical endpoint at one
is not an extra update after the budget is exhausted.

The return value is the shared `SearchBudget.result` dictionary. Diagnostics
include initialization/population/GBPM FE counts, strategy generation and
evaluated-particle counts, each state-estimation event and neighborhood counts,
GBPM attempts/acceptances/coordinates/FE indices, first and last parameter
values with the actual FE progress, the Singer multiplier and repair count,
the final stagnation value, and terminal partial-update size. Counts satisfy:

```text
initialization_fes + population_update_fes + gbpm_fes = result.fes = max_fes
sum(strategy_evaluations.values()) = population_update_fes
sum(strategy_generations.values()) = result.n_updates
```

## Verification

Run `python experiments/tests/test_amsepso_v4.py` from the workspace root.
The tests use hand-derived formula fixtures, the real shared budget with
controlled objectives, and a small real deployment scenario. They cover:

- the exact Singer quartic and whole-polynomial multiplier, coefficient
  schedules, variance ratios, and safe degenerate cases;
- all three state regions, threshold equality, exclusion counts, ring wrapping,
  distinct-member elite selection, mean personal-best exemplars, dimensionwise
  velocity terms, and one-coordinate clipped GBPM;
- initialization-only and partial budgets, strict `stagnation>5`, budget-ending
  GBPM, rejection/acceptance, cached metrics, monotone best history, reproducible
  random streams, and FE schedules including GBPM;
- tiny populations and a real two-UAV search with exactly 32 objective calls.

The tests were written before the respective implementation stages: missing
mechanisms first failed, then 11 equation/exemplar tests passed; the missing
budgeted runner and Singer safeguard then failed, followed by all 21 dedicated
tests passing. No production experiment was launched by this implementation
task.
