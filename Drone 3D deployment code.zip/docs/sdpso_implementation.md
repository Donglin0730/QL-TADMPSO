# SDPSO (adapted): implementation and source limits

This implementation is a **deployment-domain adaptation**, and must be displayed
as **SDPSO (adapted)** in comparison tables, figures, and conclusions. It is not a
verbatim reproduction or author-code implementation of the original path planner.
It retains the paper's PSO, simulated-annealing (SA), and dimensional-learning
(DLS) mechanisms; it does not substitute differential evolution for either one.

## Primary source and provenance

Zhenhua Yu, Zhijie Si, Xiaobo Li, Dan Wang, and Houbing Song, *A Novel Hybrid
Particle Swarm Optimization Algorithm for Path Planning of UAVs*, IEEE Internet
of Things Journal, 9(22), 22547-22558, 2022.
[Publisher record](https://ieeexplore.ieee.org/document/9795684/),
[DOI](https://doi.org/10.1109/JIOT.2022.3182798).

The supplied PDF is the implementation source. Equations (15)-(19), Algorithms
1-4 (pp. 22551-22553), and Table II (p. 22553, visually inspected) were checked.
Web searches on 2026-09-18 using the exact title, DOI, SDPSO, and author names did
not identify a source-code release whose authorship could be verified. This is
an availability limit of that search, not a claim that no release exists. No
unverified third-party implementation was used as normative source code.

The original study optimizes path waypoints and path length, height, and turning
costs. Here every candidate is the shared static UAV-BS deployment vector
`[x1, y1, h1, ..., xN, yN, hN]`, evaluated with the experiment's common scenario,
priority mask, propagation mode, and objective. Original path costs, mountain
obstacles, flight constraints, and the paper's reported numerical performance
are not reproduced.

## Source-prescribed behavior and explicit choices

| Item | Implemented value or rule | Provenance / interpretation |
| --- | --- | --- |
| PSO motion | Inertia, personal best, social guide, then position update | Eqs. (15)-(16) |
| Inertia | `w = 0.9 - 0.5*p` | Table II gives 0.9 to 0.4; linear FE scheduling is an adaptation |
| Learning factors | `c1 = c2 = 2.0 - 1.6*p` | Table II gives 2.0 to 0.4; linear FE scheduling is an adaptation |
| Random factors | Independent scalar `r1,r2 ~ U[0,1)` per particle and PSO step | Eq. (15) describes two random numbers; scalar convention is declared here |
| Population / budget | Defaults `S=50`, `max_fes=25000` | Common comparison protocol, replacing the paper's `S=200` and iteration limits |
| Dimension / bounds | `3*n_uav`; injected `scenario.bounds()` | Deployment adaptation, no hard-coded 75-dimensional vector |
| Initial positions / velocities | Uniform positions; zero velocities | Common comparison initialization; not asserted to be the author's initialization |
| Velocity limit | `0.2*(upper-lower)` per coordinate | **Declared setup choice.** The paper mentions bounded velocity but does not give this fraction |
| Boundary treatment | Clip velocity and position to their respective bounds; retain velocity after DLS | Boundary clipping is one permitted treatment in Section IV-A; numerical settings are adaptation choices |
| Initial temperature | `max(std(F_initial, ddof=0), 1e-12)` | **Data-derived deployment choice.** A numerical `T0` is not specified in the checked paper text/table |
| Cooling | `T_next = T_current*(1-p_end)` once per completed population pass | Preserves recursive multiplication and Eq. (18)'s decreasing multiplier; replaces iteration fraction by consumed-FE fraction |
| DLS threshold | `m=p_start*(Mmax-Mmin)`, `Mmin=0`, `Mmax=10` | Eq. (19) has no additive `Mmin`; **the numerical bounds are declared setup choices**, not recovered source parameters |
| Stall counter | One per particle; consecutive failure to strictly improve personal best, including ties | Makes the consecutive-nonupdate description operational; reset on improvement and on starting DLS |
| DLS | If `count_i > m`, test copying each guide coordinate and retain only strict improvement | Algorithm 3, greedily comparing with the latest accepted particle, not its pre-scan cost |
| SA guide proposals | Sort evaluated **current positions**; select within an expanding bounded rank prefix when their best is worse than the guide | **Explicit departure from Algorithm 2's historical-personal-best sorting**, explained below |
| Rank prefix | `1 + floor(p_end*(S-1))`; uniformly choose an index in that prefix | Bounded interpretation of the paper's growing rank range; not its ambiguous `n in [0,t]` literally |
| SA acceptance | Improve/tie: accept; uphill: `U < exp(-(F_proposal-F_guide)/T)` | Eq. (17), using the selected proposal's own cost |
| Reported solution | Best evaluated candidate, cached independently of the current SA guide | Common comparison protocol; accepted uphill moves never overwrite the reporting archive |

The numerical temperature, DLS-bound, velocity, and rank choices above have not
been tuned on the final comparison seeds. They define this candidate setup and
must not be presented as values supplied by Yu et al.

## Why the SA guide is an adaptation

Algorithm 2 sorts historical personal-best positions, takes the best as a trial,
and enters its uphill branch only when that trial is worse than the previous
global guide. If the guide starts at the best personal best and the personal-best
archive is updated normally, the minimum personal-best cost cannot increase.
The guard can therefore keep the nominal annealing branch permanently inactive.
The text additionally describes `n` as lying between zero and iteration `t`,
although a population index must remain valid when `t` exceeds `S`. The
acceptance formula names a future guide before the pseudocode selects rank `n`.

The implemented, explicitly declared interpretation is:

1. Keep personal-best memory for the PSO cognitive term and a separate current
   annealing guide for the social term and DLS.
2. After a completed population pass, sort the current evaluated particles.
3. If their best cost is no worse than the current guide, adopt that best.
4. Otherwise draw a rank from the bounded prefix above and apply Eq. (17) to
   **that candidate's** cost difference against the current guide.
5. Preserve a separate monotone reporting archive of all evaluated candidates.

This makes uphill guide moves possible without losing the best discovered
deployment. It is a documented operational interpretation, not a claim to have
resolved the authors' intention. The current population is never replaced by a
DE mutation population, and no uncounted SA perturbation is evaluated.

The Metropolis test is evaluated as `delta < -T*log(U)`, avoiding division by an
underflowed temperature and exponential overflow. At zero temperature all
strictly uphill proposals are rejected; downhill/tied proposals remain valid.
Cooling multiplies the **previous** temperature. It is not the different rule
`T = T0*(1-p)`.

## Evaluation budget and iteration semantics

`p = (fes-S)/(max_fes-S)` after initialization, clipped to `[0,1]`. With an
initialization-only budget the search returns immediately. Inertia, learning
coefficients, and `m` use progress at the start of a population pass; rank choice
and cooling use progress after that pass. Cooling occurs once per completed
pass, so DLS changes both the available number of passes and the FE progress.

Particles are processed in stable index order. Each PSO update is evaluated,
then its triggered DLS scans coordinates in stable order before the next
particle advances. Every DLS trial, including copying an already-equal guide
coordinate, is an actual objective evaluation and consumes one FE. DLS compares
against the latest accepted state and updates its cached cost after each strict
improvement. Thus a later trial that beats the pre-scan cost but loses to an
earlier accepted trial is rejected.

The last FE may end the run after a PSO update or midway through a coordinate
scan. Only evaluated replacements can enter the returned state. Such a partial
pass does not receive another guide/cooling update. SA selection reuses already
evaluated current costs, so it consumes no additional FE. The final report uses
the best position and metrics cached by `SearchBudget`; it never reevaluates the
winner. This gives exactly the declared budget, including nonmultiples of `S`.

`n_updates` counts started population passes, including a truncated final pass.
`completed_passes` records passes that reached all particles and completed every
DLS scan they started. `history_fes` stores actual cumulative FE checkpoints;
the first checkpoint is after initialization and subsequent single-candidate
checkpoints increase by one. `gF_history` is the monotone archive curve, not the
possibly nonmonotone annealing-guide curve. A curve against population passes
would conceal the cost of DLS and must not replace the FE axis in comparisons.

Diagnostics also include `pso_evaluations`, `dls_calls`, `dls_trials`,
`dls_accepts`, `partial_dls_calls`, `uphill_guide_proposals`,
`uphill_guide_moves`, initial/final temperature, final guide cost, final stall
counters, and the declared numeric parameters. The accounting identity is
`fes = S + pso_evaluations + dls_trials`.

## Verification

`python experiments/tests/test_sdpso_v4.py` runs 16 checks of sequential DLS greediness,
per-particle counter reset, exact coordinate costs, mid-scan budget exhaustion,
recursive cooling, temperature underflow, Metropolis cost differences, actual
uphill guide acceptance, archive independence, cached best metrics, exact budget
tails, deterministic seeds, and varying UAV counts with finite bounded points.

The mechanism tests were first run against the missing implementation and
failed, then passed after implementation. Budget-runner tests likewise failed
before the runner was added. A full-loop SA regression also fails when uphill
acceptance is deliberately disabled in memory, then passes with the production
implementation. In its fixed analytic fixture (seed 8, four particles, 173 FEs),
the completed run records five uphill proposals and four accepted uphill guide
moves while retaining a nonincreasing best archive.

A small smoke check against the actual deployment model used two UAVs, a
10-by-10 grid, four particles, and 41 FEs in each of `a2g` and `los` modes. Both
returned finite six-coordinate solutions with exactly 41 FEs (12 and 24 DLS
trials, respectively). The local CuPy import emitted an existing CUDA-path
warning; this smoke check explicitly used CPU evaluation. No full comparison
experiments were run as part of this implementation task.

These are correctness checks, not evidence of competitive optimization
performance or replication of the source experiments.
