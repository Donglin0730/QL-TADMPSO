# APSO learning-factor feedback in QL-TADMPSO

This change only swaps how `c1,c2` of the paper's algorithm are controlled; the inertia weight, the other guidance terms, Q-learning, the matrix encoding and the random-scalar rules keep the original implementation. The default parameter of `algorithms.run_ql_tadmpso` is still `coefficient_control="ahdpso"`; `run_v4.py` passes `"apso"` explicitly. The inertia weight strictly follows `w_t=0.9-0.5*t/T`, `t=0,...,T-1`; at 499 updates the last value is about 0.401002 and is not forced to exactly 0.4.

## Source and kept mechanisms

The source is the local APSO paper: Zhan, Zhang, Li and Chung, *Adaptive Particle Swarm Optimization*, IEEE Transactions on Systems, Man, and Cybernetics, Part B: Cybernetics, 39(6), 1362-1381, 2009, DOI 10.1109/TSMCB.2009.2015956. The evolutionary-state estimation, Eqs. (7)-(9), Eqs. (11)-(12) and the four learning-factor adjustment strategies were checked.

First compute each particle's mean distance `d_i` to the other particles on the current population representation, then take the distance `d_best` of the **best-fitness particle of the current population**, and compute

`f = (d_best - min(d_i)) / (max(d_i) - min(d_i))`.

The paper's piecewise fuzzy membership functions map `f` to the four states exploration, exploitation, convergence and jumping-out. Overlapping regions keep transition continuity by the previous state: the S1/S2 overlap follows the paper's explicit example, the other overlaps extend the paper's S1->S2->S3->S4 cycle order. On the first overlap the state with the largest membership is taken; on exact ties S1, S2, S3, S4 is the order of preference.

Each non-degenerate feedback samples `delta~U[0.05,0.1]` independently; the four states map to:

| State | c1 | c2 |
| --- | --- | --- |
| Exploration | +delta | -delta |
| Exploitation | +delta/2 | -delta/2 |
| Convergence | +delta/2 | +delta/2 |
| Jumping-out | -delta | +delta |

Initial `c1=c2=2`; after each update they are clipped to `[1.5,2.5]`, and if the sum exceeds 4 they are scaled proportionally back to a sum of 4. With fewer than three particles or a numerically degenerate mean-distance range, the original coefficients and state are kept and no feedback random number is consumed.

## Deployment adaptation and reuse

The original APSO uses Euclidean distances of the raw particle coordinates. This full algorithm uses the Euclidean distances between the existing **FSW feature vectors**, making the distance insensitive to the UAV numbering permutation of the same deployment. FSW features are computed once per generation and shared by the state estimation and the topology that needs rebuilding; the fitness reuses the already-evaluated current population with no extra channel-model calls.

The feedback RNG uses an independent `feedback_seed`. The original chaotic parameter sequence is still generated in the original order, keeping the random-number rules that the inertia weight and other coefficients depend on; only the finally used `c1,c2` are overwritten. The feedback log records the FE position, evolutionary factor, state, learning factors and inertia weight, so the actual trajectory can be re-checked.

The `no_fsw` ablation makes the feedback use the boundary-normalized raw coordinates and drops FSW clustering at the same time. It tests the role of the whole FSW representation, not a change of the clustering distance alone.

## Compute cost and interpretation boundary

Let the particle count be `N_p`, the FSW feature dimension `L*M` with `M` the UAV-BS count and `L` the projection count. The added pairwise-distance computation is `O(N_p^2*L*M)` and the current distance-matrix memory is `O(N_p^2)`; FSW projection and sorting are `O(N_p*L*M*log(M))` and feature storage is `O(N_p*L*M)`. State classification and coefficient adjustment are constant-cost and there are zero extra channel-function evaluations. If the topology was not previously rebuilt every generation, computing FSW features every generation for the feedback also adds real run time; "zero extra FEs" alone does not mean no cost.

This version does not adopt APSO's adaptive inertia weight or ELS. The paper's multiple social guidance terms share `c2` and include other coefficients, so `c1+c2<=4` cannot be read as a stability proof of the whole multi-guidance update. The original paper's parameter ranges are candidate starting points, not a substitute for validation on this problem. `L=50, G=5` and the learning-factor parameters above were not re-selected against the final comparison seeds.

## Checks

`tests/test_apso_feedback.py` verifies the fuzzy states, overlap transitions, degenerate cases, coefficient constraints, fixed seeds, no extra FEs, linear inertia and the legacy default trajectory. The `legacy_coefficients` condition in the versioned ablation keeps the AHDPSO control, used to test the actual gain and cost of swapping the learning factors alone.
