# Implementation sources

All methods share the same deployment evaluation procedure; T-ADMPSO and SDPSO are the deployment adaptations described in the paper. See each method's notes for the detailed differences.

| Method | Source |
| --- | --- |
| PSO | Kennedy and Eberhart, 1995, DOI: 10.1109/ICNN.1995.488968; parameters follow the PSO control of the DNA paper. |
| AHDPSO | Zhu et al., DNA Sequence-Inspired Similarity-Driven Particle Swarm Optimization for UAV-BS Deployment, DOI: 10.1109/JIOT.2025.3649724; the paper and its PSO.py/AHDPSO1.py. |
| T-ADMPSO | Guo et al., 2026, DOI: 10.1016/j.asoc.2026.114813. |
| AMSEPSO | Yang et al., 2022, DOI: 10.1016/j.ins.2022.07.165; [implementation notes](docs/amsepso_implementation.md). |
| SDPSO | Yu et al., 2022, DOI: 10.1109/JIOT.2022.3182798; [implementation notes](docs/sdpso_implementation.md). |
| SAO-MPSO | Hu et al., 2024, DOI: 10.1007/s10462-024-10946-5; [implementation notes](docs/saompso_implementation.md). |
| APSO feedback ablation | Zhan et al., 2009, DOI: 10.1109/TSMCB.2009.2015956; [implementation notes](docs/apso_feedback_implementation.md). |

SAO-MPSO is implemented from the paper; the authors' SAO-MPSO archive was not obtained. Temperature and other details also refer to the [SAO author repository](https://github.com/denglingyun123/SAO-snow-ablation-optimizer). That supplementary source is not the SAO-MPSO authors' code.

The current materials do not keep an explicit license for the DNA released code or the SAO supplementary source above; before publication the author checks the licenses and required attribution. This table does not replace third-party authorization. The delivery package contains neither the external DNA code nor downloaded paper PDFs.

The companion paper is titled *Matching-Guided Particle Swarm Optimization for 3D Deployment of UAV Base Stations*. The formal authors, publication info and repository URL follow the author's final published version.
