"""AMSEPSO from Yang et al. (2022), adapted to a strict objective-call budget.

See docs/amsepso_implementation.md for equations, parameter provenance, and
explicit choices for details the primary paper leaves unspecified.
"""
import numpy as np

from baseline_support import SearchBudget
from scenario import DEFAULT_SCENARIO


STATES = ("exploration", "balance", "exploitation")
STAGNATION_LIMIT = 5


def singer_step(value, multiplier):
    """Equations (6)–(7): the multiplier applies to the entire quartic."""
    r = float(value)
    return float(multiplier) * (7.86 * r - 23.31 * r**2
                               + 28.75 * r**3 - 13.3 * r**4)


def bounded_singer_step(rng, value, multiplier):
    """Restart only when the printed map exits its intended open unit interval.

    At r=0.324, multiplier=1.08 the paper's exact polynomial exceeds one.
    Leaving such a value in the recurrence can diverge. The restart is a
    documented numerical safeguard, not a replacement chaotic equation.
    """
    candidate = singer_step(value, multiplier)
    if np.isfinite(candidate) and 0.0 < candidate < 1.0:
        return candidate, False
    epsilon = np.finfo(float).eps
    return float(np.clip(rng.random(), epsilon, 1.0 - epsilon)), True


def parameters(progress, singer_value):
    """Return inertia, c1, c2; use Eqs. (8)–(9), not Table 3's c2 typo."""
    progress = float(np.clip(progress, 0.0, 1.0))
    excursion = float(singer_value) * progress
    return 0.9 - 0.5 * progress, 2.5 - excursion, 0.5 + excursion


def snr_distances(positions, reference):
    """Eqs. (10)–(11), with explicit limits for a zero-variance reference."""
    numerator = np.var(np.asarray(positions) - reference, axis=1)
    denominator = float(np.var(reference))
    if denominator == 0.0:
        return np.where(numerator == 0.0, 0.0, np.inf)
    return numerator / denominator


def estimate_state(pbest, pbest_f, gbest):
    """Estimate once over N−2 historical positions (Algorithm 1, §3.7)."""
    n = len(pbest)
    best_index = int(np.argmin(pbest_f))
    # The last maximum makes the two excluded particles distinct on flat data.
    worst_index = n - 1 - int(np.argmax(np.asarray(pbest_f)[::-1]))
    included = np.ones(n, dtype=bool)
    included[[best_index, worst_index]] = False
    candidates = np.asarray(pbest)[included]
    d_best = snr_distances(candidates, gbest)
    d_worst = snr_distances(candidates, pbest[worst_index])
    n_gw = int(np.count_nonzero(d_best > d_worst))
    n_gb = int(len(candidates) - n_gw)  # Algorithm 1 sends ties to gbest.
    difference = n_gw - n_gb
    threshold = 0.3 * n
    if difference > threshold:
        state = "exploration"
    elif difference < -threshold:
        state = "exploitation"
    else:
        state = "balance"
    return state, {"n_gw": n_gw, "n_gb": n_gb, "difference": difference,
                   "threshold": threshold}


def ring_neighbor_bests(pbest, pbest_f):
    """Eq. (15): best historical position of the two adjacent ring particles."""
    indices = np.arange(len(pbest))
    left = (indices - 1) % len(pbest)
    right = (indices + 1) % len(pbest)
    winners = np.where(np.asarray(pbest_f)[left] <= np.asarray(pbest_f)[right],
                       left, right)
    return np.asarray(pbest)[winners].copy()


def elite_exemplars(rng, pbest, pbest_f):
    """Eqs. (12)–(13): distinct elite tournament, then challenge own pbest."""
    n = len(pbest)
    elite_count = min(n, max(2, int(np.ceil(0.2 * n))))
    elite = np.argsort(pbest_f, kind="stable")[:elite_count]
    exemplars = np.asarray(pbest).copy()
    for i in range(n):
        if elite_count == 1:
            winner = int(elite[0])
        else:
            a, b = rng.choice(elite, size=2, replace=False)
            winner = int(a if pbest_f[a] <= pbest_f[b] else b)
        if pbest_f[winner] < pbest_f[i]:
            exemplars[i] = pbest[winner]
    return exemplars


def learning_exemplars(state, pbest, pbest_f, rng):
    """Construct the cognitive and social exemplars in Eqs. (15)–(17)."""
    if state == "exploration":
        return np.asarray(pbest).copy(), ring_neighbor_bests(pbest, pbest_f)
    social = np.broadcast_to(np.mean(pbest, axis=0), np.shape(pbest)).copy()
    if state == "balance":
        return np.asarray(pbest).copy(), social
    if state == "exploitation":
        return elite_exemplars(rng, pbest, pbest_f), social
    raise ValueError(f"Unknown AMSEPSO state: {state}")


def velocity_step(position, velocity, cognitive, social, inertia, c1, c2, r1, r2):
    """The common velocity formula, with explicit per-coordinate random terms."""
    return (inertia * velocity + c1 * r1 * (cognitive - position)
            + c2 * r2 * (social - position))


def perturb_gbest(rng, gbest, lower, upper):
    """Eq. (18), Algorithm 2: perturb exactly one dimension before clipping."""
    candidate = np.asarray(gbest).copy()
    dimension = int(rng.integers(len(candidate)))
    candidate[dimension] += rng.standard_normal() * (upper[dimension] - lower[dimension])
    candidate[dimension] = np.clip(candidate[dimension], lower[dimension], upper[dimension])
    return candidate, dimension


def run_amsepso(rng, priority, mode, n_p=50, max_fes=25000,
                scenario=DEFAULT_SCENARIO):
    """Run Algorithm 3 with every initialization, swarm, and GBPM FE counted.

    A terminal partial population consumes an otherwise unused remainder. The
    time schedules use consumed-FE progress because GBPM uses additional FEs.
    All objective values and final metrics are obtained from SearchBudget.
    """
    budget = SearchBudget(rng, priority, mode, n_p, max_fes, scenario)
    n, dimension = budget.n_p, budget.dimension
    position = rng.uniform(budget.lower, budget.upper, size=(n, dimension))
    velocity = np.zeros_like(position)
    pbest_f, _ = budget.evaluate(position)
    pbest = position.copy()

    # Equation (7) uses a time-independent multiplier and random r(0).
    multiplier = float(rng.uniform(0.9, 1.08))
    epsilon = np.finfo(float).eps
    singer_value = float(np.clip(rng.random(), epsilon, 1.0 - epsilon))
    state, counts = estimate_state(pbest, pbest_f, budget.best_pos)
    diagnostics = {
        "initialization_fes": n,
        "population_update_fes": 0,
        "strategy_generations": {name: 0 for name in STATES},
        "strategy_evaluations": {name: 0 for name in STATES},
        "state_estimation_count": 1,
        "state_estimation_events": [dict(
            before_fes=budget.fes, completed_updates=0, stagnation=0,
            trigger="initialization", state=state, **counts,
        )],
        "gbpm_attempts": 0,
        "gbpm_accepts": 0,
        "gbpm_events": [],
        "singer_multiplier": multiplier,
        "singer_initial": singer_value,
        "singer_restarts": 0,
        "partial_update_size": 0,
        "first_parameters": None,
        "last_parameters": None,
    }
    updates, stagnation = 0, 0
    while budget.remaining:
        best_before_round = budget.best_F
        if stagnation > STAGNATION_LIMIT:
            state, counts = estimate_state(pbest, pbest_f, budget.best_pos)
            diagnostics["state_estimation_count"] += 1
            diagnostics["state_estimation_events"].append(dict(
                before_fes=budget.fes, completed_updates=updates,
                stagnation=stagnation, trigger="stagnation", state=state, **counts,
            ))
            candidate, coordinate = perturb_gbest(
                rng, budget.best_pos, budget.lower, budget.upper,
            )
            before_fes = budget.fes
            trial_f, _ = budget.evaluate_one(candidate)
            accepted = trial_f < best_before_round
            diagnostics["gbpm_attempts"] += 1
            diagnostics["gbpm_accepts"] += int(accepted)
            diagnostics["gbpm_events"].append({
                "before_fes": before_fes, "fe": budget.fes,
                "coordinate": coordinate, "accepted": bool(accepted),
                "stagnation": stagnation,
                "previous_best_F": best_before_round, "trial_F": trial_f,
            })
            if accepted:
                stagnation = 0
            if not budget.remaining:
                break

        if updates:
            singer_value, restarted = bounded_singer_step(rng, singer_value, multiplier)
            diagnostics["singer_restarts"] += int(restarted)
        progress = budget.progress
        inertia, c1, c2 = parameters(progress, singer_value)
        parameter_record = {
            "before_fes": budget.fes, "progress": progress,
            "inertia": inertia, "c1": c1, "c2": c2,
            "singer_value": singer_value,
        }
        if diagnostics["first_parameters"] is None:
            diagnostics["first_parameters"] = parameter_record.copy()
        diagnostics["last_parameters"] = parameter_record

        cognitive, social = learning_exemplars(state, pbest, pbest_f, rng)
        count = min(n, budget.remaining)
        r1 = rng.random((count, dimension))
        r2 = rng.random((count, dimension))
        velocity[:count] = velocity_step(
            position[:count], velocity[:count], cognitive[:count], social[:count],
            inertia, c1, c2, r1, r2,
        )
        position[:count] = np.clip(position[:count] + velocity[:count],
                                   budget.lower, budget.upper)
        current_f, _ = budget.evaluate(position[:count])
        improved = np.flatnonzero(current_f < pbest_f[:count])
        pbest[improved] = position[improved]
        pbest_f[improved] = current_f[improved]
        updates += 1
        diagnostics["strategy_generations"][state] += 1
        diagnostics["strategy_evaluations"][state] += count
        diagnostics["population_update_fes"] += count
        if count < n:
            diagnostics["partial_update_size"] = count
        # A GBPM success is also an improvement during this generation.
        stagnation = 0 if budget.best_F < best_before_round else stagnation + 1

    diagnostics["gbpm_fes"] = diagnostics["gbpm_attempts"]
    diagnostics["stagnation_final"] = stagnation
    diagnostics["final_state"] = state
    diagnostics["singer_final"] = singer_value
    return budget.result(updates, diagnostics)
