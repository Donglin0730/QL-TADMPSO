# UAV-BS experiment report v5

**FORMAL: complete formal replication**

Stage: ablation; completed 280/280 runs.

Main version: AHDPSO-derived learning-factor schedule, linear inertia weight, matrix update with per-particle shared random coefficients.

F, SASU, GASU: smaller is better; TC, SAC: larger is better. F keeps the original weights 0.5/0.3/0.2; SAC is a supplementary coverage metric.

Low signal variance at low coverage does not mean good service; coverage and uniformity must be read together. Run time is a single run, includes the method's own extra operations, excluding warm-up.

Fixed UAV-BS count: 45; rationale: m=45 is chosen as the working point that balances coverage, area uniformity, base-station count and compute time for the given scenario and budget; it is not claimed to be the unique or global optimum. Based on the formal results of 20 runs per count over ten counts, 200 runs in total: at m=45 the mean F=0.137955, TC=98.894%, SAC=99.873%, SASU=2.7130 dB, GASU=4.1354 dB, runtime 79.81 s. Going from 40 to 45 UAVs raises TC by 1.172 percentage points, lowers SASU/GASU by 0.6043/0.8951 dB, and raises mean runtime by 4.79%. Going from 45 to 50 adds 11.11% more base stations while the TC/SAC gains drop to 0.598/0.087 percentage points, SASU drops another 0.1515 dB, and mean runtime rises another 6.20%. The advantage of 50 is kept on record: its mean F is lower and GASU is 0.6633 dB below the 45-UAV value. This is an engineering trade-off judged from the observed marginal gains; no new service hard threshold or objective weight is introduced, and the differences are not called insignificant. The mechanism, ablation and seven-algorithm comparisons all use 45 UAVs with the original model, parameters, budget and preselected seeds.

## 45 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| No FSW / alignment | 20 | 0.1724 ± 0.0176 | 97.0440 ± 1.1043 | 98.7800 ± 0.9810 | 3.9224 ± 0.8119 | 5.6145 ± 0.7362 | 43.2225 ± 51.6880 |
| No FSW / alignment (permuted) | 20 | 0.1730 ± 0.0136 | 96.9420 ± 1.0740 | 98.8667 ± 0.5582 | 3.8776 ± 0.4947 | 5.6789 ± 0.7715 | 33.8476 ± 25.4512 |
| No alignment | 20 | 0.1692 ± 0.0167 | 97.1820 ± 1.0658 | 98.8933 ± 0.8909 | 3.7805 ± 0.7485 | 5.4780 ± 0.7640 | 63.2645 ± 46.7129 |
| No alignment (permuted) | 20 | 0.1604 ± 0.0173 | 97.9200 ± 0.9497 | 99.1133 ± 0.6607 | 3.6090 ± 0.7038 | 4.9064 ± 0.8300 | 66.3356 ± 62.1889 |
| No FSW | 20 | 0.1431 ± 0.0145 | 98.7000 ± 0.7294 | 99.7733 ± 0.3031 | 2.9106 ± 0.4682 | 4.3396 ± 0.8066 | 56.5705 ± 76.7983 |
| No FSW (permuted) | 20 | 0.1432 ± 0.0167 | 98.7200 ± 0.7507 | 99.6600 ± 0.5072 | 2.9557 ± 0.6384 | 4.2870 ± 0.7713 | 58.3043 ± 85.2449 |
| QL-TADMPSO | 20 | 0.1412 ± 0.0134 | 98.7020 ± 0.7022 | 99.8467 ± 0.2605 | 2.7806 ± 0.4353 | 4.3767 ± 0.7396 | 60.1627 ± 20.3068 |
| QL-TADMPSO (permuted) | 20 | 0.1378 ± 0.0110 | 98.8780 ± 0.5884 | 99.9133 ± 0.1516 | 2.6889 ± 0.2906 | 4.1699 ± 0.7160 | 71.4283 ± 46.3584 |
| Random groups | 20 | 0.1442 ± 0.0175 | 98.5240 ± 0.9457 | 99.7533 ± 0.3128 | 2.8976 ± 0.5262 | 4.4622 ± 0.9500 | 50.7399 ± 57.1426 |
| No cross-swarm | 20 | 0.1893 ± 0.0152 | 95.9320 ± 1.2212 | 98.2200 ± 0.8380 | 4.5416 ± 0.6369 | 6.4151 ± 0.8234 | 84.0332 ± 70.8156 |
| Fixed k | 20 | 0.1402 ± 0.0168 | 98.8180 ± 0.8142 | 99.7933 ± 0.2949 | 2.8419 ± 0.5099 | 4.1589 ± 0.8976 | 90.8132 ± 93.3883 |
| Factor schedule | 20 | 0.1491 ± 0.0180 | 98.2540 ± 0.9553 | 99.5800 ± 0.7396 | 3.0572 ± 0.7538 | 4.6966 ± 0.8626 | 42.9571 ± 33.6055 |
| Random actions | 20 | 0.1395 ± 0.0105 | 98.8920 ± 0.5113 | 99.7667 ± 0.2993 | 2.8097 ± 0.3871 | 4.1157 ± 0.5815 | 80.1348 ± 97.6797 |
| APSO coefficients | 20 | 0.2237 ± 0.0191 | 93.2400 ± 1.7818 | 94.0933 ± 1.9782 | 6.4209 ± 0.9082 | 6.9219 ± 0.8177 | 60.7331 ± 27.4258 |

## Reading order for the ablation

1. Read the numbering-permutation mechanism check in ../../mechanism/report/report.md first.
2. Read ablation_factorial.pdf: the FSW x matching four groups with their original-numbering / permuted-numbering conditions.
3. Read permutation_effects.pdf: paired change "permuted minus original numbering" for the same run ids.
4. Then compare fixed k, factor schedule, random actions, random partition, cross-swarm interaction and the learning-factor control.
5. Weigh gains against run-time cost before moving to the external algorithm comparison.

The interaction contrast is computed per run as full - FSW-only - matching-only + neither. A best combined mean alone does not prove an interaction gain.

The numbering-permutation check alone cannot prove the full algorithm is strictly permutation-invariant; floating-point accumulation and multiple optimal matchings may affect later trajectories. No significant difference detected does not prove equivalence.

## Paired analysis

In paired_effects.csv the difference direction is reference - comparator; interaction and permutation terms are marked separately. TC/SAC differences are in percentage points.

Formal inferential comparisons: 96. All pre-declared contrasts times six metrics form one Holm-corrected family for this stage.

Formal results give 95% percentile bootstrap intervals of the paired median difference and two-sided Wilcoxon tests. Non-formal results give only descriptive paired differences; inference columns are left blank.

## Recomputable files

Raw coordinates, actual FE histories, parameters and source hashes are stored in ../results.json and ../source_snapshot. Figure sources and qualification status are stored in report_manifest.json.

Metrics of the final coordinates are re-checked on save and on load. These post-hoc checks and figure recomputations do not participate in the search and do not count toward the optimization budget or run time. Checkpoint files have whole-content validation to prevent edits or missing completed runs.

SAO-MPSO keeps its Cubic initialization; deployment adaptations and parameter sources of the other baselines are in experiments/docs. All methods share the physics model and evaluation backend.
