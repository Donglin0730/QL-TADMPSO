"""Version-4 UAV experiment reports; descriptive output unless formally qualified.

Usage: python report_v4.py result.json [--output-dir DIRECTORY]
Statistical comparisons share one predeclared Holm family over all configured
UAV counts, comparators, and five metrics. Figures use actual FE histories.
"""
import argparse
import csv
import json
from pathlib import Path
import shutil
import tempfile

import numpy as np
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

import model


SCHEMA_VERSION = "uav-bs-experiments-v4"
KINDS = {"main", "smoke", "integration", "ablation", "ablation_smoke"}
METRICS = ("F", "TC", "SAC", "SASU", "GASU")
REQUIRED_COUNTS = (5, 10, 15, 20, 25, 30)
METHOD_LABELS = {
    "pso": "PSO", "ahdpso": "AHDPSO", "tadmpso": "T-ADMPSO (adapted)",
    "amsepso": "AMSEPSO", "sdpso": "SDPSO (adapted)", "saompso": "SAO-MPSO",
    "ql_apso": "QL-TADMPSO + APSO feedback", "full": "Full (APSO feedback)",
    "legacy_coefficients": "Legacy coefficients", "no_fsw": "No FSW",
    "no_alignment": "No alignment", "random_topology": "Random topology",
    "no_cross_swarm": "No cross-swarm", "fixed_k": "Fixed k",
    "factor_schedule": "Factor schedule",
}
METRIC_LABELS = {"F": "Objective F", "TC": "TC (%)", "SAC": "SAC (%)",
                 "SASU": "SASU (dB)", "GASU": "GASU (dB)"}
BOOTSTRAP_SEED = 20260918
REPORT_FILES = (
    "summary.csv", "paired_tests.csv", "metrics_vs_uav_count.pdf", "convergence_by_fes.pdf",
    "uav_count_layouts_2d.pdf", "uav_count_layouts_3d.pdf",
    "uav_count_layouts_2d.png", "uav_count_layouts_3d.png",
    "deployment_coordinates.csv", "case_metrics.csv", "figure_manifest.json", "report.md",
)


def validate_results(data):
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("schema_version mismatch: version-4 results required")
    if data.get("model_version") != model.MODEL_VERSION:
        raise ValueError("model_version mismatch: current objective required")
    if data.get("result_kind") not in KINDS:
        raise ValueError("unknown result_kind")
    if not isinstance(data.get("config"), dict) or not isinstance(data.get("runs"), list):
        raise ValueError("config and runs must be present")
    config = data["config"]
    if not config.get("counts") or not config.get("algorithms"):
        raise ValueError("configured counts and algorithms must be nonempty")
    if len(set(config["counts"])) != len(config["counts"]):
        raise ValueError("duplicate configured UAV counts")
    if len(set(config["algorithms"])) != len(config["algorithms"]):
        raise ValueError("duplicate configured methods")
    # Incomplete/pilot experiments are legitimate; corrupt records are not.
    # This hard validation must precede qualification and every artifact write.
    from run_v4 import validate_record
    for index, record in enumerate(data["runs"]):
        try:
            validate_record(record, config)
        except (ValueError, KeyError, TypeError, IndexError) as exc:
            raise ValueError(f"invalid experiment record {index}: {exc}") from exc
    _grouped_runs(data)
    return data


def _grouped_runs(data):
    groups = {(int(count), method): {} for count in data["config"]["counts"]
              for method in data["config"]["algorithms"]}
    for row in data["runs"]:
        key = (int(row["scenario"]["n_uav"]), row["method"])
        if key not in groups:
            raise ValueError(f"run outside configured count/method matrix: {key}")
        index = int(row["i"])
        if index in groups[key]:
            raise ValueError(f"duplicate run id {index} for {key}")
        groups[key][index] = row
    return groups


def metric_value(run, metric):
    value = float(run["best_F"] if metric == "F" else run["final_metrics"][metric])
    if not np.isfinite(value):
        raise ValueError(f"nonfinite metric {metric}")
    return value * 100.0 if metric in {"TC", "SAC"} else value


def summary_rows(data):
    """Long-form descriptive table, including explicit empty matrix cells."""
    rows = []
    for (count, method), records in _grouped_runs(data).items():
        for metric in METRICS:
            values = np.array([metric_value(run, metric) for run in records.values()])
            rows.append({
                "n_uav": count, "method": method, "metric": metric,
                "unit": "%" if metric in {"TC", "SAC"} else ("dB" if metric != "F" else "1"),
                "n": len(values),
                "mean": float(values.mean()) if len(values) else None,
                "sd": float(values.std(ddof=1)) if len(values) > 1 else None,
            })
    return rows


def paired_effect(reference, comparator, seed=BOOTSTRAP_SEED, n_boot=5000):
    """Unstandardized paired difference and percentile bootstrap interval."""
    a, b = np.asarray(reference, dtype=float), np.asarray(comparator, dtype=float)
    if a.ndim != 1 or a.shape != b.shape or not len(a):
        raise ValueError("paired samples must be nonempty equal-length vectors")
    differences = a - b
    if not np.isfinite(differences).all():
        raise ValueError("paired samples must be finite")
    rng = np.random.default_rng(seed)
    draws = rng.integers(len(differences), size=(int(n_boot), len(differences)))
    bootstrap = np.median(differences[draws], axis=1)
    low, high = np.quantile(bootstrap, [.025, .975])
    median = float(np.median(differences))
    return {"median_difference": median, "abs_median_difference": abs(median),
            "ci_low": float(low), "ci_high": float(high)}


def _reference_method(data):
    return "full" if data["result_kind"].startswith("ablation") else "ql_apso"


def paired_test_rows(data, n_boot=5000):
    """Build the entire predeclared family; generate_report gates publication."""
    groups = _grouped_runs(data)
    reference = _reference_method(data)
    methods = data["config"]["algorithms"]
    if reference not in methods:
        raise ValueError(f"paired reference method {reference} is missing")
    rows = []
    expected_ids = set(range(int(data["config"]["n_runs"])))
    for count in data["config"]["counts"]:
        ref = groups[(count, reference)]
        for comparator in (method for method in methods if method != reference):
            other = groups[(count, comparator)]
            if set(ref) != expected_ids or set(other) != expected_ids:
                raise ValueError("paired comparison requires every configured run id")
            ids = sorted(expected_ids)
            for index in ids:
                for field in ("priority_seed", "seed"):
                    if ref[index].get(field) != other[index].get(field):
                        raise ValueError(f"paired {field} mismatch at run {index}")
                if ref[index]["scenario"] != other[index]["scenario"]:
                    raise ValueError(f"paired scenario mismatch at run {index}")
            for metric in METRICS:
                va = np.array([metric_value(ref[index], metric) for index in ids])
                vb = np.array([metric_value(other[index], metric) for index in ids])
                differences = va - vb
                p_raw = (1.0 if np.all(differences == 0.0) else float(stats.wilcoxon(
                    differences, alternative="two-sided", zero_method="wilcox",
                    correction=False, method="auto",
                ).pvalue))
                rows.append({
                    "n_uav": int(count), "reference": reference,
                    "comparator": comparator, "metric": metric, "n_pairs": len(ids),
                    "unit": "percentage points" if metric in {"TC", "SAC"}
                    else ("dB" if metric != "F" else "1"),
                    "p_raw": p_raw,
                    **paired_effect(va, vb, n_boot=n_boot),
                })
    family_size = len(rows)
    ordered = sorted(range(family_size), key=lambda index: rows[index]["p_raw"])
    running = 0.0
    for rank, index in enumerate(ordered):
        running = max(running, (family_size - rank) * rows[index]["p_raw"])
        rows[index]["p_holm"] = min(1.0, running)
        rows[index]["family_size"] = family_size
        rows[index]["reject_holm_0_05"] = rows[index]["p_holm"] < .05
    return rows


def select_common_run_id(data, method):
    """One run minimizes summed distance from the within-count median F rank."""
    groups = _grouped_runs(data)
    counts = list(data["config"]["counts"])
    relevant = [groups[(count, method)] for count in counts]
    common = sorted(set.intersection(*(set(group) for group in relevant)))
    if not common:
        raise ValueError("No common run id across all configured UAV counts")
    scores = np.zeros(len(common))
    for records in relevant:
        ranks = stats.rankdata([records[index]["best_F"] for index in common])
        scores += np.abs(ranks - (len(common) + 1) / 2.0)
    return int(common[int(np.argmin(scores))])


def convergence_series(data, grid=None):
    """Step-hold each actual FE history on a shared grid, without extrapolation.

    Each group is truncated to its earliest completed FE horizon so its mean
    always contains the same runs. The default uses at most 501 FE checkpoints.
    """
    from run_v4 import history_at_fes

    config = data["config"]
    if grid is None:
        start, stop = int(config["n_p"]), int(config["max_fes"])
        grid = np.unique(np.linspace(start, stop, min(501, stop - start + 1), dtype=int))
    grid = np.asarray(grid)
    if grid.ndim != 1 or not len(grid) or np.any(np.diff(grid) <= 0):
        raise ValueError("FE grid must be a nonempty increasing vector")
    results = []
    for (count, method), records in _grouped_runs(data).items():
        if not records:
            continue
        rows = [records[index] for index in sorted(records)]
        start = max(run["history_fes"][0] for run in rows)
        stop = min(run["history_fes"][-1] for run in rows)
        selected_grid = grid[(grid >= start) & (grid <= stop)]
        if not len(selected_grid):
            continue
        values = np.array([history_at_fes(run["history_fes"], run["gF_history"],
                                          selected_grid) for run in rows])
        if not np.isfinite(values).all():
            raise ValueError("nonfinite convergence values")
        results.append({"n_uav": count, "method": method, "n": len(rows),
                        "fes": selected_grid, "mean": values.mean(axis=0),
                        "sd": values.std(axis=0, ddof=1) if len(rows) > 1 else None})
    return results


def _paper_style():
    return {"font.family": "DejaVu Sans", "font.size": 8, "axes.labelsize": 8,
            "axes.titlesize": 9, "xtick.labelsize": 7, "ytick.labelsize": 7,
            "axes.linewidth": .65, "pdf.fonttype": 42, "ps.fonttype": 42,
            "savefig.facecolor": "white", "axes.unicode_minus": True}


def _method_style(method, index):
    colors = ("#737373", "#0072B2", "#E69F00", "#009E73", "#CC79A7",
              "#825C3B", "#56B4E9", "#55559E")
    proposed = method in {"ql_apso", "full"}
    return {"color": "#C82F38" if proposed else colors[index % len(colors)],
            "marker": ("o", "s", "^", "D", "v", "P", "X", "h")[index % 8],
            "linewidth": 1.7 if proposed else 1.05,
            "label": METHOD_LABELS.get(method, method)}


def _header(fig, title, formal):
    if formal:
        fig.suptitle(title, fontsize=10, fontweight="bold", y=.977)
    else:
        fig.text(.5, .987, "NONFORMAL / validation only", ha="center", va="top",
                 fontsize=10, fontweight="bold", color="#9B3425")
        fig.text(.5, .949, title, ha="center", va="top", fontsize=9)


def metrics_figure(data, formal=False):
    rows = {(row["n_uav"], row["method"], row["metric"]): row
            for row in summary_rows(data)}
    counts = sorted(data["config"]["counts"])
    methods = data["config"]["algorithms"]
    with plt.rc_context(_paper_style()):
        fig, axes = plt.subplots(2, 3, figsize=(8.2, 5.8))
        fig.subplots_adjust(left=.083, right=.979, bottom=.105, top=.862,
                            wspace=.35, hspace=.39)
        for index, metric in enumerate(METRICS):
            ax = axes.flat[index]
            for j, method in enumerate(methods):
                values = [rows[(count, method, metric)] for count in counts]
                mean = [np.nan if row["mean"] is None else row["mean"] for row in values]
                sd = [np.nan if row["sd"] is None else row["sd"] for row in values]
                style = _method_style(method, j)
                ax.errorbar(counts, mean, yerr=sd, markersize=3.4, capsize=2.0,
                            capthick=.6, elinewidth=.65, **style)
            direction = "higher" if metric in {"TC", "SAC"} else "lower"
            ax.set_title(f"({chr(97+index)}) {METRIC_LABELS[metric]} ({direction})", loc="left")
            ax.set_xlabel("UAV-BS count")
            ax.set_xticks(counts)
            ax.grid(axis="y", color="#E4E8ED", linewidth=.5)
            ax.set_axisbelow(True)
            ax.spines[["top", "right"]].set_visible(False)
        legend_axis = axes.flat[5]
        legend_axis.axis("off")
        handles = [Line2D([], [], markersize=3.5, **_method_style(method, index))
                   for index, method in enumerate(methods)]
        legend_axis.legend(handles=handles, loc="upper left", frameon=False,
                           fontsize=7.4, handlelength=2.1, borderaxespad=0.0)
        legend_axis.text(0, .06, "Error bars: sample SD\nN = 1: SD unavailable",
                         fontsize=7.2, va="bottom", color="#425263")
        _header(fig, "Five metrics across UAV-BS counts", formal)
        fig.text(.5, .022, "Fixed objective weights: 0.5 / 0.3 / 0.2. Lower F represents a tradeoff among its components.",
                 ha="center", fontsize=7.1, color="#425263")
    return fig


def convergence_figure(data, formal=False):
    counts = sorted(data["config"]["counts"])
    methods = data["config"]["algorithms"]
    series = {(row["n_uav"], row["method"]): row for row in convergence_series(data)}
    columns = min(3, len(counts))
    rows = (len(counts) + columns - 1) // columns
    with plt.rc_context(_paper_style()):
        height = 2.1*rows + 1.55
        fig, axes = plt.subplots(rows, columns, squeeze=False,
                                 figsize=(8.2 if columns > 1 else 6.4, height))
        fig.subplots_adjust(left=.083, right=.979, bottom=max(.22, 1.15 / height), top=.855,
                            wspace=.30, hspace=.42)
        for index, count in enumerate(counts):
            ax = axes.flat[index]
            plotted = False
            for j, method in enumerate(methods):
                item = series.get((count, method))
                if item is None:
                    continue
                style = _method_style(method, j)
                style.pop("marker")
                ax.step(item["fes"], item["mean"], where="post", **style)
                if item["sd"] is not None:
                    ax.fill_between(item["fes"], item["mean"]-item["sd"],
                                    item["mean"]+item["sd"], step="post",
                                    color=style["color"], alpha=.07, linewidth=0)
                plotted = True
            if not plotted:
                ax.text(.5, .5, "No completed runs", ha="center", va="center",
                        transform=ax.transAxes, color="#65717D")
            ax.set_title(f"({chr(97+index)}) {count} UAV-BSs", loc="left")
            ax.set_xlabel("Objective evaluations (FEs)")
            ax.set_ylabel("Best objective F")
            ax.ticklabel_format(axis="x", style="sci", scilimits=(0, 4))
            ax.grid(color="#E4E8ED", linewidth=.5)
            ax.spines[["top", "right"]].set_visible(False)
        for ax in axes.flat[len(counts):]:
            ax.axis("off")
        handles = [Line2D([], [], **dict(_method_style(method, index), marker=None))
                   for index, method in enumerate(methods)]
        fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5, .065),
                   ncol=min(4, len(methods)), frameon=False, fontsize=7.2,
                   columnspacing=1.4, handlelength=2.0)
        _header(fig, "Convergence by actual objective evaluations", formal)
        fig.text(.5, .018, "Step hold of the last observed best; mean over the same runs. Shading: sample SD (N >= 2).",
                 ha="center", fontsize=7.0, color="#425263")
    return fig


def prepare_deployment_panels(data, complete):
    """Validate the selected actual layouts; backend/metric errors propagate."""
    if not complete:
        return None, "skipped: incomplete experiment matrix", None
    if tuple(sorted(data["config"]["counts"])) != REQUIRED_COUNTS:
        return None, "skipped: all six required UAV counts are needed", None
    method = _reference_method(data)
    if method not in data["config"]["algorithms"]:
        return None, "skipped: proposed method is absent", None
    import deployment_atlas as atlas

    # All ablations have algo=ql_apso; filter by method before using the atlas.
    subset = dict(data, runs=[run for run in data["runs"] if run["method"] == method])
    run_id = select_common_run_id(subset, method)
    panels = atlas.prepare_panels(subset, counts=REQUIRED_COUNTS,
                                  algo="ql_apso", run_id=run_id)
    return panels, "generated: validated single common run", run_id


def _write_csv(path, rows):
    if not rows:
        raise ValueError("cannot infer CSV columns from no rows")
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _save_pdf(figure, path, title, formal):
    with plt.rc_context(_paper_style()):
        figure.savefig(path, metadata={
            "Title": title,
            "Subject": "Formal qualified experiment" if formal else "NONFORMAL / validation only",
            "Creator": "Matplotlib; actual-FE version-4 experiment report",
        })
    plt.close(figure)


def _summary_cell(row):
    if not row["n"]:
        return "unavailable"
    digits = 2 if row["metric"] in {"TC", "SAC"} else 4
    mean = f"{row['mean']:.{digits}f}"
    return (f"{mean} (SD unavailable)" if row["sd"] is None
            else f"{mean} +/- {row['sd']:.{digits}f}")


def _markdown_report(data, source, qualification, summary, tests, result):
    formal = result["formal"]
    lines = ["# UAV-BS experiment report (v4)", "",
             "**FORMAL: qualified repeated-run comparison**" if formal
             else "**NONFORMAL / descriptive validation only**", "",
             f"Source: `{source.resolve()}`", "",
             f"Recorded runs: {qualification['actual_runs']} / {qualification['expected_runs']}. "
             f"Experiment matrix complete: {qualification['complete']}.", ""]
    if qualification["reasons"]:
        lines += ["Qualification notes:", ""]
        lines += [f"- {reason}" for reason in dict.fromkeys(qualification["reasons"])]
        lines.append("")
    lines += ["## Interpretation and reporting rules", "",
              "The proposed-method label denotes QL-TADMPSO with APSO coefficient feedback.", "",
              "F is the fixed-weight tradeoff `0.5*f1 + 0.3*f2 + 0.2*f3`, with "
              "`f1=1-TC`, `f2=ln(1+SASU)/ln(100)`, and `f3=ln(1+GASU)/ln(1000)`. "
              "A lower F does not establish improvement in every metric. TC and SAC are "
              "larger-is-better; SASU and GASU are smaller-is-better. SAC is an additional "
              "coverage measure and is not an independent term in F.", "",
              "Tables show mean +/- sample standard deviation (`ddof=1`), with no SD "
              "reported when N=1. TC and SAC are percentages; their paired differences "
              "are percentage points. No missing run is imputed.", "",
              "Convergence uses actual objective evaluations (FEs), including extra "
              "algorithm-specific evaluations. Each history is held at its last observed "
              "value without lookahead, on at most 501 common FE checkpoints. A group's "
              "curve stops at its earliest recorded endpoint so its run set remains "
              "constant; it is not an iteration curve.", ""]
    if not formal:
        lines += ["Inferential comparisons are withheld. This report contains descriptive "
                  "results only and is not evidence for superiority claims.", ""]
    lookup = {(row["n_uav"], row["method"], row["metric"]): row for row in summary}
    for count in sorted(data["config"]["counts"]):
        lines += [f"## {count} UAV-BSs: descriptive results", "",
                  "| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) |",
                  "| --- | ---: | ---: | ---: | ---: | ---: | ---: |"]
        for method in data["config"]["algorithms"]:
            values = [lookup[(count, method, metric)] for metric in METRICS]
            cells = [_summary_cell(row) for row in values]
            lines.append(f"| {METHOD_LABELS.get(method, method)} | {values[0]['n']} | "
                         + " | ".join(cells) + " |")
        lines.append("")
    if formal:
        family_size = len(tests)
        lines += ["## Predeclared paired comparison family", "",
                  f"All {family_size} two-sided paired Wilcoxon signed-rank comparisons "
                  "(all configured counts x comparators x five metrics) form one Holm "
                  "family. The reference is the proposed full algorithm. Pairs match "
                  "run id, optimization seed, priority-map seed, and physical scenario. "
                  "The all-zero-difference case is assigned p=1.", "",
                  "Effects are raw-scale paired medians, reference minus comparator; "
                  "the CSV also records their absolute magnitude. Bootstrap 95% "
                  f"percentile intervals use 5,000 paired resamples and fixed seed {BOOTSTRAP_SEED}. "
                  "These intervals are marginal, not simultaneous; Holm correction "
                  "applies to the p-values. Sign and metric direction must be read "
                  "together; no automatic all-metric improvement claim is made.", "",
                  "| UAVs | Comparator | Metric | Pairs | Median difference | 95% bootstrap CI | Holm p |",
                  "| ---: | --- | --- | ---: | ---: | --- | ---: |"]
        for row in tests:
            lines.append(f"| {row['n_uav']} | {METHOD_LABELS.get(row['comparator'], row['comparator'])} "
                         f"| {row['metric']} | {row['n_pairs']} | {row['median_difference']:.6g} "
                         f"| [{row['ci_low']:.6g}, {row['ci_high']:.6g}] | {row['p_holm']:.6g} |")
        lines.append("")
    lines += ["## Deployment illustrations and files", "",
              f"Atlas status: {result['atlas_status']}.", ""]
    if result["selected_run_id"] is not None:
        lines += [f"One common run id ({result['selected_run_id']}) is used for every count. "
                  "It minimizes the sum, across counts, of the absolute distance from "
                  "the median F rank, with smallest run id breaking ties. The layouts "
                  "are single-run illustrations, not repeated-run means. Their metrics "
                  "were recomputed from the stored coordinates using the recorded "
                  "evaluation backend before rendering.", ""]
    for key, label in [("summary_csv", "Descriptive summary"), ("metrics_pdf", "Five metrics"),
                       ("convergence_pdf", "FE convergence"), ("paired_tests_csv", "Paired comparisons"),
                       ("atlas_2d_pdf", "2D deployment atlas"), ("atlas_3d_pdf", "3D deployment atlas")]:
        if result.get(key):
            lines.append(f"- [{label}]({Path(result[key]).name})")
    return "\n".join(lines) + "\n"


def _publish_report(stage, output):
    """Publish only finished artifacts; restore prior files if replacement fails."""
    from run_v4 import directory_lock
    with directory_lock(output):
        _publish_locked_report(stage, output)


def _publish_locked_report(stage, output):
    """The caller holds the output lock until replacement or recovery completes."""
    stage, output = Path(stage), Path(output)
    output.mkdir(parents=True, exist_ok=True)
    backup = Path(tempfile.mkdtemp(prefix=".report-backup-", dir=output.parent))
    changed, cleanup_backup = [], False
    try:
        for name in REPORT_FILES:
            previous = output/name
            if previous.exists():
                shutil.copy2(previous, backup/name)
        for name in REPORT_FILES:
            incoming, target = stage/name, output/name
            if incoming.exists():
                incoming.replace(target)
                changed.append(name)
            elif target.exists():
                target.unlink()
                changed.append(name)
        cleanup_backup = True
    except BaseException as exc:
        recovery_errors = []
        for name in reversed(changed):
            try:
                if (backup/name).exists():
                    (backup/name).replace(output/name)
                else:
                    (output/name).unlink(missing_ok=True)
            except OSError as recovery_error:
                recovery_errors.append(str(recovery_error))
        if recovery_errors:
            raise RuntimeError(f"Report replacement failed; recovery copies retained in {backup}") from exc
        cleanup_backup = True
        raise
    finally:
        if cleanup_backup:
            shutil.rmtree(backup)


def generate_report(result_path, output_dir=None):
    """Write qualified formal or clearly labelled descriptive report artifacts."""
    from run_v4 import qualify

    source = Path(result_path)
    data = validate_results(json.loads(source.read_text(encoding="utf-8")))
    qualification = qualify(data)
    formal = bool(qualification["qualified"] and qualification["complete"]
                  and int(data["config"]["n_runs"]) >= 20
                  and data["result_kind"] in {"main", "ablation"})
    # Validate layouts before creating any artifact. Inconsistencies must fail.
    panels, atlas_status, selected_id = prepare_deployment_panels(data, qualification["complete"])
    summary = summary_rows(data)
    tests = paired_test_rows(data) if formal else []
    output = Path(output_dir) if output_dir is not None else source.parent / "report"
    result = {
        "formal": formal, "complete": qualification["complete"],
        "qualification": qualification, "atlas_status": atlas_status,
        "selected_run_id": selected_id,
        "report_md": str((output / "report.md").resolve()),
        "summary_csv": str((output / "summary.csv").resolve()),
        "metrics_pdf": str((output / "metrics_vs_uav_count.pdf").resolve()),
        "convergence_pdf": str((output / "convergence_by_fes.pdf").resolve()),
        "paired_tests_csv": None, "atlas_2d_pdf": None, "atlas_3d_pdf": None,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    # A plotting/export failure must not mix new tables with an old report.
    with tempfile.TemporaryDirectory(prefix=".report-stage-", dir=output.parent) as directory:
        stage = Path(directory)
        _write_csv(stage/"summary.csv", [
            dict(row, evidence_status="FORMAL" if formal else "NONFORMAL") for row in summary
        ])
        if formal:
            _write_csv(stage/"paired_tests.csv", tests)
            result["paired_tests_csv"] = str((output/"paired_tests.csv").resolve())
        _save_pdf(metrics_figure(data, formal), stage/"metrics_vs_uav_count.pdf", "Five UAV-BS metrics", formal)
        _save_pdf(convergence_figure(data, formal), stage/"convergence_by_fes.pdf", "Actual-FE convergence", formal)
        if panels is not None:
            import deployment_atlas as atlas

            atlas.render_atlas(panels, stage, watermark=None if formal else "NONFORMAL / validation only")
            atlas.export_metadata(panels, stage, source)
            result["atlas_2d_pdf"] = str((output / "uav_count_layouts_2d.pdf").resolve())
            result["atlas_3d_pdf"] = str((output / "uav_count_layouts_3d.pdf").resolve())
        (stage/"report.md").write_text(
            _markdown_report(data, source, qualification, summary, tests, result), encoding="utf-8",
        )
        _publish_report(stage, output)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("result_path", type=Path)
    parser.add_argument("--output-dir", type=Path)
    arguments = parser.parse_args(argv)
    result = generate_report(arguments.result_path, arguments.output_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
