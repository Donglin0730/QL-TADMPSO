"""Paper figures and evidence tables for staged v5 experiments."""
import argparse
import csv
import json
from pathlib import Path
import shutil
import tempfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
from scipy import stats

import deployment_atlas as atlas
from count_selection import count_summary
import protocol_v5 as protocol
from report_v4 import paired_effect

METRIC_LABELS = dict(F='Objective F', TC='TC (%)', SAC='SAC (%)',
                     SASU='SASU (dB)', GASU='GASU (dB)', runtime_seconds='Run time (s)')
PALETTE = ['#0072B2', '#E69F00', '#009E73', '#CC79A7', '#56B4E9', '#7A6C5D',
           '#D55E00', '#596778', '#6C5BA7', '#8C8C3B']
REPORT_FILES = (
    'report.md', 'summary.csv', 'count_selection_table.csv', 'paired_effects.csv',
    'report_manifest.json', 'metrics_vs_uav_count.pdf', 'convergence_by_fes.pdf',
    'metrics_by_method.pdf', 'ablation_factorial.pdf', 'permutation_effects.pdf',
    'uav_count_layouts_2d.pdf', 'uav_count_layouts_3d.pdf',
    'uav_count_layouts_2d.png', 'uav_count_layouts_3d.png',
    'deployment_coordinates.csv', 'case_metrics.csv', 'figure_manifest.json',
    'mechanism_diagnostics.pdf', 'mechanism_summary.csv', 'mechanism_trials.csv',
)


def holm_adjust(p_values):
    p = np.asarray(p_values, dtype=float)
    if p.ndim != 1 or not np.isfinite(p).all() or np.any((p < 0) | (p > 1)):
        raise ValueError('p values must be finite probabilities')
    order = np.argsort(p, kind='stable')
    corrected = np.empty_like(p)
    corrected[order] = np.minimum(1., np.maximum.accumulate((len(p) - np.arange(len(p))) * p[order]))
    return corrected.tolist()


def comparison_pairs(stage):
    if stage == 'count':
        return []
    if stage == 'comparison':
        return [('full', method, 'external') for method in protocol.METHODS if method != 'full']
    pairs = [('full', method, 'mechanism') for method in protocol.VARIANTS if method != 'full']
    pairs.extend([('no_alignment', 'no_fsw_no_alignment', 'factorial'),
                  ('no_fsw', 'no_fsw_no_alignment', 'factorial')])
    pairs.extend([(variant + '_permuted', variant, 'permutation') for variant in protocol.FACTORIAL])
    return pairs


def _groups(data):
    grouped = {(m, method): {} for m in data['config']['counts'] for method in data['config']['algorithms']}
    for record in data['runs']:
        count, method, index = protocol.record_key(record)
        grouped[(count, method)][index] = record
    return grouped


def summary_rows(data):
    rows = []
    for (count, method), indexed in _groups(data).items():
        for metric in protocol.METRICS:
            values = np.array([protocol.metric_value(r, metric) for r in indexed.values()])
            rows.append(dict(n_uav=count, method=method, metric=metric,
                             unit='%' if metric in ('TC', 'SAC') else 's' if metric == 'runtime_seconds' else '1' if metric == 'F' else 'dB',
                             n=len(values), mean=float(values.mean()) if len(values) else None,
                             sd=float(values.std(ddof=1)) if len(values) > 1 else None,
                             median=float(np.median(values)) if len(values) else None))
    return rows


def _paired_vectors(indexed, methods, ids, metric):
    arrays = []
    reference = indexed[methods[0]]
    for method in methods:
        records = indexed[method]
        for i in ids:
            if any(records[i][key] != reference[i][key] for key in ('seed', 'priority_seed', 'scenario')):
                raise ValueError('comparison must use paired scenarios and initialization seeds')
        arrays.append(np.array([protocol.metric_value(records[i], metric) for i in ids]))
    return arrays


def contrast_summary(differences, inferential=False, n_boot=5000):
    differences = np.asarray(differences, dtype=float)
    if differences.ndim != 1 or not len(differences) or not np.isfinite(differences).all():
        raise ValueError('paired differences must be a nonempty finite vector')
    result = dict(mean_difference=float(differences.mean()), median_difference=float(np.median(differences)),
                  sd_difference=float(differences.std(ddof=1)) if len(differences) > 1 else None,
                  ci_low=None, ci_high=None, p_raw=None)
    if inferential:
        if len(differences) < 2:
            raise ValueError('inference requires repeated independent pairs')
        effect = paired_effect(differences, np.zeros_like(differences), seed=20260919, n_boot=n_boot)
        result.update(ci_low=effect['ci_low'], ci_high=effect['ci_high'])
        result['p_raw'] = (1. if np.all(differences == 0) else float(stats.wilcoxon(
            differences, zero_method='wilcox', alternative='two-sided', method='auto').pvalue))
    return result


def paired_rows(data, inferential=False, n_boot=5000):
    if inferential and not protocol.qualify(data)['qualified']:
        raise ValueError('inferential comparisons require a complete formal protocol')
    grouped, rows = _groups(data), []
    ids = list(range(data['config']['n_runs']))
    stage = data['config']['stage']
    for count in data['config']['counts']:
        indexed = {method: records for (m, method), records in grouped.items() if m == count}
        specs = [(a, b, kind, [a, b]) for a, b, kind in comparison_pairs(stage)]
        if stage == 'ablation':
            specs.append(('full - FSW-only - matching-only + neither', 'zero', 'interaction',
                          ['full', 'no_alignment', 'no_fsw', 'no_fsw_no_alignment']))
        for a, b, kind, methods in specs:
            if any(method not in indexed or set(indexed[method]) != set(ids) for method in methods):
                if inferential:
                    raise ValueError('missing members of a formal paired comparison')
                continue
            for metric in protocol.METRICS:
                vectors = _paired_vectors(indexed, methods, ids, metric)
                differences = vectors[0] - vectors[1] if kind != 'interaction' else vectors[0] - vectors[1] - vectors[2] + vectors[3]
                row = dict(n_uav=count, reference=a, comparator=b, contrast_kind=kind,
                           metric=metric, n_pairs=len(ids),
                           unit='percentage points' if metric in ('TC', 'SAC') else 's' if metric == 'runtime_seconds' else '1' if metric == 'F' else 'dB',
                           **contrast_summary(differences, inferential, n_boot), p_holm=None, family_size=0,
                           reject_holm_0_05=None)
                rows.append(row)
    if inferential:
        for row, corrected in zip(rows, holm_adjust([r['p_raw'] for r in rows])):
            row.update(p_holm=corrected, family_size=len(rows), reject_holm_0_05=corrected < .05)
    return rows


def _csv(path, rows):
    if not rows:
        return
    with Path(path).open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _finish(fig, directory, name, title, formal, footer):
    fig.suptitle(title, x=.075, y=.966, ha='left', fontsize=12, fontweight='bold', color='#213547')
    if not formal:
        fig.text(.975, .988, 'NONFORMAL / SOFTWARE VALIDATION', ha='right', va='top',
                 fontsize=7.3, color='#A14732')
    fig.text(.5, .017, footer, ha='center', va='bottom', fontsize=7, color='#495A67')
    fig.savefig(Path(directory) / (name + '.pdf'), metadata={
        'Title': title, 'Subject': 'Formal repeated-run evidence' if formal else 'NONFORMAL / software validation only',
        'Creator': 'UAV-BS v5 experiment reporting; Matplotlib'})
    plt.close(fig)


def _axes_style(ax):
    ax.grid(axis='y', color='#DDE4EA', linewidth=.55)
    ax.set_axisbelow(True)
    ax.spines[['top', 'right']].set_visible(False)


def _metrics_figure(data, directory, formal):
    count_stage = data['config']['stage'] == 'count'
    summary = {(r['n_uav'], r['method'], r['metric']): r for r in summary_rows(data)}
    methods = [m for m in data['config']['algorithms'] if not m.endswith('_permuted')]
    counts = sorted(data['config']['counts'])
    with plt.rc_context(atlas.paper_style()):
        fig, axes = plt.subplots(2, 3, figsize=(9.2, 6.5))
        fig.subplots_adjust(left=.08, right=.975, top=.87, bottom=.15 if count_stage else .25,
                            hspace=.44, wspace=.32)
        for ax, metric in zip(axes.flat, protocol.METRICS):
            _axes_style(ax)
            ax.set_title(METRIC_LABELS[metric], loc='left')
            if count_stage:
                values = [summary[(m, 'full', metric)] for m in counts]
                means = [np.nan if r['mean'] is None else r['mean'] for r in values]
                errors = [0. if r['sd'] is None else r['sd'] for r in values]
                ax.errorbar(counts, means, yerr=errors, color='#007D86', marker='o',
                            ms=4, lw=1.5, capsize=2.5)
                ax.set_xticks(counts)
                ax.set_xlabel('Number of UAV-BSs')
            else:
                for j, method in enumerate(methods):
                    row = summary[(counts[0], method, metric)]
                    if row['mean'] is not None:
                        ax.errorbar(j+1, row['mean'], yerr=0 if row['sd'] is None else row['sd'],
                                    color=PALETTE[j % len(PALETTE)], marker='o', ms=5, capsize=3, lw=1.2)
                ax.set_xticks(range(1, len(methods)+1))
                ax.set_xlabel('Method index')
        if not count_stage:
            handles = [Line2D([], [], marker='o', ls='', color=PALETTE[j % len(PALETTE)],
                              label=f'{j+1}: {protocol.LABELS[m]}') for j, m in enumerate(methods)]
            fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.5, .065),
                       ncol=3, frameon=False, fontsize=7.4, columnspacing=1.5)
        _finish(fig, directory, 'metrics_vs_uav_count' if count_stage else 'metrics_by_method',
                'Deployment scale: service quality and computation' if count_stage else f"{counts[0]} UAV-BSs: {data['config']['stage']}",
                formal, 'Points: means. Error bars: sample SD when N >= 2. All completed runs are retained.')


def _convergence_figure(data, directory, formal):
    counts = sorted(data['config']['counts'])
    methods = [m for m in data['config']['algorithms'] if not m.endswith('_permuted')]
    grouped = _groups(data)
    columns = min(3, len(counts))
    rows = (len(counts) + columns - 1) // columns
    grid = np.unique(np.linspace(data['config']['n_p'], data['config']['max_fes'],
                                 min(501, data['config']['max_fes'] // data['config']['n_p']), dtype=int))
    if len(grid) == 1:
        grid = np.array([data['config']['n_p']])
    with plt.rc_context(atlas.paper_style()):
        fig, axes = plt.subplots(rows, columns, squeeze=False,
                                 figsize=(8.7 if columns > 1 else 7.4, 4.8 if rows == 1 else 2.25*rows + 1.55))
        fig.subplots_adjust(left=.085, right=.97, top=.83 if rows == 1 else .88,
                            bottom=.34 if rows == 1 else .16,
                            hspace=.48, wspace=.33)
        for ax, count in zip(axes.flat, counts):
            for j, method in enumerate(methods):
                runs = list(grouped[(count, method)].values())
                if not runs:
                    continue
                traces = np.array([protocol.history_at_fes(r['history_fes'], r['gF_history'], grid) for r in runs])
                color = PALETTE[j % len(PALETTE)]
                ax.step(grid, traces.mean(axis=0), where='post', color=color, lw=1.4,
                        label=protocol.LABELS[method])
                if len(traces) > 1:
                    sd = traces.std(axis=0, ddof=1)
                    ax.fill_between(grid, traces.mean(axis=0)-sd, traces.mean(axis=0)+sd,
                                    step='post', color=color, alpha=.08, linewidth=0)
            ax.set(title=f'{count} UAV-BSs', xlabel='Objective evaluations (FEs)', ylabel='Best objective F')
            _axes_style(ax)
            ax.ticklabel_format(axis='x', style='sci', scilimits=(0, 4))
        for ax in axes.flat[len(counts):]:
            ax.axis('off')
        handles = [Line2D([], [], color=PALETTE[j % len(PALETTE)], label=protocol.LABELS[m]) for j,m in enumerate(methods)]
        fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.5, .06),
                   ncol=min(3, len(methods)), frameon=False, fontsize=7.3)
        _finish(fig, directory, 'convergence_by_fes', 'Convergence under a common evaluation budget', formal,
                'Actual FEs include initialization and extra trials. Step-hold interpolation; shading is sample SD.')


def _factorial_figures(data, directory, formal, effects):
    grouped = _groups(data)
    count = data['config']['counts'][0]
    with plt.rc_context(atlas.paper_style()):
        fig, axes = plt.subplots(2, 3, figsize=(9.0, 6.3))
        fig.subplots_adjust(left=.085, right=.975, top=.87, bottom=.19, hspace=.43, wspace=.35)
        for ax, metric in zip(axes.flat, protocol.METRICS):
            for permuted, color, marker, label in [(False, '#0072B2', 'o', 'Original numbering'),
                                                   (True, '#D55E00', 's', 'Independent relabeling')]:
                means, errors = [], []
                for variant in protocol.FACTORIAL:
                    records = grouped.get((count, variant + ('_permuted' if permuted else '')), {})
                    values = [protocol.metric_value(r, metric) for r in records.values()]
                    means.append(np.mean(values) if values else np.nan)
                    errors.append(np.std(values, ddof=1) if len(values) > 1 else 0.)
                ax.errorbar(range(4), means, yerr=errors, color=color, marker=marker, capsize=2.5,
                            ms=4, lw=1.2, label=label)
            ax.set_xticks(range(4), ['Neither', 'FSW only', 'Match only', 'Both'])
            ax.tick_params(axis='x', labelsize=7)
            ax.set_title(METRIC_LABELS[metric], loc='left')
            _axes_style(ax)
        handles, labels = axes.flat[0].get_legend_handles_labels()
        fig.legend(handles, labels, loc='lower center', bbox_to_anchor=(.5, .07), ncol=2, frameon=False, fontsize=8)
        _finish(fig, directory, 'ablation_factorial', 'Representation and guide matching: a 2 x 2 ablation', formal,
                'All other mechanisms and budgets are fixed. Original and relabeled runs share physical initialization.')
        fig, axes = plt.subplots(2, 3, figsize=(9.0, 6.0))
        fig.subplots_adjust(left=.09, right=.975, top=.86, bottom=.12, hspace=.45, wspace=.38)
        lookup = {(r['reference'], r['metric']):r for r in effects if r['contrast_kind'] == 'permutation'}
        for ax, metric in zip(axes.flat, protocol.METRICS):
            ax.axhline(0, color='#8796A1', lw=.9, ls='--')
            for j, variant in enumerate(protocol.FACTORIAL):
                row = lookup.get((variant + '_permuted', metric))
                if row is not None:
                    ax.errorbar(j, row['mean_difference'], yerr=row['sd_difference'] or 0,
                                color=PALETTE[j], marker='o', ms=5, capsize=3)
            ax.set_xticks(range(4), ['Neither', 'FSW only', 'Match only', 'Both'])
            ax.tick_params(axis='x', labelsize=7)
            label = f'{metric} (pp)' if metric in ('TC', 'SAC') else METRIC_LABELS[metric]
            ax.set_title('Paired change: ' + label, loc='left', fontsize=8)
            _axes_style(ax)
        _finish(fig, directory, 'permutation_effects', 'Effect of relabeling: permuted minus original', formal,
                'TC/SAC differences are percentage points. Error bars are sample SD of paired differences, not confidence intervals.')


def _publish(stage, output):
    """Replace only owned report files, with rollback and preserved user files."""
    stage, output = Path(stage), Path(output)
    with protocol.directory_lock(output):
        backup = Path(tempfile.mkdtemp(prefix='.v5-report-backup-', dir=output.parent)).resolve()
        if backup.parent != output.parent.resolve():
            raise RuntimeError('report backup escaped its intended directory')
        changed, cleanup = [], False
        try:
            for name in REPORT_FILES:
                old = output / name
                if old.exists():
                    shutil.copy2(old, backup / name)
            for name in REPORT_FILES:
                incoming, target = stage / name, output / name
                if incoming.exists():
                    incoming.replace(target)
                    changed.append(name)
                elif target.exists():
                    target.unlink()
                    changed.append(name)
            cleanup = True
        except BaseException as exc:
            errors = []
            for name in reversed(changed):
                try:
                    if (backup / name).exists():
                        (backup / name).replace(output / name)
                    else:
                        (output / name).unlink(missing_ok=True)
                except OSError as error:
                    errors.append(str(error))
            if errors:
                raise RuntimeError(f'Report rollback incomplete; backup retained at {backup}') from exc
            cleanup = True
            raise
        finally:
            if cleanup:
                shutil.rmtree(backup)


def _number(value, digits=4):
    return '-' if value is None else f'{value:.{digits}f}'


def _markdown(data, qualification, summary, effects, manifest):
    stage = data['config']['stage']
    lines = ['# UAV-BS experiment report v5', '',
             '**FORMAL: complete formal replication**' if manifest['formal'] else '**NONFORMAL: descriptive result / software validation, not used for superiority claims**', '',
             f"Stage: {stage}; completed {qualification['actual_runs']}/{qualification['expected_runs']} runs.", '',
             'Main version: AHDPSO-derived learning-factor schedule, linear inertia weight, matrix update with per-particle shared random coefficients.', '',
             'F, SASU, GASU: smaller is better; TC, SAC: larger is better. F keeps the original weights 0.5/0.3/0.2; SAC is a supplementary coverage metric.', '',
             'Low signal variance at low coverage does not mean good service; coverage and uniformity must be read together. Run time is a single run, includes the method\'s own extra operations, excluding warm-up.', '']
    lines += ['- ' + reason for reason in qualification['reasons']]
    if stage == 'count':
        lines += ['', '## Count selection basis', '', 'This report provides the data needed for count selection; the selection record and rationale live in selection.json at the experiment root. If that file is missing, no UAV-BS count has been selected yet. The smallest F, the largest count or 25 UAVs must not be called optimal automatically.', '',
                  'Use the table below plus the coverage gain, uniformity improvement, F improvement and time increase per extra 5 UAVs in count_selection_table.csv to record the chosen trade-off and its rationale.', '',
                  'This selection only applies to the given scenario and evaluation budget. If the gains show no clear plateau, that fact must be reported.', '']
        if manifest['layout_counts']:
            lines += [f"Layout figures cover {manifest['layout_counts']} and all use run id {manifest['representative_run_id']}. This id minimizes the total distance to the median rank within each count; the figures do not stitch the best run of each count.", '']
    else:
        choice = data['config']['selection']
        lines += [f"Fixed UAV-BS count: {choice['selected_count']}; rationale: {choice['reason']}", '']
    lookup = {(r['n_uav'], r['method'], r['metric']):r for r in summary}
    for count in sorted(data['config']['counts']):
        lines += [f'## {count} UAVs: mean ± sample SD', '',
                  '| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |',
                  '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
        for method in data['config']['algorithms']:
            cells = []
            for metric in protocol.METRICS:
                row = lookup[(count, method, metric)]
                cells.append(_number(row['mean']) + (' ± ' + _number(row['sd']) if row['sd'] is not None else ' (SD unavailable)'))
            lines.append('| ' + ' | '.join([protocol.LABELS[method], str(lookup[(count,method,'F')]['n']), *cells]) + ' |')
        lines.append('')
    if stage == 'ablation':
        lines += ['## Reading order for the ablation', '',
                  '1. Read the numbering-permutation mechanism check in ../../mechanism/report/report.md first.',
                  '2. Read ablation_factorial.pdf: the FSW x matching four groups with their original-numbering / permuted-numbering conditions.',
                  '3. Read permutation_effects.pdf: paired change "permuted minus original numbering" for the same run ids.',
                  '4. Then compare fixed k, factor schedule, random actions, random partition, cross-swarm interaction and the learning-factor control.',
                  '5. Weigh gains against run-time cost before moving to the external algorithm comparison.', '',
                  'The interaction contrast is computed per run as full - FSW-only - matching-only + neither. A best combined mean alone does not prove an interaction gain.', '',
                  'The numbering-permutation check alone cannot prove the full algorithm is strictly permutation-invariant; floating-point accumulation and multiple optimal matchings may affect later trajectories. No significant difference detected does not prove equivalence.', '']
    if effects:
        lines += ['## Paired analysis', '',
                  'In paired_effects.csv the difference direction is reference - comparator; interaction and permutation terms are marked separately. TC/SAC differences are in percentage points.', '',
                  f"Formal inferential comparisons: {manifest['inferential_comparisons']}. All pre-declared contrasts times six metrics form one Holm-corrected family for this stage.", '',
                  'Formal results give 95% percentile bootstrap intervals of the paired median difference and two-sided Wilcoxon tests. Non-formal results give only descriptive paired differences; inference columns are left blank.', '']
    lines += ['## Recomputable files', '',
              'Raw coordinates, actual FE histories, parameters and source hashes are stored in ../results.json and ../source_snapshot. Figure sources and qualification status are stored in report_manifest.json.', '',
              'Metrics of the final coordinates are re-checked on save and on load. These post-hoc checks and figure recomputations do not participate in the search and do not count toward the optimization budget or run time. Checkpoint files have whole-content validation to prevent edits or missing completed runs.', '',
              'SAO-MPSO keeps its Cubic initialization; deployment adaptations and parameter sources of the other baselines are in experiments/docs. All methods share the physics model and evaluation backend.', '']
    return '\n'.join(lines)


def generate_report(result_path, output_dir=None):
    result_path = Path(result_path).resolve()
    source_hash = protocol.file_digest(result_path)
    data = protocol.load_data(result_path)
    if protocol.file_digest(result_path) != source_hash:
        raise RuntimeError('source changed while loading the report')
    qualification = protocol.qualify(data)
    formal = qualification['qualified']
    output = Path(output_dir).resolve() if output_dir else result_path.parent / 'report'
    output.parent.mkdir(parents=True, exist_ok=True)
    summary = summary_rows(data)
    effects = paired_rows(data, inferential=formal)
    manifest = dict(source=str(result_path), source_sha256=source_hash, formal=formal,
                    qualification=qualification, inferential_comparisons=sum(r['p_raw'] is not None for r in effects),
                    layout_counts=[], representative_run_id=None)
    with tempfile.TemporaryDirectory(prefix='.v5-report-stage-', dir=output.parent) as temporary:
        stage = Path(temporary)
        _csv(stage / 'summary.csv', summary)
        _csv(stage / 'paired_effects.csv', effects)
        _metrics_figure(data, stage, formal)
        _convergence_figure(data, stage, formal)
        if data['config']['stage'] == 'count':
            _csv(stage / 'count_selection_table.csv', count_summary(data))
            if qualification['complete'] and sorted(data['config']['counts']) == protocol.COUNTS:
                panels = atlas.prepare_panels(data, counts=protocol.COUNTS, algo='ql')
                atlas.render_atlas(panels, stage, watermark=None if formal else 'NONFORMAL / SOFTWARE VALIDATION')
                atlas.export_metadata(panels, stage, result_path)
                manifest.update(layout_counts=list(protocol.COUNTS), representative_run_id=panels[0]['record']['i'])
        elif data['config']['stage'] == 'ablation':
            _factorial_figures(data, stage, formal, effects)
        (stage / 'report.md').write_text(_markdown(data, qualification, summary, effects, manifest), encoding='utf-8')
        manifest['files'] = sorted(p.name for p in stage.iterdir())
        protocol.save_json(stage / 'report_manifest.json', manifest)
        if protocol.file_digest(result_path) != source_hash:
            raise RuntimeError('experiment changed during rendering; report was not published')
        _publish(stage, output)
    return manifest


def generate_probe_report(result_path):
    from count_selection import load_selection
    from permutation_probe import load_probe
    result_path = Path(result_path).resolve()
    source_hash = protocol.file_digest(result_path)
    raw = json.loads(result_path.read_text(encoding='utf-8'))
    choice = load_selection(raw['selection_path'], allow_smoke=not raw['formal'])
    data = load_probe(result_path, choice)
    output = result_path.parent / 'report'
    summaries, trials = [], []
    for row in data['runs']:
        base = dict(i=row['i'], source_kind=row['source_kind'], n_uav=row['scenario']['n_uav'],
                    n_permutations=row['n_permutations'], passed=row['passed'])
        summary = dict(base)
        for key in ('coordinate_distance', 'fsw_distance', 'matched_residual',
                    'inter_deployment_fsw_change', 'matching_cost_change', 'aligned_displacement_change'):
            summary[key + '_max'] = row[key + '_max']
        for key, value in row['metric_error_max'].items():
            summary['error_' + key] = value
        for component in ('coordinate', 'fsw', 'alignment'):
            summary[component + '_median_us'] = float(np.median([t[component + '_seconds'] for t in row['trials']]) * 1e6)
        summaries.append(summary)
        for trial in row['trials']:
            flat = dict(base, **{key:value for key,value in trial.items() if key != 'metric_errors'})
            flat.update({'error_' + key: value for key,value in trial['metric_errors'].items()})
            trials.append(flat)
    with tempfile.TemporaryDirectory(prefix='.v5-probe-report-', dir=output.parent) as temporary:
        stage = Path(temporary)
        _csv(stage / 'mechanism_summary.csv', summaries)
        _csv(stage / 'mechanism_trials.csv', trials)
        with plt.rc_context(atlas.paper_style()):
            fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.9))
            fig.subplots_adjust(left=.09, right=.97, top=.78, bottom=.24, wspace=.35)
            for index, kind in enumerate(('initial', 'final')):
                subset = [r for r in summaries if r['source_kind'] == kind]
                x = np.arange(3) + (index - .5) * .32
                discrepancies = [max(r[key + '_max'] for r in subset) for key in
                                 ('coordinate_distance', 'fsw_distance', 'matched_residual')]
                bars = axes[0].bar(x, discrepancies, width=.3, color=PALETTE[index], label=kind.capitalize())
                for bar, value in zip(bars, discrepancies):
                    axes[0].annotate(f'{value:.2g}', (bar.get_x() + bar.get_width()/2, value),
                                     xytext=(0, 4), textcoords='offset points', ha='center', fontsize=7)
                timings = [np.median([r[key + '_median_us'] for r in subset]) for key in ('coordinate', 'fsw', 'alignment')]
                axes[1].bar(x, timings, width=.3, color=PALETTE[index])
            axes[0].set(ylabel='Maximum normalized discrepancy', title='Same physical deployment after relabeling')
            axes[1].set(ylabel='Median time (us / call)', title='Standalone component cost')
            for ax in axes:
                ax.set_xticks(range(3), ['Coordinates', 'FSW', 'Matching'])
                ax.margins(y=.22)
                _axes_style(ax)
            axes[0].legend(frameon=False, fontsize=7)
            _finish(fig, stage, 'mechanism_diagnostics', 'Numbering sensitivity: representation and guidance', data['formal'],
                    'Permutations are nested within deployments. Component timings are not fractions of full optimizer runtime.')
        unique_runs = len(data['config']['run_ids'])
        lines = ['# Numbering-permutation mechanism check', '', '**FORMAL: mechanism diagnostics of the formal count stage**' if data['formal'] else '**NONFORMAL: software validation**', '',
                 f"Selected count m={choice['selected_count']}. From {unique_runs} run ids; for each id the initial and final deployments are checked, each deployment permuted {data['config']['n_permutations']} times.", '',
                 'These permutations are repeated measurements inside one deployment and do not count as extra independent optimization runs. Final optimization performance is tested by the four combined ablations that follow.', '',
                 'Checks the coordinate distance, FSW distance and matching residual of the same layout, plus FSW distance and minimum matching cost changes after independently relabeling two different layouts.', '',
                 'Multiple optimal matchings may give different indices or guide displacements; displacement changes are therefore saved, but permutation consistency is checked via the optimal matching cost, without forcing identical indices.', '',
                 'Physical metric errors are checked against preset numerical tolerances; full per-trial data are in mechanism_trials.csv; raw coordinates and seeds are in ../results.json.', '',
                 'Component timings are statistics of independent calls on fixed inputs; they are neither the time share of the full optimizer nor evidence about final search quality.', '']
        (stage / 'report.md').write_text('\n'.join(lines), encoding='utf-8')
        manifest = dict(source=str(result_path), source_sha256=source_hash, formal=data['formal'],
                        independent_run_ids=unique_runs, nested_cases=len(summaries),
                        files=sorted(p.name for p in stage.iterdir()))
        protocol.save_json(stage / 'report_manifest.json', manifest)
        if protocol.file_digest(result_path) != source_hash:
            raise RuntimeError('mechanism data changed during rendering')
        _publish(stage, output)
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results', type=Path)
    args = parser.parse_args(argv)
    payload = json.loads(args.results.read_text(encoding='utf-8'))
    if payload.get('schema_version') == 'uav-bs-permutation-mechanism-v5':
        generate_probe_report(args.results)
    else:
        generate_report(args.results)


if __name__ == '__main__':
    main()
