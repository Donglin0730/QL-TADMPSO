"""Relabeling diagnostics on fixed physical deployments, before performance ablation."""
import json
from pathlib import Path
import time

import numpy as np

import algorithms
from count_selection import load_selection, validate_selection
import protocol_v5 as protocol
from scenario import DeploymentScenario, ScenarioConfig
from topology import align_guide, fsw_features

SCHEMA = 'uav-bs-permutation-mechanism-v5'
METRIC_TOLERANCES = dict(F=1e-6, TC=1e-12, SAC=1e-12, SASU=1e-4, GASU=1e-4)


def probe_deployment(positions, scene, priority, seed, n_permutations, L,
                     guide_positions=None):
    """One independent deployment, with nested permutations and a fixed second guide.

    The coordinate norm uses the same domain normalization as clustering. The
    matched norm measures residual positional displacement after assignment.
    Pairwise matching costs, rather than assignment indices, handle ties.
    """
    n_permutations = protocol.integer(n_permutations, 'permutation count', 1)
    positions = np.asarray(positions, dtype=float)
    if positions.shape != (scene.config.n_uav, 3) or not np.isfinite(positions).all():
        raise ValueError('invalid probe deployment shape or coordinates')
    lower, upper = scene.bounds()
    if np.any(positions.ravel() < lower) or np.any(positions.ravel() > upper):
        raise ValueError('probe coordinates are outside the physical domain')
    guide = positions if guide_positions is None else np.asarray(guide_positions, dtype=float)
    if guide.shape != positions.shape or not np.isfinite(guide).all():
        raise ValueError('guide must contain the same number of finite XYZ points')
    span = (upper - lower).reshape(-1, 3)
    directions = algorithms.FSW_DIRECTIONS
    original_metrics = scene.evaluate(positions.ravel(), priority, 'a2g')
    base_features = fsw_features(np.stack([positions, guide]), directions, L, scenario=scene)
    base_distance = float(np.linalg.norm(base_features[0] - base_features[1]))
    base_aligned = align_guide(positions, guide, scenario=scene)
    base_cost = float(np.sum(((base_aligned - positions) / span) ** 2))
    rng = np.random.default_rng(seed)
    trials = []
    for trial in range(n_permutations):
        order = rng.permutation(len(positions))
        shuffled = positions[order]
        started = time.perf_counter()
        raw_distance = float(np.linalg.norm((positions - shuffled) / span))
        raw_seconds = time.perf_counter() - started
        started = time.perf_counter()
        features = fsw_features(np.stack([positions, shuffled]), directions, L, scenario=scene)
        set_distance = float(np.linalg.norm(features[0] - features[1]))
        fsw_seconds = time.perf_counter() - started
        started = time.perf_counter()
        matched = align_guide(positions, shuffled, scenario=scene)
        residual = float(np.linalg.norm((matched - positions) / span))
        alignment_seconds = time.perf_counter() - started
        metrics = scene.evaluate(shuffled.ravel(), priority, 'a2g')
        errors = {key: abs(metrics[key] - original_metrics[key]) for key in METRIC_TOLERANCES}
        shuffled_guide = guide[rng.permutation(len(guide))]
        pair_features = fsw_features(np.stack([shuffled, shuffled_guide]), directions, L, scenario=scene)
        pair_distance = float(np.linalg.norm(pair_features[0] - pair_features[1]))
        pair_aligned = align_guide(shuffled, shuffled_guide, scenario=scene)
        pair_cost = float(np.sum(((pair_aligned - shuffled) / span) ** 2))
        restored = np.empty_like(pair_aligned)
        restored[order] = pair_aligned
        trials.append(dict(trial=trial, coordinate_distance=raw_distance, fsw_distance=set_distance,
                           matched_residual=residual, metric_errors=errors,
                           inter_deployment_fsw_change=abs(pair_distance - base_distance),
                           matching_cost_change=abs(pair_cost - base_cost),
                           aligned_displacement_change=float(np.linalg.norm((restored - base_aligned) / span)),
                           coordinate_seconds=raw_seconds, fsw_seconds=fsw_seconds,
                           alignment_seconds=alignment_seconds))
    result = dict(n_permutations=n_permutations, independent_deployments=1,
                  seed=int(seed), L=int(L), positions=positions.tolist(), guide_positions=guide.tolist(),
                  original_metrics=original_metrics, trials=trials,
                  diagnostic_evaluations=1 + n_permutations)
    for field in ('coordinate_distance', 'fsw_distance', 'matched_residual',
                  'inter_deployment_fsw_change', 'matching_cost_change', 'aligned_displacement_change'):
        result[field + '_max'] = max(t[field] for t in trials)
    result['metric_error_max'] = {key: max(t['metric_errors'][key] for t in trials) for key in METRIC_TOLERANCES}
    result['passed'] = (result['fsw_distance_max'] <= 1e-12 and result['matched_residual_max'] <= 1e-12
                        and result['inter_deployment_fsw_change_max'] <= 1e-12
                        and result['matching_cost_change_max'] <= 1e-10
                        and all(result['metric_error_max'][key] <= tol for key, tol in METRIC_TOLERANCES.items()))
    # A nonzero restored displacement can be legitimate for multiple optimal
    # assignments. It is recorded, never silently rounded away or called a failure.
    return protocol.jsonable(result)


def _content_digest(data):
    return protocol.digest({key: value for key, value in data.items() if key != 'content_sha256'})


def _write_probe(path, data):
    data['content_sha256'] = _content_digest(data)
    protocol.save_json(path, data)


def _probe_config(source, choice):
    """Permission to read pilot data must not choose the diagnostic protocol."""
    formal = choice['formal']
    ids = sorted(r['i'] for r in source['runs']
                 if r['scenario']['n_uav'] == choice['selected_count'])
    return dict(run_ids=ids, n_permutations=20 if formal else 3,
                L=source['config']['L'], seed_base=1400000 if formal else 2400000,
                metric_tolerances=METRIC_TOLERANCES, representation_tolerance=1e-12,
                matching_cost_tolerance=1e-10,
                initial_case_rule='particle i modulo Np from the original initialization',
                repetitions='permutations are nested within one deployment; initial/final share a run id',
                timings='standalone component calls; not full-optimizer time fractions')


def load_probe(path, choice, require_complete=True):
    path = Path(path)
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('schema_version') != SCHEMA or data.get('content_sha256') != _content_digest(data):
        raise ValueError('invalid or modified mechanism evidence')
    if (data['selection_sha256'] != choice['selection_sha256']
            or data['count_result_sha256'] != choice['count_result_sha256']
            or data['source_sha256'] != protocol.source_hashes()):
        raise ValueError('mechanism evidence differs from the selected campaign')
    source = validate_selection(choice, allow_smoke=not choice['formal'])
    config = _probe_config(source, choice)
    if data.get('formal') is not choice['formal'] or data['config'] != config:
        raise ValueError('mechanism protocol/qualification differs from its count evidence')
    keys = [(r['i'], r['source_kind']) for r in data['runs']]
    expected = {(i, kind) for i in config['run_ids'] for kind in ('initial', 'final')}
    if len(keys) != len(set(keys)) or not set(keys) <= expected:
        raise ValueError('duplicated or unexpected mechanism case')
    for row in data['runs']:
        expected_seed = config['seed_base'] + row['i'] * 2 + int(row['source_kind'] == 'final')
        if (row['seed'] != expected_seed or row['L'] != config['L']
                or row['n_permutations'] != config['n_permutations']):
            raise ValueError('mechanism row differs from the bound diagnostic protocol')
        if len(row['trials']) != config['n_permutations'] or not row['passed']:
            raise ValueError('mechanism tolerance check failed or trial list is incomplete')
    if require_complete and set(keys) != expected:
        raise ValueError('mechanism evidence is incomplete')
    return data


def run_probe(selection_path, output_dir, allow_smoke=False, make_report=True):
    choice = load_selection(selection_path, allow_smoke)
    source = validate_selection(choice, allow_smoke)
    selected = sorted((r for r in source['runs'] if r['scenario']['n_uav'] == choice['selected_count']),
                      key=lambda r:r['i'])
    config = _probe_config(source, choice)
    output_dir = Path(output_dir)
    with protocol.directory_lock(output_dir):
        path = output_dir / 'results.json'
        if path.exists():
            data = load_probe(path, choice, require_complete=False)
            if data['config'] != config:
                raise ValueError('mechanism protocol changed; use a new campaign directory')
        else:
            data = dict(schema_version=SCHEMA, selection_path=str(Path(selection_path).resolve()),
                        selection_sha256=choice['selection_sha256'],
                        count_result_sha256=choice['count_result_sha256'], source_sha256=protocol.source_hashes(),
                        created_utc=protocol.utc_now(), formal=choice['formal'], config=config, runs=[])
            _write_probe(path, data)
        done = {(r['i'], r['source_kind']) for r in data['runs']}
        for record in selected:
            scene = DeploymentScenario(ScenarioConfig.from_dict(record['scenario']))
            priority = scene.priority_mask(record['priority_seed'])
            initial, _ = algorithms.init_swarm(np.random.default_rng(record['seed']),
                                              source['config']['n_p'], scenario=scene)
            first = initial[record['i'] % len(initial)].reshape(-1, 3)
            final = np.asarray(record['best_pos']).reshape(-1, 3)
            for kind, positions, guide in (('initial', first, final), ('final', final, first)):
                if (record['i'], kind) in done:
                    continue
                seed = config['seed_base'] + record['i'] * 2 + int(kind == 'final')
                row = probe_deployment(positions, scene, priority, seed,
                                       config['n_permutations'], config['L'], guide_positions=guide)
                row.update(i=record['i'], source_kind=kind, scenario=record['scenario'],
                           priority_seed=record['priority_seed'])
                data['runs'].append(row)
                _write_probe(path, data)
                if not row['passed']:
                    raise RuntimeError('Mechanism check failed; diagnostic evidence was saved for review.')
                print(f"Mechanism: run={record['i']+1} {kind}; FSW={row['fsw_distance_max']:.2e}; "
                      f"matched={row['matched_residual_max']:.2e}", flush=True)
        load_probe(path, choice)
    if make_report:
        from report_v5 import generate_probe_report
        generate_probe_report(path)
    return data
