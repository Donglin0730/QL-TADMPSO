"""Permutation-invariant representation, topological grouping and guide alignment for UAV deployment sets."""
import numpy as np
from scipy.optimize import linear_sum_assignment

from scenario import DEFAULT_SCENARIO

XYZ_MIN = np.array(
    [0.0, 0.0, DEFAULT_SCENARIO.config.h_min_m], dtype=np.float64
)
XYZ_SPAN = np.array(
    [DEFAULT_SCENARIO.config.area_m, DEFAULT_SCENARIO.config.area_m,
     DEFAULT_SCENARIO.config.h_max_m - DEFAULT_SCENARIO.config.h_min_m],
    dtype=np.float64,
)


def _normalization(scenario):
    config = scenario.config
    minimum = np.array([0.0, 0.0, config.h_min_m], dtype=np.float64)
    span = np.array(
        [config.area_m, config.area_m, config.h_max_m - config.h_min_m],
        dtype=np.float64,
    )
    return minimum, span


def direction_pool(max_l=100, seed=20260829):
    """Generate a fixed, uniform pool of 3D unit projection directions usable as nested prefixes."""
    max_l = int(max_l)
    if max_l <= 0:
        raise ValueError("max_l must be positive")
    rng = np.random.default_rng(seed)
    directions = rng.normal(size=(max_l, 3))
    return directions / np.linalg.norm(directions, axis=1, keepdims=True)


def fsw_features(X, directions, L, scenario=DEFAULT_SCENARIO):
    """Compute finite-slice Wasserstein (FSW) deployment features.

    Each direction projects the normalized 3D coordinates of the configured
    n_uav UAVs, then sorts along the UAV axis. Sorting removes UAV numbering,
    so any permutation of the same deployment gives identical features.
    """
    directions = np.asarray(directions, dtype=np.float64)
    L = int(L)
    if directions.ndim != 2 or directions.shape[1] != 3:
        raise ValueError("directions must have shape (n_directions, 3)")
    if not 1 <= L <= len(directions):
        raise ValueError("L must be between 1 and the direction-pool size")
    n_uav = scenario.config.n_uav
    pts = np.asarray(X, dtype=np.float64).reshape(-1, n_uav, 3)
    minimum, span = _normalization(scenario)
    normalized = (pts - minimum) / span
    projections = np.einsum("nmc,lc->nlm", normalized, directions[:L])
    projections.sort(axis=2)
    return (projections / np.sqrt(L * n_uav)).reshape(len(pts), -1)


def _repair_minimum_size(assign, features, centers, min_size):
    """Move surplus-cluster particles to shortfall clusters at minimum incremental cost."""
    assign = assign.copy()
    k = len(centers)
    counts = np.bincount(assign, minlength=k)
    for target in range(k):
        while counts[target] < min_size:
            candidates = np.flatnonzero(counts[assign] > min_size)
            if len(candidates) == 0:
                raise RuntimeError("minimum-size repair has no feasible donor")
            donor = assign[candidates]
            to_target = ((features[candidates] - centers[target]) ** 2).sum(axis=1)
            from_donor = ((features[candidates] - centers[donor]) ** 2).sum(axis=1)
            delta = to_target - from_donor
            moved = int(candidates[int(np.argmin(delta))])
            old = int(assign[moved])
            assign[moved] = target
            counts[old] -= 1
            counts[target] += 1
    return assign


def cluster_features(features, k, rng, min_size=3, max_iter=100):
    """K-means on an arbitrary feature matrix with minimum-size repair."""
    features = np.asarray(features, dtype=np.float64)
    if features.ndim != 2:
        raise ValueError("features must be a two-dimensional matrix")
    n = len(features)
    k = int(k)
    min_size = int(min_size)
    if k < 1 or min_size < 1:
        raise ValueError("k and min_size must be positive")
    if n < k * min_size:
        raise ValueError("clustering requires n >= k * min_size")

    centers = features[rng.choice(n, k, replace=False)].copy()
    previous = None
    assign = np.zeros(n, dtype=np.int64)
    for _ in range(int(max_iter)):
        distances = ((features[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
        assign = distances.argmin(axis=1).astype(np.int64)
        assign = _repair_minimum_size(assign, features, centers, min_size)

        new_centers = np.empty_like(centers)
        for group in range(k):
            new_centers[group] = features[assign == group].mean(axis=0)
        centers = new_centers
        if previous is not None and np.array_equal(assign, previous):
            break
        previous = assign.copy()

    return [np.flatnonzero(assign == group) for group in range(k)]


def cluster_deployments(X, k, rng, directions, L, min_size=3, max_iter=100,
                        scenario=DEFAULT_SCENARIO):
    """K-means in FSW feature space with at least min_size particles per sub-swarm."""
    features = fsw_features(X, directions, L, scenario=scenario)
    return cluster_features(features, k, rng, min_size=min_size,
                            max_iter=max_iter)


def align_guide(reference, guide, scenario=DEFAULT_SCENARIO):
    """Reorder deployment guides to the current particles' UAV order via one-to-one minimum-total-cost matching."""
    reference = np.asarray(reference, dtype=np.float64).reshape(-1, 3)
    guide = np.asarray(guide, dtype=np.float64).reshape(-1, 3)
    if len(reference) != len(guide):
        raise ValueError("reference and guide must contain the same number of UAVs")
    minimum, span = _normalization(scenario)
    ref_norm = (reference - minimum) / span
    guide_norm = (guide - minimum) / span
    cost = ((ref_norm[:, None, :] - guide_norm[None, :, :]) ** 2).sum(axis=2)
    rows, cols = linear_sum_assignment(cost)
    aligned = np.empty_like(guide)
    aligned[rows] = guide[cols]
    return aligned
