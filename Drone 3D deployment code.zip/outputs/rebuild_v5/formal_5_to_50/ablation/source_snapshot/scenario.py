"""Versioned deployment scenarios and propagation model for UAV-BS experiments."""
from dataclasses import asdict, dataclass
import math
import os

import numpy as np


PT_DBM = 20.0
NOISE_DBM = -95.0
RX_THRESHOLD_DBM = -80.0
SNR_THRESHOLD_DB = 15.0
POWER_FLOOR_MW = 1e-10
MU1, MU2 = 1.0, 20.0
C_LOS, D_LOS = 0.60, 0.11
W1, W2, W3 = 0.5, 0.3, 0.2
COV_ANGLE_DEG = 25.0

TETROMINO_SHAPES = (
    ((0, 0), (1, 0), (2, 0), (3, 0)),
    ((0, 0), (1, 0), (0, 1), (1, 1)),
    ((0, 0), (1, 0), (2, 0), (1, 1)),
    ((0, 0), (1, 0), (2, 0), (2, 1)),
    ((0, 0), (1, 0), (2, 0), (0, 1)),
    ((1, 0), (2, 0), (0, 1), (1, 1)),
    ((0, 0), (1, 0), (1, 1), (2, 1)),
)

os.environ.setdefault(
    "CUPY_CACHE_DIR",
    os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".cupy_cache")),
)
try:
    import cupy as cp
    _HAS_CUDA = bool(cp.cuda.runtime.getDeviceCount() > 0)
except Exception:
    cp = None
    _HAS_CUDA = False
_USE_GPU = _HAS_CUDA
_GPU_SIGNAL_KERNEL = None


def gpu_name(use_gpu=None):
    enabled = _USE_GPU if use_gpu is None else bool(use_gpu)
    if enabled and _HAS_CUDA:
        try:
            props = cp.cuda.runtime.getDeviceProperties(0)
            return props["name"].decode()
        except Exception:
            return "CUDA"
    return "CPU (float32 vectorized)"


def _gpu_signal_kernel():
    global _GPU_SIGNAL_KERNEL
    if _GPU_SIGNAL_KERNEL is None:
        source = r'''
        extern "C" __global__
        void uav_signal_field(
            const float* uavs, const float* gx, const float* gy,
            float* signal_dbm, unsigned char* covered,
            const int n_points, const int n_uavs, const int mode,
            const float log_scale, const float fspl_const,
            const float pt, const float mu1, const float mu2,
            const float c_los, const float d_los,
            const float inv_tan15, const float inv_tan25,
            const float rx_threshold, const float power_floor)
        {
            const int i = blockDim.x * blockIdx.x + threadIdx.x;
            if (i >= n_points) return;
            float total_mw = power_floor;
            unsigned char is_covered = 0;
            const float x = gx[i];
            const float y = gy[i];
            for (int a = 0; a < n_uavs; ++a) {
                const float ux = uavs[3 * a];
                const float uy = uavs[3 * a + 1];
                const float h  = uavs[3 * a + 2];
                const float dx = x - ux;
                const float dy = y - uy;
                const float d2 = sqrtf(dx * dx + dy * dy);
                const float d3 = fmaxf(sqrtf(d2 * d2 + h * h), 1.0f);
                float path_loss = log_scale * logf(d3) + fspl_const;
                if (mode == 0) {
                    path_loss += mu2;
                    if (d2 < inv_tan15 * h) {
                        const float theta = atan2f(h, d2) * 57.29577951308232f;
                        const float p_los = c_los * powf(theta - 15.0f, d_los);
                        path_loss -= p_los * (mu2 - mu1);
                    }
                }
                const float received = pt - path_loss;
                if (d2 <= inv_tan25 * h && received >= rx_threshold) {
                    is_covered = 1;
                    total_mw += powf(10.0f, received / 10.0f);
                }
            }
            signal_dbm[i] = 10.0f * log10f(total_mw);
            covered[i] = is_covered;
        }
        '''
        _GPU_SIGNAL_KERNEL = cp.RawKernel(source, "uav_signal_field")
    return _GPU_SIGNAL_KERNEL


def dbm_to_mw(dbm):
    return np.power(10.0, np.asarray(dbm, dtype=np.float64) / 10.0)


def mw_to_dbm(power_mw):
    return 10.0 * np.log10(np.asarray(power_mw, dtype=np.float64))


def aggregate_signal_dbm(received_dbm, valid):
    received_dbm = np.asarray(received_dbm, dtype=np.float64)
    valid = np.asarray(valid, dtype=bool)
    if received_dbm.shape != valid.shape:
        raise ValueError("received_dbm and valid must share the same shape")
    total_mw = POWER_FLOOR_MW + np.where(
        valid, dbm_to_mw(received_dbm), 0.0
    ).sum(axis=0)
    return mw_to_dbm(total_mw)


def freespace_loss(d_m, f_mhz=2000.0):
    d = np.asarray(d_m, dtype=np.float64)
    loss = 20.0 * np.log10(d) + 20.0 * math.log10(f_mhz) - 27.55
    return float(loss) if loss.ndim == 0 else loss


def plos_prob(theta_deg):
    theta = np.asarray(theta_deg, dtype=np.float64)
    if theta.ndim == 0:
        return float(C_LOS * (theta - 15.0) ** D_LOS) if theta > 15.0 else 0.0
    result = np.zeros_like(theta)
    valid = theta > 15.0
    result[valid] = C_LOS * (theta[valid] - 15.0) ** D_LOS
    return result


def coverage_radius(height):
    radius = np.asarray(height, dtype=np.float64) / math.tan(
        math.radians(COV_ANGLE_DEG)
    )
    return float(radius) if radius.ndim == 0 else radius


def link_validity(horizontal_distance, height, received_dbm):
    return (
        np.asarray(horizontal_distance) <= coverage_radius(height)
    ) & (np.asarray(received_dbm) >= RX_THRESHOLD_DBM)


def _d2(points, uavs):
    points = np.asarray(points, dtype=np.float64)
    uavs = np.asarray(uavs, dtype=np.float64)
    dx = points[None, :, 0] - uavs[:, None, 0]
    dy = points[None, :, 1] - uavs[:, None, 1]
    return np.sqrt(dx * dx + dy * dy)


def metrics_from_summary(tc, sac, sasu, gasu):
    tc, sac = float(tc), float(sac)
    sasu, gasu = float(sasu), float(gasu)
    f1 = 1.0 - tc
    f2 = math.log1p(sasu) / math.log(100.0)
    f3 = math.log1p(gasu) / math.log(1000.0)
    objective = W1 * f1 + W2 * f2 + W3 * f3
    return {
        "F": objective,
        "f1": f1,
        "f2": f2,
        "f3": f3,
        "TC": tc,
        "SAC": sac,
        "SASU": sasu,
        "GASU": gasu,
    }


def metrics_from_field(signal_dbm, covered, priority):
    signal_dbm = np.asarray(signal_dbm, dtype=np.float64)
    covered = np.asarray(covered, dtype=bool)
    priority = np.asarray(priority, dtype=bool)
    if not (signal_dbm.shape == covered.shape == priority.shape):
        raise ValueError("signal_dbm, covered and priority must share the same shape")
    general = ~priority
    tc = float(covered.mean())
    sac = float(covered[priority].mean()) if priority.any() else 0.0
    sasu = float(signal_dbm[priority].std(ddof=0)) if priority.any() else 0.0
    gasu = float(signal_dbm[general].std(ddof=0)) if general.any() else 0.0
    return metrics_from_summary(tc, sac, sasu, gasu)


@dataclass(frozen=True)
class ScenarioConfig:
    area_m: float = 5000.0
    n_grid: int = 50
    n_uav: int = 25
    h_min_m: float = 100.0
    h_max_m: float = 500.0
    priority_fraction: float = 0.30
    frequency_mhz: float = 2000.0
    propagation_mode: str = "a2g"

    def __post_init__(self):
        if self.area_m <= 0 or self.n_grid <= 0 or self.n_uav <= 0:
            raise ValueError("area_m, n_grid and n_uav must be positive")
        if self.frequency_mhz <= 0:
            raise ValueError("frequency_mhz must be positive")
        if self.h_min_m >= self.h_max_m:
            raise ValueError("h_min_m must be smaller than h_max_m")
        if not 0.0 <= self.priority_fraction <= 1.0:
            raise ValueError("priority_fraction must be between zero and one")
        target = self.priority_fraction * self.n_grid * self.n_grid
        if not math.isclose(target, round(target), rel_tol=0.0, abs_tol=1e-9):
            raise ValueError("scenario requires an integer priority-cell count")
        if self.propagation_mode not in ("a2g", "los"):
            raise ValueError("propagation_mode must be 'a2g' or 'los'")

    @property
    def cell_size_m(self):
        return self.area_m / self.n_grid

    def to_dict(self):
        return asdict(self) | {"cell_size_m": self.cell_size_m}

    @classmethod
    def from_dict(cls, data):
        values = dict(data)
        values.pop("cell_size_m", None)
        return cls(**values)


class DeploymentScenario:
    def __init__(self, config):
        if not isinstance(config, ScenarioConfig):
            raise TypeError("config must be a ScenarioConfig")
        self.config = config
        self.grid_axis = (
            np.arange(config.n_grid, dtype=np.float64) + 0.5
        ) * config.cell_size_m
        self.grid_xy = np.stack(
            np.meshgrid(self.grid_axis, self.grid_axis, indexing="ij"), axis=-1
        ).reshape(-1, 2)
        self._grid_x32 = self.grid_xy[:, 0].astype(np.float32)
        self._grid_y32 = self.grid_xy[:, 1].astype(np.float32)
        self._log_scale = np.float32(20.0 / math.log(10.0))
        self._fspl_const = np.float32(
            20.0 * math.log10(config.frequency_mhz) - 27.55
        )
        self._inv_tan15 = np.float32(1.0 / math.tan(math.radians(15.0)))
        self._inv_tan25 = np.float32(
            1.0 / math.tan(math.radians(COV_ANGLE_DEG))
        )
        self._gpu_grid_cache = None
        self._gpu_priority_owner = None
        self._gpu_priority_cache = None
        self._gpu_general_cache = None
        self._gpu_priority_count = 0

    def bounds(self):
        lower = np.tile(
            [0.0, 0.0, self.config.h_min_m], self.config.n_uav
        )
        upper = np.tile(
            [self.config.area_m, self.config.area_m, self.config.h_max_m],
            self.config.n_uav,
        )
        return lower, upper

    def _priority_cells(self, seed=0, max_attempts=100_000):
        rng = np.random.default_rng(seed)
        target = int(round(
            self.config.priority_fraction
            * self.config.n_grid
            * self.config.n_grid
        ))
        occupied = set()
        attempts = 0
        while len(occupied) < target:
            if attempts >= max_attempts:
                raise RuntimeError("priority-area placement did not reach target")
            attempts += 1
            shape = TETROMINO_SHAPES[int(rng.integers(len(TETROMINO_SHAPES)))]
            max_i = max(di for di, _ in shape)
            max_j = max(dj for _, dj in shape)
            i = int(rng.integers(0, self.config.n_grid - max_i))
            j = int(rng.integers(0, self.config.n_grid - max_j))
            cells = [(i + di, j + dj) for di, dj in shape]
            if any(cell in occupied for cell in cells):
                continue
            remaining = target - len(occupied)
            occupied.update(cells[:remaining])
        return np.asarray(sorted(occupied), dtype=np.int64).reshape(-1, 2)

    def priority_mask(self, seed=0, max_attempts=100_000):
        cells = self._priority_cells(seed, max_attempts)
        mask = np.zeros(self.grid_xy.shape[0], dtype=bool)
        if len(cells):
            mask[cells[:, 0] * self.config.n_grid + cells[:, 1]] = True
        return mask

    def prepare_for_evaluation(self, priority):
        """Prepare scenario-specific arrays before the fixed timing starts."""
        host = self._validate_priority(priority)
        if _USE_GPU:
            self._gpu_grid()
            self._gpu_area_masks(priority)
            cp.cuda.Stream.null.synchronize()
        return host

    def _reshape_deployment(self, position):
        values = np.asarray(position, dtype=np.float32)
        expected = self.config.n_uav * 3
        if values.size != expected:
            raise ValueError(
                f"position must contain {expected} values for "
                f"{self.config.n_uav} UAVs"
            )
        return values.reshape(self.config.n_uav, 3)

    def _validate_priority(self, priority):
        mask = np.asarray(priority, dtype=bool)
        expected = self.grid_xy.shape[0]
        if mask.shape != (expected,):
            raise ValueError(f"priority mask must have shape ({expected},)")
        return mask

    def _fields(self, points, uavs, mode):
        uavs = np.asarray(uavs, dtype=np.float64).reshape(-1, 3)
        points = np.asarray(points, dtype=np.float64).reshape(-1, 2)
        height = uavs[:, None, 2]
        horizontal = _d2(points, uavs)
        distance = np.maximum(
            np.sqrt(horizontal * horizontal + height * height), 1.0
        )
        theta = np.degrees(np.arctan2(height, horizontal))
        if mode == "a2g":
            probability = plos_prob(theta)
            path_loss = (
                freespace_loss(distance, self.config.frequency_mhz)
                + MU2
                - probability * (MU2 - MU1)
            )
            received_dbm = PT_DBM - path_loss
        elif mode == "los":
            received_dbm = PT_DBM - freespace_loss(
                distance, self.config.frequency_mhz
            )
        else:
            raise ValueError(f"unknown mode: {mode} ('a2g' or 'los')")
        return horizontal, distance, theta, received_dbm

    def point_coverage(self, points, uavs):
        uavs = np.asarray(uavs, dtype=np.float64).reshape(-1, 3)
        height = uavs[:, None, 2]
        return (_d2(points, uavs) <= coverage_radius(height)).any(axis=0)

    def point_signal_and_coverage(self, points, uavs, mode=None):
        mode = self.config.propagation_mode if mode is None else mode
        uavs = np.asarray(uavs, dtype=np.float64).reshape(-1, 3)
        points = np.asarray(points, dtype=np.float64).reshape(-1, 2)
        horizontal, _, _, received_dbm = self._fields(points, uavs, mode)
        height = uavs[:, None, 2]
        valid = link_validity(horizontal, height, received_dbm)
        return aggregate_signal_dbm(received_dbm, valid), valid.any(axis=0)

    def point_snr(self, points, uavs, mode=None):
        signal_dbm, _ = self.point_signal_and_coverage(points, uavs, mode)
        return signal_dbm - NOISE_DBM

    def _gpu_grid(self):
        if self._gpu_grid_cache is None:
            self._gpu_grid_cache = (
                cp.asarray(self._grid_x32),
                cp.asarray(self._grid_y32),
            )
        return self._gpu_grid_cache

    def _gpu_area_masks(self, priority):
        if priority is not self._gpu_priority_owner:
            host = self._validate_priority(priority)
            self._gpu_priority_owner = priority
            self._gpu_priority_cache = cp.asarray(host)
            self._gpu_general_cache = ~self._gpu_priority_cache
            self._gpu_priority_count = int(host.sum())
        return (
            self._gpu_priority_cache,
            self._gpu_general_cache,
            self._gpu_priority_count,
        )

    def _signal_and_coverage_gpu_device(self, uavs, mode):
        if mode == "a2g":
            mode_code = 0
        elif mode == "los":
            mode_code = 1
        else:
            raise ValueError(f"unknown mode: {mode} ('a2g' or 'los')")
        uavs = self._reshape_deployment(uavs)
        grid_x, grid_y = self._gpu_grid()
        uavs_gpu = cp.asarray(uavs)
        n_points = self.grid_xy.shape[0]
        signal_dbm = cp.empty(n_points, dtype=cp.float32)
        covered = cp.empty(n_points, dtype=cp.uint8)
        threads = 256
        blocks = (n_points + threads - 1) // threads
        _gpu_signal_kernel()(
            (blocks,),
            (threads,),
            (
                uavs_gpu,
                grid_x,
                grid_y,
                signal_dbm,
                covered,
                np.int32(n_points),
                np.int32(self.config.n_uav),
                np.int32(mode_code),
                self._log_scale,
                self._fspl_const,
                np.float32(PT_DBM),
                np.float32(MU1),
                np.float32(MU2),
                np.float32(C_LOS),
                np.float32(D_LOS),
                self._inv_tan15,
                self._inv_tan25,
                np.float32(RX_THRESHOLD_DBM),
                np.float32(POWER_FLOOR_MW),
            ),
        )
        return signal_dbm, covered

    def _signal_and_coverage_gpu(self, uavs, mode):
        signal_dbm, covered = self._signal_and_coverage_gpu_device(uavs, mode)
        return cp.asnumpy(signal_dbm), cp.asnumpy(covered).astype(bool)

    def _signal_and_coverage_cpu(self, uavs, mode):
        uavs = self._reshape_deployment(uavs)
        total_mw = np.full(
            self.grid_xy.shape[0],
            np.float32(POWER_FLOOR_MW),
            dtype=np.float32,
        )
        covered = np.zeros(self.grid_xy.shape[0], dtype=bool)
        for uav in uavs:
            height = uav[2]
            dx = self._grid_x32 - uav[0]
            dy = self._grid_y32 - uav[1]
            horizontal = np.sqrt(dx * dx + dy * dy)
            distance = np.sqrt(horizontal * horizontal + height * height)
            np.maximum(distance, 1.0, out=distance)
            if mode == "a2g":
                path_loss = (
                    self._log_scale * np.log(distance)
                    + self._fspl_const
                    + np.float32(MU2)
                )
                near = horizontal < self._inv_tan15 * height
                if near.any():
                    theta = np.degrees(np.arctan2(height, horizontal[near]))
                    probability = np.float32(C_LOS) * (
                        theta - 15.0
                    ) ** np.float32(D_LOS)
                    path_loss[near] -= probability * np.float32(MU2 - MU1)
                received_dbm = np.float32(PT_DBM) - path_loss
            elif mode == "los":
                received_dbm = np.float32(PT_DBM) - (
                    self._log_scale * np.log(distance) + self._fspl_const
                )
            else:
                raise ValueError(f"unknown mode: {mode} ('a2g' or 'los')")
            valid = (
                horizontal <= self._inv_tan25 * height
            ) & (received_dbm >= np.float32(RX_THRESHOLD_DBM))
            covered |= valid
            total_mw += np.where(
                valid,
                np.power(
                    np.float32(10.0), received_dbm / np.float32(10.0)
                ),
                np.float32(0.0),
            )
        return np.float32(10.0) * np.log10(total_mw), covered

    def _signal_and_coverage(self, uavs, mode, use_gpu=None):
        enabled = _USE_GPU if use_gpu is None else bool(use_gpu)
        if enabled and _HAS_CUDA:
            return self._signal_and_coverage_gpu(uavs, mode)
        return self._signal_and_coverage_cpu(uavs, mode)

    def _evaluate_gpu(self, position, priority, mode):
        uavs = self._reshape_deployment(position)
        priority = self._validate_priority(priority)
        signal_dbm, covered = self._signal_and_coverage_gpu_device(uavs, mode)
        priority_gpu, general_gpu, n_priority = self._gpu_area_masks(priority)
        n_total = self.grid_xy.shape[0]
        n_general = n_total - n_priority
        tc_gpu = covered.mean(dtype=cp.float64)
        if n_priority:
            sac_gpu = covered[priority_gpu].mean(dtype=cp.float64)
            sasu_gpu = signal_dbm[priority_gpu].std(dtype=cp.float64)
        else:
            sac_gpu = cp.asarray(0.0, dtype=cp.float64)
            sasu_gpu = cp.asarray(0.0, dtype=cp.float64)
        if n_general:
            gasu_gpu = signal_dbm[general_gpu].std(dtype=cp.float64)
        else:
            gasu_gpu = cp.asarray(0.0, dtype=cp.float64)
        tc, sac, sasu, gasu = cp.asnumpy(
            cp.stack((tc_gpu, sac_gpu, sasu_gpu, gasu_gpu))
        )
        return metrics_from_summary(tc, sac, sasu, gasu)

    def _evaluate(self, position, priority, mode, use_gpu=None):
        mode = self.config.propagation_mode if mode is None else mode
        enabled = _USE_GPU if use_gpu is None else bool(use_gpu)
        if enabled and _HAS_CUDA:
            return self._evaluate_gpu(position, priority, mode)
        uavs = self._reshape_deployment(position)
        priority = self._validate_priority(priority)
        signal_dbm, covered = self._signal_and_coverage_cpu(uavs, mode)
        return metrics_from_field(signal_dbm, covered, priority)

    def evaluate(self, position, priority, mode=None):
        return self._evaluate(position, priority, mode)

    def _snr_field(self, position, mode=None, use_gpu=None):
        mode = self.config.propagation_mode if mode is None else mode
        uavs = self._reshape_deployment(position)
        signal_dbm, covered = self._signal_and_coverage(uavs, mode, use_gpu)
        return signal_dbm - NOISE_DBM, covered

    def snr_field(self, position, mode=None):
        return self._snr_field(position, mode)


DEFAULT_CONFIG = ScenarioConfig()
DEFAULT_SCENARIO = DeploymentScenario(DEFAULT_CONFIG)
