"""Versioned seven-method rerun with actual FE budgets and resumable checkpoints.

Examples (from experiments): python run_v4.py smoke; python run_v4.py main
The formal main command runs 7 methods x 6 UAV counts x 20 paired repetitions.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import sys
import time

for _thread_variable in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ.setdefault(_thread_variable, "1")

import numpy as np
import scipy

import algorithms
import model
from scenario import DeploymentScenario, ScenarioConfig, gpu_name, metrics_from_summary

HERE = Path(__file__).resolve().parent
SCHEMA = "uav-bs-experiments-v4"
COUNTS = [5, 10, 15, 20, 25, 30]
METHODS = ["pso", "ahdpso", "tadmpso", "amsepso", "sdpso", "saompso", "ql_apso"]
LABELS = {"pso": "PSO", "ahdpso": "AHDPSO", "tadmpso": "T-ADMPSO (adapted)",
          "amsepso": "AMSEPSO", "sdpso": "SDPSO (adapted)",
          "saompso": "SAO-MPSO", "ql_apso": "QL-TADMPSO + APSO feedback"}
VARIANTS = {
    "full": {},
    "legacy_coefficients": {"coefficient_control": "ahdpso"},
    "no_fsw": {"use_fsw": False, "feedback_distance": "normalized_coordinates"},
    "no_alignment": {"align_guides": False},
    "random_topology": {"use_topology": False},
    "no_cross_swarm": {"use_cross_swarm": False},
    "fixed_k": {"use_q_learning": False, "k0": 16},
    "factor_schedule": {"use_q_learning": False, "schedule_label": "factorization"},
}
SOURCE_FILES = ["run_v4.py", "algorithms.py", "apso_feedback.py", "baseline_support.py",
                "baseline_amsepso.py", "baseline_sdpso.py", "baseline_saompso.py",
                "evaluation.py", "scenario.py", "model.py", "topology.py", "timing.py"]


def jsonable(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [jsonable(v) for v in value]
    return value


def save_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(jsonable(data), ensure_ascii=False, allow_nan=False,
                                     separators=(",", ":")) + "\n", encoding="utf-8")
    temporary.replace(path)


def source_hashes():
    return {name: hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in SOURCE_FILES}


def save_source_snapshot(output_dir, fingerprints):
    """Keep the exact optimizer/model sources beside their results."""
    folder = Path(output_dir)/"source_snapshot"
    folder.mkdir(parents=True, exist_ok=True)
    for name, digest in fingerprints.items():
        destination = folder/name
        content = destination.read_bytes() if destination.exists() else (HERE/name).read_bytes()
        if hashlib.sha256(content).hexdigest() != digest:
            raise ValueError(f"source snapshot differs: {name}; choose a new output directory")
        if not destination.exists():
            destination.write_bytes(content)


@contextmanager
def directory_lock(output_dir):
    """One writer per experiment; OS releases the lock even after a crash."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir/".run.lock").open("a+b") as handle:
        if handle.seek(0, os.SEEK_END) == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise RuntimeError(f"Another run is already using this output directory: {output_dir}") from exc
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def runtime_fingerprint():
    runtime = {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
            "platform": platform.platform(),
            "machine": platform.machine() or ("64-bit" if sys.maxsize > 2**32 else "32-bit"), "device": gpu_name(),
            "processor": platform.processor(), "cupy": None, "cuda_runtime": None, "cuda_driver": None,
            "threads": {k: os.environ.get(k) for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS")}}
    if not runtime["device"].startswith("CPU"):
        from scenario import cp
        runtime.update(cupy=cp.__version__, cuda_runtime=cp.cuda.runtime.runtimeGetVersion(),
                       cuda_driver=cp.cuda.runtime.driverGetVersion())
    return runtime


def validate_provenance(data):
    provenance = data.get("provenance", {})
    fingerprints = provenance.get("source_sha256", {})
    if set(fingerprints) != set(SOURCE_FILES) or any(
            not isinstance(h, str) or re.fullmatch(r"[0-9a-f]{64}", h) is None
            for h in fingerprints.values()):
        raise ValueError("missing or invalid source provenance")
    runtime = provenance.get("runtime", {})
    fields = ("python", "numpy", "scipy", "platform", "machine", "device")
    if any(not isinstance(runtime.get(k), str) or not runtime[k] for k in fields):
        raise ValueError("missing runtime provenance")
    threads = runtime.get("threads", {})
    if set(threads) != {"OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"} or any(
            not isinstance(v, str) or not v.isdecimal() or int(v) < 1 for v in threads.values()):
        raise ValueError("invalid thread configuration provenance")
    if runtime["device"] != data["config"].get("device"):
        raise ValueError("recorded backend differs from the runtime provenance")
    if not runtime["device"].startswith("CPU") and (
            not isinstance(runtime.get("cupy"), str) or not runtime["cupy"] or
            any(type(runtime.get(k)) is not int or runtime[k] <= 0
                for k in ("cuda_runtime", "cuda_driver"))):
        raise ValueError("missing GPU runtime provenance")


def make_config(kind):
    if kind not in ("main", "smoke", "integration", "ablation", "ablation_smoke"):
        raise ValueError("unknown experiment kind")
    ablation = kind.startswith("ablation")
    formal = kind in ("main", "ablation")
    budget = 500 if "smoke" in kind else 25000
    seed_base, priority_base = (11000, 2100) if formal else (81000, 8100) if "smoke" in kind else (91000, 9100)
    return {
        "experiment_kind": kind, "n_p": 50, "max_fes": budget,
        "n_runs": 20 if formal else 1, "counts": [25] if ablation or kind == "integration" else list(COUNTS),
        "algorithms": list(VARIANTS) if ablation else list(METHODS),
        "mode": "a2g", "L": 50, "G": 5, "device": gpu_name(),
        "optimization_seed_base": seed_base, "priority_seed_base": priority_base,
        "feedback_seed_base": seed_base + 20000, "order_seed_base": seed_base + 40000,
        "scenario_base": ScenarioConfig().to_dict(), "formal_protocol": formal,
        "initialization": "intrinsic paper initialization; SAO-MPSO uses Cubic",
        "inertia_for_proposed": "existing_linear_0.9_to_0.4",
        "proposed_random_rule": "one_scalar_per_particle_per_learning_term",
        "proposed_coefficients": {"controller": "APSO_feedback_FSW", "initial": 2.,
                                  "step": [.05, .1], "range": [1.5, 2.5], "sum_max": 4.},
        "objective_weights": [.5, .3, .2], "uniformity_log_bases": [100, 1000],
        "parameter_status": "L/G inherited; APSO defaults are an untuned candidate",
        "statistics_family": "all requested counts x proposed-versus-comparator x five metrics; Holm",
    }


def expected_keys(config):
    return {(int(m), method, i) for i in range(int(config["n_runs"]))
            for m in config["counts"] for method in config["algorithms"]}


def integer(value, label, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{label} must be an integer >= {minimum}")
    return value


def record_key(record):
    return (integer(record["scenario"]["n_uav"], "n_uav", 1), record["method"], integer(record["i"], "run id"))


def history_at_fes(history_fes, values, grid):
    points, values, grid = np.asarray(history_fes), np.asarray(values), np.asarray(grid)
    if not len(points) or len(values) != len(points) or np.any(np.diff(points) <= 0):
        raise ValueError("invalid FE history")
    if np.any(grid < points[0]) or np.any(grid > points[-1]):
        raise ValueError("requested FE grid extends outside recorded evaluations")
    return values[np.searchsorted(points, grid, side="right")-1]


def validate_record(record, config):
    key = record_key(record)
    if key not in expected_keys(config):
        raise ValueError(f"unexpected experiment cell {key}")
    count, method, index = key
    if record.get("algo") != ("ql_apso" if method in VARIANTS else method):
        raise ValueError("recorded algorithm identity differs from the method")
    if method in VARIANTS and record.get("variant") != method:
        raise ValueError("ablation variant mismatch")
    if record["seed"] != config["optimization_seed_base"]+index or record["priority_seed"] != config["priority_seed_base"]+index:
        raise ValueError("record seed does not match the paired protocol")
    if record["feedback_seed"] != config["feedback_seed_base"]+index:
        raise ValueError("feedback seed mismatch")
    expected_scene = dict(config["scenario_base"], n_uav=count)
    if record["scenario"] != expected_scene:
        raise ValueError("record scenario mismatch")
    scene = DeploymentScenario(ScenarioConfig.from_dict(record["scenario"]))
    position = np.asarray(record["best_pos"], dtype=float)
    low, high = scene.bounds()
    if position.shape != low.shape or not np.isfinite(position).all() or np.any(position < low) or np.any(position > high):
        raise ValueError("invalid recorded deployment")
    if integer(record["fes"], "FEs", 1) != config["max_fes"]:
        raise ValueError("actual FEs do not equal the configured budget")
    integer(record["n_updates"], "update count")
    if not np.isfinite([record["best_F"], record["runtime_seconds"]]).all() or record["runtime_seconds"] < 0:
        raise ValueError("best objective and elapsed runtime must be finite")
    h, y = np.asarray(record["history_fes"], dtype=float), np.asarray(record["gF_history"], dtype=float)
    if (h.ndim != 1 or y.ndim != 1 or len(h) != len(y) or not len(h) or
            not np.isfinite(h).all() or np.any(h != np.floor(h)) or
            h[0] != config["n_p"] or h[-1] != record["fes"] or np.any(np.diff(h) <= 0)):
        raise ValueError("recorded FE history is inconsistent")
    if not np.isfinite(y).all() or np.any(np.diff(y) > 1e-12) or abs(y[-1]-record["best_F"]) > 1e-12:
        raise ValueError("historical-best archive is inconsistent")
    m = record["final_metrics"]
    values = np.array([m[k] for k in ("F", "TC", "SAC", "SASU", "GASU")], dtype=float)
    if not np.isfinite(values).all() or not (0 <= m["TC"] <= 1 and 0 <= m["SAC"] <= 1) or min(m["SASU"], m["GASU"]) < 0:
        raise ValueError("invalid final metrics")
    expected = metrics_from_summary(m["TC"], m["SAC"], m["SASU"], m["GASU"])
    if abs(expected["F"]-record["best_F"]) > 1e-10 or abs(m["F"]-record["best_F"]) > 1e-10:
        raise ValueError("weighted objective disagrees with its components")


def load_or_initialize(path, config):
    current = {"source_sha256": source_hashes(), "runtime": runtime_fingerprint()}
    path = Path(path)
    if not path.exists():
        return {"schema_version": SCHEMA, "model_version": model.MODEL_VERSION,
                "result_kind": config["experiment_kind"], "config": config,
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "provenance": current, "runs": []}
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("schema_version") != SCHEMA or data.get("model_version") != model.MODEL_VERSION:
        raise ValueError("result schema/model version mismatch")
    if data["config"] != config:
        raise ValueError("configuration differs; choose a new output directory")
    if data.get("result_kind") != config["experiment_kind"]:
        raise ValueError("result kind differs from its configured protocol")
    if data["provenance"] != current:
        raise ValueError("source/runtime fingerprint differs; choose a new output directory")
    validate_provenance(data)
    keys = [record_key(r) for r in data["runs"]]
    if len(keys) != len(set(keys)):
        raise ValueError("duplicate saved experiment cells")
    for record in data["runs"]:
        validate_record(record, config)
    return data


def qualify(data):
    config, reasons = data["config"], []
    expected = expected_keys(config)
    actual = [record_key(r) for r in data["runs"]]
    complete = len(actual) == len(expected) and set(actual) == expected
    if not complete:
        reasons.append("experiment matrix is incomplete or duplicated")
    if config.get("experiment_kind") not in ("main", "ablation") or not config.get("formal_protocol"):
        reasons.append("validation/pilot protocol is not formal evidence")
    else:
        canonical = make_config(config["experiment_kind"])
        # Historical reports may be inspected on a different computer.
        canonical["device"] = config.get("device")
        if canonical != config:
            reasons.append("fixed formal protocol differs from the canonical configuration")
    if data.get("result_kind") != config.get("experiment_kind"):
        reasons.append("result kind differs from the configured protocol")
    if config["n_runs"] != 20 or config["max_fes"] != 25000 or config["n_p"] != 50:
        reasons.append("formal replication/budget/population mismatch")
    if config["experiment_kind"] == "main" and (config["counts"] != COUNTS or config["algorithms"] != METHODS):
        reasons.append("formal main comparison matrix mismatch")
    if config["experiment_kind"] == "ablation" and (config["counts"] != [25] or config["algorithms"] != list(VARIANTS)):
        reasons.append("formal ablation matrix mismatch")
    if data.get("schema_version") != SCHEMA or data.get("model_version") != model.MODEL_VERSION:
        reasons.append("schema/model version mismatch")
    try:
        validate_provenance(data)
    except (ValueError, KeyError, TypeError) as exc:
        reasons.append(str(exc))
    for record in data["runs"]:
        try:
            validate_record(record, config)
        except (ValueError, KeyError, TypeError) as exc:
            reasons.append(str(exc))
            break
    return {"qualified": not reasons, "complete": complete, "reasons": reasons,
            "expected_runs": len(expected), "actual_runs": len(actual)}


def run_single(method, seed, feedback_seed, priority, scene, config):
    rng = np.random.default_rng(seed)
    common = dict(n_p=config["n_p"], max_fes=config["max_fes"], scenario=scene)
    started = time.perf_counter()
    if method in ("pso", "ahdpso", "tadmpso"):
        fn = {"pso": algorithms.run_standard_pso, "ahdpso": algorithms.run_ahdpso,
              "tadmpso": algorithms.run_tadmpso}[method]
        result = fn(rng, priority, config["mode"], **common)
    elif method in ("amsepso", "sdpso", "saompso"):
        from importlib import import_module
        fn = getattr(import_module(f"baseline_{method}"), f"run_{method}")
        result = fn(rng, priority, config["mode"], **common)
    elif method == "ql_apso" or method in VARIANTS:
        options = dict(coefficient_control="apso", feedback_seed=feedback_seed)
        options.update(VARIANTS.get(method, {}))
        if method == "factor_schedule":
            options["k_schedule"] = algorithms.factorization_schedule(
                algorithms.update_count(common["max_fes"], common["n_p"]), common["n_p"])
        result = algorithms.run_ql_tadmpso(rng, priority, config["mode"],
                                          G=config["G"], L=config["L"], **common, **options)
    else:
        raise ValueError(f"unknown method {method}")
    result["runtime_seconds"] = time.perf_counter()-started
    if "history_fes" not in result:
        result["history_fes"] = (np.arange(len(result["gF_history"]))+1)*config["n_p"]
    return jsonable(result)


def run_suite(kind, output_dir, make_report=True):
    with directory_lock(output_dir):
        return _run_suite(kind, output_dir, make_report)


def _run_suite(kind, output_dir, make_report=True):
    config = make_config(kind)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir/"results.json"
    data = load_or_initialize(path, config)
    save_source_snapshot(output_dir, data["provenance"]["source_sha256"])
    save_json(path, data)
    done = {record_key(r) for r in data["runs"]}
    total = len(expected_keys(config))
    print(f"{kind}: {len(done)}/{total} saved; output={path}", flush=True)
    if len(done) < total:
        # Warm up outside measured/recorded runs, including CUDA kernel compilation.
        warm = dict(config, n_p=6, max_fes=18, G=2)
        warm_scene = DeploymentScenario(ScenarioConfig(n_uav=5))
        warm_priority = warm_scene.priority_mask(78001)
        for method in config["algorithms"]:
            run_single(method, 78002, 78003, warm_priority, warm_scene, warm)
    for index in range(config["n_runs"]):
        seed = config["optimization_seed_base"]+index
        priority_seed = config["priority_seed_base"]+index
        feedback_seed = config["feedback_seed_base"]+index
        for count in config["counts"]:
            scene = DeploymentScenario(ScenarioConfig.from_dict(dict(config["scenario_base"], n_uav=count)))
            priority = scene.priority_mask(priority_seed)
            order = np.random.default_rng(config["order_seed_base"]+index*100+count).permutation(config["algorithms"])
            for method in order.tolist():
                key = (count, method, index)
                if key in done:
                    continue
                result = run_single(method, seed, feedback_seed, priority, scene, config)
                record = dict(result, i=index, method=method,
                              algo="ql_apso" if method in VARIANTS else method,
                              seed=seed, priority_seed=priority_seed, feedback_seed=feedback_seed,
                              scenario=scene.config.to_dict(), scenario_id=f"{count}uav")
                if method in VARIANTS:
                    record["variant"] = method
                validate_record(record, config)
                if source_hashes() != data["provenance"]["source_sha256"]:
                    raise RuntimeError("source changed during execution; refusing mixed checkpoint")
                data["runs"].append(record)
                done.add(key)
                data["status"] = {"completed": len(done), "expected": total}
                save_json(path, data)
                print(f"[{len(done)}/{total}] M={count} run={index+1} {method}: "
                      f"F={result['best_F']:.6f} TC={100*result['final_metrics']['TC']:.2f}% "
                      f"FEs={result['fes']} time={result['runtime_seconds']:.2f}s", flush=True)
    data["qualification"] = qualify(data)
    save_json(path, data)
    if make_report:
        from report_v4 import generate_report
        generate_report(path)
    return data


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task", choices=["main", "smoke", "integration", "ablation", "ablation_smoke"])
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--no-report", action="store_true")
    args = parser.parse_args(argv)
    output = args.output_dir or HERE/"outputs/rebuild_v4"/args.task
    try:
        run_suite(args.task, output, make_report=not args.no_report)
    except KeyboardInterrupt:
        print("Stopped; completed runs are saved. Repeat the same command to resume.", flush=True)
        return 130
    return 0


if __name__ == "__main__":
    sys.exit(main())
