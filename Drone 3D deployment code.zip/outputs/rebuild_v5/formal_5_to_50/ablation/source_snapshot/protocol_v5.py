"""Shared protocol and strict record validation for the staged v5 campaign."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

import numpy as np

import model
import run_v4 as support
from scenario import DeploymentScenario, ScenarioConfig, gpu_name, metrics_from_summary

HERE = Path(__file__).resolve().parent
SCHEMA = 'uav-bs-experiments-v5'
COUNTS = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50]
METRICS = ('F', 'TC', 'SAC', 'SASU', 'GASU', 'runtime_seconds')
RECONSTRUCTION_TOLERANCES = dict(F=1e-6, f1=1e-12, f2=1e-6, f3=1e-6,
                                 TC=1e-12, SAC=1e-12, SASU=1e-4, GASU=1e-4)
FACTORIAL = ('no_fsw_no_alignment', 'no_alignment', 'no_fsw', 'full')
VARIANTS = {
    'full': {},
    'no_fsw': {'use_fsw': False},
    'no_alignment': {'align_guides': False},
    'no_fsw_no_alignment': {'use_fsw': False, 'align_guides': False},
    'random_topology': {'use_topology': False},
    'no_cross_swarm': {'use_cross_swarm': False},
    'fixed_k': {'use_q_learning': False, 'k0': 16},
    'factor_schedule': {'use_q_learning': False, 'schedule_label': 'factorization'},
    'random_actions': {'use_q_learning': False, 'random_actions': True},
    'apso_coefficients': {'coefficient_control': 'apso'},
}
ABLATIONS = [condition for variant in FACTORIAL
             for condition in (variant, variant + '_permuted')]
ABLATIONS += [key for key in VARIANTS if key not in FACTORIAL]
METHODS = ['pso', 'ahdpso', 'tadmpso', 'amsepso', 'sdpso', 'saompso', 'full']
LABELS = dict(support.LABELS, full='QL-TADMPSO', no_fsw='No FSW',
              no_alignment='No alignment', no_fsw_no_alignment='No FSW / alignment',
              random_topology='Random groups', no_cross_swarm='No cross-swarm',
              fixed_k='Fixed k', factor_schedule='Factor schedule',
              random_actions='Random actions', apso_coefficients='APSO coefficients')
for _variant in FACTORIAL:
    LABELS[_variant + '_permuted'] = LABELS[_variant] + ' (permuted)'
SOURCE_FILES = support.SOURCE_FILES + ['protocol_v5.py', 'count_selection.py', 'run_v5.py',
                                     'permutation_probe.py', 'report_v5.py', 'report_v4.py',
                                     'deployment_atlas.py']
save_json = support.save_json
jsonable = support.jsonable
directory_lock = support.directory_lock
runtime_fingerprint = support.runtime_fingerprint
integer = support.integer
history_at_fes = support.history_at_fes


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def digest(value):
    encoded = json.dumps(jsonable(value), sort_keys=True, ensure_ascii=False,
                         separators=(',', ':'), allow_nan=False).encode('utf-8')
    return hashlib.sha256(encoded).hexdigest()


def file_digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def result_digest(data):
    return digest({key: value for key, value in data.items() if key != 'content_sha256'})


def save_results(path, data):
    """Seal the complete atomic checkpoint, including the set of saved cells."""
    data['status'] = dict(completed=len(data['runs']), expected=len(expected_keys(data['config'])))
    data['content_sha256'] = result_digest(data)
    save_json(path, data)


def source_hashes():
    return {name: file_digest(HERE / name) for name in SOURCE_FILES}


def _base_config(stage, selection=None, smoke=False):
    if stage not in ('count', 'ablation', 'comparison'):
        raise ValueError('unknown experiment stage')
    if stage != 'count' and selection is None:
        raise ValueError('a validated count selection is required')
    seed_base = {'count': 1100000, 'ablation': 1200000, 'comparison': 1300000}[stage]
    if smoke:
        seed_base += 1000000
    return {
        'stage': stage, 'formal_protocol': not smoke,
        'n_p': 12 if smoke else 50, 'max_fes': 120 if smoke else 25000,
        'n_runs': 1 if smoke else 20,
        'counts': list(COUNTS) if stage == 'count' else [selection['selected_count']],
        'algorithms': ['full'] if stage == 'count' else list(ABLATIONS if stage == 'ablation' else METHODS),
        'mode': 'a2g', 'L': 50, 'G': 5, 'device': gpu_name(),
        'optimization_seed_base': seed_base, 'priority_seed_base': seed_base + 10000,
        'feedback_seed_base': seed_base + 20000, 'order_seed_base': seed_base + 30000,
        'permutation_seed_base': seed_base + 40000,
        'scenario_base': ScenarioConfig().to_dict(),
        'selection': deepcopy(selection),
        'initialization': 'paper initialization; SAO-MPSO retains Cubic initialization',
        'proposed_coefficients': 'original_AHDPSO_derived_Logistic_schedule',
        'proposed_inertia': 'existing_linear_0.9_to_0.4',
        'proposed_random_rule': 'one_scalar_per_particle_per_learning_term',
        'matrix_update': 'synchronous_population_arithmetic_legacy_draw_order',
        'objective_weights': [.5, .3, .2], 'uniformity_log_bases': [100, 1000],
        'statistics': 'paired Wilcoxon; Holm within predeclared stage family; paired bootstrap median CI',
        'posthoc_validation': 'reconstruct saved metrics on the recorded backend; outside search FEs and runtime',
    }


def make_config(stage, selection=None, smoke=False):
    if stage != 'count':
        if selection is None:
            raise ValueError('a validated count selection is required')
        from count_selection import validate_selection
        validate_selection(selection, allow_smoke=smoke)
    return _base_config(stage, selection, smoke)


def base_variant(method):
    return method.removesuffix('_permuted')


def optimizer_options(method, config, index):
    variant = base_variant(method)
    if variant not in VARIANTS:
        return {}
    options = dict(G=config['G'], L=config['L'], coefficient_control='ahdpso')
    options.update(VARIANTS[variant])
    if options['coefficient_control'] == 'apso':
        options['feedback_seed'] = config['feedback_seed_base'] + index
    if method.endswith('_permuted'):
        options['permutation_seed'] = config['permutation_seed_base'] + index
    return options


def expected_keys(config):
    return {(m, method, i) for m in config['counts']
            for method in config['algorithms'] for i in range(config['n_runs'])}


def record_key(record):
    return (integer(record['scenario']['n_uav'], 'n_uav', 1),
            record['method'], integer(record['i'], 'run id'))


def metric_value(record, metric):
    if metric == 'runtime_seconds':
        return float(record[metric])
    value = float(record['final_metrics'][metric])
    return value * 100 if metric in ('TC', 'SAC') else value


def validate_config(config):
    stage = config['stage']
    if stage not in ('count', 'ablation', 'comparison') or type(config['formal_protocol']) is not bool:
        raise ValueError('invalid stage or protocol flag')
    for field in ('n_p', 'max_fes', 'n_runs', 'L', 'G'):
        integer(config[field], field, 1)
    if config['max_fes'] < config['n_p'] or config['max_fes'] % config['n_p']:
        raise ValueError('budget must include initialization and whole proposed-method generations')
    for field in ('optimization_seed_base', 'priority_seed_base', 'feedback_seed_base',
                  'order_seed_base', 'permutation_seed_base'):
        integer(config[field], field)
    counts, methods = config['counts'], config['algorithms']
    if not counts or len(set(counts)) != len(counts) or any(type(m) is not int or m not in COUNTS for m in counts):
        raise ValueError('invalid or duplicated candidate counts')
    allowed = ['full'] if stage == 'count' else ABLATIONS if stage == 'ablation' else METHODS
    if not methods or len(set(methods)) != len(methods) or any(m not in allowed for m in methods):
        raise ValueError('invalid or duplicated method identity')
    if config['mode'] != 'a2g':
        raise ValueError('v5 uses the unchanged a2g model')
    ScenarioConfig.from_dict(config['scenario_base'])
    if stage == 'count':
        if config['selection'] is not None:
            raise ValueError('count stage cannot inherit a chosen count')
    elif config['selection'] is None or counts != [config['selection']['selected_count']]:
        raise ValueError('stage count differs from its selection')
    else:
        from count_selection import validate_selection
        validate_selection(config['selection'], allow_smoke=not config['formal_protocol'],
                           require_current=False)


def validate_record(record, config):
    count, method, index = record_key(record)
    if (count, method, index) not in expected_keys(config):
        raise ValueError('unexpected experiment cell')
    expected_algo = 'ql' if base_variant(method) in VARIANTS else method
    if record.get('algo') != expected_algo or record.get('algorithm_options') != optimizer_options(method, config, index):
        raise ValueError('algorithm/controller/options identity mismatch')
    for field, base in (('seed', 'optimization_seed_base'), ('priority_seed', 'priority_seed_base'),
                        ('feedback_seed', 'feedback_seed_base')):
        if type(record.get(field)) is not int or record[field] != config[base] + index:
            raise ValueError('paired seed mismatch')
    if record['scenario'] != dict(config['scenario_base'], n_uav=count):
        raise ValueError('physical scenario mismatch')
    scene = DeploymentScenario(ScenarioConfig.from_dict(record['scenario']))
    lower, upper = scene.bounds()
    position = np.asarray(record['best_pos'], dtype=float)
    if position.shape != lower.shape or not np.isfinite(position).all() or np.any(position < lower) or np.any(position > upper):
        raise ValueError('invalid final deployment')
    if integer(record['fes'], 'FEs', 1) != config['max_fes']:
        raise ValueError('actual FEs do not equal the budget')
    integer(record['n_updates'], 'update count')
    if not np.isfinite([record['best_F'], record['runtime_seconds']]).all() or record['runtime_seconds'] < 0:
        raise ValueError('invalid objective/runtime')
    points, history = np.asarray(record['history_fes']), np.asarray(record['gF_history'])
    if (points.ndim != 1 or history.shape != points.shape or not len(points)
            or not np.isfinite(points).all() or np.any(points != np.floor(points))
            or points[0] != config['n_p'] or points[-1] != record['fes'] or np.any(np.diff(points) <= 0)):
        raise ValueError('invalid actual-FE history')
    if not np.isfinite(history).all() or np.any(np.diff(history) > 1e-12) or abs(history[-1] - record['best_F']) > 1e-12:
        raise ValueError('best archive is inconsistent')
    validate_fe_ledger(record, config)
    metrics = record['final_metrics']
    if not np.isfinite([metrics[key] for key in METRICS[:-1]]).all():
        raise ValueError('nonfinite final metrics')
    if not (0 <= metrics['TC'] <= 1 and 0 <= metrics['SAC'] <= 1) or min(metrics['SASU'], metrics['GASU']) < 0:
        raise ValueError('invalid metric ranges')
    expected = metrics_from_summary(metrics['TC'], metrics['SAC'], metrics['SASU'], metrics['GASU'])
    if abs(expected['F'] - record['best_F']) > 1e-10 or abs(metrics['F'] - record['best_F']) > 1e-10:
        raise ValueError('objective differs from its components')
    # This checks saved evidence only. It neither proposes a search candidate
    # nor updates any optimizer archive, FE ledger or measured run time.
    use_gpu = not config['device'].startswith('CPU')
    if use_gpu and gpu_name(True).startswith('CPU'):
        raise ValueError('recorded GPU backend is required for metric reconstruction')
    rebuilt = scene._evaluate(position, scene.priority_mask(record['priority_seed']),
                              config['mode'], use_gpu=use_gpu)
    for key, tolerance in RECONSTRUCTION_TOLERANCES.items():
        if key not in metrics or not np.isfinite(metrics[key]) or abs(metrics[key] - rebuilt[key]) > tolerance:
            raise ValueError('saved deployment does not reconstruct metric ' + key)


def validate_fe_ledger(record, config):
    """Check each method's evaluation granularity and outer-update meaning."""
    n, budget = config['n_p'], config['max_fes']
    points = np.asarray(record['history_fes'])
    steps = np.diff(points)
    updates = integer(record['n_updates'], 'update count')
    method = record['algo']
    if method in ('ql', 'pso', 'ahdpso', 'tadmpso'):
        if updates != budget // n - 1 or not np.array_equal(points, np.arange(n, budget + 1, n)):
            raise ValueError('population-update FE ledger is incomplete')
        return
    diagnostics = record['diagnostics']
    if method == 'amsepso':
        events = diagnostics['gbpm_events']
        trial_ends = {event['fe'] for event in events}
        trials = integer(diagnostics['gbpm_attempts'], 'GBPM attempts')
        trial_mask = np.isin(points[1:], list(trial_ends))
        population_steps = steps[~trial_mask]
        if (len(events) != trials or len(trial_ends) != trials or trial_mask.sum() != trials
                or diagnostics['gbpm_fes'] != trials
                or any(event['fe'] != event['before_fes'] + 1 for event in events)
                or np.any(steps[trial_mask] != 1)
                or len(population_steps) != updates
                or np.any(population_steps < 1) or np.any(population_steps > n)
                or np.any(population_steps[:-1] != n)
                or diagnostics['population_update_fes'] != int(population_steps.sum())
                or sum(diagnostics['strategy_generations'].values()) != updates
                or sum(diagnostics['strategy_evaluations'].values()) != int(population_steps.sum())
                or diagnostics['initialization_fes'] != n
                or n + int(population_steps.sum()) + trials != budget):
            raise ValueError('AMSEPSO population/perturbation FE ledger is inconsistent')
    elif method == 'sdpso':
        pso = integer(diagnostics['pso_evaluations'], 'PSO evaluations')
        trials = integer(diagnostics['dls_trials'], 'DLS trials')
        if (not np.array_equal(points, np.arange(n, budget + 1))
                or n + pso + trials != budget or updates != (pso + n - 1) // n
                or not max(0, updates - 1) <= diagnostics['completed_passes'] <= updates):
            raise ValueError('SDPSO particle/learning FE ledger is inconsistent')
    elif method == 'saompso':
        phases = diagnostics['phase_history']
        iterations = [phase['iteration'] for phase in phases]
        if (len(phases) != len(steps) or np.any(steps != n)
                or set(iterations) != set(range(1, updates + 1))
                or iterations != sorted(iterations)
                or sum(diagnostics['phase_counts'].values()) != len(phases)
                or sum(diagnostics['phase_candidate_counts'].values()) != budget - n):
            raise ValueError('SAO-MPSO phase/update FE ledger is inconsistent')
        for i, phase in enumerate(phases):
            if (phase['fes_before'] != points[i] or phase['fes_after'] != points[i + 1]
                    or phase['evaluated'] != steps[i]):
                raise ValueError('SAO-MPSO phase FE ledger is inconsistent')
    else:
        raise ValueError('unknown FE ledger method')


def validate_results(data):
    if data.get('schema_version') != SCHEMA or data.get('model_version') != model.MODEL_VERSION:
        raise ValueError('schema/model mismatch; old results cannot be mixed into v5')
    if data.get('content_sha256') != result_digest(data):
        raise ValueError('checkpoint integrity mismatch; records were changed or removed')
    config = data['config']
    validate_config(config)
    if data.get('result_kind') != config['stage']:
        raise ValueError('result kind differs from stage')
    provenance = data['provenance']
    hashes = provenance['source_sha256']
    if set(hashes) != set(SOURCE_FILES) or any(not isinstance(h, str) or re.fullmatch('[0-9a-f]{64}', h) is None for h in hashes.values()):
        raise ValueError('invalid source provenance')
    # Reuse the existing runtime validator, with only its known source keys.
    support.validate_provenance(dict(data, provenance=dict(provenance, source_sha256={
        name: hashes[name] for name in support.SOURCE_FILES})))
    if not isinstance(data.get('runs'), list):
        raise ValueError('missing run records')
    if data.get('status') != dict(completed=len(data['runs']), expected=len(expected_keys(config))):
        raise ValueError('checkpoint status differs from its saved cells')
    keys = [record_key(record) for record in data['runs']]
    if len(keys) != len(set(keys)):
        raise ValueError('duplicate run records')
    for record in data['runs']:
        validate_record(record, config)


def qualify(data):
    validate_results(data)
    config = data['config']
    complete = {record_key(r) for r in data['runs']} == expected_keys(config)
    reasons = []
    if not complete:
        reasons.append('incomplete experiment matrix')
    if not config['formal_protocol']:
        reasons.append('smoke/pilot results are not formal evidence')
    canonical = _base_config(config['stage'], config['selection'], smoke=False)
    canonical['device'] = config['device']
    if config != canonical:
        reasons.append('configuration differs from the fixed formal protocol')
    if config['stage'] != 'count' and not config['selection'].get('formal'):
        reasons.append('count selection is not based on complete formal evidence')
    return dict(qualified=not reasons, complete=complete, reasons=reasons,
                actual_runs=len(data['runs']), expected_runs=len(expected_keys(config)))


def load_data(path, require_current=False):
    path = Path(path)
    data = json.loads(path.read_text(encoding='utf-8'))
    validate_results(data)
    for name, expected in data['provenance']['source_sha256'].items():
        snapshot = path.parent / 'source_snapshot' / name
        if not snapshot.is_file() or file_digest(snapshot) != expected:
            raise ValueError('missing or changed source snapshot: ' + name)
    if require_current and data['provenance']['source_sha256'] != source_hashes():
        raise ValueError('source changed; choose a new campaign directory')
    return data
