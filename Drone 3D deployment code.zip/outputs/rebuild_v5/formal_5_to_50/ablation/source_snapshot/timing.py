"""Wall-clock stopping protocol with whole-generation checkpoints."""
from dataclasses import dataclass
import os
import platform as platform_module
import time

import numpy as np


def hardware_fingerprint():
    """Return JSON-serializable runtime and compute-device information."""
    processor = (
        platform_module.processor()
        or os.environ.get("PROCESSOR_IDENTIFIER")
        or "unknown CPU"
    )
    cupy_version = "unavailable"
    backend = "CPU"
    device = processor
    cuda_available = False
    try:
        import cupy as cp
        cupy_version = str(cp.__version__)
        if int(cp.cuda.runtime.getDeviceCount()) > 0:
            properties = cp.cuda.runtime.getDeviceProperties(0)
            raw_name = properties.get("name", "CUDA device")
            device = (
                raw_name.decode(errors="replace")
                if isinstance(raw_name, bytes) else str(raw_name)
            )
            backend = "CUDA"
            cuda_available = True
    except Exception:
        pass
    return {
        "python": platform_module.python_version(),
        "numpy": str(np.__version__),
        "cupy": cupy_version,
        "platform": platform_module.platform(),
        "processor": str(processor),
        "backend": backend,
        "device": str(device),
        "cuda_available": cuda_available,
    }


@dataclass(frozen=True)
class TimeProtocol:
    limit_seconds: float = 60.0
    checkpoints_seconds: tuple = (15.0, 30.0, 60.0)
    max_fes_safety: int = 5_000_000

    def __post_init__(self):
        limit = float(self.limit_seconds)
        checkpoints = tuple(float(value) for value in self.checkpoints_seconds)
        max_fes = int(self.max_fes_safety)
        if limit <= 0.0:
            raise ValueError("limit_seconds must be positive")
        if not checkpoints or any(value <= 0.0 for value in checkpoints):
            raise ValueError("checkpoints must be positive and non-empty")
        if any(right <= left for left, right in zip(checkpoints, checkpoints[1:])):
            raise ValueError("checkpoints must be strictly ordered")
        if not np.isclose(checkpoints[-1], limit, rtol=0.0, atol=1e-12):
            raise ValueError("last checkpoint must equal the time limit")
        if max_fes <= 0:
            raise ValueError("max_fes_safety must be positive")
        object.__setattr__(self, "limit_seconds", limit)
        object.__setattr__(self, "checkpoints_seconds", checkpoints)
        object.__setattr__(self, "max_fes_safety", max_fes)


class TimingController:
    def __init__(self, protocol, clock=time.perf_counter):
        if not isinstance(protocol, TimeProtocol):
            raise TypeError("protocol must be a TimeProtocol")
        self.protocol = protocol
        self.clock = clock
        self._start_time = None
        self._last_elapsed = 0.0
        self._next_checkpoint = 0
        self._checkpoints = []
        self._stop_reason = None

    def start(self):
        if self._start_time is not None:
            raise RuntimeError("timing controller has already started")
        self._start_time = float(self.clock())
        self._last_elapsed = 0.0

    def _elapsed(self):
        if self._start_time is None:
            raise RuntimeError("timing controller has not started")
        elapsed = float(self.clock()) - self._start_time
        if elapsed + 1e-12 < self._last_elapsed:
            raise RuntimeError("clock moved backwards")
        self._last_elapsed = max(self._last_elapsed, elapsed)
        return self._last_elapsed

    @property
    def last_progress(self):
        return float(np.clip(
            self._last_elapsed / self.protocol.limit_seconds, 0.0, 1.0
        ))

    def progress(self):
        self._elapsed()
        return self.last_progress

    def _after_boundary(self, fes, best_f, metrics, best_pos=None):
        if self._stop_reason is not None:
            return True
        fes = int(fes)
        elapsed = self._elapsed()
        while (
            self._next_checkpoint < len(self.protocol.checkpoints_seconds)
            and elapsed >= self.protocol.checkpoints_seconds[self._next_checkpoint]
        ):
            target = self.protocol.checkpoints_seconds[self._next_checkpoint]
            row = {
                "target_seconds": target,
                "actual_seconds": elapsed,
                "fes": fes,
                "best_F": float(best_f),
                "final_metrics": dict(metrics),
            }
            if best_pos is not None:
                row["best_pos"] = np.asarray(best_pos).reshape(-1).tolist()
            self._checkpoints.append(row)
            self._next_checkpoint += 1
        if elapsed >= self.protocol.limit_seconds:
            self._stop_reason = "time_limit"
        elif fes >= self.protocol.max_fes_safety:
            self._stop_reason = "max_fes_safety"
        return self._stop_reason is not None

    def after_initialization(self, fes, best_f, metrics, best_pos=None):
        return self._after_boundary(fes, best_f, metrics, best_pos)

    def after_generation(self, fes, best_f, metrics, best_pos=None):
        return self._after_boundary(fes, best_f, metrics, best_pos)

    def refresh_boundary(self, fes):
        """Backfill actual elapsed time for checkpoints at the given FE boundary."""
        elapsed = self._elapsed()
        for row in reversed(self._checkpoints):
            if int(row["fes"]) != int(fes):
                break
            row["actual_seconds"] = elapsed
        return elapsed

    def result(self):
        if self._start_time is None:
            raise RuntimeError("timing controller has not started")
        overshoot = 0.0
        if self._stop_reason == "time_limit":
            overshoot = max(0.0, self._last_elapsed - self.protocol.limit_seconds)
        return {
            "checkpoints": [dict(row) for row in self._checkpoints],
            "stop_reason": self._stop_reason,
            "overshoot_seconds": overshoot,
            "actual_seconds": self._last_elapsed,
        }
