"""Staged experiments: count -> explicit selection -> mechanisms -> ablation -> comparison."""
import argparse
import os
from pathlib import Path
import sys
import time

for _thread_variable in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(_thread_variable, '1')

import numpy as np

import algorithms
import model
import protocol_v5 as protocol
import run_v4 as support
from scenario import DeploymentScenario, ScenarioConfig


def run_single(method, index, priority, scene, config):
    rng = np.random.default_rng(config['optimization_seed_base'] + index)
    options = protocol.optimizer_options(method, config, index)
    common = dict(n_p=config['n_p'], max_fes=config['max_fes'], scenario=scene)
    started = time.perf_counter()
    if protocol.base_variant(method) in protocol.VARIANTS:
        call_options = dict(options)
        if protocol.base_variant(method) == 'factor_schedule':
            call_options['k_schedule'] = algorithms.factorization_schedule(
                algorithms.update_count(config['max_fes'], config['n_p']), config['n_p'])
        result = algorithms.run_ql_tadmpso(rng, priority, config['mode'], **common, **call_options)
    elif method in ('pso', 'ahdpso', 'tadmpso'):
        fn = dict(pso=algorithms.run_standard_pso, ahdpso=algorithms.run_ahdpso,
                  tadmpso=algorithms.run_tadmpso)[method]
        result = fn(rng, priority, config['mode'], **common)
    else:
        from importlib import import_module
        fn = getattr(import_module('baseline_' + method), 'run_' + method)
        result = fn(rng, priority, config['mode'], **common)
    result['runtime_seconds'] = time.perf_counter() - started
    if 'history_fes' not in result:
        result['history_fes'] = (np.arange(len(result['gF_history'])) + 1) * config['n_p']
    result.update(i=index, method=method,
                  algo='ql' if protocol.base_variant(method) in protocol.VARIANTS else method,
                  algorithm_options=options, seed=config['optimization_seed_base'] + index,
                  priority_seed=config['priority_seed_base'] + index,
                  feedback_seed=config['feedback_seed_base'] + index,
                  scenario=scene.config.to_dict(), scenario_id=f'{scene.config.n_uav}uav')
    return protocol.jsonable(result)


def run_suite(config, output_dir, make_report=True):
    protocol.validate_config(config)
    if config['selection'] is not None:
        from count_selection import validate_selection
        validate_selection(config['selection'], allow_smoke=not config['formal_protocol'])
    output_dir = Path(output_dir)
    with protocol.directory_lock(output_dir):
        path = output_dir / 'results.json'
        current = dict(source_sha256=protocol.source_hashes(), runtime=protocol.runtime_fingerprint())
        if path.exists():
            data = protocol.load_data(path, require_current=True)
            if data['config'] != config or data['provenance'] != current:
                raise ValueError('configuration/source/runtime changed; choose a new campaign directory')
        else:
            data = dict(schema_version=protocol.SCHEMA, model_version=model.MODEL_VERSION,
                        result_kind=config['stage'], config=config, created_utc=protocol.utc_now(),
                        provenance=current, runs=[])
            support.save_source_snapshot(output_dir, current['source_sha256'])
            protocol.save_results(path, data)
        done = {protocol.record_key(r) for r in data['runs']}
        total = len(protocol.expected_keys(config))
        print(f"{config['stage']}: {len(done)}/{total} saved; {path}", flush=True)
        if len(done) < total:
            # Warm-up does not enter the FE ledger or measured run time.
            warm = dict(config, n_p=6, max_fes=18, G=2)
            scene = DeploymentScenario(ScenarioConfig.from_dict(dict(config['scenario_base'], n_uav=5)))
            for method in config['algorithms']:
                run_single(method, 999, scene.priority_mask(789991), scene, warm)
        for index in range(config['n_runs']):
            count_order = np.random.default_rng(config['order_seed_base'] + index).permutation(config['counts'])
            for count in count_order.tolist():
                scene = DeploymentScenario(ScenarioConfig.from_dict(dict(config['scenario_base'], n_uav=count)))
                priority = scene.priority_mask(config['priority_seed_base'] + index)
                order = np.random.default_rng(config['order_seed_base'] + index * 100 + count).permutation(config['algorithms'])
                for method in order.tolist():
                    if (count, method, index) in done:
                        continue
                    record = run_single(method, index, priority, scene, config)
                    protocol.validate_record(record, config)
                    if protocol.source_hashes() != current['source_sha256']:
                        raise RuntimeError('source changed during execution; refusing a mixed checkpoint')
                    data['runs'].append(record)
                    done.add((count, method, index))
                    data['status'] = dict(completed=len(done), expected=total)
                    protocol.save_results(path, data)
                    print(f"[{len(done)}/{total}] m={count} run={index+1} {method}: "
                          f"F={record['best_F']:.6f} TC={record['final_metrics']['TC']*100:.2f}% "
                          f"FEs={record['fes']} time={record['runtime_seconds']:.2f}s", flush=True)
        data['qualification'] = protocol.qualify(data)
        protocol.save_results(path, data)
    if make_report:
        from report_v5 import generate_report
        generate_report(path)
    return data


def _require_predecessor(root, stage, choice, smoke):
    if stage in ('ablation', 'comparison'):
        from permutation_probe import load_probe
        load_probe(root / 'mechanism/results.json', choice)
    if stage == 'comparison':
        previous = protocol.load_data(root / 'ablation/results.json', require_current=True)
        status = protocol.qualify(previous)
        if (previous['config']['selection'] != choice or not status['complete']
                or (not smoke and not status['qualified'])):
            raise ValueError('a matching complete ablation stage is required before comparison')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', choices=['count', 'select', 'mechanism', 'ablation', 'comparison', 'continue', 'smoke', 'report'])
    parser.add_argument('--root', type=Path)
    parser.add_argument('--uav-count', type=int)
    parser.add_argument('--reason')
    parser.add_argument('--no-report', action='store_true')
    args = parser.parse_args(argv)
    smoke = args.task == 'smoke'
    root = args.root or protocol.HERE / 'outputs/rebuild_v5' / ('smoke_5_to_50' if smoke else 'formal_5_to_50')
    try:
        from count_selection import load_selection, select_count
        if args.uav_count is not None and args.uav_count not in protocol.COUNTS:
            raise ValueError('UAV count must be one of 5,10,15,20,25,30,35,40,45,50')
        if args.task in ('count', 'smoke'):
            run_suite(protocol.make_config('count', smoke=smoke), root / 'count', not args.no_report)
            if not smoke:
                print('Count evidence is ready. Review count/report/report.md, then use select --uav-count M --reason TEXT.', flush=True)
                return 0
            select_count(root / 'count/results.json', root / 'selection.json', 10 if args.uav_count is None else args.uav_count,
                         'Software validation only; this is not an optimal count claim.', allow_smoke=True)
        if args.task == 'select':
            if sys.stdin.isatty():
                if args.uav_count is None:
                    print('First read count/report/report.md and the count selection table.')
                    args.uav_count = int(input('Enter the selected UAV-BS count (5,10,15,20,25,30,35,40,45,50): ').strip())
                if not args.reason:
                    args.reason = input('Record the selection rationale covering coverage, uniformity and runtime: ').strip()
            if args.uav_count is None or not args.reason:
                raise ValueError('select requires --uav-count and --reason')
            choice = select_count(root / 'count/results.json', root / 'selection.json', args.uav_count, args.reason)
            print(f"Recorded m={choice['selected_count']}. Use continue to run subsequent stages.", flush=True)
            return 0
        if args.task == 'report':
            from report_v5 import generate_report, generate_probe_report
            for stage in ('count', 'ablation', 'comparison'):
                path = root / stage / 'results.json'
                if path.exists():
                    generate_report(path)
            if (root / 'mechanism/results.json').exists():
                generate_probe_report(root / 'mechanism/results.json')
            return 0
        choice = load_selection(root / 'selection.json', allow_smoke=smoke)
        if args.task in ('mechanism', 'continue', 'smoke'):
            from permutation_probe import run_probe
            run_probe(root / 'selection.json', root / 'mechanism', allow_smoke=smoke,
                      make_report=not args.no_report)
        for stage in ('ablation', 'comparison'):
            if args.task in (stage, 'continue', 'smoke'):
                _require_predecessor(root, stage, choice, smoke)
                run_suite(protocol.make_config(stage, choice, smoke=smoke), root / stage, not args.no_report)
        return 0
    except KeyboardInterrupt:
        print('Stopped; completed runs are saved. Repeat the same command to resume.', flush=True)
        return 130
    except (ValueError, FileNotFoundError) as exc:
        print('Cannot continue: ' + str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
