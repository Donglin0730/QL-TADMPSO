# UAV-BS experiment report v5

**FORMAL: complete formal replication**

Stage: count; completed 200/200 runs.

Main version: AHDPSO-derived learning-factor schedule, linear inertia weight, matrix update with per-particle shared random coefficients.

F, SASU, GASU: smaller is better; TC, SAC: larger is better. F keeps the original weights 0.5/0.3/0.2; SAC is a supplementary coverage metric.

Low signal variance at low coverage does not mean good service; coverage and uniformity must be read together. Run time is a single run, includes the method's own extra operations, excluding warm-up.


## Count selection basis

This report provides the data needed for count selection; the selection record and rationale live in selection.json at the experiment root. If that file is missing, no UAV-BS count has been selected yet. The smallest F, the largest count or 25 UAVs must not be called optimal automatically.

Use the table below plus the coverage gain, uniformity improvement, F improvement and time increase per extra 5 UAVs in count_selection_table.csv to record the chosen trade-off and its rationale.

This selection only applies to the given scenario and evaluation budget. If the gains show no clear plateau, that fact must be reported.

Layout figures cover [5, 10, 15, 20, 25, 30, 35, 40, 45, 50] and all use run id 7. This id minimizes the total distance to the median rank within each count; the figures do not stitch the best run of each count.

## 5 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| QL-TADMPSO | 20 | 0.5816 ± 0.0286 | 16.4640 ± 10.8398 | 11.2467 ± 7.6506 | 5.8988 ± 3.8281 | 7.7889 ± 3.6380 | 48.4890 ± 6.6394 |

## 10 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| QL-TADMPSO | 20 | 0.5039 ± 0.0007 | 46.7940 ± 0.1312 | 49.1000 ± 2.9435 | 11.5119 ± 0.0775 | 11.5636 ± 0.0810 | 51.1350 ± 1.1332 |

## 15 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| QL-TADMPSO | 20 | 0.3984 ± 0.0066 | 66.8080 ± 1.0752 | 70.9800 ± 2.6282 | 10.6592 ± 0.2811 | 11.1986 ± 0.0992 | 54.7687 ± 1.6629 |

## 20 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| QL-TADMPSO | 20 | 0.3183 ± 0.0126 | 79.9940 ± 1.7179 | 84.1867 ± 2.3916 | 8.8618 ± 0.5580 | 9.9607 ± 0.3129 | 58.0040 ± 3.7348 |

## 25 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| QL-TADMPSO | 20 | 0.2565 ± 0.0155 | 88.4060 ± 1.8729 | 92.2667 ± 1.6157 | 6.7977 ± 0.6012 | 8.4428 ± 0.6058 | 60.3906 ± 8.3626 |

## 30 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| QL-TADMPSO | 20 | 0.2179 ± 0.0169 | 92.6600 ± 1.3254 | 95.9267 ± 1.9570 | 5.3671 ± 1.0078 | 7.3507 ± 0.5096 | 64.5843 ± 8.9648 |

## 35 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| QL-TADMPSO | 20 | 0.1818 ± 0.0190 | 95.8280 ± 1.1630 | 98.3600 ± 1.0210 | 4.0293 ± 0.8438 | 6.1054 ± 0.7105 | 67.0318 ± 7.8627 |

## 40 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| QL-TADMPSO | 20 | 0.1577 ± 0.0181 | 97.7220 ± 0.9736 | 99.3400 ± 0.4271 | 3.3173 ± 0.6184 | 5.0305 ± 0.8404 | 76.1588 ± 8.6159 |

## 45 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| QL-TADMPSO | 20 | 0.1380 ± 0.0103 | 98.8940 ± 0.4844 | 99.8733 ± 0.1528 | 2.7130 ± 0.2939 | 4.1354 ± 0.6133 | 79.8097 ± 11.4617 |

## 50 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| QL-TADMPSO | 20 | 0.1279 ± 0.0131 | 99.4920 ± 0.4050 | 99.9600 ± 0.0762 | 2.5615 ± 0.3808 | 3.4721 ± 0.7098 | 84.7565 ± 10.5018 |

## Recomputable files

Raw coordinates, actual FE histories, parameters and source hashes are stored in ../results.json and ../source_snapshot. Figure sources and qualification status are stored in report_manifest.json.

Metrics of the final coordinates are re-checked on save and on load. These post-hoc checks and figure recomputations do not participate in the search and do not count toward the optimization budget or run time. Checkpoint files have whole-content validation to prevent edits or missing completed runs.

SAO-MPSO keeps its Cubic initialization; deployment adaptations and parameter sources of the other baselines are in experiments/docs. All methods share the physics model and evaluation backend.
