# UAV-BS experiment report v5

**FORMAL: complete formal replication**

Stage: comparison; completed 140/140 runs.

Main version: AHDPSO-derived learning-factor schedule, linear inertia weight, matrix update with per-particle shared random coefficients.

F, SASU, GASU: smaller is better; TC, SAC: larger is better. F keeps the original weights 0.5/0.3/0.2; SAC is a supplementary coverage metric.

Low signal variance at low coverage does not mean good service; coverage and uniformity must be read together. Run time is a single run, includes the method's own extra operations, excluding warm-up.

Fixed UAV-BS count: 45; rationale: m=45 is chosen as the working point that balances coverage, area uniformity, base-station count and compute time for the given scenario and budget; it is not claimed to be the unique or global optimum. Based on the formal results of 20 runs per count over ten counts, 200 runs in total: at m=45 the mean F=0.137955, TC=98.894%, SAC=99.873%, SASU=2.7130 dB, GASU=4.1354 dB, runtime 79.81 s. Going from 40 to 45 UAVs raises TC by 1.172 percentage points, lowers SASU/GASU by 0.6043/0.8951 dB, and raises mean runtime by 4.79%. Going from 45 to 50 adds 11.11% more base stations while the TC/SAC gains drop to 0.598/0.087 percentage points, SASU drops another 0.1515 dB, and mean runtime rises another 6.20%. The advantage of 50 is kept on record: its mean F is lower and GASU is 0.6633 dB below the 45-UAV value. This is an engineering trade-off judged from the observed marginal gains; no new service hard threshold or objective weight is introduced, and the differences are not called insignificant. The mechanism, ablation and seven-algorithm comparisons all use 45 UAVs with the original model, parameters, budget and preselected seeds.

## 45 UAVs: mean ± sample SD

| Method | N | F | TC (%) | SAC (%) | SASU (dB) | GASU (dB) | Time (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| PSO | 20 | 0.1892 ± 0.0190 | 95.9840 ± 1.2340 | 97.9533 ± 1.2607 | 4.6443 ± 0.9456 | 6.2660 ± 0.6572 | 16.3654 ± 0.3849 |
| AHDPSO | 20 | 0.1970 ± 0.0170 | 95.4640 ± 1.4098 | 97.5467 ± 1.0836 | 4.9760 ± 0.7274 | 6.5429 ± 0.8450 | 16.4598 ± 0.4139 |
| T-ADMPSO (adapted) | 20 | 0.1867 ± 0.0153 | 96.2740 ± 1.1173 | 98.0000 ± 0.8366 | 4.6048 ± 0.6949 | 6.0314 ± 0.7656 | 16.5216 ± 0.4832 |
| AMSEPSO | 20 | 0.2043 ± 0.0138 | 95.1000 ± 1.1564 | 95.6000 ± 1.4183 | 5.6708 ± 0.6995 | 6.0800 ± 0.6282 | 16.5087 ± 0.5900 |
| SDPSO (adapted) | 20 | 0.1027 ± 0.0067 | 99.7540 ± 0.1762 | 99.9867 ± 0.0596 | 1.7105 ± 0.1719 | 2.5608 ± 0.3884 | 17.7062 ± 0.3659 |
| SAO-MPSO | 20 | 0.1031 ± 0.0093 | 99.8380 ± 0.2702 | 100.0000 ± 0.0000 | 1.7490 ± 0.2120 | 2.5754 ± 0.5373 | 16.5034 ± 0.5635 |
| QL-TADMPSO | 20 | 0.1385 ± 0.0138 | 98.8760 ± 0.6984 | 99.8667 ± 0.2029 | 2.7537 ± 0.3545 | 4.1296 ± 0.8590 | 43.3133 ± 2.8544 |

## Paired analysis

In paired_effects.csv the difference direction is reference - comparator; interaction and permutation terms are marked separately. TC/SAC differences are in percentage points.

Formal inferential comparisons: 36. All pre-declared contrasts times six metrics form one Holm-corrected family for this stage.

Formal results give 95% percentile bootstrap intervals of the paired median difference and two-sided Wilcoxon tests. Non-formal results give only descriptive paired differences; inference columns are left blank.

## Recomputable files

Raw coordinates, actual FE histories, parameters and source hashes are stored in ../results.json and ../source_snapshot. Figure sources and qualification status are stored in report_manifest.json.

Metrics of the final coordinates are re-checked on save and on load. These post-hoc checks and figure recomputations do not participate in the search and do not count toward the optimization budget or run time. Checkpoint files have whole-content validation to prevent edits or missing completed runs.

SAO-MPSO keeps its Cubic initialization; deployment adaptations and parameter sources of the other baselines are in experiments/docs. All methods share the physics model and evaluation backend.
