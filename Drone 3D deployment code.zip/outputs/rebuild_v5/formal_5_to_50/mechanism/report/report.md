# Numbering-permutation mechanism check

**FORMAL: mechanism diagnostics of the formal count stage**

Selected count m=45. From 20 run ids; for each id the initial and final deployments are checked, each deployment permuted 20 times.

These permutations are repeated measurements inside one deployment and do not count as extra independent optimization runs. Final optimization performance is tested by the four combined ablations that follow.

Checks the coordinate distance, FSW distance and matching residual of the same layout, plus FSW distance and minimum matching cost changes after independently relabeling two different layouts.

Multiple optimal matchings may give different indices or guide displacements; displacement changes are therefore saved, but permutation consistency is checked via the optimal matching cost, without forcing identical indices.

Physical metric errors are checked against preset numerical tolerances; full per-trial data are in mechanism_trials.csv; raw coordinates and seeds are in ../results.json.

Component timings are statistics of independent calls on fixed inputs; they are neither the time share of the full optimizer nor evidence about final search quality.
