# Selection record of the formal count experiment (2026-09-20)

**Decision: the mechanism validation, ablation and seven-algorithm comparisons all use m=45.**

This is an engineering trade-off made with user authorization based on the complete count experiment. The current objective function includes no UAV-count cost or runtime penalty, so ranking by mean F alone makes 50 UAVs the best among the tested candidates; the current experiments cannot prove that 45 is the unique optimum, nor that no better layout exists outside the candidate range.

## Data source

- Source: `count/results.json`; SHA-256: `07666cdb2b0d366fd391e584984eda6d99e1ed34d93c5e9221f38b783ff5a375`.
- Ten candidate counts, 20 independent runs each; 50 particles, 25,000 actual FEs per run, L=50, G=5.
- The values below are recomputed directly from the raw run records. TC/SAC are percentages, SASU/GASU are in dB; time is in seconds.

| UAV-BS count | F mean | TC mean (%) | SAC mean (%) | SASU mean (dB) | GASU mean (dB) | Time mean (s) | Time median (s) |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 5 | 0.581595 | 16.464 | 11.247 | 5.8988 | 7.7889 | 48.49 | 48.92 |
| 10 | 0.503901 | 46.794 | 49.100 | 11.5119 | 11.5636 | 51.13 | 50.99 |
| 15 | 0.398362 | 66.808 | 70.980 | 10.6592 | 11.1986 | 54.77 | 54.53 |
| 20 | 0.318334 | 79.994 | 84.187 | 8.8618 | 9.9607 | 58.00 | 57.56 |
| 25 | 0.256533 | 88.406 | 92.267 | 6.7977 | 8.4428 | 60.39 | 62.82 |
| 30 | 0.217910 | 92.660 | 95.927 | 5.3671 | 7.3507 | 64.58 | 66.23 |
| 35 | 0.181823 | 95.828 | 98.360 | 4.0293 | 6.1054 | 67.03 | 68.35 |
| 40 | 0.157732 | 97.722 | 99.340 | 3.3173 | 5.0305 | 76.16 | 75.78 |
| 45 | 0.137955 | 98.894 | 99.873 | 2.7130 | 4.1354 | 79.81 | 76.93 |
| 50 | 0.127946 | 99.492 | 99.960 | 2.5615 | 3.4721 | 84.76 | 83.24 |

## Selection basis and cost

m=45 is chosen as the working point that balances coverage, area uniformity, base-station count and compute time for the given scenario and budget; it is not claimed to be the unique or global optimum. Based on the formal results of 20 runs per count over ten counts, 200 runs in total: at m=45 the mean F=0.137955, TC=98.894%, SAC=99.873%, SASU=2.7130 dB, GASU=4.1354 dB, runtime 79.81 s. Going from 40 to 45 UAVs raises TC by 1.172 percentage points, lowers SASU/GASU by 0.6043/0.8951 dB, and raises mean runtime by 4.79%. Going from 45 to 50 adds 11.11% more base stations while the TC/SAC gains drop to 0.598/0.087 percentage points, SASU drops another 0.1515 dB, and mean runtime rises another 6.20%. The advantage of 50 is kept on record: its mean F is lower and GASU is 0.6633 dB below the 45-UAV value. This is an engineering trade-off judged from the observed marginal gains; no new service hard threshold or objective weight is introduced, and the differences are not called insignificant. The mechanism, ablation and seven-algorithm comparisons all use 45 UAVs with the original model, parameters, budget and preselected seeds.

The time medians at 40, 45, 50 UAVs are 75.78, 76.93, 83.24 s, pointing the same way as the means; the timing is subject to system-load fluctuations, so no exact complexity ratio is claimed from it.

At low counts, a lower signal standard deviation alone is not a good outcome. For example at 5 UAVs there are 5 runs with zero coverage in the priority area; the uniform signal-value floor affects the dispersion.

This is not a mathematical optimum derived from service thresholds set after the fact. The original 0.5/0.3/0.2 objective weights are unchanged, and no UAV count or time was secretly added to the objective. The better F and general-area uniformity improvement of 50 UAVs should still be reported as-is in the paper.

## Next steps

Permutation mechanism validation (initial/final deployments of 20 run numbers, 20 permutations each) -> 14 conditions x 20 ablation -> 7 algorithms x 20 comparison.
Each stage reads the same selection.json and re-checks the count results, source and run environment; later optimizations use the preselected independent stage seeds.
