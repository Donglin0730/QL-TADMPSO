# Paper experiment figures

This directory keeps the 7 final experiment PDFs cited by the paper, all byte-identical to the files in the paper directory. The paper adjusted fonts, legends and cropping; the redraw commands use the original data to produce generic versions and do not guarantee recovering the final layout.

## Redraw

Run from the `experiments` directory; the output directory must not exist:

```text
python reproduce.py figures
python reproduce.py figures --device cuda --output outputs/reproduction_figures_cuda
```

CPU can redraw the performance, convergence and permutation-diagnosis figures; GPU can also redraw the 2D/3D deployment and aggregate-power figures. The program first re-verifies the archived data, and GPU mode additionally re-evaluates metrics from the saved coordinates; neither reruns the optimization search.

## Data mapping

Data paths in the table below are relative to `outputs/rebuild_v5/formal_5_to_50/`.

| Paper figure file | Data source | Redrawn file |
| --- | --- | --- |
| `04_UAV-BS_count_vs_performance.pdf` | `count/results.json` | `metrics_vs_uav_count.pdf` |
| `05_2D_deployments_by_count.pdf` | `count/results.json`, `count/report/deployment_coordinates.csv` | `uav_count_layouts_2d.pdf` |
| `06_aggregate_received_power_distribution.pdf` | final coordinates of the 45-UAV, group 8 run in the count experiment | `aggregate_received_power_45.pdf` |
| `07_permutation_mechanism_diagnosis.pdf` | `mechanism/results.json` | `mechanism_diagnostics.pdf` |
| `12_seven_algorithm_convergence_curves.pdf` | evaluation counts and history best values in `comparison/results.json` | `convergence_by_fes.pdf` |
| `13_seven_algorithm_final_performance.pdf` | `comparison/results.json` | `metrics_by_method.pdf` |
| `14_3D_deployments_by_count.pdf` | same as the 2D deployment figure | `uav_count_layouts_3d.pdf` |

The deployment figures share run number `i=7`, i.e. group 8. That number minimizes the total distance of the objective-value rank from the middle rank of each group across the ten counts, ties broken toward the smaller number; it is not a best pick per figure. The power figure uses the 45-UAV layout of the same group, keeps the 50 x 50 original grid without interpolation; uncovered points are -100 dBm.

The 40 layouts of the permutation diagnosis come from 20 runs; the 800 re-numberings inside are not counted as independent optimization samples. The figure's timing takes the median within each layout first, then the median across initial/final layouts; it cannot be used to infer the per-module time share of a full run.

## Layout and provenance notes

- The final version of figure 04 marks the 45-UAV choice; the generic redraw does not restore this mark.
- Figure 06 has subscript edits at the PDF level; figure 14 had its legend adjusted. The full final-layout generation script was not recovered; the new export tool is not the original plotting script of these figures.
- The paper crops figure 14 with LaTeX, showing only the 45-UAV subplot and the shared legend; the redraw outputs the full ten-count figure. The 3D height axis is visually stretched, values stay in meters.
- Every export saves `verification/verification.json` and `export_manifest.json`, recording data and file digests; GPU mode additionally outputs coordinate and power-grid CSVs. Figure manifests in older archives may point to PDFs/PNGs no longer in the archive; they are kept as history.

Uncited figures 08-11, 15 and external references are not in this directory. On Windows, the first CuPy compile may need a writable `TEMP`/`TMP` path that contains no Chinese characters.
