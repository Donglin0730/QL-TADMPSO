"""SAO-MPSO from Hu et al. (2024), adapted to an actual-FE budget.

Equations (3.5)-(3.9), (4.1)-(4.10) and Algorithm 2 are implemented
independently of the incomplete SAO-MPSO baseline in the DNA release.
Author code was unavailable; see docs/saompso_implementation.md for the
source hierarchy, explicit ambiguities and deployment-specific choices.
"""
import numpy as np

from baseline_support import SearchBudget
from scenario import DEFAULT_SCENARIO


def cubic_sequence(seeds, count):
    """Eq. (4.1): a separate recurrence for each supplied coordinate seed."""
    seeds = np.asarray(seeds, dtype=float)
    sequence = np.empty((int(count), seeds.size), dtype=float)
    sequence[0] = seeds
    for i in range(1, len(sequence)):
        previous = sequence[i - 1]
        sequence[i] = 2.59 * previous * (1.0 - previous ** 2)
    return sequence


def initialize_population(rng, n_p, lower, upper):
    """Map Cubic chains into scenario bounds; initialize velocity to zero."""
    lower, upper = np.asarray(lower), np.asarray(upper)
    seeds = np.clip(rng.random(len(lower)), np.finfo(float).eps,
                    1.0 - np.finfo(float).eps)
    x = lower + cubic_sequence(seeds, n_p) * (upper - lower)
    return x, np.zeros_like(x)


def saompso_parameters(progress):
    """Paper schedules with post-initialization FE progress replacing it/T."""
    p = float(np.clip(progress, 0.0, 1.0))
    c1 = np.sin(3.0 * np.pi * p) + 1.5
    c2 = np.cos(3.0 * np.pi * p) + 1.5
    c = c1 + c2
    return {
        "c1": float(c1),
        "c2": float(c2),
        "F": float(2.0 / (2.0 + np.log10(c) + abs(1.0 - np.sqrt(c) / 2.0))),
        "w": float(0.3 * np.sin(2.0 * np.pi * p) + 0.6),
        "velocity_scale": float(1.0 - np.log10(1.0 + 8.0 * p)),
        "M": float((0.35 + 0.25 * np.expm1(p) / np.expm1(1.0)) * np.exp(-p)),
    }


def pso_step(x, v, pbest, gbest, brownian, r1, params, vmax):
    """Eqs. (4.2)-(4.3), with the symmetric dynamic velocity limit."""
    attraction = (pbest - x) + (gbest - x) + (gbest - pbest)
    new_v = brownian * params["w"] * v + params["F"] * r1 * attraction
    new_v = np.clip(new_v, -vmax, vmax)
    return x + new_v, new_v


def snow_step(x, gbest, mean, elite, brownian, r2):
    """Eq. (4.4), also used by the exploration branch of Eq. (4.10)."""
    return elite + brownian * (r2 * (gbest - x) + (1.0 - r2) * (mean - x))


def memory_step(x, v, pbest, gbest, mean, elite, brownian, r1, r2,
                explore, params, vmax):
    """Eq. (4.10): select a complete update rule once for each particle."""
    snow = snow_step(x, gbest, mean, elite, brownian, r2)
    attraction = (pbest - x) + (gbest - x) + (gbest - pbest)
    melting_v = params["w"] * v + params["M"] * r1 * attraction
    melting_v = np.clip(melting_v, -vmax, vmax)
    choose_snow = np.asarray(explore, dtype=bool)[:, None]
    # Snow has no velocity update in the paper: retain the particle's memory.
    return (np.where(choose_snow, snow, x + melting_v),
            np.where(choose_snow, v, melting_v))


def elite_pool(x, fitness, archived_best):
    """Eqs. (3.5)-(3.7); ranking never rearranges particle state arrays."""
    order = np.argsort(fitness, kind="stable")
    top_count = len(x) // 2
    return np.vstack((archived_best, x[order[1]], x[order[2]],
                      x[order[:top_count]].mean(axis=0)))


def _evaluate_phase(budget, x, v, fitness, pbest, pfitness,
                    candidates, candidate_v):
    """Evaluate a full phase, or its fixed-index prefix at the FE limit.

    Commit only evaluated positions and their velocities. Historical best
    states remain associated with the same particle index throughout.
    """
    count = min(len(x), budget.remaining)
    bounded = np.clip(candidates[:count], budget.lower, budget.upper)
    values, _ = budget.evaluate(bounded)
    x[:count], v[:count], fitness[:count] = bounded, candidate_v[:count], values
    improved = np.flatnonzero(values < pfitness[:count])
    pbest[improved] = x[improved]
    pfitness[improved] = values[improved]
    return count


def run_saompso(rng, priority, mode, n_p=50, max_fes=25000,
                scenario=DEFAULT_SCENARIO):
    """Run the two-species search and subsequent memory phases exactly to FE.

    ``n_updates`` counts entered outer iterations; ``phase_history`` records
    every evaluated candidate phase. Once Nb reaches zero, an outer iteration
    contains both a PSO phase and a separate memory phase when budget permits.
    """
    budget = SearchBudget(rng, priority, mode, n_p, max_fes, scenario)
    if budget.n_p < 3:
        raise ValueError("SAO-MPSO requires at least three particles for its elite pool")
    n_p = budget.n_p
    x, v = initialize_population(rng, n_p, budget.lower, budget.upper)
    fitness, _ = budget.evaluate(x)
    pbest, pfitness = x.copy(), fitness.copy()
    base_vmax = 0.2 * (budget.upper - budget.lower)
    na, nb = n_p // 2, n_p - n_p // 2
    diagnostics = {
        "implementation": "paper_equations_algorithm2_with_documented_adaptations",
        "settings": {
            "cubic_rho": 2.59,
            "cubic_layout": "one_coordinate_seed_then_recurrence_across_particles",
            "initial_velocity": "zero",
            "base_vmax_span_fraction": 0.2,
            "parameter_progress": "post_initialization_actual_fes_at_phase_start",
            "r1_interval": [0.0, 1.0],
            "r2_interval": [-1.0, 1.0],
            "memory_branch": "one_equal_probability_choice_per_particle",
            "tail_selection": "ascending_stable_particle_index_prefix",
            "no_op_second_evaluation_before_memory": "omitted_and_not_charged",
        },
        "phase_counts": {"dual_species": 0, "pso": 0, "memory": 0},
        "phase_candidate_counts": {"dual_species": 0, "pso": 0, "memory": 0},
        "phase_history": [],
        "group_counts": [],
        "memory_snow_candidates": 0,
        "memory_melting_candidates": 0,
    }

    def evaluate_phase(phase, candidates, velocities, progress, iteration):
        before = budget.fes
        count = _evaluate_phase(budget, x, v, fitness, pbest, pfitness,
                                candidates, velocities)
        diagnostics["phase_counts"][phase] += 1
        diagnostics["phase_candidate_counts"][phase] += count
        diagnostics["phase_history"].append({
            "iteration": iteration, "phase": phase, "evaluated": count,
            "fes_before": before, "fes_after": budget.fes, "progress": progress,
        })
        return count

    iteration = 0
    while budget.remaining:
        iteration += 1
        progress = budget.progress
        params = saompso_parameters(progress)
        vmax = base_vmax * params["velocity_scale"]
        elite = elite_pool(x, fitness, budget.best_pos)
        mean, gbest = x.mean(axis=0), budget.best_pos.copy()
        brownian = rng.standard_normal(x.shape)
        zone1 = rng.permutation(n_p)[:na]
        # Original SAO uses setdiff: the complementary indices are ascending.
        zone2 = np.setdiff1d(np.arange(n_p), zone1, assume_unique=True)
        na_before, nb_before = na, nb
        candidates, velocities = x.copy(), v.copy()
        candidates[zone1], velocities[zone1] = pso_step(
            x[zone1], v[zone1], pbest[zone1], gbest, brownian[zone1],
            rng.random((na, 1)), params, vmax,
        )
        # Algorithm 2 increments before the snow loop: one old snow member
        # stays unchanged during a transition, but is still evaluated below.
        if na < n_p:
            na, nb = na + 1, nb - 1
        snow_indices = zone2[:nb]
        if nb:
            candidates[snow_indices] = snow_step(
                x[snow_indices], gbest, mean, elite[rng.integers(4, size=nb)],
                brownian[snow_indices], rng.uniform(-1.0, 1.0, size=(nb, 1)),
            )
        phase = "dual_species" if nb_before else "pso"
        count = evaluate_phase(phase, candidates, velocities, progress, iteration)
        zone1_evaluated = int(np.count_nonzero(zone1 < count))
        zone2_evaluated = int(np.count_nonzero(snow_indices < count))
        diagnostics["group_counts"].append({
            "iteration": iteration, "na_before": na_before, "nb_before": nb_before,
            "na_after": na, "nb_after": nb,
            "zone1_planned": len(zone1), "zone2_planned": len(snow_indices),
            "unchanged_planned": n_p - len(zone1) - len(snow_indices),
            "zone1_evaluated": zone1_evaluated,
            "zone2_evaluated": zone2_evaluated,
            "unchanged_evaluated": count - zone1_evaluated - zone2_evaluated,
            "evaluated": count,
        })

        if nb == 0 and budget.remaining:
            # This is an additional candidate/evaluation phase, not a switch
            # replacing the first phase once all particles belong to zone1.
            progress = budget.progress
            params = saompso_parameters(progress)
            vmax = base_vmax * params["velocity_scale"]
            elite = elite_pool(x, fitness, budget.best_pos)
            explore = rng.random(n_p) < 0.5
            candidates, velocities = memory_step(
                x, v, pbest, budget.best_pos.copy(), x.mean(axis=0),
                elite[rng.integers(4, size=n_p)], rng.standard_normal(x.shape),
                rng.random((n_p, 1)), rng.uniform(-1.0, 1.0, size=(n_p, 1)),
                explore, params, vmax,
            )
            count = evaluate_phase("memory", candidates, velocities, progress, iteration)
            snow_count = int(np.count_nonzero(explore[:count]))
            diagnostics["memory_snow_candidates"] += snow_count
            diagnostics["memory_melting_candidates"] += count - snow_count

    return budget.result(iteration, diagnostics=diagnostics)
