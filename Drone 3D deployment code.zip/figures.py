"""Reporting figures (implementation plan §4.0): convergence curves, k
trajectories, deployment layouts (2D/3D), five-metric distribution comparison
+ Wilcoxon significance annotations.

Usage: python figures.py [results.json]  -> outputs to figures/
"""
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei",
                                          "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from mpl_toolkits.mplot3d import Axes3D   # import registers the 3d projection, required for add_subplot(projection="3d")
import numpy as np
from scipy import stats

import model
from report import (
    FORMAL_ALGORITHMS, VARIANT_LABEL, VARIANT_ORDER, ablation_summary,
    paired_comparison_rows, result_kind,
    validate_results as validate_report_results,
)
from scenario import DeploymentScenario, ScenarioConfig, coverage_radius

HERE = os.path.dirname(os.path.abspath(__file__))
FIG_DIR = os.path.join(HERE, "figures")
ALGO_LABEL = {
    "pso": "PSO", "ahdpso": "AHDPSO",
    "tadmpso": "T-ADMPSO (adapted)", "ql": "QL-TADMPSO",
}
ALGO_COLOR = {
    "pso": "#1f77b4", "ahdpso": "#2ca02c",
    "tadmpso": "#9467bd", "ql": "#d62728",
}
SCHEMA_VERSION = model.MODEL_VERSION
PRIORITY_LABEL = "priority service area"


def validate_results(data):
    return validate_report_results(data)


def scenario_for_run(run, root_config):
    """Rebuild the fixed scenario for a run; do not mask corrupted v3 data."""
    serialized = run.get("scenario")
    if serialized is None:
        serialized = root_config.get("scenario")
    if serialized is None:
        return model.DEFAULT_SCENARIO
    if not isinstance(serialized, dict):
        raise ValueError("serialized scenario must be an object")
    try:
        return DeploymentScenario(ScenarioConfig.from_dict(serialized))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid serialized scenario: {exc}") from exc


def _grid_for_imshow(values, scenario=model.DEFAULT_SCENARIO):
    """Convert the model's flat ``[x,y]`` order to imshow's ``[row=y,col=x]``."""
    array = np.asarray(values)
    n_grid = scenario.config.n_grid
    if array.size != n_grid * n_grid:
        raise ValueError("grid value count mismatch")
    return array.reshape(n_grid, n_grid).T


def _set_planar_domain(ax, scenario=model.DEFAULT_SCENARIO):
    """Coverage circles may cross the boundary; the axes stay fixed on the study area."""
    area = scenario.config.area_m
    ax.set_xlim(0.0, area)
    ax.set_ylim(0.0, area)
    ax.set_aspect("equal", adjustable="box")


def _priority_overlay_points(mask_xy, axis):
    """Return physical coordinates of the priority cells in the ``[x,y]`` mask for the 3D ground overlay."""
    x_index, y_index = np.nonzero(np.asarray(mask_xy, dtype=bool))
    return np.asarray(axis)[x_index], np.asarray(axis)[y_index]


def _paired_representative_runs(runs):
    """Pick one jointly centered paired run for side-by-side multi-algorithm panels.

    Rank runs within each algorithm by F, then pick the common run minimizing
    the sum of absolute distances to each algorithm's median rank; this avoids
    stitching each algorithm's own best case into one incomparable figure.
    """
    algos = [algo for algo in FORMAL_ALGORITHMS if runs.get(algo)]
    if not algos:
        return {}
    by_algo = {}
    for algo in algos:
        by_id = {int(run["i"]): run for run in runs[algo]}
        if len(by_id) != len(runs[algo]):
            raise ValueError(f"duplicate run ids for {algo}")
        by_algo[algo] = by_id
    common = set.intersection(*(set(by_algo[algo]) for algo in algos))
    if not common:
        raise ValueError("comparative deployment requires paired run ids")
    ids = sorted(common)
    target = (len(ids) - 1) / 2.0
    distance = {run_id: 0.0 for run_id in ids}
    for algo in algos:
        values = [by_algo[algo][run_id]["best_F"] for run_id in ids]
        ranks = stats.rankdata(values, method="average") - 1.0
        for run_id, rank in zip(ids, ranks):
            distance[run_id] += abs(float(rank) - target)
    selected_id = min(ids, key=lambda run_id: (distance[run_id], run_id))
    selected = {algo: by_algo[algo][selected_id] for algo in algos}
    priority_seeds = {int(run["priority_seed"]) for run in selected.values()}
    if len(priority_seeds) != 1:
        raise ValueError("paired representative runs must share priority_seed")
    optimization_seeds = {int(run["seed"]) for run in selected.values()
                          if "seed" in run}
    if len(optimization_seeds) > 1:
        raise ValueError("paired representative runs must share optimization seed")
    return selected


def fes_axis(history_length, n_p):
    """History point 0 is the gbest after initialization, so the x-axis starts at NP, not 0."""
    return (np.arange(int(history_length), dtype=np.int64) + 1) * int(n_p)


def load_runs(path):
    with open(path, encoding="utf-8") as f:
        data = validate_results(json.load(f))
    runs = {}
    for r in data["runs"]:
        runs.setdefault(r["algo"], []).append(r)
    return runs, data.get("config", {})


def plot_convergence(runs, config, tag):
    n_p = config.get("n_p", 50)
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    final_fes = None
    for algo in FORMAL_ALGORITHMS:
        hs = [r["gF_history"] for r in runs.get(algo, [])]
        if not hs:
            continue
        hs = np.array(hs)
        fes = fes_axis(hs.shape[1], n_p)
        final_fes = fes[-1] if final_fes is None else max(final_fes, fes[-1])
        mean = hs.mean(axis=0)
        std = hs.std(axis=0)
        ax.plot(fes, mean, label=ALGO_LABEL[algo], color=ALGO_COLOR[algo])
        ax.fill_between(fes, mean - std, mean + std, alpha=0.2,
                        color=ALGO_COLOR[algo])
    if final_fes is None:
        plt.close(fig)
        return
    ax.set_xlim(0, final_fes * 1.03)   # starts at 0, 3% headroom on the right, aligned with auto ticks
    ax.set_xlabel("FEs")
    ax.set_ylabel("F (gbest)")
    ax.grid(ls="--", alpha=0.35)
    ax.set_axisbelow(True)
    ax.legend()
    ax.set_title(f"Convergence ({len(hs)} runs, NP={n_p})")
    fig.tight_layout()
    out = os.path.join(FIG_DIR, f"convergence_{tag}.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("saved", out)


def _k_frequency(ql_runs):
    """Frequency of k per decision point. Returns (decision iterations, {iteration: {k: run count}})."""
    its = [it for it, _ in ql_runs[0]["k_history"]]
    counts = {it: {} for it in its}
    for r in ql_runs:
        for it, k in r["k_history"]:
            counts[it][k] = counts[it].get(k, 0) + 1
    return its, counts


def plot_k_trajectory(runs, tag):
    """k trajectory plot: one line per run (20 runs). k takes only a few
    integers (13-16 in practice), so overlapping lines would fully coincide;
    each line gets a fixed vertical jitter (±0.14, fixed seed, reproducible)
    to fan the bundle out. Major ticks are integer k, minor ticks every 0.5.
    A mode-k line (no jitter, dashed) summarizes the overall decision trend."""
    ql = runs.get("ql", [])
    if not ql:
        return
    its, counts = _k_frequency(ql)
    if not its:                     # edge case: k_history empty (e.g. G>T) -> skip the figure
        print("skip k_trajectory: k_history is empty")
        return
    n_runs = len(ql)
    rng = np.random.default_rng(42)   # fixed jitter seed: same figure for the same results file every time
    offsets = rng.uniform(-0.14, 0.14, n_runs)

    fig, ax = plt.subplots(figsize=(7.8, 4.6))
    for i, r in enumerate(ql):
        ks = [k for _, k in r["k_history"]]
        ax.plot(its, np.array(ks) + offsets[i], color=ALGO_COLOR["ql"],
                lw=0.9, alpha=0.55, zorder=2,
                label="individual runs (vertical jitter)" if i == 0 else None)
    # mode line: most frequent k per decision point, summarizes the Q-learning decision trend
    mode_k = [max(counts[it], key=counts[it].get) for it in its]
    ax.plot(its, mode_k, color="0.12", lw=1.8, ls="--", marker="o",
            ms=4.5, mfc="white", mec="0.12", mew=1.2, zorder=3,
            label="mode k (per decision point)")

    ks = sorted({k for r in ql for _, k in r["k_history"]})
    ax.set_yticks(ks)
    # minor ticks every 0.5 to read the jitter; major grid only at integer k
    ax.set_yticks(np.arange(min(ks) - 0.5, max(ks) + 0.6, 0.5), minor=True)
    ax.set_ylim(min(ks) - 0.35, max(ks) + 0.35)   # jitter is ±0.14, keep 0.35 margin above and below
    ax.set_xlim(0, its[-1] * 1.03)
    ax.set_xlabel("iteration", fontsize=11)
    ax.set_ylabel("k (subpopulations)", fontsize=11)
    ax.tick_params(labelsize=9)
    ax.tick_params(axis="y", which="minor", length=3)
    ax.grid(ls="--", alpha=0.3, lw=0.7)
    ax.grid(axis="y", which="minor", ls=":", alpha=0.15, lw=0.5)
    ax.set_axisbelow(True)
    ax.set_title("QL-TADMPSO: k trajectory "
                 f"({n_runs} runs × {len(its)} decisions)", fontsize=12)
    ax.legend(loc="lower right", frameon=False, fontsize=9)

    fig.text(0.5, 0.02,
             f"k is an integer, so {n_runs} trajectories fully coincide; each line gets a vertical jitter of ±0.14 "
             f"(fixed seed, display only) to fan out the overlapping bundle; the dashed line is the mode k per decision point",
             ha="center", fontsize=8.5, color="0.35")
    fig.subplots_adjust(bottom=0.15, right=0.97)
    out = os.path.join(FIG_DIR, f"k_trajectory_{tag}.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("saved", out)


def _priority_mask_for_run(run, root_config, scenario):
    if "scenario" not in run and "scenario" not in root_config:
        return model.priority_mask(run["priority_seed"])
    return scenario.priority_mask(run["priority_seed"])


def plot_deployment(runs, tag, mode="a2g", root_config=None):
    """Plot the SNR field, priority area and coverage of each algorithm for one paired representative run."""
    root_config = {} if root_config is None else root_config
    selected = _paired_representative_runs(runs)
    scenarios = {
        algo: scenario_for_run(run, root_config)
        for algo, run in selected.items()
    }
    serialized = {
        json.dumps(scenario.config.to_dict(), sort_keys=True)
        for scenario in scenarios.values()
    }
    if len(serialized) > 1:
        raise ValueError("paired deployment figures must share one scenario")
    for algo in FORMAL_ALGORITHMS:
        if algo not in selected:
            continue
        best = selected[algo]
        scenario = scenarios[algo]
        mask = _priority_mask_for_run(best, root_config, scenario)
        mask2d = _grid_for_imshow(mask, scenario)
        pos = np.array(best["best_pos"]).reshape(scenario.config.n_uav, 3)
        snr, covered = scenario.snr_field(pos, mode=mode)
        field = _grid_for_imshow(snr, scenario)
        cov = _grid_for_imshow(covered, scenario)
        extent = [0.0, scenario.config.area_m, 0.0, scenario.config.area_m]

        fig, axes = plt.subplots(1, 2, figsize=(12, 4.6),
                                 gridspec_kw={"width_ratios": [1, 1]})
        # left: SNR heatmap
        im = axes[0].imshow(field, origin="lower", extent=extent,
                            cmap="viridis", aspect="equal")
        axes[0].imshow(mask2d, origin="lower", extent=extent,
                       cmap="Reds", alpha=0.30, vmin=0, vmax=1)
        axes[0].scatter(pos[:, 0], pos[:, 1], marker="^", s=30, c="white",
                        edgecolors="k", label="UAV")
        axes[0].set_title(
            f"{ALGO_LABEL[algo]}: best run i={best.get('i', '?')}, "
            f"priority seed={best['priority_seed']}"
        )
        axes[0].legend(handles=[
            Patch(facecolor="red", alpha=0.30, label=PRIORITY_LABEL)],
            loc="lower right", fontsize=8)
        fig.colorbar(im, ax=axes[0], label="SNR (dB)")
        # right: coverage map
        axes[1].imshow(cov, origin="lower", extent=extent,
                       cmap="Greys", aspect="equal", vmin=0, vmax=1)
        axes[1].imshow(mask2d, origin="lower", extent=extent,
                       cmap="Reds", alpha=0.30, vmin=0, vmax=1)
        for (x, y, h) in pos:
            axes[1].add_patch(plt.Circle((x, y), coverage_radius(h),
                                         fill=False, ec="tab:green", lw=0.6))
        axes[1].scatter(pos[:, 0], pos[:, 1], marker="^", s=30, c="red")
        _set_planar_domain(axes[0], scenario)
        _set_planar_domain(axes[1], scenario)
        m = best["final_metrics"]
        axes[1].set_title(f"TC={m['TC']*100:.2f}% SAC={m['SAC']*100:.2f}% "
                          f"F={best['best_F']:.4f}")
        fig.tight_layout()
        out = os.path.join(FIG_DIR, f"deployment_{tag}_{algo}.png")
        fig.savefig(out, dpi=200)
        plt.close(fig)
        print("saved", out)


def plot_deployment_3d(runs, tag, mode="a2g", root_config=None):
    """3D deployment of the same jointly selected paired run for each available algorithm."""
    root_config = {} if root_config is None else root_config
    selected = _paired_representative_runs(runs)
    algorithms = [algo for algo in FORMAL_ALGORITHMS if algo in selected]
    if not algorithms:
        return
    scenarios = {
        algo: scenario_for_run(selected[algo], root_config)
        for algo in algorithms
    }
    serialized = {
        json.dumps(scenario.config.to_dict(), sort_keys=True)
        for scenario in scenarios.values()
    }
    if len(serialized) != 1:
        raise ValueError("paired deployment panels must share one scenario")
    scenario = scenarios[algorithms[0]]
    n_grid = scenario.config.n_grid
    step = max(1, int(np.ceil(n_grid / 100.0)))
    indices = np.arange(0, n_grid, step, dtype=int)
    axis = scenario.grid_axis[indices]
    X, Y = np.meshgrid(axis, axis, indexing="ij")

    panels = {}
    for algo in algorithms:
        best = selected[algo]
        pos = np.array(best["best_pos"]).reshape(scenario.config.n_uav, 3)
        snr, _ = scenario.snr_field(pos, mode=mode)
        field = snr.reshape(n_grid, n_grid)[np.ix_(indices, indices)]
        mask = _priority_mask_for_run(best, root_config, scenario)
        mask2d = mask.reshape(n_grid, n_grid)[np.ix_(indices, indices)]
        panels[algo] = (best, pos, field, mask2d)
    fields = [panel[2] for panel in panels.values()]
    norm = plt.Normalize(
        min(field.min() for field in fields),
        max(field.max() for field in fields),
    )

    fig = plt.figure(figsize=(4.8 * len(algorithms) + 1.0, 4.25))
    for index, algo in enumerate(algorithms):
        ax = fig.add_subplot(1, len(algorithms), index + 1, projection="3d")
        best, pos, field, mask2d = panels[algo]
        ax.plot_surface(
            X, Y, np.zeros_like(X),
            facecolors=plt.cm.viridis(norm(field)),
            shade=True, antialiased=False,
        )
        priority_x, priority_y = _priority_overlay_points(mask2d, axis)
        ax.scatter(
            priority_x, priority_y, np.full_like(priority_x, 30.0),
            marker="s", s=14, c="red", alpha=0.50,
            edgecolors="none", depthshade=False,
        )
        for x, y, height in pos:
            ax.plot(
                [x, x], [y, y], [0.0, height],
                color="0.45", lw=0.7, alpha=0.65,
            )
            theta = np.linspace(0.0, 2.0 * np.pi, 48)
            radius = coverage_radius(height)
            ax.plot(
                x + radius * np.cos(theta), y + radius * np.sin(theta),
                0.0, color="tab:green", lw=0.6, alpha=0.8,
            )
        ax.scatter(
            pos[:, 0], pos[:, 1], pos[:, 2], marker="^", s=36,
            c="crimson", depthshade=False,
        )
        metrics = best["final_metrics"]
        ax.set_title(
            f"{ALGO_LABEL[algo]}\nTC={metrics['TC']*100:.2f}%  "
            f"SAC={metrics['SAC']*100:.2f}%  F={best['best_F']:.4f}",
            fontsize=9.5,
        )
        ax.view_init(elev=30, azim=-60)
        ax.set_zlim(0.0, scenario.config.h_max_m * 1.08)
        ax.set_box_aspect((1, 1, 0.18), zoom=1.24)
        ax.set_axis_off()
    mappable = plt.cm.ScalarMappable(norm=norm, cmap="viridis")
    colorbar_ax = fig.add_axes([0.945, 0.18, 0.010, 0.58])
    fig.colorbar(mappable, cax=colorbar_ax, label="SNR (dB)")
    representative = selected[algorithms[0]]
    fig.suptitle(
        f"Paired representative run i={representative['i']}, "
        f"priority seed={representative['priority_seed']} "
        "(red ground cells: priority service area)",
        fontsize=11,
    )
    fig.subplots_adjust(
        left=0.005, right=0.93, bottom=0.01, top=0.82, wspace=-0.02
    )
    out = os.path.join(FIG_DIR, f"deployment_3d_{tag}.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("saved", out)


def _metric_values(runs, algo, m):
    if m == "best_F":
        return np.array([r["best_F"] for r in runs[algo]])
    return np.array([r["final_metrics"][m] for r in runs[algo]])


def _wilcoxon_p(va, vb):
    """Paired Wilcoxon; returns p=1 instead of nan when all differences are 0 (e.g. saturated TC)."""
    d = va - vb
    if np.all(d == 0):
        return 1.0
    p = stats.wilcoxon(va, vb).pvalue
    return p if np.isfinite(p) else 1.0


def _distribution_test_map(runs):
    """Shares one complete Holm test family with the report."""
    return {(row["metric"], row["a"], row["b"]): row
            for row in paired_comparison_rows(runs)}


def _panel_ylim(ymin, ymax, span, scale, n_brackets=0):
    """Reserve vertical space for significance brackets of each QL-vs-baseline pair."""
    required_fraction = (
        0.20 + 0.15 * (int(n_brackets) - 1)
        if n_brackets else 0.0
    )
    top = ymax + max(0.50, required_fraction) * span
    if scale == 100.0 and int(n_brackets) <= 2:
        top = min(top, 100.0 + 0.40 * span)
    return ymin - 0.10 * span, top


def plot_distribution(runs, tag):
    """Five-metric distribution using the report's complete Holm family."""
    algos = [algo for algo in FORMAL_ALGORITHMS if runs.get(algo)]
    if len(algos) < 2:
        return
    pos_of = {a: i for i, a in enumerate(algos)}
    jrng = np.random.default_rng(42)   # fixed jitter seed: same figure for the same results file every time
    specs = [("best_F", "F", 1.0, "%.3f"), ("TC", "TC (%)", 100.0, "%.1f"),
             ("SAC", "SAC (%)", 100.0, "%.1f"),
             ("SASU", "SASU (dB) ↓", 1.0, "%.2f"),
             ("GASU", "GASU (dB) ↓", 1.0, "%.2f")]
    sub_labels = ("a", "b", "c", "d", "e")   # (a)-(e) panel labels

    test_map = _distribution_test_map(runs)
    fig, axes = plt.subplots(1, 5, figsize=(17.0, 5.0))
    sig_ps = []
    for pi, (ax, (m, label, scale, fmt)) in enumerate(zip(axes, specs)):
        data = {a: _metric_values(runs, a, m) * scale for a in algos}
        bp = ax.boxplot([data[a] for a in algos], positions=range(len(algos)),
                        patch_artist=True, widths=0.56, showfliers=False,
                        medianprops=dict(color="white", lw=2.2),
                        whiskerprops=dict(color="0.3", lw=1.0),
                        capprops=dict(color="0.3", lw=1.0))
        for patch, a in zip(bp["boxes"], algos):
            patch.set_facecolor(ALGO_COLOR[a])
            patch.set_alpha(0.62)
            patch.set_linewidth(1.1)
            patch.set_edgecolor("0.2")
        # mean diamond marker: dark fill + white edge, distinct from the white median line
        for j, a in enumerate(algos):
            ax.scatter([j], [np.mean(data[a])], marker="D", s=34,
                       facecolor="0.15", edgecolors="white", linewidths=0.9,
                       zorder=5)
        # jittered scatter (all runs): ±0.055 along x so equal values do not overlap
        for j, a in enumerate(algos):
            ax.scatter(j + jrng.normal(0.0, 0.055, len(data[a])), data[a],
                       s=15, alpha=0.55, color=ALGO_COLOR[a],
                       edgecolors="white", linewidths=0.4, zorder=3)

        ymin = min(v.min() for v in data.values())
        ymax = max(v.max() for v in data.values())
        span = max(ymax - ymin, 0.02 * abs(ymax) if ymax else 0.02)
        # when all values are equal (e.g. TC all 100%), fall back to a span of 0.02*|ymax| to avoid zero span
        pairs = [("ql", baseline) for baseline in algos if baseline != "ql"
                 and "ql" in data]
        for k, (a, b) in enumerate(pairs):
            row = test_map[(m, a, b)]
            p_holm = row["p_holm"]
            if p_holm < 0.05:
                sig_ps.append(p_holm)
                # bracket heights: 0.15 span for pair 1, 0.33 for pair 2, offset so they do not overlap
                # (max 0.36 span < the 0.40 span cap of percentage panels)
                lvl = ymax + (0.10 + 0.15 * k) * span
                x0, x1 = pos_of[a], pos_of[b]
                ax.plot([x0, x0, x1, x1],
                        [lvl, lvl + 0.03 * span, lvl + 0.03 * span, lvl],
                        color="0.15", lw=1.1)   # end ticks are 0.03 span tall
        ax.set_ylim(
            _panel_ylim(ymin, ymax, span, scale, n_brackets=len(pairs))
        )
        ax.set_xticks([])
        ax.yaxis.set_major_formatter(plt.FormatStrFormatter(fmt))
        ax.set_title(label, fontsize=12, pad=10)
        ax.text(0.02, 0.98, f"({sub_labels[pi]})", transform=ax.transAxes,
                fontsize=12, fontweight="bold", va="top", ha="left")
        ax.spines[["top", "right"]].set_visible(False)
        ax.spines[["left", "bottom"]].set_linewidth(0.8)
        ax.grid(axis="y", ls="--", alpha=0.3, lw=0.7)
        ax.set_axisbelow(True)
        ax.tick_params(labelsize=9)

    n_runs = len(next(iter(runs.values())))
    fig.legend(handles=[Patch(facecolor=ALGO_COLOR[a], alpha=0.75,
                              edgecolor="0.2")
                        for a in algos],
               labels=[ALGO_LABEL[a] for a in algos],
               ncol=len(algos), loc="upper center",
               bbox_to_anchor=(0.5, 1.0), frameon=False, fontsize=11,
               handlelength=1.4, columnspacing=1.8)
    if sig_ps and max(sig_ps) < 0.001:
        sig_text = "all shown comparisons Holm p<0.001"
    elif sig_ps:
        sig_text = "Holm p<0.05"
    else:
        sig_text = "Holm p>=0.05, no brackets"
    fig.text(0.5, 0.02,
             f"Distribution of each metric over {n_runs} runs: box plots (white line = median, diamond = mean, "
             f"box = IQR) plus all data points; groups joined by a bracket above differ significantly "
             f"(paired Wilcoxon, {sig_text}); every bracket is QL-TADMPSO vs a baseline; "
             f"exact p values are in the report tables",
             ha="center", fontsize=8.5, color="0.35")
    fig.subplots_adjust(left=0.055, right=0.995, top=0.88, bottom=0.18,
                        wspace=0.30)
    out = os.path.join(FIG_DIR, f"distribution_{tag}.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("saved", out)


def plot_q_diagnostics(runs, tag):
    """Four-panel diagnostics: Q values, state-action visits, action frequency and interval rewards."""
    ql = [run for run in runs.get("ql", []) if "q_table" in run]
    if not ql:
        return
    q_mean = np.mean([np.asarray(run["q_table"], dtype=float) for run in ql], axis=0)
    visits = np.sum([np.asarray(run["q_visits"], dtype=float) for run in ql], axis=0)
    action_counts = np.zeros(3, dtype=int)
    reward_updates, rewards = [], []
    for run in ql:
        for item in run.get("action_history", []):
            action_counts[int(item["action"])] += 1
        for item in run.get("reward_history", []):
            reward_updates.append(int(item["update"]))
            rewards.append(float(item["reward"]))

    fig, axes = plt.subplots(2, 2, figsize=(10.5, 7.2))
    im0 = axes[0, 0].imshow(q_mean, aspect="auto", cmap="coolwarm")
    axes[0, 0].set(title="Mean Q table", xlabel="action", ylabel="state k−1")
    axes[0, 0].set_xticks([0, 1, 2], ["k+1", "k−1", "hold"])
    fig.colorbar(im0, ax=axes[0, 0], shrink=0.8)

    im1 = axes[0, 1].imshow(visits, aspect="auto", cmap="Blues")
    axes[0, 1].set(title="State–action visits", xlabel="action", ylabel="state k−1")
    axes[0, 1].set_xticks([0, 1, 2], ["k+1", "k−1", "hold"])
    fig.colorbar(im1, ax=axes[0, 1], shrink=0.8)

    axes[1, 0].bar([0, 1, 2], action_counts, color=["#4c78a8", "#f58518", "#54a24b"])
    axes[1, 0].set_xticks([0, 1, 2], ["k+1", "k−1", "hold"])
    axes[1, 0].set(title="Action frequency", ylabel="count")

    if rewards:
        axes[1, 1].scatter(reward_updates, rewards, s=18, alpha=0.65,
                           color=ALGO_COLOR["ql"])
        axes[1, 1].axhline(0.0, color="0.3", lw=0.8)
    axes[1, 1].set(title="Interval rewards", xlabel="completed updates",
                   ylabel="gbest improvement")
    for ax in axes.ravel():
        ax.grid(ls="--", alpha=0.2)
        ax.set_axisbelow(True)
    fig.tight_layout()
    out = os.path.join(FIG_DIR, f"q_diagnostics_{tag}.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("saved", out)


def plot_l_representation(data, tag="v1"):
    """Joint figure of distance/clustering stability and representation/clustering time for L."""
    rows = data.get("summary", [])
    if not rows:
        return
    L = np.asarray([row["L"] for row in rows])
    rank = np.asarray([row["rank_mean"] for row in rows])
    rank_std = np.asarray([row.get("rank_std", 0.0) for row in rows])
    ari = np.asarray([row["ari_mean"] for row in rows])
    ari_std = np.asarray([row.get("ari_std", 0.0) for row in rows])
    feature_ms = 1000 * np.asarray([row["feature_seconds_mean"] for row in rows])
    cluster_ms = 1000 * np.asarray([row["clustering_seconds_mean"] for row in rows])
    shortlist = set(data.get("shortlist", []))

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2))
    axes[0].errorbar(L, rank, yerr=rank_std, marker="o", capsize=3,
                     label="distance-rank correlation")
    axes[0].errorbar(L, ari, yerr=ari_std, marker="s", capsize=3,
                     label="clustering ARI")
    for x, y in zip(L, rank):
        if int(x) in shortlist:
            axes[0].scatter([x], [y], s=120, facecolors="none",
                            edgecolors="crimson", linewidths=1.5)
    axes[0].set(xlabel="projection count L", ylabel="agreement with L=100",
                ylim=(min(0.0, float(min(rank.min(), ari.min())) - 0.05), 1.03))
    axes[0].legend(fontsize=8)

    width = np.maximum(1.0, np.diff(np.r_[L, L[-1] + max(1, L[-1] - L[-2])]) * 0.28)
    axes[1].bar(L - width / 2, feature_ms, width=width,
                label="FSW feature", color="#4c78a8")
    axes[1].bar(L + width / 2, cluster_ms, width=width,
                label="clustering", color="#f58518")
    axes[1].set(xlabel="projection count L", ylabel="time per snapshot (ms)")
    axes[1].legend(fontsize=8)
    for ax in axes:
        ax.set_xticks(L)
        ax.grid(ls="--", alpha=0.3)
        ax.set_axisbelow(True)
    fig.suptitle("FSW projection-count sensitivity (red rings: shortlist)")
    fig.tight_layout()
    out = os.path.join(FIG_DIR, f"l_representation_{tag}.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("saved", out)


def plot_l_optimization(data, tag="v1"):
    """Paired optimization performance (mean ± SE) and total run time for shortlisted L."""
    rows = data.get("summary", [])
    if not rows:
        return
    L = np.asarray([row["L"] for row in rows])
    mean_f = np.asarray([row["mean_F"] for row in rows])
    se_f = np.asarray([row["se_F"] for row in rows])
    runtime = np.asarray([row["runtime_seconds_mean"] for row in rows])
    recommended = int(data["recommended_L"])
    colors = ["crimson" if int(value) == recommended else "#4c78a8" for value in L]

    fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.0))
    axes[0].errorbar(L, mean_f, yerr=se_f, marker="o", capsize=5,
                     color="#4c78a8", lw=1.5)
    axes[0].axhline(float(data["one_se_limit"]), color="crimson", ls="--",
                    label="one-SE limit")
    axes[0].scatter([recommended], [mean_f[np.where(L == recommended)[0][0]]],
                    s=100, facecolors="none", edgecolors="crimson", lw=1.7,
                    label=f"recommended L={recommended}")
    axes[0].set(xlabel="projection count L", ylabel="final F (mean ± SE)")
    axes[0].legend(fontsize=8)
    axes[1].bar(L, runtime, width=np.maximum(4, L * 0.18), color=colors)
    axes[1].set(xlabel="projection count L", ylabel="mean runtime per run (s)")
    for ax in axes:
        ax.set_xticks(L)
        ax.grid(ls="--", alpha=0.3)
        ax.set_axisbelow(True)
    fig.suptitle("Paired full-budget optimization sensitivity for L")
    fig.tight_layout()
    out = os.path.join(FIG_DIR, f"l_optimization_{tag}.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("saved", out)


def plot_g_sensitivity(data, tag="v1"):
    """Performance, sample size and run time of the Q-learning decision interval."""
    rows = data.get("summary", [])
    if not rows:
        return
    G = np.asarray([row["G"] for row in rows])
    mean_f = np.asarray([row["mean_F"] for row in rows])
    se_f = np.asarray([row["se_F"] for row in rows])
    actions = np.asarray([row["actions_mean"] for row in rows])
    visits = np.asarray([row["visited_state_actions_mean"] for row in rows])
    runtime = np.asarray([row["runtime_seconds_mean"] for row in rows])
    recommended = int(data["recommended_G"])
    selected = np.where(G == recommended)[0][0]

    fig, axes = plt.subplots(1, 3, figsize=(13.0, 4.0))
    axes[0].errorbar(G, mean_f, yerr=se_f, marker="o", capsize=5,
                     color="#4c78a8", lw=1.5)
    axes[0].axhline(float(data["one_se_limit"]), color="crimson", ls="--",
                    label="one-SE limit")
    axes[0].scatter([recommended], [mean_f[selected]], s=100,
                    facecolors="none", edgecolors="crimson", lw=1.7,
                    label=f"recommended G={recommended}")
    axes[0].set(xlabel="decision interval G (updates)",
                ylabel="final F (mean ± SE)")
    axes[0].legend(fontsize=8)

    width = 1.5
    axes[1].bar(G - width / 2, actions, width=width,
                label="Q decisions", color="#4c78a8")
    axes[1].bar(G + width / 2, visits, width=width,
                label="visited state–actions", color="#f58518")
    axes[1].set(xlabel="decision interval G (updates)", ylabel="mean count")
    axes[1].legend(fontsize=8)

    colors = ["crimson" if int(value) == recommended else "#4c78a8"
              for value in G]
    axes[2].bar(G, runtime, width=2.5, color=colors)
    axes[2].set(xlabel="decision interval G (updates)",
                ylabel="mean runtime per run (s)")
    for ax in axes:
        ax.set_xticks(G)
        ax.grid(ls="--", alpha=0.3)
        ax.set_axisbelow(True)
    fig.suptitle("Q-learning decision-interval sensitivity")
    fig.tight_layout()
    out = os.path.join(FIG_DIR, f"g_sensitivity_{tag}.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("saved", out)


def plot_ablation(data, tag="v1"):
    """Final F and paired mechanism effects of the ablation; historical wall-clock time is not used as paper evidence."""
    rows = ablation_summary(data)
    if not rows:
        return
    groups = {}
    for run in data["runs"]:
        variant = run.get("variant")
        if variant:
            groups.setdefault(variant, []).append(run)
    variants = ["full"] + [name for name in VARIANT_ORDER if name in groups]
    labels = [VARIANT_LABEL[name] for name in variants]
    means = np.asarray([np.mean([r["best_F"] for r in groups[name]])
                        for name in variants])
    ses = np.asarray([np.std([r["best_F"] for r in groups[name]]) /
                      np.sqrt(len(groups[name])) for name in variants])
    x = np.arange(len(variants))

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.5))
    colors = [ALGO_COLOR["ql"]] + ["#4c78a8"] * (len(variants) - 1)
    axes[0].bar(x, means, yerr=ses, capsize=4, color=colors, alpha=0.9)
    axes[0].set(ylabel="final F (mean ± SE)", title="Optimization result")

    paired_x = np.arange(len(rows))
    medians = np.asarray([row["median_delta_F"] for row in rows])
    lower = medians - np.asarray([row["ci_low"] for row in rows])
    upper = np.asarray([row["ci_high"] for row in rows]) - medians
    sig_colors = ["crimson" if row["p_holm"] < 0.05 else "#4c78a8"
                  for row in rows]
    axes[1].axhline(0.0, color="0.25", lw=1.0, ls="--")
    for i, row in enumerate(rows):
        axes[1].errorbar(i, medians[i], yerr=[[lower[i]], [upper[i]]],
                         fmt="o", capsize=5, color=sig_colors[i])
        axes[1].text(i, row["ci_high"] + 0.003,
                     "*" if row["p_holm"] < 0.05 else "ns",
                     ha="center", va="bottom", fontsize=9)
    axes[1].set(ylabel="variant F − full F (median, 95% CI)",
                title="Paired mechanism effect")

    axes[0].set_xticks(x, labels, rotation=28, ha="right")
    axes[1].set_xticks(paired_x, [VARIANT_LABEL[row["variant"]]
                                  for row in rows], rotation=28, ha="right")
    for ax in axes:
        ax.grid(axis="y", ls="--", alpha=0.3)
        ax.set_axisbelow(True)
    fig.suptitle(f"Mechanism ablation ({len(groups['full'])} paired runs; *: Holm p<0.05)")
    fig.text(0.5, 0.01,
             "Wall-clock time is omitted: historical runs were not randomized/interleaved.",
             ha="center", fontsize=8.5, color="0.35")
    fig.tight_layout(rect=[0, 0.04, 1, 0.95])
    out = os.path.join(FIG_DIR, f"ablation_{tag}.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("saved", out)


def _bootstrap_mean_ci(values, seed, n_boot=2000):
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1 or values.size == 0:
        raise ValueError("bootstrap values must be non-empty and one-dimensional")
    if values.size == 1:
        value = float(values[0])
        return value, value, value
    rng = np.random.default_rng(int(seed))
    indices = rng.integers(0, values.size, size=(int(n_boot), values.size))
    means = values[indices].mean(axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    return float(values.mean()), float(low), float(high)


def _ordered_scenario_ids(data):
    registry = data.get("config", {}).get("case_registry", [])
    ids = [str(entry["scenario_id"]) for entry in registry]
    ids.extend(str(run.get("scenario_id", "default")) for run in data["runs"])
    return list(dict.fromkeys(ids))


def _sweep_context_label(data, kind):
    registry = data.get("config", {}).get("case_registry", [])
    scenarios = [entry.get("scenario", {}) for entry in registry]
    if not scenarios:
        return "frozen scenario context unavailable"
    cell_sizes = {
        float(item.get("cell_size_m", item["area_m"] / item["n_grid"]))
        for item in scenarios
    }
    cell_text = (
        f"{next(iter(cell_sizes)):g} m grid cells"
        if len(cell_sizes) == 1 else "registered grid resolutions"
    )
    if kind == "area_sweep":
        counts = {int(item["n_uav"]) for item in scenarios}
        count_text = (
            f"fixed {next(iter(counts))} UAVs"
            if len(counts) == 1 else "registered UAV counts"
        )
        return f"{count_text}; {cell_text}"
    areas = {float(item["area_m"]) / 1000.0 for item in scenarios}
    area_text = (
        f"fixed {next(iter(areas)):g} km × {next(iter(areas)):g} km area"
        if len(areas) == 1 else "registered study areas"
    )
    return f"{area_text}; {cell_text}"


def _plot_sweep(data, tag, kind):
    algorithms = [
        algo for algo in data.get("config", {}).get(
            "algorithms", FORMAL_ALGORITHMS
        )
        if any(run.get("algo") == algo for run in data["runs"])
    ]
    scenario_ids = _ordered_scenario_ids(data)
    specs = (
        ("best_F", "F", 1.0),
        ("TC", "TC (%)", 100.0),
        ("SAC", "SAC (%)", 100.0),
    )
    fig, axes = plt.subplots(1, 3, figsize=(12.8, 4.2))
    x = np.arange(len(scenario_ids), dtype=float)
    offsets = np.linspace(-0.18, 0.18, max(1, len(algorithms)))
    for panel_index, (metric, label, scale) in enumerate(specs):
        ax = axes[panel_index]
        for algo_index, algo in enumerate(algorithms):
            means, lower, upper = [], [], []
            for case_index, scenario_id in enumerate(scenario_ids):
                selected = [
                    run for run in data["runs"]
                    if run.get("algo") == algo
                    and str(run.get("scenario_id", "default")) == scenario_id
                ]
                values = [
                    (run["best_F"] if metric == "best_F"
                     else run["final_metrics"][metric]) * scale
                    for run in selected
                ]
                mean, low, high = _bootstrap_mean_ci(
                    values, seed=31000 + 100 * panel_index
                    + 10 * algo_index + case_index,
                )
                means.append(mean)
                lower.append(mean - low)
                upper.append(high - mean)
            ax.errorbar(
                x + offsets[algo_index], means,
                yerr=np.asarray([lower, upper]),
                marker="o", ms=4, lw=1.4, capsize=3,
                color=ALGO_COLOR[algo], label=ALGO_LABEL[algo],
            )
        ax.set_xticks(x, scenario_ids)
        ax.set_ylabel(label)
        ax.grid(axis="y", ls="--", alpha=0.3)
        ax.set_axisbelow(True)
        ax.spines[["top", "right"]].set_visible(False)
    title = "Area-scale robustness" if kind == "area_sweep" else "UAV-count robustness"
    context = _sweep_context_label(data, kind)
    fig.suptitle(
        f"{title}: mean and bootstrap 95% CI\n({context})", y=0.99
    )
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles, labels, loc="upper center", ncol=len(algorithms),
        bbox_to_anchor=(0.5, 0.86), frameon=False,
    )
    fig.tight_layout(rect=[0, 0, 1, 0.77])
    out = os.path.join(FIG_DIR, f"{kind}_{tag}.png")
    fig.savefig(out, dpi=200)
    plt.close(fig)
    print("saved", out)
    return out


def plot_area_sweep(data, tag="v1"):
    return _plot_sweep(data, tag, "area_sweep")


def plot_uav_sweep(data, tag="v1"):
    return _plot_sweep(data, tag, "uav_sweep")


def _checkpoint_row(run, target):
    matches = [
        row for row in run.get("checkpoints", [])
        if np.isclose(
            float(row.get("target_seconds", np.nan)), float(target),
            rtol=0.0, atol=1e-12,
        )
    ]
    if len(matches) != 1:
        raise ValueError(
            f"timed run requires one checkpoint at {target} seconds"
        )
    return matches[0]


def _time_context_label(data):
    hardware = data.get("config", {}).get("hardware", {})
    backend = str(hardware.get("backend", "unknown backend"))
    device = str(hardware.get("device", "unknown device"))
    return (
        f"Hardware: {backend} / {device}; complete-generation stopping; "
        "overshoot is bounded by one generation plus terminal bookkeeping."
    )


def plot_time_budget(data, tag="v1"):
    algorithms = [
        algo for algo in data.get("config", {}).get(
            "algorithms", FORMAL_ALGORITHMS
        )
        if any(run.get("algo") == algo for run in data["runs"])
    ]
    checkpoints = [
        float(value) for value in data["config"]["stop_protocol"][
            "checkpoints_seconds"
        ]
    ]
    fig, axes = plt.subplots(2, 2, figsize=(11.2, 8.0))
    for algo_index, algo in enumerate(algorithms):
        selected = [run for run in data["runs"] if run.get("algo") == algo]
        means, lower, upper = [], [], []
        for checkpoint_index, target in enumerate(checkpoints):
            values = [
                float(_checkpoint_row(run, target)["best_F"])
                for run in selected
            ]
            mean, low, high = _bootstrap_mean_ci(
                values, seed=41000 + 100 * algo_index + checkpoint_index
            )
            means.append(mean)
            lower.append(mean - low)
            upper.append(high - mean)
        axes[0, 0].errorbar(
            checkpoints, means, yerr=np.asarray([lower, upper]),
            marker="o", capsize=3, lw=1.5,
            color=ALGO_COLOR[algo], label=ALGO_LABEL[algo],
        )
    axes[0, 0].set_xlabel("Wall-clock checkpoint (s)")
    axes[0, 0].set_ylabel("F")
    axes[0, 0].set_xticks(
        checkpoints, [f"{target:g}" for target in checkpoints]
    )
    axes[0, 0].grid(ls="--", alpha=0.3)
    axes[0, 0].set_axisbelow(True)

    checkpoint_x = np.arange(len(checkpoints), dtype=float)
    fes_width = 0.8 / max(1, len(algorithms))
    for algo_index, algo in enumerate(algorithms):
        selected = [run for run in data["runs"] if run.get("algo") == algo]
        means, lower, upper = [], [], []
        for checkpoint_index, target in enumerate(checkpoints):
            values = [
                float(_checkpoint_row(run, target)["fes"])
                for run in selected
            ]
            mean, low, high = _bootstrap_mean_ci(
                values, seed=41500 + 100 * algo_index + checkpoint_index
            )
            means.append(mean)
            lower.append(mean - low)
            upper.append(high - mean)
        offset = (algo_index - (len(algorithms) - 1) / 2.0) * fes_width
        axes[0, 1].bar(
            checkpoint_x + offset, means, fes_width,
            yerr=np.asarray([lower, upper]), capsize=2,
            color=ALGO_COLOR[algo], alpha=0.82, label=ALGO_LABEL[algo],
        )
    axes[0, 1].set_xticks(
        checkpoint_x, [f"{target:g}" for target in checkpoints]
    )
    axes[0, 1].set_xlabel("Wall-clock checkpoint (s)")
    axes[0, 1].set_ylabel("Completed FEs")
    axes[0, 1].grid(axis="y", ls="--", alpha=0.3)
    axes[0, 1].set_axisbelow(True)

    final_target = checkpoints[-1]
    x = np.arange(len(algorithms), dtype=float)
    width = 0.34
    tc_means, tc_errors, sac_means, sac_errors = [], [], [], []
    for algo_index, algo in enumerate(algorithms):
        selected = [run for run in data["runs"] if run.get("algo") == algo]
        tc = [
            _checkpoint_row(run, final_target)["final_metrics"]["TC"] * 100.0
            for run in selected
        ]
        sac = [
            _checkpoint_row(run, final_target)["final_metrics"]["SAC"] * 100.0
            for run in selected
        ]
        tc_mean, tc_low, tc_high = _bootstrap_mean_ci(tc, 42000 + algo_index)
        sac_mean, sac_low, sac_high = _bootstrap_mean_ci(sac, 43000 + algo_index)
        tc_means.append(tc_mean)
        tc_errors.append((tc_mean - tc_low, tc_high - tc_mean))
        sac_means.append(sac_mean)
        sac_errors.append((sac_mean - sac_low, sac_high - sac_mean))
    axes[1, 0].bar(
        x - width / 2, tc_means, width,
        yerr=np.asarray(tc_errors).T, capsize=3, label="TC",
        color="#4c78a8",
    )
    axes[1, 0].bar(
        x + width / 2, sac_means, width,
        yerr=np.asarray(sac_errors).T, capsize=3, label="SAC",
        color="#f58518",
    )
    axes[1, 0].set_xticks(
        x, [ALGO_LABEL[algo] for algo in algorithms], rotation=18, ha="right"
    )
    axes[1, 0].set_ylabel("Coverage at 60 s (%)")
    axes[1, 0].legend(frameon=False)
    axes[1, 0].grid(axis="y", ls="--", alpha=0.3)

    overshoots = [
        [float(run["overshoot_seconds"]) for run in data["runs"]
         if run.get("algo") == algo]
        for algo in algorithms
    ]
    boxes = axes[1, 1].boxplot(
        overshoots, patch_artist=True, showfliers=True
    )
    for patch, algo in zip(boxes["boxes"], algorithms):
        patch.set_facecolor(ALGO_COLOR[algo])
        patch.set_alpha(0.65)
    point_rng = np.random.default_rng(44000)
    for index, (algo, values) in enumerate(zip(algorithms, overshoots), start=1):
        jitter = point_rng.normal(0.0, 0.035, len(values))
        axes[1, 1].scatter(
            index + jitter, values, s=16, color=ALGO_COLOR[algo],
            edgecolors="white", linewidths=0.4, alpha=0.7, zorder=3,
        )
    axes[1, 1].set_xticks(
        np.arange(1, len(algorithms) + 1),
        [ALGO_LABEL[algo] for algo in algorithms], rotation=18, ha="right",
    )
    axes[1, 1].set_ylabel("Stopping overshoot (s)")
    axes[1, 1].grid(axis="y", ls="--", alpha=0.3)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(
        handles, labels, loc="upper center", ncol=len(algorithms),
        frameon=False, bbox_to_anchor=(0.5, 0.98),
    )
    fig.suptitle("Fixed-time comparison", y=0.99)
    fig.text(
        0.5, 0.01, _time_context_label(data),
        ha="center", fontsize=8.5, color="0.35",
    )
    fig.tight_layout(rect=[0, 0.04, 1, 0.92])
    out = os.path.join(FIG_DIR, f"time_budget_{tag}.png")
    fig.savefig(out, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("saved", out)
    return out


def _suffix_tag(tag, prefix):
    return tag[len(prefix):] if tag.startswith(prefix) else tag


def generate_figures(data, tag):
    """Dispatch plotting by result kind; returns the recognized kind."""
    os.makedirs(FIG_DIR, exist_ok=True)
    kind = result_kind(data)
    if kind == "l_repr":
        plot_l_representation(data, _suffix_tag(tag, "l_representation_"))
        return kind
    if kind == "l_opt":
        plot_l_optimization(data, _suffix_tag(tag, "l_optimization_"))
        return kind
    if kind == "g_sensitivity":
        plot_g_sensitivity(data, _suffix_tag(tag, "g_sensitivity_"))
        return kind
    if kind == "area_sweep":
        plot_area_sweep(data, _suffix_tag(tag, "area_sweep_"))
        return kind
    if kind == "uav_sweep":
        plot_uav_sweep(data, _suffix_tag(tag, "uav_sweep_"))
        return kind
    if kind == "time_budget":
        plot_time_budget(data, _suffix_tag(tag, "time_budget_"))
        return kind
    if kind == "protocol_smoke":
        return kind
    if kind == "ablation":
        plot_ablation(data, _suffix_tag(tag, "ablation_"))
        return kind
    runs = {}
    for run in data["runs"]:
        runs.setdefault(run["algo"], []).append(run)
    config = data.get("config", {})
    plot_convergence(runs, config, tag)
    plot_k_trajectory(runs, tag)
    plot_q_diagnostics(runs, tag)
    mode = config.get("mode", "a2g")
    plot_deployment(runs, tag, mode=mode, root_config=config)
    plot_deployment_3d(runs, tag, mode=mode, root_config=config)
    plot_distribution(runs, tag)
    return kind


def main(argv=None):
    argv = sys.argv[1:] if argv is None else list(argv)
    path = argv[0] if argv else os.path.join(
        HERE, "outputs", "full_results_50grid_v2.json")
    tag = os.path.splitext(os.path.basename(path))[0]
    with open(path, encoding="utf-8") as stream:
        data = validate_results(json.load(stream))
    generate_figures(data, tag)


if __name__ == "__main__":
    main()
