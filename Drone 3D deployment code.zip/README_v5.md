# Experiment protocol

The formal entry point is `run_v5.py`; for reproduction use `reproduce.py` from [README](README.md) to avoid writing into the original directories.

## Stages and settings

| Stage | Conditions | Independent optimizations |
| --- | --- | ---: |
| Count experiment | QL-TADMPSO; 5, 10, 15, 20, 25, 30, 35, 40, 45, 50 UAVs | 200 |
| Ablation | 14 conditions, 45 UAVs | 280 |
| Baseline comparison | 7 methods, 45 UAVs | 140 |

Each condition has 20 runs, 50 particles and 25,000 actual objective evaluations; initialization and auxiliary search count toward the evaluation budget. L=50, G=5, initial/max subgroup count 16, minimum subgroup size 3, clustering cap 100; Q-learning rate 0.5, discount 0.95, exploration range [0.4, 0.9], cross-swarm threshold 0.8. The scenario is 5 km x 5 km, a 50 x 50 grid, 30% priority area, objective weights 0.5/0.3/0.2.

The three stages use different seed groups; within a stage, scenarios and seeds are matched by run number and the execution order is randomized. Different counts have different variable dimensions, so initial coordinates are not elementwise identical. SAO-MPSO keeps its Cubic initialization; the other methods use uniform initialization.

45 UAVs is the comparison setting the paper chose by weighing coverage, uniformity, device count and time; it is not a count the program proved optimal automatically. The basis and sources are kept in `outputs/rebuild_v5/formal_5_to_50/selection.json`.

## Ablation mapping

| Paper label | Code label | Adjustment |
| --- | --- | --- |
| QL-TADMPSO | `full` | complete setting |
| V1 | `no_fsw_no_alignment` | coordinate grouping, guide by number |
| V2 | `no_alignment` | keep FSW, guide by number |
| V3 | `no_fsw` | coordinate grouping, keep matching |
| V4 | `random_topology` | random partition |
| V5 | `no_cross_swarm` | cross-swarm term off |
| V6 | `fixed_k` | subgroup count fixed at 16 |
| V7 | `factor_schedule` | factorization schedule |
| V8 | `random_actions` | random subgroup-adjustment actions |
| V9 | `apso_coefficients` | APSO learning-factor feedback, not full APSO |

`full` and V1-V3 each have one extra `_permuted` condition that only independently relabels the UAV coordinate triples of each particle at initialization, using an independent permutation random source; 14 conditions in total.

The numbering diagnostics take the initial and final 45-UAV deployments from the 20 runs of the count stage, 40 snapshots in total, each permuted 20 times internally. These permutations are not extra independent optimization samples. Representation invariance does not mean the whole randomized search trajectory is invariant.

## Statistics and figures

The six metrics are F, TC, SAC, SASU, GASU and run time. TC/SAC are percentages, paired differences in percentage points; standard deviations use ddof=1. Timing includes initialization, objective evaluation and algorithm operations, excluding warm-up, post-hoc checks and plotting. The current experiments use equal evaluation counts, not equal wall-clock limits.

The ablation's 15 direct comparisons and 1 interaction comparison each cover 6 metrics; the 96 entries are Holm-corrected together, and the baseline comparison's 36 entries are corrected separately. Raw p values come from SciPy's two-sided Wilcoxon signed-rank test with `zero_method='wilcox'`, `method='auto'`; significance is judged by corrected p<0.05.

The interaction difference is `full − no_alignment − no_fsw + no_fsw_no_alignment`. The 95% intervals of the paired median differences use 5000 paired bootstrap percentile resamples, seed 20260919, without multiple-comparison correction. Not significant does not mean equivalent.

The deployment figures pick the shared run number by the sum of distances to the median rank within each count, ties broken toward the smaller number; the paper uses i=7, i.e. group 8. The best run is not picked separately per count. Single-run layout metrics and 20-run means must not be mixed.

`source_snapshot` saves the stage source; the original results contain config, seeds, evaluation histories, final coordinates and source digests. The original resume entry points still require config, source and environment to match; the new tool only solves archive relocation reads and does not remove those protections.
