"""Unified objective-evaluation budget management.

Both the initial population and every whole-population update count as FEs;
partial populations may not cross the budget, and result summaries use the
best solution cached during the search.
"""
import numpy as np

from scenario import DEFAULT_SCENARIO


class BudgetExceeded(RuntimeError):
    """The requested next batch of objective evaluations would exceed the declared FE cap."""


def update_count(max_fes, n_particles):
    """Return the full update generations available after initialization.

    The main config max_fes=25000, n_particles=50 gives exactly 499 updates.
    """
    max_fes = int(max_fes)
    n_particles = int(n_particles)
    if n_particles <= 0:
        raise ValueError("n_particles must be positive")
    if max_fes < n_particles:
        raise ValueError("max_fes must include one full initialization population")
    remainder = (max_fes - n_particles) % n_particles
    if remainder:
        raise ValueError("max_fes must contain whole populations after initialization")
    return (max_fes - n_particles) // n_particles


class ObjectiveEvaluator:
    """Batch-call the deployment objective and strictly record actual FEs."""

    def __init__(self, priority, mode, max_fes, evaluate_fn=None,
                 scenario=DEFAULT_SCENARIO):
        self.priority = priority
        self.mode = mode
        self.max_fes = int(max_fes)
        self.scenario = scenario
        self.evaluate_fn = scenario.evaluate if evaluate_fn is None else evaluate_fn
        self.fes = 0

    def evaluate_population(self, X):
        X = np.asarray(X)
        n = len(X)
        if self.fes + n > self.max_fes:
            raise BudgetExceeded(f"{self.fes}+{n}>{self.max_fes}")
        metrics = [self.evaluate_fn(x, self.priority, self.mode) for x in X]
        self.fes += n
        return np.asarray([m["F"] for m in metrics], dtype=np.float64), metrics
