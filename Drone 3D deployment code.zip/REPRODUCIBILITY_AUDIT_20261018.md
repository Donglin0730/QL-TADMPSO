# Code and experiment-result reproduction check

Check date: 2026-10-18.

## Conclusion

The current algorithm code can reproduce the sampled formal experiments on this machine, and the saved formal statistics can be recomputed. Both the CPU and GPU small-scale pipelines run end to end. This directory has not yet reached "download on another computer and reproduce all paper results and final figures without any setup"; absolute paths, pinned dependency versions and figure-generation scripts still need handling before publication.

This round modified no algorithm, formal experiment data or paper, and nothing was uploaded to GitHub. All new runs are checks only and do not replace the paper's original results.

## Verification performed

| Check | Result |
| --- | --- |
| Copied programs, tests and docs into an independent directory without the original outputs, then ran the full test entry | 22/22 test scripts passed |
| CPU small-scale full pipeline | 10 count, 14 ablation and 7 comparison runs plus 2 diagnostic snapshots completed; report generation succeeded |
| GPU small-scale full pipeline | same as above; report generation succeeded |
| Original formal record verification | 200 count, 280 ablation and 140 comparison runs, 620 in total; source, budget and final-coordinate metric recomputation passed |
| Saved statistics recomputation | means, sample SDs and medians of the 186 summary rows match; the 96 ablation and 36 comparison tests match |
| Numbering diagnostics | 40 snapshots and 800 internal re-numbering checks passed; not counted as 800 independent optimizations |
| Full-budget reruns | 9 runs, each 50 particles, 45 UAV-BSs and 25,000 evaluations; apart from run time, the complete records match item by item |

The 132 statistical recomputations include the original two-sided Wilcoxon p values, Holm-corrected p values, paired median differences and 5000-resample bootstrap intervals. Comparison against the saved CSVs used absolute and relative tolerances of 1e-13; all passed.

The three formal optimization stages each have 19 source snapshots whose byte hashes match the corresponding current code, 57 in total. Historical logs were not treated as this round's check results.

### Full-budget sample details

The values below are single-run objectives, not 20-run means. Run-group numbers start at 1.

| Stage | Method | Run group | Rerun F | vs original record |
| --- | --- | ---: | ---: | --- |
| Count experiment | QL-TADMPSO | 8 | 0.138031176200040 | match |
| Ablation experiment | QL-TADMPSO | 1 | 0.126605548670326 | match |
| Algorithm comparison | PSO | 1 | 0.200159996299910 | match |
| Algorithm comparison | AHDPSO | 1 | 0.218752182239594 | match |
| Algorithm comparison | T-ADMPSO (adapted) | 1 | 0.193083959887432 | match |
| Algorithm comparison | AMSEPSO | 1 | 0.227842395360717 | match |
| Algorithm comparison | SDPSO (adapted) | 1 | 0.100764521780793 | match |
| Algorithm comparison | SAO-MPSO | 1 | 0.091970131969605 | match |
| Algorithm comparison | QL-TADMPSO | 1 | 0.135952718220399 | match |

The comparison includes final deployment coordinates, all saved metrics, objective trajectories, evaluation counts and the other diagnostic records each method saves; for QL-TADMPSO the Q table, subgroup counts, actions and reward records were also compared. Run times are re-measured and were not required to equal the original values.

## Items to handle before publication

1. **Existing experiment records contain absolute local paths.** `count_selection.py` reads `count_result_path` from the selection record directly, and the mechanism report also reads `selection_path`. Files may not be found after moving the existing formal results. Add a relocation method that keeps the source verification instead of editing the old JSON and dropping its hash relations.
2. **Default commands reuse the old formal directory.** `run_v5.py` strictly verifies the source and run environment; resuming old results on another computer is rejected. This is a reasonable protection against mixing experiments. The public docs should separate "viewing the original results" from "rerunning in a new directory" and pass `--root` explicitly for the latter.
3. **Reading the formal GPU records is tied to GPU metric re-checking.** Without a GPU you can run CPU experiments from scratch, but the current report entry cannot directly re-check the old GPU-generated results. Provide a CPU entry that only recomputes the stored data statistics and document that it does not include the coordinate metric re-check of the same GPU backend.
4. **Dependencies are not pinned.** The current requirements only give lower bounds. The environment recorded for the formal results is Python 3.12.10, NumPy 2.5.2, SciPy 1.18.0, CuPy 14.1.1 and CUDA runtime 12.9; this round's environment matches it. The release should provide pinned dependencies and installation steps. This round did not install dependencies in a fresh virtual environment and did not test on another physical computer.
5. **Git line-ending conversion can break source hashes.** On this machine `core.autocrlf=true` and some frozen sources have mixed line endings, while the program hashes the raw file bytes. Set `.gitattributes` before publication to protect the frozen sources, snapshots and original evidence files so that automatic line-ending conversion does not break verification.
6. **The final paper figures have no complete generation pipeline.** The current report program can generate generic figures, but the generation scripts of some final polished figures were not found in this workspace, including the two-panel versions of 08-11 and the Q-learning trajectory figure 15; these five candidate experiment figures are not currently cited by main.tex and should be distinguished from the figures used in the paper. The figure index also links to the paper figures directory outside experiments. Complete the generation scripts and in-repo links; existing PDFs cannot be treated as complete plotting reproduction code.
7. **The run environment and test entry points need documentation.** The Windows launcher prefers the local D-drive interpreter; the public version should prefer the environment the reader activates. Some GPU tests carry fixed millisecond thresholds, so a slow GPU may be numerically correct but fail the test; consider separating them from the default correctness tests. Also tidy the ignore rules, citation info, and have the author decide the license.

## Command structure for new experiments

The commands below run in the experiments directory and must use a new output directory that is not occupied yet. This shows the pipeline; it does not mean the 620 formal experiments were all rerun this round.

```text
python -B tests/run_all_tests.py
python run_v5.py smoke --root outputs/reproduction_smoke
python run_v5.py count --root outputs/reproduction_paper
python run_v5.py select --root outputs/reproduction_paper --uav-count 45 --reason "reproduce the paper's 45-UAV-BS follow-up experiment setting"
python run_v5.py continue --root outputs/reproduction_paper
```

Dependency installation, GPU environment and versions should be prepared following the public environment docs. After the count experiment the selection basis must still be recorded; 45 UAVs is the paper's fixed comparison setting and does not mean the program automatically proved it optimal.

## Check boundaries and run environment

This round only reran the 9 full-budget experiments above from scratch; it did not re-optimize all 620. The CPU tests use 12 particles, 120 evaluations and 1 repetition and are pipeline checks, not a substitute for the full paper experiments on a CPU platform. Bitwise numerical consistency across GPUs, CPUs or software versions is not verified; run times also cannot be required to be identical across machines or loads.

The tests first hit the temp-directory permission limits of this run's sandbox; putting the temp directory under a Chinese path then triggered the CUDA compile path-encoding error. After switching to a writable pure-English temp directory, all 22 test scripts passed. No algorithm or assertion was changed to make the tests pass.

This round's raw check outputs are in `../tmp/repro_audit_20261018_155757/`. The persistently saved summaries and test logs are in [verification/reproducibility_20261018](verification/reproducibility_20261018/), including the statistics recomputation, full-budget reruns, CPU/GPU pipelines and software version records. The Matplotlib version observed this round is 3.11.1; the full local CUDA dependency versions are in `observed_environment.json`; that file is an environment record, not a verified installation lock file.
