"""Seven-algorithm final deployment comparison figure (2D top view + 3D).

Reads only the completed comparison-stage checkpoint, picks a representative
run id common to all algorithms, rebuilds each algorithm's final 45-UAV-BS
deployment on the recorded GPU backend, checks the stored metrics, then
outputs publication-style panel figures. This script modifies no algorithms
and no existing result files.

Usage: python comparison_layouts.py [--input results.json] [--output DIR]
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, ListedColormap, Normalize
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
from scipy.stats import rankdata

import deployment_atlas as atlas
import protocol_v5 as protocol
from scenario import (
    DeploymentScenario, ScenarioConfig, W1, W2, W3,
    gpu_name, metrics_from_field,
)

HERE = Path(__file__).resolve().parent
DEFAULT_INPUT = HERE / "outputs" / "rebuild_v5" / "formal_5_to_50" / "comparison" / "results.json"


def select_paired_runs(runs):
    """Pick a common run id that is jointly central by each algorithm's internal F ranking."""
    by_method = {}
    for method in protocol.METHODS:
        records = [r for r in runs if r["method"] == method]
        by_id = {int(r["i"]): r for r in records}
        if len(by_id) != len(records):
            raise ValueError(f"duplicate run ids for {method}")
        by_method[method] = by_id
    common = set.intersection(*(set(by_method[m]) for m in protocol.METHODS))
    if not common:
        raise ValueError("no common run id across the comparison methods")
    ids = sorted(common)
    target = (len(ids) - 1) / 2.0
    distance = {run_id: 0.0 for run_id in ids}
    for method in protocol.METHODS:
        values = [by_method[method][run_id]["best_F"] for run_id in ids]
        ranks = rankdata(values, method="average") - 1.0
        for run_id, rank in zip(ids, ranks):
            distance[run_id] += abs(float(rank) - target)
    run_id = min(ids, key=lambda i: (distance[i], i))
    selected = {method: by_method[method][run_id] for method in protocol.METHODS}
    if len({int(r["priority_seed"]) for r in selected.values()}) != 1:
        raise ValueError("paired runs must share priority_seed")
    if len({int(r["seed"]) for r in selected.values()}) != 1:
        raise ValueError("paired runs must share optimization seed")
    return selected


def build_panels(data, selected):
    config = data["config"]
    mode = config["mode"]
    use_gpu = not config["device"].startswith("CPU")
    if use_gpu and gpu_name(True).startswith("CPU"):
        raise ValueError("these results used GPU evaluation; that backend is required to rebuild them")
    panels, reference_priority = [], None
    for method in protocol.METHODS:
        record = selected[method]
        scene = DeploymentScenario(ScenarioConfig.from_dict(record["scenario"]))
        positions = np.asarray(record["best_pos"], dtype=float).reshape(-1, 3)
        low, high = scene.bounds()
        if (not np.isfinite(positions).all()
                or np.any(positions.ravel() < low) or np.any(positions.ravel() > high)):
            raise ValueError(f"{method}: invalid or out-of-bounds deployment")
        priority = scene.priority_mask(record["priority_seed"])
        if reference_priority is not None and not np.array_equal(priority, reference_priority):
            raise ValueError("priority maps differ despite matching seeds")
        reference_priority = priority
        # Same as the deployment atlas: rebuild with the recorded numeric backend, avoiding float differences near thresholds.
        signal, covered = scene._signal_and_coverage(positions, mode, use_gpu=use_gpu)
        metrics = metrics_from_field(signal, covered, priority)
        differences = {}
        for key in ("F", "TC", "SAC", "SASU", "GASU"):
            expected = record["best_F"] if key == "F" else record["final_metrics"][key]
            differences[key] = abs(metrics[key] - expected)
            tolerance = 1e-12 if key in ("TC", "SAC") else 1e-4
            if not np.isfinite(expected) or differences[key] > tolerance:
                raise ValueError(f"{method}: stored metric {key} disagrees with the rebuilt layout")
        n = scene.config.n_grid
        panels.append({
            "method": method, "record": record, "scene": scene,
            "positions": positions, "device": config["device"],
            "priority": priority.reshape(n, n).T,
            "covered": covered.reshape(n, n).T,
            "metrics": metrics, "metric_check_abs_error": differences,
            "categories": (2 * covered.astype(int) + priority.astype(int)).reshape(n, n).T,
            "components": [W1 * metrics["f1"], W2 * metrics["f2"], W3 * metrics["f3"]],
        })
    return panels


def panel_title(ax, panel, index, is_3d=False):
    m = panel["metrics"]
    ax.set_title(f"({chr(97 + index)})  {protocol.LABELS[panel['method']]}",
                 loc="left", fontweight="bold", pad=21 if not is_3d else 24)
    label = f"F = {m['F']:.4f}   TC = {100*m['TC']:.2f}%"
    if is_3d:
        ax.text2D(0, 1.06, label, transform=ax.transAxes, fontsize=7.5, color="#43515D")
    else:
        ax.text(0, 1.035, label, transform=ax.transAxes, fontsize=7.5, color="#43515D")


def save_figure(fig, output, name, watermark=None):
    if watermark:
        fig.text(.5, .987, watermark, ha="center", va="top", fontsize=10,
                 fontweight="bold", color="#9B3425")
    fig.savefig(output / f"{name}.pdf", metadata={
        "Title": "UAV-BS final deployment method comparison",
        "Subject": (f"{watermark}; " if watermark else "")
                   + "Single jointly representative paired run; validated layouts; not repeated-run means",
        "Creator": "Matplotlib; validated against the deployment evaluation model",
    })
    fig.savefig(output / f"{name}.png", dpi=240)
    plt.close(fig)


def render_comparison(panels, output, watermark=None):
    if len(panels) != 7:
        raise ValueError("comparison layout requires the seven comparison methods")
    rows, columns = 2, 4
    scene = panels[0]["scene"]
    height_norm = Normalize(scene.config.h_min_m, scene.config.h_max_m)
    cmap = ListedColormap(atlas.GROUND_COLORS)
    ground_norm = BoundaryNorm(np.arange(-.5, 4.5), 4)
    with plt.rc_context(atlas.paper_style()):
        fig, axes = plt.subplots(rows, columns, figsize=(10.6, 5.9))
        fig.subplots_adjust(left=.055, right=.988, bottom=.18,
                            top=.88 if watermark else .92,
                            wspace=.30, hspace=.55)
        for index, (ax, panel) in enumerate(zip(axes.flat, panels)):
            area = panel["scene"].config.area_m
            edges = np.linspace(0, area, panel["scene"].config.n_grid + 1)
            ax.pcolormesh(edges, edges, panel["categories"], cmap=cmap,
                          norm=ground_norm, shading="flat", rasterized=False,
                          edgecolors="none", antialiased=False)
            pos = panel["positions"]
            ax.scatter(pos[:, 0], pos[:, 1], c=pos[:, 2], cmap=atlas.HEIGHT_CMAP,
                       norm=height_norm, marker="^", s=30, edgecolor="#292D3E",
                       linewidth=.55, zorder=4, clip_on=False)
            ax.set(xlim=(0, area), ylim=(0, area), xlabel="x (m)", ylabel="y (m)")
            ax.set_aspect("equal")
            ax.set_xticks([0, area / 2, area])
            ax.set_yticks([0, area / 2, area])
            ax.tick_params(length=2.5, pad=2)
            for spine in ax.spines.values():
                spine.set_color("#75818B")
            panel_title(ax, panel, index)
        for ax in axes.flat[len(panels):]:
            ax.axis("off")
        atlas.add_common_legend(fig, height_norm)
        save_figure(fig, output, "uav_comparison_layouts_2d", watermark=watermark)

        fig = plt.figure(figsize=(12.6, 6.6))
        fig.subplots_adjust(left=.015, right=.955, bottom=.16,
                            top=.84 if watermark else .91, wspace=.10, hspace=.45)
        for index, panel in enumerate(panels):
            ax = fig.add_subplot(rows, columns, index + 1, projection="3d", computed_zorder=False)
            area = panel["scene"].config.area_m
            n = panel["scene"].config.n_grid
            edges = np.linspace(0, area, n + 1)
            # One polygon per evaluation cell, keeping the discrete true coverage state.
            polygons, colors = [], []
            for row in range(n):
                for col in range(n):
                    x0, x1, y0, y1 = edges[col], edges[col + 1], edges[row], edges[row + 1]
                    polygons.append([(x0, y0, 0), (x1, y0, 0), (x1, y1, 0), (x0, y1, 0)])
                    colors.append(atlas.GROUND_COLORS[panel["categories"][row, col]])
            ax.add_collection3d(Poly3DCollection(polygons, facecolors=colors,
                                                edgecolors="none", zorder=1))
            pos = panel["positions"]
            for x, y, h in pos:
                ax.plot([x, x], [y, y], [0, h], color="#677988", alpha=.65,
                        lw=.55, ls=(0, (2, 2)), zorder=2)
            ax.scatter(pos[:, 0], pos[:, 1], np.zeros(len(pos)), s=6,
                       c="#536A79", alpha=.8, depthshade=False, zorder=3)
            ax.scatter(pos[:, 0], pos[:, 1], pos[:, 2], c=pos[:, 2],
                       norm=height_norm, cmap=atlas.HEIGHT_CMAP, s=24, marker="^",
                       edgecolors="#292D3E", linewidths=.45, depthshade=False, zorder=4)
            ax.view_init(elev=26, azim=-58)
            ax.set_proj_type("ortho")
            ax.set_box_aspect((1, 1, .47), zoom=.94)
            ax.set(xlim=(0, area), ylim=(0, area), zlim=(0, 550))
            ax.set_xticks([0, area])
            ax.set_yticks([area / 2, area])
            ax.set_zticks([100, 300, 500])
            ax.set_xlabel("x (m)", labelpad=-8)
            ax.set_ylabel("y (m)", labelpad=2)
            ax.set_zlabel("h (m)", labelpad=-7)
            ax.tick_params(labelsize=6.6, pad=-3)
            for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
                axis.pane.fill = False
                axis.pane.set_edgecolor("#D9DFE4")
                axis._axinfo["grid"].update(color="#D5DDE3", linewidth=.4)
                axis.line.set_color("#8995A0")
            panel_title(ax, panel, index, is_3d=True)
        atlas.add_common_legend(fig, height_norm)
        save_figure(fig, output, "uav_comparison_layouts_3d", watermark=watermark)


def export_metadata(panels, output, source, script_path):
    with (output / "deployment_coordinates.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["method", "uav_id", "x_m", "y_m", "height_m"])
        for panel in panels:
            for index, pos in enumerate(panel["positions"], 1):
                writer.writerow([panel["method"], index, *pos])
    with (output / "case_metrics.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["method", "F", "TC_percent", "SAC_percent", "SASU_dB", "GASU_dB",
                         "weighted_uncovered", "weighted_priority_uniformity",
                         "weighted_general_uniformity", "fes", "seed", "priority_seed"])
        for panel in panels:
            m, r = panel["metrics"], panel["record"]
            writer.writerow([panel["method"], m["F"], 100 * m["TC"], 100 * m["SAC"],
                             m["SASU"], m["GASU"], *panel["components"],
                             r["fes"], r["seed"], r["priority_seed"]])
    atlas.write_json(output / "figure_manifest.json", {
        "source": str(source.resolve()),
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "script": script_path.name,
        "script_sha256": hashlib.sha256(script_path.read_bytes()).hexdigest(),
        "core_sha256_at_render": atlas.core_hashes(),
        "evaluation_device": panels[0]["device"],
        "coordinate_units": "m", "height_color_limits_m": [100, 500],
        "coverage": "actual effective-link union on the 50x50 evaluation grid; no interpolation",
        "ground_categories": dict(zip(atlas.GROUND_LABELS, atlas.GROUND_COLORS)),
        "three_dimensional_view": "orthographic; vertical scale visually exaggerated; numeric heights unchanged",
        "representative_run_selection": "per-method F ranks across common run ids; run id minimizing the sum of absolute distances to the median rank",
        "panels": [{
            "method": p["method"], "run_id": p["record"]["i"],
            "optimization_seed": p["record"]["seed"],
            "priority_seed": p["record"]["priority_seed"],
            "fes": p["record"]["fes"], "metrics": p["metrics"],
            "weighted_objective_components": p["components"],
            "metric_check_abs_error": p["metric_check_abs_error"],
        } for p in panels],
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--run-id", type=int,
                        help="use this run id for all methods instead of the median-rank selection")
    parser.add_argument("--watermark")
    args = parser.parse_args()
    source = args.input.resolve()
    data = protocol.load_data(source, require_current=False)
    selected = select_paired_runs(data["runs"])
    if args.run_id is not None:
        records = [r for r in data["runs"] if int(r["i"]) == args.run_id]
        by_method = {r["method"]: r for r in records}
        if set(by_method) != set(protocol.METHODS):
            raise ValueError("requested run id is missing for one or more methods")
        selected = {method: by_method[method] for method in protocol.METHODS}
    panels = build_panels(data, selected)
    output = (args.output or source.parent / "report").resolve()
    output.mkdir(parents=True, exist_ok=True)
    render_comparison(panels, output, watermark=args.watermark)
    export_metadata(panels, output, source, Path(__file__).resolve())
    print(json.dumps({
        "output": str(output),
        "run_id": panels[0]["record"]["i"],
        "methods": [p["method"] for p in panels],
        "F": [p["metrics"]["F"] for p in panels],
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
