"""Versioned experiment runner: gate, smoke, L/G sensitivity, formal comparison and ablation.

All optimization budgets use strict FEs; all candidates/algorithms in one
run share the optimization seed and the priority-area seed. Old model JSONs
without the current schema/model version are refused for resume.
"""
import argparse
import hashlib
import json
import os
import time

import numpy as np

import algorithms
import model
from scenario import DeploymentScenario, ScenarioConfig
from sensitivity import representation_sensitivity
from timing import TimeProtocol, hardware_fingerprint

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(HERE, "outputs")
SCHEMA_VERSION = model.MODEL_VERSION
V3_SCHEMA_VERSION = "uav-bs-experiment-results-v3"
V3_MODEL_VERSION = "uav-bs-a2g-ahdpso-scenario-v3"
V3_EVIDENCE_TYPES = {
    "formal_held_out_v3",
    "protocol_smoke_v3",
    "integration_nonformal_v3",
    "synthetic_qa_v3",
    "nonformal_v3",
}
N_RUNS = 20
SENSITIVITY_RUNS = 10
SEED_BASE = 1000
PRIORITY_SEED_BASE = 100
SELECTION_SEED_PROTOCOL = "selection_v1"
HELD_OUT_SEED_PROTOCOL = "held_out_v1"
ROBUSTNESS_SEED_PROTOCOL = "robustness_v1"
TIME_SEED_PROTOCOL = "time_v1"
SMOKE_SEED_PROTOCOL = "smoke_v3"
SEED_PROTOCOLS = {
    SELECTION_SEED_PROTOCOL: (SEED_BASE, PRIORITY_SEED_BASE),
    HELD_OUT_SEED_PROTOCOL: (3000, 300),
    ROBUSTNESS_SEED_PROTOCOL: (5000, 500),
    TIME_SEED_PROTOCOL: (7000, 700),
    SMOKE_SEED_PROTOCOL: (11000, 1100),
}
MAIN_CONFIG = {"n_p": 50, "max_fes": 25000, "mode": "a2g"}
GATE_CONFIG = {"n_p": 30, "max_fes": 15000, "mode": "los"}
L_VALUES = [5, 10, 16, 32, 50, 100]
G_VALUES = [5, 10, 15, 25]
AREA_CASES = (
    ("5km", 5000.0, 50),
    ("7km", 7000.0, 70),
    ("10km", 10000.0, 100),
)
UAV_CASES = (("10uav", 10), ("25uav", 25), ("50uav", 50))
FORMAL_ALGORITHMS = ("pso", "ahdpso", "tadmpso", "ql")
ABLATION_VARIANTS = (
    ("ql", "full", {}),
    ("ql", "no_fsw", {"use_fsw": False}),
    ("ql", "no_alignment", {"align_guides": False}),
    ("ql", "random_topology", {"use_topology": False}),
    ("ql", "no_cross_swarm", {"use_cross_swarm": False}),
    ("ql", "fixed_k", {"use_q_learning": False}),
    (
        "ql",
        "factor_schedule",
        {"use_q_learning": False, "schedule_label": "factorization"},
    ),
)

OUTPUT_FILES = {
    "gate": "gate_50grid_v2.json",
    "smoke": "smoke_50grid_v2.json",
    "l_repr": "l_representation_50grid_v2.json",
    "l_opt": "l_optimization_50grid_v2.json",
    "g_sensitivity": "g_sensitivity_50grid_v2.json",
    "full": "full_results_50grid_v2.json",
    "ablation": "ablation_50grid_v2.json",
    "full_final": "full_results_heldout_v3.json",
    "ablation_final": "ablation_heldout_v3.json",
    "area_sweep_final": "area_sweep_heldout_v3.json",
    "uav_sweep_final": "uav_sweep_heldout_v3.json",
    "time_final": "time_budget_heldout_v3.json",
    "protocol_smoke": "protocol_smoke_v3.json",
}
OPTIMIZER_SOURCE_FILES = [
    "model.py", "scenario.py", "evaluation.py", "topology.py",
    "algorithms.py", "sensitivity.py", "timing.py", "run_exp.py",
]


def _now():
    return time.strftime("%H:%M:%S")


def paired_seeds(run_index, protocol=SELECTION_SEED_PROTOCOL):
    """Return the (optimization seed, priority-area seed) pair of one paired run."""
    if protocol not in SEED_PROTOCOLS:
        raise ValueError(f"unknown seed protocol: {protocol}")
    optimization_base, priority_base = SEED_PROTOCOLS[protocol]
    return optimization_base + int(run_index), priority_base + int(run_index)


def algorithm_order(run_index):
    rng = np.random.default_rng(9000 + int(run_index))
    order = rng.permutation(len(FORMAL_ALGORITHMS))
    return tuple(np.asarray(FORMAL_ALGORITHMS)[order].tolist())


def optimizer_source_fingerprint():
    """Formal results depend on the source SHA-256; refuse silent resume after code changes."""
    digest = hashlib.sha256()
    for name in OPTIMIZER_SOURCE_FILES:
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        with open(os.path.join(HERE, name), "rb") as stream:
            digest.update(stream.read())
        digest.update(b"\0")
    return digest.hexdigest()


def _jsonable(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def _normalized(value):
    return json.loads(json.dumps(_jsonable(value), sort_keys=True))


def scenario_from_config(config):
    if not isinstance(config, dict) or not isinstance(config.get("scenario"), dict):
        raise ValueError("v3 config requires a scenario object")
    try:
        scenario_config = ScenarioConfig.from_dict(config["scenario"])
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid v3 scenario: {exc}") from exc
    return DeploymentScenario(scenario_config)


def _validate_v3_config(config):
    required = {
        "scenario", "algorithms", "seed_protocol", "n_runs",
        "stop_protocol", "source_fingerprint", "n_p", "max_fes",
        "mode", "L", "G", "evidence_type", "formal_qualification",
    }
    missing = sorted(required - set(config))
    if missing:
        raise ValueError(f"v3 config missing required fields: {missing}")
    scenario_from_config(config)
    if not isinstance(config["algorithms"], (list, tuple)) or not config["algorithms"]:
        raise ValueError("v3 config algorithms must be non-empty")
    if len(set(config["algorithms"])) != len(config["algorithms"]):
        raise ValueError("v3 config algorithms must be unique")
    if any(algo not in FORMAL_ALGORITHMS for algo in config["algorithms"]):
        raise ValueError("v3 config contains an unknown algorithm")
    if not isinstance(config["seed_protocol"], str) or not config["seed_protocol"]:
        raise ValueError("v3 config seed_protocol must be non-empty")
    if config["seed_protocol"] not in SEED_PROTOCOLS:
        raise ValueError("v3 config seed_protocol is not registered")
    if int(config["n_runs"]) <= 0:
        raise ValueError("v3 config n_runs must be positive")
    if int(config["n_p"]) <= 0:
        raise ValueError("v3 config n_p must be positive")
    if int(config["L"]) <= 0 or int(config["G"]) <= 0:
        raise ValueError("v3 config L/G must be positive")
    if config["mode"] != config["scenario"]["propagation_mode"]:
        raise ValueError("v3 config mode must match the scenario")
    evidence_type = config["evidence_type"]
    formal_flag = config["formal_qualification"]
    if evidence_type not in V3_EVIDENCE_TYPES:
        raise ValueError("v3 config evidence type is not registered")
    if not isinstance(formal_flag, bool):
        raise ValueError("v3 config formal_qualification must be boolean")
    if (evidence_type == "formal_held_out_v3") != formal_flag:
        raise ValueError("v3 evidence type and formal_qualification disagree")
    stop = config["stop_protocol"]
    if not isinstance(stop, dict) or stop.get("kind") not in {
        "fixed_fes", "fixed_time", "protocol_smoke"
    }:
        raise ValueError("v3 config stop_protocol kind is invalid")
    if stop.get("kind") == "fixed_fes":
        if int(stop.get("max_fes", 0)) <= 0:
            raise ValueError("v3 fixed-FE protocol requires positive max_fes")
    elif stop.get("kind") == "fixed_time":
        try:
            TimeProtocol(
                limit_seconds=stop["limit_seconds"],
                checkpoints_seconds=tuple(stop["checkpoints_seconds"]),
                max_fes_safety=stop["max_fes_safety"],
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"invalid v3 fixed-time protocol: {exc}") from exc
    else:
        if int(stop.get("fixed_fes", 0)) <= 0:
            raise ValueError("v3 smoke protocol requires positive fixed_fes")
        timed_stop = stop.get("fixed_time")
        if not isinstance(timed_stop, dict):
            raise ValueError("v3 smoke protocol requires fixed_time")
        try:
            TimeProtocol(
                limit_seconds=timed_stop["limit_seconds"],
                checkpoints_seconds=tuple(timed_stop["checkpoints_seconds"]),
                max_fes_safety=timed_stop["max_fes_safety"],
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"invalid v3 smoke timing protocol: {exc}") from exc
    fingerprint = config["source_fingerprint"]
    if (
        not isinstance(fingerprint, str)
        or len(fingerprint) != 64
        or any(char not in "0123456789abcdef" for char in fingerprint)
    ):
        raise ValueError("v3 config source_fingerprint must be SHA-256 hex")
    registry = config.get("case_registry")
    if registry is not None:
        if not isinstance(registry, list) or not registry:
            raise ValueError("v3 config case_registry must be a non-empty list")
        scenario_ids = []
        for entry in registry:
            if not isinstance(entry, dict) or not {
                "scenario_id", "scenario"
            }.issubset(entry):
                raise ValueError("v3 config case_registry entry is incomplete")
            scenario_ids.append(str(entry["scenario_id"]))
            try:
                DeploymentScenario(ScenarioConfig.from_dict(entry["scenario"]))
            except (TypeError, ValueError) as exc:
                raise ValueError(f"invalid v3 case scenario: {exc}") from exc
        if len(set(scenario_ids)) != len(scenario_ids):
            raise ValueError("v3 config case_registry has duplicate scenario_id")


def _scenario_for_record(record, config):
    scenario_data = config["scenario"]
    registry = config.get("case_registry")
    if registry is not None:
        scenario_id = str(record.get("scenario_id", ""))
        matches = [
            entry for entry in registry
            if str(entry["scenario_id"]) == scenario_id
        ]
        if len(matches) != 1:
            raise ValueError("v3 record scenario_id is outside case_registry")
        scenario_data = matches[0]["scenario"]
        if "scenario" not in record:
            raise ValueError("v3 sweep record must embed its scenario")
    if "scenario" in record and _normalized(record["scenario"]) != _normalized(
        scenario_data
    ):
        raise ValueError("v3 record scenario mismatch")
    try:
        return DeploymentScenario(ScenarioConfig.from_dict(scenario_data))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid v3 record scenario: {exc}") from exc


def _stop_protocol_for_record(record, config):
    stop = config["stop_protocol"]
    if stop.get("kind") != "protocol_smoke":
        return stop
    protocol_kind = record.get("protocol_kind")
    if protocol_kind == "fixed_fes":
        return {"kind": "fixed_fes", "max_fes": int(stop["fixed_fes"])}
    if protocol_kind == "fixed_time":
        return dict(stop["fixed_time"], kind="fixed_time")
    raise ValueError("v3 smoke record protocol_kind is invalid")


def _exact_nonnegative_int(value, label):
    if isinstance(value, bool):
        raise ValueError(f"{label} must be an integer")
    try:
        converted = int(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{label} must be an integer") from exc
    try:
        exact = float(value) == float(converted)
    except (TypeError, ValueError, OverflowError):
        exact = False
    if not exact or converted < 0:
        raise ValueError(f"{label} must be a non-negative integer")
    return converted


def _validated_position(value, deployment, label):
    try:
        position = np.asarray(value, dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be numeric") from exc
    lower, upper = deployment.bounds()
    if position.shape != lower.shape:
        raise ValueError(f"{label} length mismatch")
    if not np.all(np.isfinite(position)):
        raise ValueError(f"{label} contains non-finite values")
    if np.any(position < lower - 1e-12) or np.any(position > upper + 1e-12):
        raise ValueError(f"{label} lies outside scenario bounds")
    return position


def _validated_metrics(metrics, label, expected_f=None):
    keys = ("F", "TC", "SAC", "SASU", "GASU")
    if not isinstance(metrics, dict) or not set(keys).issubset(metrics):
        raise ValueError(f"{label} incomplete")
    try:
        values = np.asarray([metrics[key] for key in keys], dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be numeric") from exc
    if not np.all(np.isfinite(values)):
        raise ValueError(f"{label} contains non-finite values")
    if values[0] < 0.0:
        raise ValueError(f"{label} F must be non-negative")
    if not (0.0 <= values[1] <= 1.0 and 0.0 <= values[2] <= 1.0):
        raise ValueError(f"{label} coverage values must be within [0,1]")
    if values[3] < 0.0 or values[4] < 0.0:
        raise ValueError(f"{label} unevenness values must be non-negative")
    if expected_f is not None and not np.isclose(
        values[0], float(expected_f), rtol=0.0, atol=1e-12
    ):
        raise ValueError(f"{label} F does not match best_F")
    return values


def _validate_v3_run_record(record, config):
    required = {
        "i", "scenario_id", "algo", "seed", "priority_seed", "best_F",
        "gF_history", "final_metrics", "best_pos", "fes", "n_updates",
        "runtime_seconds", "scenario",
    }
    missing = sorted(required - set(record))
    if missing:
        raise ValueError(f"v3 record missing required fields: {missing}")
    deployment = _scenario_for_record(record, config)
    _validated_position(record["best_pos"], deployment, "v3 record best_pos")
    best_f = float(record["best_F"])
    metrics = record["final_metrics"]
    _validated_metrics(metrics, "v3 record final_metrics", best_f)
    try:
        history = np.asarray(record["gF_history"], dtype=float)
    except (TypeError, ValueError) as exc:
        raise ValueError("v3 record gF_history must be numeric") from exc
    if history.ndim != 1 or history.size == 0:
        raise ValueError("v3 record gF_history must be non-empty")
    scalars = [best_f, record["runtime_seconds"]]
    scalars.extend(history.tolist())
    if not np.all(np.isfinite(np.asarray(scalars, dtype=float))):
        raise ValueError("v3 record contains non-finite values")
    if float(record["runtime_seconds"]) < 0.0:
        raise ValueError("v3 record runtime_seconds must be non-negative")
    if best_f < 0.0:
        raise ValueError("v3 record best_F must be non-negative")
    if not np.isclose(best_f, history[-1], rtol=0.0, atol=1e-12):
        raise ValueError("v3 record best_F does not match history")
    if np.any(np.diff(history) > 1e-12):
        raise ValueError("v3 record gF_history must be non-increasing")
    n_p = int(config["n_p"])
    fes = _exact_nonnegative_int(record["fes"], "v3 record fes")
    n_updates = _exact_nonnegative_int(
        record["n_updates"], "v3 record n_updates"
    )
    if history.size != n_updates + 1:
        raise ValueError("v3 record history length does not match n_updates")
    stop = _stop_protocol_for_record(record, config)
    if stop.get("kind") == "fixed_time" and fes > int(stop["max_fes_safety"]):
        raise ValueError("v3 record exceeds the safety ceiling")
    if n_p <= 0 or fes != n_p * (n_updates + 1):
        raise ValueError("v3 record FEs and n_updates are inconsistent")
    if stop.get("kind") == "fixed_fes":
        expected_fes = int(stop.get("max_fes", config.get("max_fes", -1)))
        if fes != expected_fes:
            raise ValueError("v3 record FEs do not match fixed-FE config")
        return

    if stop.get("kind") != "fixed_time":
        raise ValueError("v3 record stop protocol is invalid")
    safety = int(stop["max_fes_safety"])
    timing_fields = {
        "checkpoints", "stop_reason", "overshoot_seconds", "actual_seconds",
        "order_seed", "order_index",
    }
    timing_missing = sorted(timing_fields - set(record))
    if timing_missing:
        raise ValueError(f"v3 timed record missing fields: {timing_missing}")
    if record["stop_reason"] not in {"time_limit", "max_fes_safety"}:
        raise ValueError("v3 timed record stop_reason is invalid")
    actual = float(record["actual_seconds"])
    overshoot = float(record["overshoot_seconds"])
    if not np.isfinite([actual, overshoot]).all() or actual < 0.0 or overshoot < 0.0:
        raise ValueError("v3 timed record contains invalid timing values")
    if float(record["runtime_seconds"]) + 1e-9 < actual:
        raise ValueError("v3 timed runtime_seconds is shorter than actual_seconds")
    checkpoints = record["checkpoints"]
    if not isinstance(checkpoints, list):
        raise ValueError("v3 timed record checkpoints must be a list")
    configured_targets = [float(value) for value in stop["checkpoints_seconds"]]
    actual_targets = [
        float(row.get("target_seconds", -1.0))
        if isinstance(row, dict) else -1.0
        for row in checkpoints
    ]
    if record["stop_reason"] == "time_limit":
        if actual_targets != configured_targets:
            raise ValueError("v3 timed record checkpoints are incomplete")
        limit = float(stop["limit_seconds"])
        if actual < limit or not np.isclose(
            overshoot, actual - limit, rtol=0.0, atol=1e-9
        ):
            raise ValueError("v3 timed record overshoot is inconsistent")
    else:
        if actual_targets != configured_targets[:len(actual_targets)]:
            raise ValueError("v3 safety-stop checkpoints are not a valid prefix")
        if fes != safety:
            raise ValueError("v3 safety-stop record must end at the safety ceiling")
        if actual >= float(stop["limit_seconds"]) or overshoot != 0.0:
            raise ValueError("v3 safety-stop timing is inconsistent")
    checkpoint_actuals = []
    checkpoint_fes = []
    checkpoint_best = []
    for row in checkpoints:
        required_checkpoint = {
            "target_seconds", "actual_seconds", "fes", "best_F",
            "final_metrics", "best_pos",
        }
        if not isinstance(row, dict) or not required_checkpoint.issubset(row):
            raise ValueError("v3 timed checkpoint is incomplete")
        target = float(row["target_seconds"])
        row_actual = float(row["actual_seconds"])
        row_fes = _exact_nonnegative_int(
            row["fes"], "v3 timed checkpoint fes"
        )
        row_best = float(row["best_F"])
        if not np.isfinite([target, row_actual, row_best]).all():
            raise ValueError("v3 timed checkpoint contains non-finite values")
        if row_actual + 1e-12 < target or row_actual > actual + 1e-9:
            raise ValueError("v3 timed checkpoint actual_seconds is inconsistent")
        if row_fes < n_p or row_fes % n_p or row_fes > fes:
            raise ValueError("v3 timed checkpoint FEs exceed final FEs")
        history_index = row_fes // n_p - 1
        if not np.isclose(
            row_best, history[history_index], rtol=0.0, atol=1e-12
        ):
            raise ValueError("v3 timed checkpoint best_F does not match history")
        _validated_metrics(
            row["final_metrics"], "v3 timed checkpoint final_metrics", row_best
        )
        _validated_position(
            row["best_pos"], deployment, "v3 timed checkpoint best_pos"
        )
        checkpoint_actuals.append(row_actual)
        checkpoint_fes.append(row_fes)
        checkpoint_best.append(row_best)
    if np.any(np.diff(checkpoint_actuals) < -1e-12):
        raise ValueError("v3 timed checkpoint actual_seconds is not monotone")
    if np.any(np.diff(checkpoint_fes) < 0):
        raise ValueError("v3 timed checkpoint FEs are not monotone")
    if np.any(np.diff(checkpoint_best) > 1e-12):
        raise ValueError("v3 timed checkpoint best_F is not monotone")


def _validate_v3_record_domain(record, config, result_kind):
    i = _exact_nonnegative_int(record.get("i"), "v3 record i")
    if i >= int(config["n_runs"]):
        raise ValueError("v3 record i is outside n_runs")
    algo = record.get("algo")
    if algo not in config["algorithms"]:
        raise ValueError("v3 record algorithm is outside the registry")
    scenario_ids = (
        {str(entry["scenario_id"]) for entry in config["case_registry"]}
        if config.get("case_registry") else {"default"}
    )
    scenario_id = str(record.get("scenario_id", "default"))
    if scenario_id not in scenario_ids:
        raise ValueError("v3 record scenario_id is outside the registry")
    variants = set(config.get("variants", ()))
    variant = record.get("variant")
    if result_kind == "ablation":
        if variant not in variants:
            raise ValueError("v3 ablation record variant is outside the registry")
    elif result_kind == "protocol_smoke":
        if variant is not None and variant not in variants:
            raise ValueError("v3 smoke record variant is outside the registry")
    elif variant is not None:
        raise ValueError("v3 non-ablation record must not contain a variant")
    if result_kind in {"full", "ablation", "time_budget"} and scenario_id != "default":
        raise ValueError("v3 result kind requires the default scenario_id")
    expected_seed, expected_priority = paired_seeds(i, config["seed_protocol"])
    if (
        _exact_nonnegative_int(record.get("seed"), "v3 record seed")
        != expected_seed
        or _exact_nonnegative_int(
            record.get("priority_seed"), "v3 record priority_seed"
        ) != expected_priority
    ):
        raise ValueError("v3 record seed pair does not match the protocol")
    stop = _stop_protocol_for_record(record, config)
    if stop.get("kind") == "fixed_time":
        order_seed_base = _exact_nonnegative_int(
            config.get("order_seed_base"), "v3 config order_seed_base"
        )
        order_seed = _exact_nonnegative_int(
            record.get("order_seed"), "v3 record order_seed"
        )
        order_index = _exact_nonnegative_int(
            record.get("order_index"), "v3 record order_index"
        )
        expected_order = algorithm_order(i)
        if (
            order_seed != order_seed_base + i
            or order_index >= len(expected_order)
            or expected_order[order_index] != algo
        ):
            raise ValueError("v3 timed algorithm order metadata is inconsistent")


def validate_v3_result_data(data, expected_result_kind=None,
                            expected_config=None):
    """Validate one v3 root and every persisted record before resume/reporting."""
    if not isinstance(data, dict):
        raise ValueError("v3 result root must be an object")
    if data.get("schema_version") != V3_SCHEMA_VERSION:
        raise ValueError("v3 schema_version mismatch")
    if data.get("model_version") != V3_MODEL_VERSION:
        raise ValueError("v3 model_version mismatch")
    result_kind = data.get("result_kind")
    allowed_kinds = {
        "full", "ablation", "area_sweep", "uav_sweep",
        "time_budget", "protocol_smoke",
    }
    if result_kind not in allowed_kinds:
        raise ValueError("v3 result_kind is invalid")
    if expected_result_kind is not None and result_kind != expected_result_kind:
        raise ValueError("v3 result_kind mismatch")
    config = data.get("config")
    if not isinstance(config, dict):
        raise ValueError("v3 config must be an object")
    _validate_v3_config(config)
    if expected_config is not None and _normalized(config) != _normalized(
        expected_config
    ):
        raise ValueError("v3 config mismatch")
    runs = data.get("runs")
    if not isinstance(runs, list):
        raise ValueError("v3 result file must contain a runs list")
    seen = set()
    for record in runs:
        if not isinstance(record, dict):
            raise ValueError("v3 record must be an object")
        _validate_v3_run_record(record, config)
        _validate_v3_record_domain(record, config, result_kind)
        key = _run_key(record)
        if key in seen:
            raise ValueError("v3 result matrix contains a duplicate key")
        seen.add(key)
    return data


def load_or_initialize_v3(path, result_kind, config):
    _validate_v3_config(config)
    expected_config = _normalized(config)
    if not isinstance(result_kind, str) or not result_kind:
        raise ValueError("v3 result_kind must be non-empty")
    if not os.path.exists(path):
        return {
            "schema_version": V3_SCHEMA_VERSION,
            "model_version": V3_MODEL_VERSION,
            "result_kind": result_kind,
            "config": expected_config,
            "runs": [],
        }
    with open(path, encoding="utf-8") as stream:
        data = json.load(stream)
    if data.get("schema_version") != V3_SCHEMA_VERSION:
        raise ValueError("v3 schema_version mismatch")
    if data.get("model_version") != V3_MODEL_VERSION:
        raise ValueError("v3 model_version mismatch")
    if data.get("result_kind") != result_kind:
        raise ValueError("v3 result_kind mismatch")
    stored_config = data.get("config")
    if (
        isinstance(stored_config, dict)
        and ("hardware" in stored_config or "hardware" in expected_config)
        and _normalized(stored_config.get("hardware"))
        != _normalized(expected_config.get("hardware"))
    ):
        raise ValueError("v3 hardware mismatch: use a new output filename")
    if _normalized(stored_config) != expected_config:
        raise ValueError("v3 config mismatch: choose a new output filename")
    return validate_v3_result_data(data, result_kind, expected_config)


def _save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as stream:
        json.dump(_jsonable(data), stream, ensure_ascii=False, indent=2,
                  allow_nan=False)
    os.replace(temporary, path)


def _validate_run_record(record, config):
    required = {
        "i", "algo", "seed", "priority_seed", "best_F", "gF_history",
        "final_metrics", "best_pos", "fes", "n_updates", "runtime_seconds",
    }
    missing = sorted(required - set(record))
    if missing:
        raise ValueError(f"record missing required fields: {missing}")
    if len(record["best_pos"]) != model.N_UAV * 3:
        raise ValueError("record best_pos length mismatch")
    metrics = record["final_metrics"]
    metric_keys = {"F", "TC", "SAC", "SASU", "GASU"}
    if not isinstance(metrics, dict) or not metric_keys.issubset(metrics):
        raise ValueError("record final_metrics incomplete")
    if int(record["fes"]) != int(config["max_fes"]):
        raise ValueError("record FEs do not match config")
    scalars = [record["best_F"], record["runtime_seconds"]]
    scalars.extend(metrics[key] for key in metric_keys)
    if not np.all(np.isfinite(np.asarray(scalars, dtype=float))):
        raise ValueError("record contains non-finite values")


def load_or_initialize(path, config):
    """Create a current-version result root, or resume only when version and config match exactly."""
    expected_config = _normalized(config)
    if not os.path.exists(path):
        return {
            "schema_version": SCHEMA_VERSION,
            "model_version": model.MODEL_VERSION,
            "config": expected_config,
            "runs": [],
        }
    with open(path, encoding="utf-8") as stream:
        data = json.load(stream)
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("schema_version mismatch: refuse to resume old results")
    if data.get("model_version") != model.MODEL_VERSION:
        raise ValueError("model_version mismatch: refuse to resume old results")
    if _normalized(data.get("config")) != expected_config:
        raise ValueError("config mismatch: choose a new output filename")
    if not isinstance(data.get("runs"), list):
        raise ValueError("current result file must contain a runs list")
    for record in data["runs"]:
        if not isinstance(record, dict):
            raise ValueError("record must be an object")
        _validate_run_record(record, expected_config)
    return data


def _run_one(algo, rng_seed, priority, config, scenario=None):
    """Run one algorithm instance; fresh RNG per call, candidates paired but generator state not shared."""
    if scenario is None:
        scenario = (
            scenario_from_config(config)
            if "scenario" in config else model.DEFAULT_SCENARIO
        )
    rng = np.random.default_rng(rng_seed)
    common = {"n_p": int(config["n_p"]), "max_fes": int(config["max_fes"])}
    timed = {}
    stop = config.get("stop_protocol", {})
    if stop.get("kind") == "fixed_time":
        timed["time_protocol"] = TimeProtocol(
            limit_seconds=float(stop["limit_seconds"]),
            checkpoints_seconds=tuple(stop["checkpoints_seconds"]),
            max_fes_safety=int(stop["max_fes_safety"]),
        )
    t0 = time.perf_counter()
    if algo == "pso":
        result = algorithms.run_standard_pso(
            rng, priority, config["mode"], scenario=scenario, **common,
            **timed,
        )
    elif algo == "ahdpso":
        result = algorithms.run_ahdpso(
            rng, priority, config["mode"], scenario=scenario, **common,
            **timed,
        )
    elif algo == "tadmpso":
        result = algorithms.run_tadmpso(
            rng, priority, config["mode"], scenario=scenario, **common,
            **timed,
        )
    elif algo == "ql":
        ql_kwargs = dict(config.get("ql_kwargs", {}))
        if (
            ql_kwargs.get("schedule_label") == "factorization"
            and ql_kwargs.get("use_q_learning") is False
            and "k_schedule" not in ql_kwargs
        ):
            if timed:
                ql_kwargs["k_schedule"] = lambda progress: (
                    algorithms.timed_factorization_k(
                        progress, common["n_p"]
                    )
                )
                ql_kwargs["schedule_label"] = "factorization_time_normalized"
            else:
                ql_kwargs["k_schedule"] = algorithms.factorization_schedule(
                    algorithms.update_count(
                        common["max_fes"], common["n_p"]
                    ),
                    common["n_p"],
                )
        result = algorithms.run_ql_tadmpso(
            rng, priority, config["mode"], **common,
            L=int(config["L"]), G=int(config["G"]),
            scenario=scenario, **timed, **ql_kwargs,
        )
    else:
        raise ValueError(f"unknown algorithm: {algo}")
    result["runtime_seconds"] = time.perf_counter() - t0
    metrics = result["final_metrics"]
    print(
        f"  [{algo:7s}] F={result['best_F']:.5f} "
        f"TC={metrics['TC']*100:.3f}% SAC={metrics['SAC']*100:.3f}% "
        f"SASU={metrics['SASU']:.3f} dB GASU={metrics['GASU']:.3f} dB "
        f"FEs={result['fes']} ({result['runtime_seconds']:.2f} s, seed={rng_seed})",
        flush=True,
    )
    return result


def _run_record(index, algo, optimization_seed, priority_seed, result, **extra):
    record = {
        "i": int(index), "algo": algo, "seed": int(optimization_seed),
        "priority_seed": int(priority_seed), "best_F": float(result["best_F"]),
        "gF_history": result["gF_history"],
        "final_metrics": result["final_metrics"], "best_pos": result["best_pos"],
        "fes": int(result["fes"]), "n_updates": int(result["n_updates"]),
        "runtime_seconds": float(result["runtime_seconds"]),
    }
    for key in (
        "k_history", "q_table", "q_visits", "action_history",
        "reward_history", "k_schedule", "schedule_label", "factor_pairs",
        "factor_boundaries", "checkpoints", "stop_reason",
        "overshoot_seconds", "actual_seconds",
    ):
        if key in result:
            record[key] = result[key]
    record.update(extra)
    return _jsonable(record)


def _path(task):
    return os.path.join(OUT_DIR, OUTPUT_FILES[task])


def cmd_gate(max_fes=None):
    config = dict(GATE_CONFIG)
    if max_fes is not None:
        config["max_fes"] = int(max_fes)
    data = load_or_initialize(_path("gate"), config)
    if not data["runs"]:
        result = _run_one("ahdpso", 0, model.priority_mask(0), config)
        data["runs"].append(_run_record(0, "ahdpso", 0, 0, result))
        _save_json(_path("gate"), data)
    return data


def cmd_smoke(max_fes=None, L=16, G=15):
    config = dict(MAIN_CONFIG, L=int(L), G=int(G))
    if max_fes is not None:
        config["max_fes"] = int(max_fes)
    path = (_path("smoke") if config["max_fes"] == MAIN_CONFIG["max_fes"]
            else os.path.join(OUT_DIR,
                              f"smoke_{config['max_fes']}fes_50grid_v2.json"))
    data = load_or_initialize(path, config)
    done = {run["algo"] for run in data["runs"]}
    seed, priority_seed = paired_seeds(0)
    priority = model.priority_mask(priority_seed)
    for algo in ("pso", "ahdpso", "ql"):
        if algo not in done:
            result = _run_one(algo, seed, priority, config)
            data["runs"].append(_run_record(0, algo, seed, priority_seed, result))
            _save_json(path, data)
    return data


def _summarize_representation(snapshot_rows):
    summary = []
    for L in L_VALUES:
        rows = [snapshot["rows"][L_VALUES.index(L)] for snapshot in snapshot_rows]
        summary.append({
            "L": L,
            "rank_mean": float(np.mean([r["rank_correlation_to_L100"] for r in rows])),
            "rank_std": float(np.std([r["rank_correlation_to_L100"] for r in rows])),
            "ari_mean": float(np.mean([r["ari_to_L100"] for r in rows])),
            "ari_std": float(np.std([r["ari_to_L100"] for r in rows])),
            "feature_seconds_mean": float(np.mean([r["feature_seconds"] for r in rows])),
            "clustering_seconds_mean": float(np.mean([r["clustering_seconds"] for r in rows])),
        })
    eligible = [r["L"] for r in summary
                if r["rank_mean"] + r["rank_std"] >= 1.0 - 1e-12
                and r["ari_mean"] + r["ari_std"] >= 1.0 - 1e-12]
    if len(eligible) < 2:
        order = sorted(summary,
                       key=lambda r: (-(r["rank_mean"] + r["ari_mean"]), r["L"]))
        eligible.extend(r["L"] for r in order if r["L"] not in eligible)
    return summary, sorted(set(eligible[:2]))


def cmd_l_repr(n_snapshots=5):
    config = {"n_p": 50, "L_values": L_VALUES, "n_snapshots": int(n_snapshots),
              "direction_seed": 20260829, "cluster_seed": 20260829}
    snapshots = []
    for i in range(int(n_snapshots)):
        X, _ = algorithms.init_swarm(np.random.default_rng(2000 + i), 50)
        snapshots.append({"snapshot_seed": 2000 + i,
                          "rows": representation_sensitivity(X, L_VALUES,
                                                              seed=20260829)})
    summary, shortlist = _summarize_representation(snapshots)
    data = {
        "schema_version": SCHEMA_VERSION, "model_version": model.MODEL_VERSION,
        "config": config, "snapshots": snapshots, "summary": summary,
        "shortlist": shortlist,
        "shortlist_rule": (
            "within one snapshot standard deviation of L=100 for rank and ARI; "
            "if fewer than two survive, supplement by joint stability score"
        ),
    }
    _save_json(_path("l_repr"), data)
    return data


def _read_l_shortlist():
    path = _path("l_repr")
    if not os.path.exists(path):
        raise ValueError("run l_repr before l_opt")
    with open(path, encoding="utf-8") as stream:
        data = json.load(stream)
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("schema_version mismatch in L representation results")
    if data.get("model_version") != model.MODEL_VERSION:
        raise ValueError("model_version mismatch in L representation results")
    config = data.get("config", {})
    if (int(config.get("n_p", -1)) != MAIN_CONFIG["n_p"]
            or list(config.get("L_values", [])) != L_VALUES):
        raise ValueError("L representation config mismatch")
    return [int(value) for value in data["shortlist"]]


def _recommend_one_se(runs, parameter):
    rows = []
    for value in sorted({int(run[parameter]) for run in runs}):
        selected = [run for run in runs if int(run[parameter]) == value]
        scores = np.asarray([run["best_F"] for run in selected])
        std = float(scores.std(ddof=1)) if len(scores) > 1 else 0.0
        rows.append({parameter: value, "mean_F": float(scores.mean()), "std_F": std,
                     "se_F": std / np.sqrt(len(scores)),
                     "runtime_seconds_mean": float(np.mean([
                         run["runtime_seconds"] for run in selected]))})
    best = min(rows, key=lambda row: row["mean_F"])
    limit = best["mean_F"] + best["se_F"]
    eligible = [row for row in rows if row["mean_F"] <= limit]
    return rows, int(min(row[parameter] for row in eligible)), float(limit)


def cmd_l_opt(n_runs=SENSITIVITY_RUNS, candidates=None, max_fes=None, G=15):
    candidates = _read_l_shortlist() if candidates is None else [int(v) for v in candidates]
    config = dict(MAIN_CONFIG, candidate_L=candidates, G=int(G), n_runs=int(n_runs))
    if max_fes is not None:
        config["max_fes"] = int(max_fes)
    path = _path("l_opt")
    data = load_or_initialize(path, config)
    done = {(int(run["i"]), int(run["L"])) for run in data["runs"]}
    for i in range(int(n_runs)):
        seed, priority_seed = paired_seeds(i)
        priority = model.priority_mask(priority_seed)
        for L in candidates:
            if (i, L) not in done:
                result = _run_one("ql", seed, priority, dict(config, L=L))
                data["runs"].append(_run_record(i, "ql", seed, priority_seed,
                                                        result, L=L, G=int(G)))
                _save_json(path, data)
    summary, recommended, limit = _recommend_one_se(data["runs"], "L")
    data.update(summary=summary, recommended_L=recommended, one_se_limit=limit)
    _save_json(path, data)
    return data


def _recommended_l():
    path = _path("l_opt")
    if not os.path.exists(path):
        raise ValueError("run l_opt before G sensitivity")
    with open(path, encoding="utf-8") as stream:
        data = json.load(stream)
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("schema_version mismatch in L optimization results")
    if data.get("model_version") != model.MODEL_VERSION:
        raise ValueError("model_version mismatch in L optimization results")
    config = data.get("config", {})
    if any(config.get(key) != value for key, value in MAIN_CONFIG.items()):
        raise ValueError("L selection must use the main full-budget config")
    recommended = int(data["recommended_L"])
    if recommended not in [int(value) for value in config.get("candidate_L", [])]:
        raise ValueError("recommended_L is outside candidate_L")
    return recommended


def cmd_g_sensitivity(n_runs=SENSITIVITY_RUNS, L=None, max_fes=None):
    L = _recommended_l() if L is None else int(L)
    config = dict(MAIN_CONFIG, L=L, candidate_G=G_VALUES, n_runs=int(n_runs))
    if max_fes is not None:
        config["max_fes"] = int(max_fes)
    path = _path("g_sensitivity")
    data = load_or_initialize(path, config)
    done = {(int(run["i"]), int(run["G"])) for run in data["runs"]}
    for i in range(int(n_runs)):
        seed, priority_seed = paired_seeds(i)
        priority = model.priority_mask(priority_seed)
        for G in G_VALUES:
            if (i, G) not in done:
                result = _run_one("ql", seed, priority, dict(config, G=G))
                data["runs"].append(_run_record(i, "ql", seed, priority_seed,
                                                        result, L=L, G=G))
                _save_json(path, data)
    summary, recommended, limit = _recommend_one_se(data["runs"], "G")
    for row in summary:
        selected = [run for run in data["runs"] if int(run["G"]) == row["G"]]
        row["actions_mean"] = float(np.mean([len(run["action_history"])
                                              for run in selected]))
        row["visited_state_actions_mean"] = float(np.mean([
            np.count_nonzero(np.asarray(run["q_visits"])) for run in selected]))
    data.update(summary=summary, recommended_G=recommended, one_se_limit=limit)
    _save_json(path, data)
    return data


def _recommended_g():
    path = _path("g_sensitivity")
    if not os.path.exists(path):
        raise ValueError("run g_sensitivity before full comparison")
    with open(path, encoding="utf-8") as stream:
        data = json.load(stream)
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("schema_version mismatch in G sensitivity results")
    if data.get("model_version") != model.MODEL_VERSION:
        raise ValueError("model_version mismatch in G sensitivity results")
    config = data.get("config", {})
    if any(config.get(key) != value for key, value in MAIN_CONFIG.items()):
        raise ValueError("G selection must use the main full-budget config")
    if int(config.get("L", -1)) != _recommended_l():
        raise ValueError("G selection L does not match recommended_L")
    if [int(value) for value in config.get("candidate_G", [])] != G_VALUES:
        raise ValueError("G sensitivity candidates mismatch")
    recommended = int(data["recommended_G"])
    if recommended not in G_VALUES:
        raise ValueError("recommended_G is outside candidate_G")
    return recommended


def _validate_legacy_selection_runs(data, config, parameter, candidates):
    """Validate the immutable v2 tuning evidence used by the v3 protocol."""
    runs = data.get("runs")
    if not isinstance(runs, list):
        raise ValueError(f"legacy {parameter} selection runs must be a list")
    expected_keys = {
        (i, int(value))
        for i in range(SENSITIVITY_RUNS)
        for value in candidates
    }
    actual_keys = set()
    for record in runs:
        if not isinstance(record, dict):
            raise ValueError(f"legacy {parameter} selection record must be an object")
        _validate_run_record(record, config)
        key = (int(record["i"]), int(record[parameter]))
        if key in actual_keys:
            raise ValueError(f"legacy {parameter} selection has duplicate runs")
        actual_keys.add(key)
        expected_seed, expected_priority_seed = paired_seeds(key[0])
        if (
            int(record["seed"]), int(record["priority_seed"])
        ) != (expected_seed, expected_priority_seed):
            raise ValueError(f"legacy {parameter} selection seed mismatch")
    if actual_keys != expected_keys:
        raise ValueError(f"legacy {parameter} selection matrix is incomplete")

    summary = data.get("summary")
    if not isinstance(summary, list) or {
        int(row.get(parameter, -1)) for row in summary
    } != {int(value) for value in candidates}:
        raise ValueError(f"legacy {parameter} selection summary is incomplete")
    recomputed, recommended, limit = _recommend_one_se(runs, parameter)
    summary_by_value = {int(row[parameter]): row for row in summary}
    for expected in recomputed:
        actual = summary_by_value[int(expected[parameter])]
        for key in ("mean_F", "std_F", "se_F", "runtime_seconds_mean"):
            if not np.isclose(
                float(actual.get(key, np.nan)), float(expected[key]),
                rtol=0.0, atol=1e-12,
            ):
                raise ValueError(f"legacy {parameter} selection summary mismatch")
    if not np.isclose(
        float(data.get("one_se_limit", np.nan)), limit, rtol=0.0, atol=1e-12
    ):
        raise ValueError(f"legacy {parameter} selection one-SE limit mismatch")
    return int(recommended)


def _legacy_recommended_l():
    """Read only the exact completed v2 L-selection evidence for v3 runs."""
    path = _path("l_opt")
    if not os.path.exists(path):
        raise ValueError("valid legacy L selection evidence is required")
    with open(path, encoding="utf-8") as stream:
        data = json.load(stream)
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("legacy L selection schema_version mismatch")
    if data.get("model_version") != model.MODEL_VERSION:
        raise ValueError("legacy L selection model_version mismatch")
    expected_config = dict(
        MAIN_CONFIG, candidate_L=[50, 100], G=15,
        n_runs=SENSITIVITY_RUNS,
    )
    if _normalized(data.get("config")) != _normalized(expected_config):
        raise ValueError("legacy L selection requires the exact full-budget config")
    recomputed = _validate_legacy_selection_runs(
        data, expected_config, "L", [50, 100]
    )
    if recomputed != 50 or int(data.get("recommended_L", -1)) != 50:
        raise ValueError("legacy L selection recommendation mismatch")
    return 50


def _legacy_recommended_g():
    """Read only the exact completed v2 G-selection evidence for v3 runs."""
    selected_l = _legacy_recommended_l()
    path = _path("g_sensitivity")
    if not os.path.exists(path):
        raise ValueError("valid legacy G selection evidence is required")
    with open(path, encoding="utf-8") as stream:
        data = json.load(stream)
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("legacy G selection schema_version mismatch")
    if data.get("model_version") != model.MODEL_VERSION:
        raise ValueError("legacy G selection model_version mismatch")
    expected_config = dict(
        MAIN_CONFIG, L=selected_l, candidate_G=list(G_VALUES),
        n_runs=SENSITIVITY_RUNS,
    )
    if _normalized(data.get("config")) != _normalized(expected_config):
        raise ValueError("legacy G selection requires the exact full-budget config")
    recomputed = _validate_legacy_selection_runs(
        data, expected_config, "G", G_VALUES
    )
    if recomputed != 5 or int(data.get("recommended_G", -1)) != 5:
        raise ValueError("legacy G selection recommendation mismatch")
    return 5


def _v3_formal_config(result_kind, algorithms_to_run, n_runs=N_RUNS,
                      L=50, G=5, scenario=None, seed_protocol=None,
                      stop_protocol=None, **extra):
    """Build an explicit, fingerprinted v3 experiment configuration."""
    if scenario is None:
        scenario = model.DEFAULT_SCENARIO
    elif isinstance(scenario, ScenarioConfig):
        scenario = DeploymentScenario(scenario)
    if not isinstance(scenario, DeploymentScenario):
        raise TypeError("scenario must be a DeploymentScenario or ScenarioConfig")
    if stop_protocol is None:
        stop_protocol = {
            "kind": "fixed_fes", "max_fes": MAIN_CONFIG["max_fes"],
        }
    stop_protocol = _normalized(stop_protocol)
    if stop_protocol.get("kind") == "fixed_fes":
        max_fes = int(stop_protocol["max_fes"])
    elif stop_protocol.get("kind") == "protocol_smoke":
        max_fes = int(stop_protocol["fixed_fes"])
    else:
        max_fes = int(stop_protocol["max_fes_safety"])
    formal_flag = extra.pop("formal_qualification", True)
    evidence_type = extra.pop(
        "evidence_type",
        "formal_held_out_v3" if formal_flag else "nonformal_v3",
    )
    config = {
        "scenario": scenario.config.to_dict(),
        "algorithms": list(algorithms_to_run),
        "seed_protocol": (
            HELD_OUT_SEED_PROTOCOL if seed_protocol is None else seed_protocol
        ),
        "n_runs": int(n_runs),
        "stop_protocol": stop_protocol,
        "source_fingerprint": optimizer_source_fingerprint(),
        "n_p": MAIN_CONFIG["n_p"],
        "max_fes": max_fes,
        "mode": scenario.config.propagation_mode,
        "L": int(L),
        "G": int(G),
        "evidence_type": evidence_type,
        "formal_qualification": formal_flag,
    }
    config.update(extra)
    _validate_v3_config(config)
    if not isinstance(result_kind, str) or not result_kind:
        raise ValueError("result_kind must be non-empty")
    return config


def _run_key(run):
    return (
        int(run["i"]), run.get("scenario_id", "default"),
        run["algo"], run.get("variant"),
    )


def _v3_algorithm_runs(task, result_kind, algorithms_to_run, config, n_runs,
                       scenario=None, scenario_id="default"):
    """Run and atomically persist one paired v3 algorithm matrix."""
    if scenario is None:
        scenario = scenario_from_config(config)
    path = _path(task)
    data = load_or_initialize_v3(path, result_kind, config)
    done = {_run_key(run) for run in data["runs"]}
    seed_protocol = config["seed_protocol"]
    for i in range(int(n_runs)):
        seed, priority_seed = paired_seeds(i, seed_protocol)
        priority = scenario.priority_mask(priority_seed)
        for item in algorithms_to_run:
            algo = item if isinstance(item, str) else item[0]
            variant = None if isinstance(item, str) else item[1]
            key = (i, scenario_id, algo, variant)
            if key in done:
                continue
            local = dict(config)
            if not isinstance(item, str) and len(item) > 2:
                local["ql_kwargs"] = dict(item[2])
            result = _run_one(
                algo, seed, priority, local, scenario=scenario
            )
            extra = {
                "scenario_id": str(scenario_id),
                "scenario": scenario.config.to_dict(),
            }
            if variant is not None:
                extra["variant"] = variant
            record = _run_record(
                i, algo, seed, priority_seed, result, **extra
            )
            _validate_v3_run_record(record, config)
            data["runs"].append(record)
            done.add(key)
            _save_json(path, data)
    return data


def _paired_algorithm_runs(task, algorithms_to_run, config, n_runs):
    path = _path(task)
    data = load_or_initialize(path, config)
    done = {(int(run["i"]), run["algo"], run.get("variant"))
            for run in data["runs"]}
    seed_protocol = config.get("seed_protocol", SELECTION_SEED_PROTOCOL)
    for i in range(int(n_runs)):
        seed, priority_seed = paired_seeds(i, seed_protocol)
        priority = model.priority_mask(priority_seed)
        for item in algorithms_to_run:
            algo = item if isinstance(item, str) else item[0]
            variant = None if isinstance(item, str) else item[1]
            if (i, algo, variant) in done:
                continue
            local = dict(config)
            if not isinstance(item, str) and len(item) > 2:
                local["ql_kwargs"] = item[2]
            result = _run_one(algo, seed, priority, local)
            extra = {} if variant is None else {"variant": variant}
            data["runs"].append(_run_record(i, algo, seed, priority_seed,
                                                    result, **extra))
            _save_json(path, data)
    return data


def _cmd_full(task, n_runs=N_RUNS, L=None, G=None, max_fes=None,
              seed_protocol=None):
    L = _recommended_l() if L is None else int(L)
    G = _recommended_g() if G is None else int(G)
    config = dict(MAIN_CONFIG, L=L, G=G, n_runs=int(n_runs))
    if seed_protocol is not None:
        config["seed_protocol"] = seed_protocol
        config["source_fingerprint"] = optimizer_source_fingerprint()
    if max_fes is not None:
        config["max_fes"] = int(max_fes)
    return _paired_algorithm_runs(task, ["pso", "ahdpso", "ql"],
                                  config, n_runs)


def cmd_full(n_runs=N_RUNS, L=None, G=None, max_fes=None):
    """Historical selection-seed result; kept for layout and trend checks."""
    return _cmd_full("full", n_runs, L, G, max_fes)


def _validate_final_arguments(n_runs, L, G, max_fes, label):
    if int(n_runs) != N_RUNS:
        raise ValueError(f"final {label} requires exactly {N_RUNS} runs")
    if max_fes is not None and int(max_fes) != MAIN_CONFIG["max_fes"]:
        raise ValueError(f"final {label} requires the main 25000-FE budget")
    recommended_l = _legacy_recommended_l()
    recommended_g = _legacy_recommended_g()
    if L is not None and int(L) != recommended_l:
        raise ValueError(f"final {label} L must match recommended_L={recommended_l}")
    if G is not None and int(G) != recommended_g:
        raise ValueError(f"final {label} G must match recommended_G={recommended_g}")
    return recommended_l, recommended_g


def cmd_full_final(n_runs=N_RUNS, L=None, G=None, max_fes=None):
    """Formal held-out seed comparison, fully isolated from parameter selection."""
    selected_l, selected_g = _validate_final_arguments(
        n_runs, L, G, max_fes, "comparison"
    )
    config = _v3_formal_config(
        "full", FORMAL_ALGORITHMS, n_runs=n_runs,
        L=selected_l, G=selected_g,
    )
    return _v3_algorithm_runs(
        "full_final", "full", FORMAL_ALGORITHMS, config, n_runs,
        scenario=model.DEFAULT_SCENARIO,
    )


def reuse_full_variant(ablation_data, full_data, config, n_runs):
    """Reuse QL records from the same-config formal experiment as the ablation full-algorithm group."""
    if full_data.get("schema_version") == V3_SCHEMA_VERSION:
        if full_data.get("model_version") != V3_MODEL_VERSION:
            raise ValueError("full-result v3 model mismatch")
        if full_data.get("result_kind") != "full":
            raise ValueError("full-result v3 result_kind mismatch")
        full_config = full_data.get("config")
        if not isinstance(full_config, dict):
            raise ValueError("full-result v3 config is missing")
        common_keys = {
            "scenario", "seed_protocol", "n_runs", "stop_protocol",
            "source_fingerprint", "n_p", "max_fes", "mode", "L", "G",
        }
        if any(
            _normalized(full_config.get(key)) != _normalized(config.get(key))
            for key in common_keys
        ):
            raise ValueError("full-result v3 config mismatch")
        if tuple(full_config.get("algorithms", ())) != FORMAL_ALGORITHMS:
            raise ValueError("full-result v3 algorithm matrix mismatch")
        for run in full_data.get("runs", []):
            _validate_v3_run_record(run, full_config)
    else:
        if full_data.get("schema_version") != SCHEMA_VERSION:
            raise ValueError("full-result schema mismatch")
        if full_data.get("model_version") != model.MODEL_VERSION:
            raise ValueError("full-result model mismatch")
        if _normalized(full_data.get("config")) != _normalized(config):
            raise ValueError("full-result config mismatch")

    existing = {(int(run["i"]), run.get("variant"))
                for run in ablation_data["runs"]}
    copied = 0
    for i in range(int(n_runs)):
        if (i, "full") in existing:
            continue
        matches = [run for run in full_data["runs"]
                   if run.get("algo") == "ql" and int(run["i"]) == i]
        if len(matches) != 1:
            raise ValueError(f"full results require one QL record for run {i}")
        seed_protocol = config.get("seed_protocol", SELECTION_SEED_PROTOCOL)
        seed, priority_seed = paired_seeds(i, seed_protocol)
        if (int(matches[0]["seed"]), int(matches[0]["priority_seed"])) != (seed, priority_seed):
            raise ValueError(f"full-result seed mismatch at run {i}")
        record = dict(matches[0])
        record["variant"] = "full"
        ablation_data["runs"].append(record)
        copied += 1
    return copied


def _cmd_ablation(task, full_task, n_runs=N_RUNS, L=None, G=None,
                  max_fes=None, seed_protocol=None):
    L = _recommended_l() if L is None else int(L)
    G = _recommended_g() if G is None else int(G)
    config = dict(MAIN_CONFIG, L=L, G=G, n_runs=int(n_runs))
    if seed_protocol is not None:
        config["seed_protocol"] = seed_protocol
        config["source_fingerprint"] = optimizer_source_fingerprint()
    if max_fes is not None:
        config["max_fes"] = int(max_fes)
    ablation_path = _path(task)
    ablation_data = load_or_initialize(ablation_path, config)
    full_path = _path(full_task)
    if os.path.exists(full_path):
        with open(full_path, encoding="utf-8") as stream:
            full_data = json.load(stream)
        copied = reuse_full_variant(ablation_data, full_data, config, n_runs)
        if copied:
            print(f"  [reuse  ] copied {copied} full QL runs into ablation")
            _save_json(ablation_path, ablation_data)
    variants = [
        ("ql", "full", {}),
        ("ql", "no_fsw", {"use_fsw": False}),
        ("ql", "no_alignment", {"align_guides": False}),
        ("ql", "random_topology", {"use_topology": False}),
        ("ql", "no_cross_swarm", {"use_cross_swarm": False}),
        ("ql", "fixed_k", {"use_q_learning": False}),
    ]
    return _paired_algorithm_runs(task, variants, config, n_runs)


def cmd_ablation(n_runs=N_RUNS, L=None, G=None, max_fes=None):
    """Historical selection-seed ablation; kept for layout and trend checks."""
    return _cmd_ablation("ablation", "full", n_runs, L, G, max_fes)


def _cmd_ablation_v3(config, n_runs):
    ablation_path = _path("ablation_final")
    ablation_data = load_or_initialize_v3(
        ablation_path, "ablation", config
    )
    full_path = _path("full_final")
    if not os.path.exists(full_path):
        raise ValueError("run full_final before ablation_final")
    with open(full_path, encoding="utf-8") as stream:
        full_data = json.load(stream)
    copied = reuse_full_variant(
        ablation_data, full_data, config, n_runs
    )
    if copied:
        print(f"  [reuse  ] copied {copied} held-out QL runs into ablation")
        _save_json(ablation_path, ablation_data)
    return _v3_algorithm_runs(
        "ablation_final", "ablation", ABLATION_VARIANTS,
        config, n_runs, scenario=model.DEFAULT_SCENARIO,
    )


def _area_case_registry():
    return [
        {
            "scenario_id": scenario_id,
            "scenario": ScenarioConfig(
                area_m=area_m, n_grid=n_grid, n_uav=25
            ).to_dict(),
        }
        for scenario_id, area_m, n_grid in AREA_CASES
    ]


def _uav_case_registry():
    return [
        {
            "scenario_id": scenario_id,
            "scenario": ScenarioConfig(n_uav=n_uav).to_dict(),
        }
        for scenario_id, n_uav in UAV_CASES
    ]


def _cmd_sweep(task, result_kind, case_registry, n_runs, *, L, G,
               max_fes):
    """Execute one scenario sweep with pairing across cases and algorithms."""
    config = _v3_formal_config(
        result_kind,
        FORMAL_ALGORITHMS,
        n_runs=n_runs,
        L=L,
        G=G,
        scenario=model.DEFAULT_SCENARIO,
        seed_protocol=ROBUSTNESS_SEED_PROTOCOL,
        stop_protocol={"kind": "fixed_fes", "max_fes": int(max_fes)},
        case_registry=_normalized(case_registry),
    )
    path = _path(task)
    data = load_or_initialize_v3(path, result_kind, config)
    done = {_run_key(run) for run in data["runs"]}
    for i in range(int(n_runs)):
        seed, priority_seed = paired_seeds(i, ROBUSTNESS_SEED_PROTOCOL)
        for entry in config["case_registry"]:
            scenario_id = str(entry["scenario_id"])
            scenario = DeploymentScenario(
                ScenarioConfig.from_dict(entry["scenario"])
            )
            priority = scenario.priority_mask(priority_seed)
            for algo in FORMAL_ALGORITHMS:
                key = (i, scenario_id, algo, None)
                if key in done:
                    continue
                result = _run_one(
                    algo, seed, priority, config, scenario=scenario
                )
                record = _run_record(
                    i,
                    algo,
                    seed,
                    priority_seed,
                    result,
                    scenario_id=scenario_id,
                    scenario=scenario.config.to_dict(),
                )
                _validate_v3_run_record(record, config)
                data["runs"].append(record)
                done.add(key)
                _save_json(path, data)
    return data


def cmd_area_sweep_final(n_runs=N_RUNS):
    selected_l, selected_g = _validate_final_arguments(
        n_runs, None, None, None, "area sweep"
    )
    return _cmd_sweep(
        "area_sweep_final", "area_sweep", _area_case_registry(),
        n_runs, L=selected_l, G=selected_g,
        max_fes=MAIN_CONFIG["max_fes"],
    )


def cmd_uav_sweep_final(n_runs=N_RUNS):
    selected_l, selected_g = _validate_final_arguments(
        n_runs, None, None, None, "UAV sweep"
    )
    return _cmd_sweep(
        "uav_sweep_final", "uav_sweep", _uav_case_registry(),
        n_runs, L=selected_l, G=selected_g,
        max_fes=MAIN_CONFIG["max_fes"],
    )


def _warmup_algorithms(L, G):
    """Warm every timed candidate without adding warm-up rows to results."""
    config = dict(MAIN_CONFIG, max_fes=100, L=int(L), G=int(G))
    for offset, algo in enumerate(FORMAL_ALGORITHMS):
        priority_seed = 800 + offset
        _run_one(
            algo,
            8000 + offset,
            model.DEFAULT_SCENARIO.priority_mask(priority_seed),
            config,
            scenario=model.DEFAULT_SCENARIO,
        )


def _cmd_time(config, n_runs):
    if config.get("warmup_completed") is not True:
        raise ValueError("timed config requires completed warm-up")
    path = _path("time_final")
    data = load_or_initialize_v3(path, "time_budget", config)
    done = {_run_key(run) for run in data["runs"]}
    for i in range(int(n_runs)):
        seed, priority_seed = paired_seeds(i, TIME_SEED_PROTOCOL)
        order = algorithm_order(i)
        pending = [
            algo for algo in order
            if (i, "default", algo, None) not in done
        ]
        contexts = {}
        for algo in pending:
            local_scenario = scenario_from_config(config)
            local_priority = local_scenario.priority_mask(priority_seed)
            local_scenario.prepare_for_evaluation(local_priority)
            contexts[algo] = (local_scenario, local_priority)
        for order_index, algo in enumerate(order):
            key = (i, "default", algo, None)
            if key in done:
                continue
            scenario, priority = contexts[algo]
            result = _run_one(
                algo, seed, priority, config, scenario=scenario
            )
            record = _run_record(
                i,
                algo,
                seed,
                priority_seed,
                result,
                scenario_id="default",
                scenario=scenario.config.to_dict(),
                order_seed=9000 + i,
                order_index=order_index,
            )
            _validate_v3_run_record(record, config)
            data["runs"].append(record)
            done.add(key)
            _save_json(path, data)
    return data


def cmd_time_final(n_runs=N_RUNS, seconds=60.0):
    if int(n_runs) != N_RUNS:
        raise ValueError(f"final time comparison requires exactly {N_RUNS} runs")
    if not np.isclose(float(seconds), 60.0, rtol=0.0, atol=1e-12):
        raise ValueError("final time comparison requires exactly 60 seconds")
    selected_l, selected_g = _validate_final_arguments(
        n_runs, None, None, None, "time comparison"
    )
    _warmup_algorithms(selected_l, selected_g)
    stop_protocol = {
        "kind": "fixed_time",
        "limit_seconds": 60.0,
        "checkpoints_seconds": [15.0, 30.0, 60.0],
        "max_fes_safety": 5_000_000,
    }
    config = _v3_formal_config(
        "time_budget",
        FORMAL_ALGORITHMS,
        n_runs=n_runs,
        L=selected_l,
        G=selected_g,
        scenario=model.DEFAULT_SCENARIO,
        seed_protocol=TIME_SEED_PROTOCOL,
        stop_protocol=stop_protocol,
        timing_protocol="time_normalized_v1",
        hardware=hardware_fingerprint(),
        order_seed_base=9000,
        warmup_completed=True,
    )
    return _cmd_time(config, n_runs)


def _smoke_case_registry():
    default = model.DEFAULT_SCENARIO.config.to_dict()
    registry = [{"scenario_id": "default", "scenario": default}]
    registry.extend({
        "scenario_id": f"area_{scenario_id}",
        "scenario": ScenarioConfig(
            area_m=area_m, n_grid=n_grid, n_uav=25
        ).to_dict(),
    } for scenario_id, area_m, n_grid in AREA_CASES)
    registry.extend({
        "scenario_id": f"uav_{scenario_id}",
        "scenario": ScenarioConfig(n_uav=n_uav).to_dict(),
    } for scenario_id, n_uav in UAV_CASES)
    registry.append({"scenario_id": "time_default", "scenario": default})
    return registry


def _cmd_protocol_smoke(config):
    path = _path("protocol_smoke")
    data = load_or_initialize_v3(path, "protocol_smoke", config)
    done = {_run_key(run) for run in data["runs"]}
    registry = {
        str(entry["scenario_id"]): DeploymentScenario(
            ScenarioConfig.from_dict(entry["scenario"])
        )
        for entry in config["case_registry"]
    }
    seed, priority_seed = paired_seeds(0, SMOKE_SEED_PROTOCOL)
    fixed_stop = {
        "kind": "fixed_fes",
        "max_fes": int(config["stop_protocol"]["fixed_fes"]),
    }
    timed_stop = dict(
        config["stop_protocol"]["fixed_time"], kind="fixed_time"
    )

    def execute(scenario_id, item, protocol_kind, suite, **metadata):
        algo = item if isinstance(item, str) else item[0]
        variant = None if isinstance(item, str) else item[1]
        key = (0, scenario_id, algo, variant)
        if key in done:
            return
        scenario = registry[scenario_id]
        local = dict(config)
        local["stop_protocol"] = (
            fixed_stop if protocol_kind == "fixed_fes" else timed_stop
        )
        local["max_fes"] = int(
            fixed_stop["max_fes"] if protocol_kind == "fixed_fes"
            else timed_stop["max_fes_safety"]
        )
        if not isinstance(item, str) and len(item) > 2:
            local["ql_kwargs"] = dict(item[2])
        priority = scenario.priority_mask(priority_seed)
        result = _run_one(
            algo, seed, priority, local, scenario=scenario
        )
        extra = {
            "scenario_id": scenario_id,
            "scenario": scenario.config.to_dict(),
            "protocol_kind": protocol_kind,
            "suite": suite,
        }
        if variant is not None:
            extra["variant"] = variant
        extra.update(metadata)
        record = _run_record(
            0, algo, seed, priority_seed, result, **extra
        )
        _validate_v3_run_record(record, config)
        data["runs"].append(record)
        done.add(key)
        _save_json(path, data)

    for algo in FORMAL_ALGORITHMS:
        execute("default", algo, "fixed_fes", "comparison")
    factor_control = next(
        item for item in ABLATION_VARIANTS if item[1] == "factor_schedule"
    )
    execute(
        "default", factor_control, "fixed_fes", "factor_control"
    )
    for scenario_id, _, _ in AREA_CASES:
        for algo in FORMAL_ALGORITHMS:
            execute(
                f"area_{scenario_id}", algo, "fixed_fes", "area_sweep"
            )
    for scenario_id, _ in UAV_CASES:
        for algo in FORMAL_ALGORITHMS:
            execute(
                f"uav_{scenario_id}", algo, "fixed_fes", "uav_sweep"
            )
    for order_index, algo in enumerate(algorithm_order(0)):
        execute(
            "time_default", algo, "fixed_time", "time_budget",
            order_seed=9000, order_index=order_index,
        )
    return data


def cmd_protocol_smoke():
    selected_l = _legacy_recommended_l()
    selected_g = _legacy_recommended_g()
    _warmup_algorithms(selected_l, selected_g)
    timed_stop = {
        "limit_seconds": 0.05,
        "checkpoints_seconds": [0.0125, 0.025, 0.05],
        "max_fes_safety": 50_000,
    }
    config = _v3_formal_config(
        "protocol_smoke",
        FORMAL_ALGORITHMS,
        n_runs=1,
        L=selected_l,
        G=selected_g,
        scenario=model.DEFAULT_SCENARIO,
        seed_protocol=SMOKE_SEED_PROTOCOL,
        stop_protocol={
            "kind": "protocol_smoke",
            "fixed_fes": 100,
            "fixed_time": timed_stop,
        },
        case_registry=_smoke_case_registry(),
        variants=["factor_schedule"],
        timing_protocol="time_normalized_v1-smoke",
        hardware=hardware_fingerprint(),
        order_seed_base=9000,
        warmup_completed=True,
        formal_qualification=False,
        evidence_type="protocol_smoke_v3",
        expected_record_count=33,
    )
    return _cmd_protocol_smoke(config)


def cmd_ablation_final(n_runs=N_RUNS, L=None, G=None, max_fes=None):
    """Formal held-out seed ablation, fully isolated from parameter selection."""
    selected_l, selected_g = _validate_final_arguments(
        n_runs, L, G, max_fes, "ablation"
    )
    config = _v3_formal_config(
        "ablation", ("ql",), n_runs=n_runs,
        L=selected_l, G=selected_g,
        variants=[item[1] for item in ABLATION_VARIANTS],
    )
    return _cmd_ablation_v3(config, n_runs)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("task", choices=list(OUTPUT_FILES))
    parser.add_argument("--max-fes", type=int)
    parser.add_argument("--runs", type=int)
    parser.add_argument("--L", type=int)
    parser.add_argument("--G", type=int)
    parser.add_argument("--seconds", type=float)
    args = parser.parse_args(argv)
    print(f"[{_now()}] compute backend: {model.gpu_name()}")
    if args.task == "gate":
        return cmd_gate(args.max_fes)
    if args.task == "smoke":
        return cmd_smoke(args.max_fes, args.L or 16, args.G or 15)
    if args.task == "l_repr":
        return cmd_l_repr()
    if args.task == "l_opt":
        return cmd_l_opt(args.runs or SENSITIVITY_RUNS,
                         max_fes=args.max_fes, G=args.G or 15)
    if args.task == "g_sensitivity":
        return cmd_g_sensitivity(args.runs or SENSITIVITY_RUNS,
                                 args.L, args.max_fes)
    if args.task == "full":
        return cmd_full(args.runs or N_RUNS, args.L, args.G, args.max_fes)
    if args.task == "ablation":
        return cmd_ablation(args.runs or N_RUNS, args.L, args.G, args.max_fes)
    if args.task == "full_final":
        return cmd_full_final(args.runs or N_RUNS, args.L, args.G,
                              args.max_fes)
    if args.task == "ablation_final":
        return cmd_ablation_final(args.runs or N_RUNS, args.L, args.G,
                                  args.max_fes)
    if args.max_fes is not None:
        raise ValueError(f"final {args.task} requires the main 25000-FE budget")
    if args.task == "area_sweep_final":
        return cmd_area_sweep_final(args.runs or N_RUNS)
    if args.task == "uav_sweep_final":
        return cmd_uav_sweep_final(args.runs or N_RUNS)
    if args.task == "time_final":
        seconds = 60.0 if args.seconds is None else args.seconds
        return cmd_time_final(args.runs or N_RUNS, seconds)
    if args.task == "protocol_smoke":
        if args.runs is not None or args.seconds is not None:
            raise ValueError("protocol_smoke uses its registered short protocol")
        return cmd_protocol_smoke()
    raise ValueError(f"task {args.task} is not implemented")


if __name__ == "__main__":
    main()
