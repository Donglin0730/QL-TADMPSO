"""Reproducible, validated PDF layouts for UAV-count case studies.

This module calls the existing optimizer without changing its search rules.
Use --collect for one preselected seed per count; these cases are not a
repeated-run performance comparison. Existing result files can be passed
with --input; a common central run is then selected across all counts.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, ListedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
from scipy.stats import rankdata

from scenario import (
    DeploymentScenario, ScenarioConfig, W1, W2, W3,
    gpu_name, metrics_from_field,
)

HERE = Path(__file__).resolve().parent
COUNTS = (5, 10, 15, 20, 25, 30)
CORE_FILES = ("algorithms.py", "topology.py", "scenario.py", "model.py",
              "evaluation.py", "timing.py", "run_exp.py")
GROUND_COLORS = ("#F4F3EF", "#E8C8BD", "#C9E1DE", "#579A93")
GROUND_LABELS = ("General: uncovered", "Priority: uncovered",
                 "General: covered", "Priority: covered")
HEIGHT_CMAP = "plasma"


def core_hashes():
    return {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
            for name in CORE_FILES}


def write_json(path, data):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n",
                         encoding="utf-8")
    temporary.replace(path)


def collect_cases(output, counts=COUNTS, seed=9100, priority_seed=910):
    from run_exp import _run_one, _run_record
    import model

    path = output / "deployment_cases.json"
    fingerprint = core_hashes()
    config = {
        "n_p": 50, "max_fes": 25000, "mode": "a2g", "L": 50, "G": 5,
        "counts": list(counts), "optimization_seed": seed,
        "priority_seed": priority_seed, "n_runs_per_count": 1,
        "algorithm": "ql", "coefficient_controller": "existing_AHDPSO_schedule",
        "random_coefficients": "one_scalar_per_particle_and_learning_term",
        "core_sha256": fingerprint, "device": gpu_name(),
    }
    data = {
        "model_version": model.MODEL_VERSION,
        "evidence_type": "fixed_seed_deployment_case_study_not_statistical_comparison",
        "selection_rule": "one seed fixed before inspecting any result",
        "config": config, "runs": [],
    }
    if path.exists():
        data = json.loads(path.read_text(encoding="utf-8"))
        if data["config"] != config:
            raise ValueError("Existing case-study configuration differs; use a new directory")
    done = {int(r["scenario"]["n_uav"]) for r in data["runs"]}
    for count in counts:
        if count in done:
            continue
        print(f"Collecting fixed-seed deployment for {count} UAV-BSs", flush=True)
        scene = DeploymentScenario(ScenarioConfig(n_uav=count))
        result = _run_one("ql", seed, scene.priority_mask(priority_seed),
                          config, scenario=scene)
        data["runs"].append(_run_record(
            0, "ql", seed, priority_seed, result,
            scenario_id=f"{count}uav", scenario=scene.config.to_dict(),
        ))
        if core_hashes() != fingerprint:
            raise RuntimeError("Optimizer/model files changed while collecting cases")
        write_json(path, data)
    return path


def prepare_panels(data, counts=COUNTS, algo="ql", run_id=None):
    groups = {count: {} for count in counts}
    for record in data["runs"]:
        if record["algo"] != algo:
            continue
        config = record.get("scenario", data.get("config", {}).get("scenario"))
        count = int(config["n_uav"])
        if count not in groups:
            continue
        index = int(record["i"])
        if index in groups[count]:
            raise ValueError(f"Duplicate run {index} for {count} UAVs")
        groups[count][index] = record
    for count, records in groups.items():
        if not records:
            raise ValueError(f"Requested UAV count {count} is missing")
    common = sorted(set.intersection(*(set(g) for g in groups.values())))
    if not common:
        raise ValueError("No common run id across requested counts")
    if run_id is None:
        scores = np.zeros(len(common))
        for records in groups.values():
            ranks = rankdata([records[i]["best_F"] for i in common])
            scores += np.abs(ranks - (len(common) + 1) / 2)
        run_id = common[int(np.argmin(scores))]
    if run_id not in common:
        raise ValueError(f"Run id {run_id} is missing from one or more counts")
    records = [groups[count][run_id] for count in counts]
    if len({r["priority_seed"] for r in records}) != 1:
        raise ValueError("Comparable panels must share a priority map seed")
    if len({r["seed"] for r in records}) != 1:
        raise ValueError("Comparable panels must share an optimization seed")
    if len({r["fes"] for r in records}) != 1:
        raise ValueError("Comparable panels must share the actual FEs budget")
    expected_budget = data.get("config", {}).get("max_fes")
    if expected_budget is not None and any(r["fes"] != expected_budget for r in records):
        raise ValueError("A case did not complete its configured FEs budget")
    panels, domain, reference_priority = [], None, None
    mode = data.get("config", {}).get("mode", "a2g")
    device = data.get("config", {}).get("device", "CPU")
    use_gpu = not device.startswith("CPU")
    if use_gpu and gpu_name().startswith("CPU"):
        raise ValueError("This result used GPU evaluation; that backend is required to reconstruct it")
    for count, record in zip(counts, records):
        scene = DeploymentScenario(ScenarioConfig.from_dict(
            record.get("scenario", data["config"].get("scenario"))))
        current_domain = scene.config.to_dict()
        del current_domain["n_uav"]
        if domain is not None and current_domain != domain:
            raise ValueError("Comparable panels must share the same physical environment")
        domain = current_domain
        positions = np.asarray(record["best_pos"], dtype=float).reshape(count, 3)
        low, high = scene.bounds()
        if (not np.isfinite(positions).all() or
                np.any(positions.ravel() < low) or np.any(positions.ravel() > high)):
            raise ValueError("Deployment contains invalid/out-of-bounds positions")
        priority = scene.priority_mask(record["priority_seed"])
        if reference_priority is not None and not np.array_equal(priority, reference_priority):
            raise ValueError("Priority maps differ despite matching seed values")
        reference_priority = priority
        # Reuse the recorded numerical backend. Near a link threshold, float32
        # CPU/GPU arithmetic can select different summed links even if the
        # union coverage agrees; changing backend would alter the depicted field.
        signal, covered = scene._signal_and_coverage(positions, mode, use_gpu=use_gpu)
        metrics = metrics_from_field(signal, covered, priority)
        differences = {}
        for key in ("F", "TC", "SAC", "SASU", "GASU"):
            expected = record["best_F"] if key == "F" else record["final_metrics"][key]
            differences[key] = abs(metrics[key] - expected)
            tolerance = 1e-12 if key in ("TC", "SAC") else 1e-4
            if not np.isfinite(expected) or differences[key] > tolerance:
                raise ValueError(f"Stored metric {key} disagrees with the actual layout")
        n = scene.config.n_grid
        panels.append({
            "record": record, "scene": scene, "positions": positions, "device": device,
            "priority": priority.reshape(n, n).T,
            "covered": covered.reshape(n, n).T,
            "metrics": metrics, "metric_check_abs_error": differences,
            "categories": (2 * covered.astype(int) + priority.astype(int)).reshape(n, n).T,
            "components": [W1 * metrics["f1"], W2 * metrics["f2"], W3 * metrics["f3"]],
        })
    return panels


def paper_style():
    return {
        "font.family": "DejaVu Sans", "font.size": 8, "axes.labelsize": 8,
        "axes.titlesize": 9, "xtick.labelsize": 7, "ytick.labelsize": 7,
        "axes.linewidth": 0.65, "pdf.fonttype": 42, "ps.fonttype": 42,
        "savefig.facecolor": "white", "axes.unicode_minus": True,
    }


def add_common_legend(fig, norm):
    handles = [Patch(facecolor=c, edgecolor="#AFB6B8", linewidth=.35, label=t)
               for c, t in zip(GROUND_COLORS, GROUND_LABELS)]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5, .073),
               ncol=4, frameon=False, fontsize=7, handlelength=1.0,
               columnspacing=1.3)
    cax = fig.add_axes([.35, .047, .33, .011])
    bar = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=HEIGHT_CMAP),
                      cax=cax, orientation="horizontal")
    bar.solids.set_rasterized(False)
    bar.solids.set_edgecolor("face")
    bar.set_ticks([100, 200, 300, 400, 500])
    bar.ax.tick_params(labelsize=7, length=2, pad=2)
    bar.outline.set_linewidth(.4)
    fig.text(.321, .047, "UAV-BS height (m)", ha="right", va="center", fontsize=7)


def panel_title(ax, panel, index, is_3d=False):
    count = panel["scene"].config.n_uav
    m = panel["metrics"]
    ax.set_title(f"({chr(97 + index)})  {count} UAV-BSs", loc="left",
                 fontweight="bold", pad=21 if not is_3d else 24)
    label = f"F = {m['F']:.4f}   TC = {100*m['TC']:.2f}%"
    if is_3d:
        ax.text2D(0, 1.06, label, transform=ax.transAxes, fontsize=7.5, color="#43515D")
    else:
        ax.text(0, 1.035, label, transform=ax.transAxes, fontsize=7.5, color="#43515D")


def save_figure(fig, output, name, watermark=None):
    # Vector artists and embedded TrueType fonts are retained in the PDF.
    if watermark:
        fig.text(.5, .987, watermark, ha="center", va="top", fontsize=10,
                 fontweight="bold", color="#9B3425")
    fig.savefig(output / f"{name}.pdf", metadata={
        "Title": "UAV-BS deployment count case study",
        "Subject": (f"{watermark}; " if watermark else "")
                   + "Single common run; validated layouts; not repeated-run means",
        "Creator": "Matplotlib; validated against the deployment evaluation model",
    })
    fig.savefig(output / f"{name}.png", dpi=240)
    plt.close(fig)


def render_atlas(panels, output, watermark=None):
    if len(panels) not in (6, 8, 10):
        raise ValueError("Publication layout requires six, eight or ten requested UAV counts")
    rows, columns = (len(panels) + 2) // 3, 3
    scene = panels[0]["scene"]
    height_norm = Normalize(scene.config.h_min_m, scene.config.h_max_m)
    cmap = ListedColormap(GROUND_COLORS)
    ground_norm = BoundaryNorm(np.arange(-.5, 4.5), 4)
    with plt.rc_context(paper_style()):
        fig, axes = plt.subplots(rows, columns, figsize=(7.25, 6.1) if rows == 2 else (8.2, 8.6 + 2.6 * (rows - 3)))
        fig.subplots_adjust(left=.07, right=.982, bottom=.17,
                            top=(.84 if watermark else .91) if rows == 2 else (.90 if watermark else .93),
                            wspace=.27, hspace=.48 if rows == 2 else .68)
        for index, (ax, panel) in enumerate(zip(axes.flat, panels)):
            area = panel["scene"].config.area_m
            edges = np.linspace(0, area, panel["scene"].config.n_grid + 1)
            ax.pcolormesh(edges, edges, panel["categories"], cmap=cmap,
                          norm=ground_norm, shading="flat", rasterized=False,
                          edgecolors="none", antialiased=False)
            pos = panel["positions"]
            ax.scatter(pos[:, 0], pos[:, 1], c=pos[:, 2], cmap=HEIGHT_CMAP,
                       norm=height_norm, marker="^", s=30, edgecolor="#292D3E",
                       linewidth=.55, zorder=4, clip_on=False)
            ax.set(xlim=(0, area), ylim=(0, area), xlabel="x (m)", ylabel="y (m)")
            ax.set_aspect("equal")
            ax.set_xticks([0, area / 2, area])
            ax.set_yticks([0, area / 2, area])
            ax.tick_params(length=2.5, pad=2)
            for spine in ax.spines.values():
                spine.set_color("#75818B")
            panel_title(ax, panel, index)
        for ax in axes.flat[len(panels):]:
            ax.axis("off")
        add_common_legend(fig, height_norm)
        save_figure(fig, output, "uav_count_layouts_2d", watermark=watermark)

        fig = plt.figure(figsize=(7.6, 6.0) if rows == 2 else (8.2, 8.6 + 2.6 * (rows - 3)))
        fig.subplots_adjust(left=.017, right=.955, bottom=.16, top=.84 if watermark else .91,
                            wspace=.09, hspace=.42)
        for index, panel in enumerate(panels):
            ax = fig.add_subplot(rows, columns, index + 1, projection="3d", computed_zorder=False)
            area = panel["scene"].config.area_m
            n = panel["scene"].config.n_grid
            edges = np.linspace(0, area, n + 1)
            # One polygon per evaluation cell preserves the discrete true coverage.
            polygons, colors = [], []
            for row in range(n):
                for col in range(n):
                    x0, x1, y0, y1 = edges[col], edges[col+1], edges[row], edges[row+1]
                    polygons.append([(x0, y0, 0), (x1, y0, 0), (x1, y1, 0), (x0, y1, 0)])
                    colors.append(GROUND_COLORS[panel["categories"][row, col]])
            ax.add_collection3d(Poly3DCollection(polygons, facecolors=colors,
                                                edgecolors="none", zorder=1))
            pos = panel["positions"]
            for x, y, h in pos:
                ax.plot([x, x], [y, y], [0, h], color="#677988", alpha=.65,
                        lw=.55, ls=(0, (2, 2)), zorder=2)
            ax.scatter(pos[:, 0], pos[:, 1], np.zeros(len(pos)), s=6,
                       c="#536A79", alpha=.8, depthshade=False, zorder=3)
            ax.scatter(pos[:, 0], pos[:, 1], pos[:, 2], c=pos[:, 2],
                       norm=height_norm, cmap=HEIGHT_CMAP, s=24, marker="^",
                       edgecolors="#292D3E", linewidths=.45, depthshade=False, zorder=4)
            ax.view_init(elev=26, azim=-58)
            ax.set_proj_type("ortho")
            ax.set_box_aspect((1, 1, .47), zoom=.94)
            ax.set(xlim=(0, area), ylim=(0, area), zlim=(0, 550))
            ax.set_xticks([0, area])
            # The y=0 and x=area labels project to the same front corner.
            ax.set_yticks([area / 2, area])
            ax.set_zticks([100, 300, 500])
            ax.set_xlabel("x (m)", labelpad=-8)
            ax.set_ylabel("y (m)", labelpad=2)
            ax.set_zlabel("h (m)", labelpad=-7)
            ax.tick_params(labelsize=6.6, pad=-3)
            for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
                axis.pane.fill = False
                axis.pane.set_edgecolor("#D9DFE4")
                axis._axinfo["grid"].update(color="#D5DDE3", linewidth=.4)
                axis.line.set_color("#8995A0")
            panel_title(ax, panel, index, is_3d=True)
        add_common_legend(fig, height_norm)
        save_figure(fig, output, "uav_count_layouts_3d", watermark=watermark)


def export_metadata(panels, output, source):
    with (output / "deployment_coordinates.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["n_uav", "uav_id", "x_m", "y_m", "height_m"])
        for panel in panels:
            count = len(panel["positions"])
            for index, pos in enumerate(panel["positions"], 1):
                writer.writerow([count, index, *pos])
    with (output / "case_metrics.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["n_uav", "F", "TC_percent", "SAC_percent", "SASU_dB", "GASU_dB",
                         "weighted_uncovered", "weighted_priority_uniformity",
                         "weighted_general_uniformity", "fes", "seed", "priority_seed"])
        for panel in panels:
            m, r = panel["metrics"], panel["record"]
            writer.writerow([len(panel["positions"]), m["F"], 100*m["TC"], 100*m["SAC"],
                             m["SASU"], m["GASU"], *panel["components"],
                             r["fes"], r["seed"], r["priority_seed"]])
    write_json(output / "figure_manifest.json", {
        "source": str(source.resolve()),
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "core_sha256_at_render": core_hashes(),
        "evaluation_device": panels[0]["device"],
        "coordinate_units": "m", "height_color_limits_m": [100, 500],
        "coverage": "actual effective-link union on the 50x50 evaluation grid; no interpolation",
        "ground_categories": dict(zip(GROUND_LABELS, GROUND_COLORS)),
        "three_dimensional_view": "orthographic; vertical scale visually exaggerated; numeric heights unchanged",
        "panels": [{
            "n_uav": len(p["positions"]), "run_id": p["record"]["i"],
            "optimization_seed": p["record"]["seed"],
            "priority_seed": p["record"]["priority_seed"],
            "fes": p["record"]["fes"], "metrics": p["metrics"],
            "weighted_objective_components": p["components"],
            "metric_check_abs_error": p["metric_check_abs_error"],
        } for p in panels],
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--input", type=Path)
    parser.add_argument("--collect", action="store_true")
    parser.add_argument("--seed", type=int, default=9100)
    parser.add_argument("--priority-seed", type=int, default=910)
    parser.add_argument("--run-id", type=int)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if args.collect == (args.input is not None):
        parser.error("Choose exactly one of --collect and --input")
    source = collect_cases(args.output_dir, seed=args.seed, priority_seed=args.priority_seed) \
        if args.collect else args.input
    data = json.loads(source.read_text(encoding="utf-8"))
    panels = prepare_panels(data, run_id=args.run_id)
    render_atlas(panels, args.output_dir)
    export_metadata(panels, args.output_dir, source)
    print(json.dumps({"output": str(args.output_dir), "counts": list(COUNTS),
                      "F": [p["metrics"]["F"] for p in panels]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
