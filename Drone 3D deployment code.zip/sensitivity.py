"""Representation and clustering stability of the FSW projection count L."""
import time

import numpy as np
from scipy.spatial.distance import pdist
from scipy.stats import spearmanr

from topology import cluster_deployments, direction_pool, fsw_features


def _comb2(values):
    values = np.asarray(values, dtype=np.float64)
    return values * (values - 1.0) / 2.0


def adjusted_rand_index(labels_a, labels_b):
    """Adjusted Rand Index without scikit-learn."""
    a = np.asarray(labels_a)
    b = np.asarray(labels_b)
    if a.shape != b.shape:
        raise ValueError("label arrays must have the same shape")
    n = len(a)
    if n < 2:
        return 1.0
    _, ai = np.unique(a, return_inverse=True)
    _, bi = np.unique(b, return_inverse=True)
    table = np.zeros((ai.max() + 1, bi.max() + 1), dtype=np.int64)
    np.add.at(table, (ai, bi), 1)
    sum_cells = float(_comb2(table).sum())
    sum_rows = float(_comb2(table.sum(axis=1)).sum())
    sum_cols = float(_comb2(table.sum(axis=0)).sum())
    total = float(n * (n - 1) / 2)
    expected = sum_rows * sum_cols / total
    upper = 0.5 * (sum_rows + sum_cols)
    denominator = upper - expected
    if denominator == 0.0:
        return 1.0
    return float((sum_cells - expected) / denominator)


def _labels(groups, n):
    labels = np.empty(n, dtype=np.int64)
    for group, members in enumerate(groups):
        labels[members] = group
    return labels


def representation_sensitivity(X, l_values, seed=20260829, k=None,
                               min_size=3):
    """Compare distance ranking and clustering agreement of each L against the fixed L=100 representation.

    All L share one 100-direction pool and take nested prefixes; each L's
    K-means uses the same random seed, so differences come from representation
    precision rather than random initialization.
    """
    X = np.asarray(X, dtype=np.float64).reshape(-1, 25, 3)
    values = [int(v) for v in l_values]
    if not values or any(v < 1 or v > 100 for v in values):
        raise ValueError("l_values must be non-empty and within [1,100]")
    n = len(X)
    if k is None:
        k = min(16, max(1, n // min_size))
    directions = direction_pool(100, seed=20260829)

    all_values = list(dict.fromkeys(values + [100]))
    features = {}
    feature_times = {}
    distances = {}
    groups = {}
    clustering_times = {}
    labels = {}
    for L in all_values:
        t0 = time.perf_counter()
        features[L] = fsw_features(X, directions, L)
        feature_times[L] = time.perf_counter() - t0
        distances[L] = pdist(features[L], metric="euclidean")
        t0 = time.perf_counter()
        groups[L] = cluster_deployments(
            X, k, np.random.default_rng(seed), directions, L,
            min_size=min_size,
        )
        clustering_times[L] = time.perf_counter() - t0
        labels[L] = _labels(groups[L], n)

    reference_distances = distances[100]
    reference_labels = labels[100]
    rows = []
    for L in values:
        if L == 100:
            correlation = 1.0
            ari = 1.0
        elif len(reference_distances) == 0:
            correlation = 1.0
            ari = adjusted_rand_index(labels[L], reference_labels)
        else:
            correlation = float(spearmanr(distances[L], reference_distances).statistic)
            if not np.isfinite(correlation):
                correlation = 1.0 if np.allclose(distances[L], reference_distances) else 0.0
            ari = adjusted_rand_index(labels[L], reference_labels)
        rows.append({
            "L": L,
            "rank_correlation_to_L100": correlation,
            "ari_to_L100": float(ari),
            "feature_seconds": float(feature_times[L]),
            "clustering_seconds": float(clustering_times[L]),
            "cluster_sizes": [int(len(g)) for g in groups[L]],
        })
    return rows
