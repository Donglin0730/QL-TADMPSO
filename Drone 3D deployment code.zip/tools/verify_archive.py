"""Read a relocated v5 archive without rewriting evidence or its absolute paths."""
import argparse
import csv
import io
import json
import math
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parents[1]
DEFAULT_ROOT = HERE / 'outputs/rebuild_v5/formal_5_to_50'
for _key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(_key, '1')
sys.path.insert(0, str(HERE))

import numpy as np
import model
import protocol_v5 as protocol
import report_v5 as report
import permutation_probe as probe
from scenario import DeploymentScenario, ScenarioConfig, metrics_from_summary

STAGES = ('count', 'ablation', 'comparison')
TOLERANCE = 1e-13


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path, hashes):
    raw = path.read_bytes()
    import hashlib
    hashes[str(path)] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw.decode('utf-8'))


def validate_static_record(record, config):
    count, method, index = protocol.record_key(record)
    require((count, method, index) in protocol.expected_keys(config), 'unexpected experiment cell')
    expected_algo = 'ql' if protocol.base_variant(method) in protocol.VARIANTS else method
    require(record['algo'] == expected_algo and record['algorithm_options'] == protocol.optimizer_options(method, config, index),
            'algorithm/options mismatch')
    for field, base in (('seed', 'optimization_seed_base'), ('priority_seed', 'priority_seed_base'),
                        ('feedback_seed', 'feedback_seed_base')):
        require(type(record[field]) is int and record[field] == config[base] + index, 'paired seed mismatch')
    require(record['scenario'] == dict(config['scenario_base'], n_uav=count), 'physical scenario mismatch')
    scene = DeploymentScenario(ScenarioConfig.from_dict(record['scenario']))
    lower, upper = scene.bounds()
    positions = np.asarray(record['best_pos'], dtype=float)
    require(positions.shape == lower.shape and np.isfinite(positions).all()
            and np.all(positions >= lower) and np.all(positions <= upper), 'invalid saved deployment')
    require(protocol.integer(record['fes'], 'FEs', 1) == config['max_fes'], 'actual FEs differ from budget')
    protocol.integer(record['n_updates'], 'update count')
    require(np.isfinite([record['best_F'], record['runtime_seconds']]).all() and record['runtime_seconds'] >= 0,
            'invalid objective/runtime')
    points, history = np.asarray(record['history_fes']), np.asarray(record['gF_history'])
    require(points.ndim == 1 and history.shape == points.shape and len(points) > 0
            and np.isfinite(points).all() and np.all(points == np.floor(points))
            and points[0] == config['n_p'] and points[-1] == record['fes'] and np.all(np.diff(points) > 0),
            'invalid actual-FE history')
    require(np.isfinite(history).all() and np.all(np.diff(history) <= 1e-12)
            and abs(history[-1] - record['best_F']) <= 1e-12, 'inconsistent best archive')
    protocol.validate_fe_ledger(record, config)
    metrics = record['final_metrics']
    require(np.isfinite([metrics[k] for k in protocol.RECONSTRUCTION_TOLERANCES]).all(), 'nonfinite saved metrics')
    require(0 <= metrics['TC'] <= 1 and 0 <= metrics['SAC'] <= 1
            and min(metrics['SASU'], metrics['GASU']) >= 0, 'invalid metric ranges')
    rebuilt = metrics_from_summary(metrics['TC'], metrics['SAC'], metrics['SASU'], metrics['GASU'])
    require(abs(metrics['F'] - record['best_F']) <= 1e-10
            and all(abs(metrics[k] - rebuilt[k]) <= 1e-10 for k in ('F', 'f1', 'f2', 'f3')),
            'objective differs from its saved components')


def validate_stage(data, stage, choice, path, hashes):
    require(data['schema_version'] == protocol.SCHEMA and data['model_version'] == model.MODEL_VERSION, 'schema/model mismatch')
    require(data['content_sha256'] == protocol.result_digest(data), 'result content hash mismatch: ' + stage)
    config = data['config']
    require(data['result_kind'] == stage and config['stage'] == stage and config['formal_protocol'] is True,
            'archive requires a formal stage')
    require(config['selection'] == (None if stage == 'count' else choice), 'embedded selection mismatch')
    canonical = protocol._base_config(stage, config['selection'], smoke=False)
    canonical['device'] = config['device']
    require(config == canonical, 'configuration differs from the fixed formal protocol')
    provenance = data['provenance']
    require(provenance['source_sha256'] == protocol.source_hashes(), 'frozen source hashes differ from the archive')
    support = protocol.support
    support.validate_provenance(dict(data, provenance=dict(provenance, source_sha256={
        name: provenance['source_sha256'][name] for name in support.SOURCE_FILES})))
    for name, expected in provenance['source_sha256'].items():
        snapshot = path.parent / 'source_snapshot' / name
        require(snapshot.is_file() and protocol.file_digest(snapshot) == expected, 'missing or changed source snapshot: ' + name)
        hashes[str(snapshot)] = expected
    require(isinstance(data['runs'], list), 'missing run records')
    keys = [protocol.record_key(r) for r in data['runs']]
    require(len(keys) == len(set(keys)) and set(keys) == protocol.expected_keys(config), 'incomplete or duplicated experiment matrix')
    require(data['status'] == dict(completed=len(keys), expected=len(protocol.expected_keys(config))), 'checkpoint status mismatch')
    for record in data['runs']:
        validate_static_record(record, config)


def validate_probe(data, count, choice):
    require(data['schema_version'] == probe.SCHEMA and data['content_sha256'] == probe._content_digest(data),
            'mechanism content hash mismatch')
    require(data['selection_sha256'] == choice['selection_sha256']
            and data['count_result_sha256'] == choice['count_result_sha256']
            and data['source_sha256'] == choice['source_sha256'], 'mechanism selection/source mismatch')
    config = probe._probe_config(count, choice)
    require(data['formal'] is True and data['config'] == config, 'mechanism protocol mismatch')
    keys = [(r['i'], r['source_kind']) for r in data['runs']]
    expected = {(i, kind) for i in config['run_ids'] for kind in ('initial', 'final')}
    require(len(keys) == len(set(keys)) and set(keys) == expected, 'incomplete or duplicated mechanism evidence')
    selected = {r['i']: r for r in count['runs'] if r['scenario']['n_uav'] == choice['selected_count']}
    fields = ('coordinate_distance', 'fsw_distance', 'matched_residual',
              'inter_deployment_fsw_change', 'matching_cost_change', 'aligned_displacement_change')
    for row in data['runs']:
        source = selected[row['i']]
        require(row['seed'] == config['seed_base'] + row['i'] * 2 + int(row['source_kind'] == 'final')
                and row['L'] == config['L'] and row['n_permutations'] == config['n_permutations']
                and row['scenario'] == source['scenario'] and row['priority_seed'] == source['priority_seed'],
                'mechanism row seed/scenario mismatch')
        scene = DeploymentScenario(ScenarioConfig.from_dict(row['scenario']))
        lower, upper = scene.bounds()
        for field in ('positions', 'guide_positions'):
            positions = np.asarray(row[field], dtype=float)
            require(positions.shape == (choice['selected_count'], 3) and np.isfinite(positions).all()
                    and np.all(positions.ravel() >= lower) and np.all(positions.ravel() <= upper), 'invalid mechanism deployment')
        final = row['positions'] if row['source_kind'] == 'final' else row['guide_positions']
        require(np.array_equal(np.asarray(final).ravel(), source['best_pos']), 'mechanism final deployment mismatch')
        trials = row['trials']
        require([t['trial'] for t in trials] == list(range(config['n_permutations'])), 'incomplete mechanism trials')
        for trial in trials:
            values = [trial[k] for k in fields] + list(trial['metric_errors'].values())
            values += [trial[k + '_seconds'] for k in ('coordinate', 'fsw', 'alignment')]
            require(np.isfinite(values).all() and min(values) >= 0, 'invalid mechanism diagnostic values')
        for field in fields:
            require(row[field + '_max'] == max(t[field] for t in trials), 'mechanism maximum mismatch')
        require(row['metric_error_max'] == {k: max(t['metric_errors'][k] for t in trials) for k in probe.METRIC_TOLERANCES},
                'mechanism metric maximum mismatch')
        require(row['passed'] is True and all(row[k + '_max'] <= 1e-12 for k in
                ('fsw_distance', 'matched_residual', 'inter_deployment_fsw_change'))
                and row['matching_cost_change_max'] <= 1e-10
                and all(row['metric_error_max'][k] <= v for k, v in probe.METRIC_TOLERANCES.items()), 'mechanism tolerance check failed')


def read_archive(root):
    root = Path(root).resolve()
    hashes = {}
    choice = read_json(root / 'selection.json', hashes)
    require(choice.get('schema_version') == 'uav-bs-count-selection-v5'
            and choice.get('selection_sha256') == protocol.digest({k: v for k, v in choice.items() if k != 'selection_sha256'}),
            'selection hash/schema mismatch')
    require(choice.get('formal') is True and type(choice['selected_count']) is int
            and choice['selected_count'] in protocol.COUNTS
            and isinstance(choice['reason'], str) and choice['reason'].strip(), 'invalid formal selection')
    stages = {}
    for stage in STAGES:
        path = root / stage / 'results.json'
        stages[stage] = read_json(path, hashes)
        validate_stage(stages[stage], stage, choice, path, hashes)
    require(choice['count_result_sha256'] == hashes[str(root / 'count/results.json')], 'selection count evidence hash mismatch')
    require(choice['source_sha256'] == stages['count']['provenance']['source_sha256'], 'selection source mismatch')
    mechanism = read_json(root / 'mechanism/results.json', hashes)
    validate_probe(mechanism, stages['count'], choice)
    return dict(root=root, stages=stages, selection=choice, mechanism=mechanism, hashes=hashes)


def paired_statistics(data):
    rows = report.paired_rows(data, inferential=False)
    grouped = report._groups(data)
    ids = list(range(data['config']['n_runs']))
    for row in rows:
        methods = ([row['reference'], row['comparator']] if row['contrast_kind'] != 'interaction'
                   else ['full', 'no_alignment', 'no_fsw', 'no_fsw_no_alignment'])
        indexed = {method: grouped[(row['n_uav'], method)] for method in methods}
        vectors = report._paired_vectors(indexed, methods, ids, row['metric'])
        difference = vectors[0] - vectors[1]
        if row['contrast_kind'] == 'interaction':
            difference = difference - vectors[2] + vectors[3]
        row.update(report.contrast_summary(difference, inferential=True, n_boot=5000))
    if rows:
        for row, corrected in zip(rows, report.holm_adjust([r['p_raw'] for r in rows])):
            row.update(p_holm=corrected, family_size=len(rows), reject_holm_0_05=corrected < .05)
    return rows


def count_statistics(data):
    summary = {(r['n_uav'], r['metric']): r for r in report.summary_rows(data)}
    rows, previous = [], None
    for count in sorted(data['config']['counts']):
        runs = [r for r in data['runs'] if r['scenario']['n_uav'] == count]
        row = dict(n_uav=count, n=len(runs), zero_TC_runs=sum(r['final_metrics']['TC'] == 0 for r in runs),
                   zero_SAC_runs=sum(r['final_metrics']['SAC'] == 0 for r in runs))
        for metric in protocol.METRICS:
            for statistic in ('mean', 'sd', 'median'):
                row[metric + '_' + statistic] = summary[(count, metric)][statistic]
        row.update(previous_count=None, TC_gain_pp=None, F_improvement=None, SASU_improvement_db=None,
                   GASU_improvement_db=None, runtime_increase_percent=None)
        if previous is not None:
            row.update(previous_count=previous['n_uav'], TC_gain_pp=row['TC_mean'] - previous['TC_mean'],
                       F_improvement=previous['F_mean'] - row['F_mean'],
                       SASU_improvement_db=previous['SASU_mean'] - row['SASU_mean'],
                       GASU_improvement_db=previous['GASU_mean'] - row['GASU_mean'])
            if previous['runtime_seconds_mean'] > 0:
                row['runtime_increase_percent'] = 100 * (row['runtime_seconds_mean'] / previous['runtime_seconds_mean'] - 1)
        rows.append(row)
        previous = row
    return rows


def mechanism_statistics(data):
    summaries, trials = [], []
    for row in data['runs']:
        base = dict(i=row['i'], source_kind=row['source_kind'], n_uav=row['scenario']['n_uav'],
                    n_permutations=row['n_permutations'], passed=row['passed'])
        summary = dict(base)
        for key in ('coordinate_distance', 'fsw_distance', 'matched_residual',
                    'inter_deployment_fsw_change', 'matching_cost_change', 'aligned_displacement_change'):
            summary[key + '_max'] = row[key + '_max']
        summary.update({'error_' + k: v for k, v in row['metric_error_max'].items()})
        for key in ('coordinate', 'fsw', 'alignment'):
            summary[key + '_median_us'] = float(np.median([t[key + '_seconds'] for t in row['trials']]) * 1e6)
        summaries.append(summary)
        for trial in row['trials']:
            flat = dict(base, **{k: v for k, v in trial.items() if k != 'metric_errors'})
            flat.update({'error_' + k: v for k, v in trial['metric_errors'].items()})
            trials.append(flat)
    return summaries, trials


def compare_csv(path, rows, hashes):
    import hashlib
    raw = path.read_bytes()
    hashes[str(path)] = hashlib.sha256(raw).hexdigest()
    reader = csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))
    saved = list(reader)
    require(len(saved) == len(rows), 'CSV row count differs: ' + str(path))
    if not rows:
        require(not raw.strip(), 'CSV expected an empty table: ' + str(path))
        return
    require(reader.fieldnames == list(rows[0]), 'CSV columns differ: ' + str(path))
    for index, (old, new) in enumerate(zip(saved, rows), 1):
        for key, value in new.items():
            actual = old[key]
            if value is None:
                matches = actual == ''
            elif isinstance(value, (bool, str)):
                matches = actual == str(value)
            else:
                try:
                    matches = math.isfinite(float(actual)) and math.isclose(float(actual), float(value), rel_tol=TOLERANCE, abs_tol=TOLERANCE)
                except (TypeError, ValueError):
                    matches = False
            require(matches, f'CSV mismatch: {path.name}, row {index}, {key}')


def verify_archive(root, output, gpu=False, checksums=None):
    root, output = Path(root).resolve(), Path(output).resolve()
    for evidence in (root, DEFAULT_ROOT.resolve()):
        require(output != evidence and evidence not in output.parents, 'output must be outside the evidence directory')
    require(not output.exists(), 'output already exists; choose a new directory')
    archive = read_archive(root)
    tables = {}
    for stage, data in archive['stages'].items():
        tables[stage + '/summary.csv'] = report.summary_rows(data)
        if stage != 'count':
            tables[stage + '/paired_effects.csv'] = paired_statistics(data)
    tables['count/count_selection_table.csv'] = count_statistics(archive['stages']['count'])
    summary, trials = mechanism_statistics(archive['mechanism'])
    tables['mechanism/mechanism_summary.csv'] = summary
    tables['mechanism/mechanism_trials.csv'] = trials
    for name, rows in tables.items():
        stage, filename = name.split('/')
        compare_csv(root / stage / 'report' / filename, rows, archive['hashes'])
    if checksums is not None:
        manifest = json.loads(Path(checksums).read_text(encoding='utf-8'))['files']
        for path, actual in archive['hashes'].items():
            key = 'outputs/rebuild_v5/formal_5_to_50/' + Path(path).relative_to(root).as_posix()
            require(key in manifest and manifest[key] == actual, 'release checksum mismatch: ' + key)
    if gpu:
        require(not protocol.gpu_name(True).startswith('CPU'), '--gpu requires an available CUDA backend')
        for data in archive['stages'].values():
            for record in data['runs']:
                protocol.validate_record(record, data['config'])
    for path, expected in archive['hashes'].items():
        require(protocol.file_digest(path) == expected, 'evidence changed during verification: ' + path)
    result = dict(schema_version='uav-bs-archive-verification-v1',
                  archive=str(root), statistics='passed', archive_integrity='passed', static_formal_protocol='passed',
                  coordinate_reconstruction='passed' if gpu else 'not_run',
                  scope=('Stored statistics and recorded-backend coordinate reconstruction.' if gpu else
                         'CPU-compatible recomputation of saved metrics and statistics only; no coordinate or physical-model reconstruction.'),
                  records=sum(len(data['runs']) for data in archive['stages'].values()),
                  summary_rows=sum(len(tables[s + '/summary.csv']) for s in STAGES),
                  paired_rows=sum(len(tables.get(s + '/paired_effects.csv', [])) for s in STAGES),
                  mechanism_cases=len(summary), mechanism_trials=len(trials), csv_files=len(tables),
                  absolute_tolerance=TOLERANCE, relative_tolerance=TOLERANCE,
                  current_runtime=protocol.runtime_fingerprint(),
                  path_mapping={archive['selection']['count_result_path']: str(root / 'count/results.json'),
                                archive['mechanism']['selection_path']: str(root / 'selection.json')},
                  release_checksums='passed' if checksums is not None else 'not_requested',
                  file_sha256={Path(path).relative_to(root).as_posix(): value for path, value in archive['hashes'].items()})
    output.mkdir(parents=True, exist_ok=False)
    for name, rows in tables.items():
        path = output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        report._csv(path, rows)
    (output / 'verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--gpu', action='store_true', help='also reconstruct all saved deployments on their recorded backend')
    parser.add_argument('--checksums', type=Path)
    args = parser.parse_args(argv)
    try:
        result = verify_archive(args.root, args.output, args.gpu, args.checksums)
    except (ValueError, OSError, KeyError, TypeError) as error:
        print('Archive verification failed: ' + str(error), file=sys.stderr)
        return 2
    print(json.dumps({k: result[k] for k in ('statistics', 'coordinate_reconstruction', 'records', 'summary_rows', 'paired_rows')}, ensure_ascii=False))
    print('Saved verification: ' + str(args.output.resolve() / 'verification.json'))
    return 0


if __name__ == '__main__':
    sys.exit(main())
