"""Export source-checked figures without changing the frozen experiment archive."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import sys


EXPERIMENTS = Path(__file__).resolve().parents[1]
DEFAULT_ROOT = EXPERIMENTS / 'outputs/rebuild_v5/formal_5_to_50'


def _sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _mechanism_figure(data, output):
    import matplotlib.pyplot as plt
    import numpy as np
    import deployment_atlas as atlas

    values = {}
    with plt.rc_context(atlas.paper_style()):
        fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.9))
        fig.subplots_adjust(left=.09, right=.98, top=.82, bottom=.25, wspace=.35)
        for j, kind in enumerate(('initial', 'final')):
            cases = [row for row in data['runs'] if row['source_kind'] == kind]
            discrepancy = [max(row[key + '_max'] for row in cases) for key in
                           ('coordinate_distance', 'fsw_distance', 'matched_residual')]
            timings = [float(np.median([np.median([t[key + '_seconds'] for t in row['trials']])
                                       for row in cases])) * 1e6
                       for key in ('coordinate', 'fsw', 'alignment')]
            values[kind] = dict(cases=len(cases), maximum_discrepancy=discrepancy,
                                median_of_case_median_microseconds=timings)
            x = np.arange(3) + (j - .5) * .32
            for ax, height in zip(axes, (discrepancy, timings)):
                bars = ax.bar(x, height, width=.3, label=kind.capitalize(),
                              color=('#0072B2', '#E69F00')[j])
                for bar, value in zip(bars, height):
                    ax.annotate(f'{value:.2g}', (bar.get_x() + bar.get_width()/2, value),
                                xytext=(0, 4), textcoords='offset points', ha='center', fontsize=7)
        for ax in axes:
            ax.set_xticks(range(3), ['Coordinates', 'FSW', 'Matching'])
            ax.grid(axis='y', color='#DDE4EA', linewidth=.55)
            ax.set_axisbelow(True)
            ax.margins(y=.22)
            ax.spines[['top', 'right']].set_visible(False)
        axes[0].set(ylabel='Maximum normalized discrepancy', title='Same deployment after relabeling')
        axes[1].set(ylabel='Recorded median time (us / call)', title='Standalone component cost')
        axes[0].legend(frameon=False, fontsize=7)
        fig.text(.5, .08, '40 saved cases from 20 run IDs; permutations are nested measurements.',
                 ha='center', fontsize=8)
        fig.text(.5, .035, 'Timings are archived measurements, not a new benchmark or optimizer cost breakdown.',
                 ha='center', fontsize=7)
        fig.savefig(output / 'mechanism_diagnostics.pdf')
        plt.close(fig)
    return values


def _power_figure(panel, mode, output):
    import matplotlib.pyplot as plt
    from matplotlib.collections import LineCollection
    from matplotlib.lines import Line2D
    import numpy as np
    import deployment_atlas as atlas
    from scenario import POWER_FLOOR_MW, metrics_from_field

    scene, record = panel['scene'], panel['record']
    use_gpu = not panel['device'].startswith('CPU')
    signal, covered = scene._signal_and_coverage(panel['positions'], mode, use_gpu=use_gpu)
    priority = scene.priority_mask(record['priority_seed'])
    actual = metrics_from_field(signal, covered, priority)
    errors = {}
    for key in ('F', 'TC', 'SAC', 'SASU', 'GASU'):
        expected = record['best_F'] if key == 'F' else record['final_metrics'][key]
        errors[key] = abs(actual[key] - expected)
        if not np.isfinite(expected) or errors[key] > (1e-12 if key in ('TC', 'SAC') else 1e-4):
            raise ValueError(f'Power-map metric mismatch: {key}')
    n, area = scene.config.n_grid, scene.config.area_m
    floor_dbm = float(10 * np.log10(POWER_FLOOR_MW))
    if not np.isfinite(signal).all() or not np.allclose(signal[~covered], floor_dbm, atol=1e-5, rtol=0):
        raise ValueError('Invalid power field or unexpected uncovered-cell floor')
    edges = np.linspace(0, area, n + 1)
    mask = priority.reshape(n, n)
    boundary = []
    for x, y in np.argwhere(mask):
        for dx, dy, segment in (
            (-1, 0, [(edges[x], edges[y]), (edges[x], edges[y+1])]),
            (1, 0, [(edges[x+1], edges[y]), (edges[x+1], edges[y+1])]),
            (0, -1, [(edges[x], edges[y]), (edges[x+1], edges[y])]),
            (0, 1, [(edges[x], edges[y+1]), (edges[x+1], edges[y+1])])):
            nx, ny = x + dx, y + dy
            if nx < 0 or ny < 0 or nx >= n or ny >= n or not mask[nx, ny]:
                boundary.append(segment)
    with plt.rc_context(atlas.paper_style()):
        fig, ax = plt.subplots(figsize=(6.8, 6.5))
        fig.subplots_adjust(left=.13, right=.86, top=.88, bottom=.19)
        mesh = ax.pcolormesh(edges, edges, signal.reshape(n, n).T, shading='flat',
                             cmap='viridis', vmin=floor_dbm, edgecolors='none', rasterized=False)
        ax.add_collection(LineCollection(boundary, colors='white', linewidths=.55))
        ax.scatter(panel['positions'][:, 0], panel['positions'][:, 1], marker='^',
                   s=28, facecolors='white', edgecolors='black', linewidths=.6)
        ax.set(xlim=(0, area), ylim=(0, area), xlabel='x (m)', ylabel='y (m)',
               title='45 UAV-BSs: aggregate received power | run i=7')
        ax.set_aspect('equal')
        fig.colorbar(mesh, ax=ax, fraction=.045, pad=.035, label='Aggregate received power (dBm)')
        handles = [Line2D([], [], marker='^', ls='', markerfacecolor='white', markeredgecolor='black', label='UAV-BS projection'),
                   Line2D([], [], color='#777777', lw=1, label='Special-area cell boundary (white on map)')]
        fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.5, .075), frameon=False, fontsize=7.5)
        fig.text(.5, .025, f'50 x 50 evaluation cells; no interpolation. Uncovered-cell floor: {floor_dbm:g} dBm.',
                 ha='center', fontsize=7.5)
        fig.savefig(output / 'aggregate_received_power_45.pdf')
        plt.close(fig)
    with (output / 'aggregate_power_grid.csv').open('w', encoding='utf-8', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['x_m', 'y_m', 'aggregate_received_power_dbm', 'covered', 'special_area'])
        for xy, value, cov, special in zip(scene.grid_xy, signal, covered, priority):
            writer.writerow([*xy, float(value), int(cov), int(special)])
    return dict(n_uav=45, run_id=int(record['i']), optimization_seed=record['seed'],
                priority_seed=record['priority_seed'], recorded_backend=panel['device'],
                field_backend='GPU' if use_gpu else 'CPU', mode=mode,
                field_shape=[n, n], grid_orientation='raw indexing ij (x, y); plotted transpose gives rows y, columns x',
                coordinates='grid-cell centres, metres; x rightwards, y upwards',
                aggregate='sum of valid-link received powers in mW plus POWER_FLOOR_MW, then 10*log10',
                uncovered_floor_dbm=floor_dbm, uncovered_cells=int((~covered).sum()),
                metric_check_abs_error=errors)


def export_figures(root, output, gpu=False):
    root, output = Path(root).resolve(), Path(output).resolve()
    if output.exists():
        raise FileExistsError('Use a new output directory; existing output is never overwritten')
    if any(output.is_relative_to(evidence) for evidence in (root, DEFAULT_ROOT.resolve())):
        raise ValueError('Output must be outside the frozen archive directory')
    output.mkdir(parents=True)
    for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        os.environ.setdefault(name, '1')
    if not gpu:
        os.environ.setdefault('CUDA_VISIBLE_DEVICES', '-1')
    os.environ.setdefault('CUPY_CACHE_DIR', str(output / '.cupy_cache'))
    sys.path.insert(0, str(EXPERIMENTS))
    from tools.verify_archive import verify_archive

    print('Verifying saved results before figure export...', flush=True)
    verification = verify_archive(root, output / 'verification', gpu=gpu)
    import matplotlib
    matplotlib.use('Agg')
    import deployment_atlas as atlas
    import report_v5 as report

    paths = {stage: root / stage / 'results.json' for stage in ('count', 'comparison', 'mechanism')}
    hashes = {stage: _sha256(path) for stage, path in paths.items()}
    if any(hashes[stage] != verification['file_sha256'][f'{stage}/results.json'] for stage in paths):
        raise RuntimeError('Source results changed after archive verification')
    data = {stage: json.loads(path.read_text(encoding='utf-8')) for stage, path in paths.items()}
    print('Exporting statistics and recorded mechanism diagnostics...', flush=True)
    report._metrics_figure(data['count'], output, True)
    report._metrics_figure(data['comparison'], output, True)
    report._convergence_figure(data['comparison'], output, True)
    mechanism = _mechanism_figure(data['mechanism'], output)
    power = None
    if gpu:
        print('Reconstructing deployment layouts and the power map with the recorded backend...', flush=True)
        panels = atlas.prepare_panels(data['count'], counts=tuple(range(5, 51, 5)), algo='ql')
        if any(int(p['record']['i']) != 7 for p in panels):
            raise ValueError('Common representative run differs from the archived paper run i=7')
        atlas.render_atlas(panels, output)
        atlas.export_metadata(panels, output, paths['count'])
        power = _power_figure(next(p for p in panels if p['scene'].config.n_uav == 45),
                              data['count']['config']['mode'], output)
    if hashes != {stage: _sha256(path) for stage, path in paths.items()}:
        raise RuntimeError('Source results changed during export')
    manifest = dict(status='passed', gpu=gpu, exporter_sha256=_sha256(__file__),
                    source_files={stage: str(path) for stage, path in paths.items()},
                    source_sha256=hashes, verification='verification/verification.json',
                    verification_scope={key: verification[key] for key in
                                        ('archive_integrity', 'statistics', 'coordinate_reconstruction')},
                    representative_run_id=7 if gpu else None, mechanism_plot_values=mechanism,
                    power_map=power, exact_paper_layout_reproduced=False,
                    skipped=[] if gpu else ['uav_count_layouts_2d.pdf', 'uav_count_layouts_3d.pdf', 'aggregate_received_power_45.pdf'],
                    note='General redraws from saved evidence. Final manuscript PDFs have separate layout/text edits.',
                    output_sha256={p.name: _sha256(p) for p in sorted(output.iterdir()) if p.is_file()})
    (output / 'export_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f'Exported {len(list(output.glob("*.pdf")))} PDFs to {output}', flush=True)
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=DEFAULT_ROOT, help='Frozen formal archive root')
    parser.add_argument('--output', type=Path, required=True, help='New directory outside the frozen archive')
    parser.add_argument('--gpu', action='store_true', help='Also verify coordinates and reconstruct layouts/power with the recorded backend')
    args = parser.parse_args(argv)
    export_figures(args.root, args.output, gpu=args.gpu)


if __name__ == '__main__':
    main()
