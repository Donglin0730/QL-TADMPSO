"""Run or check the experiments without changing the archived campaign."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ARCHIVE = HERE / 'outputs/rebuild_v5/formal_5_to_50'


def check_files(root=HERE, manifest=None):
    root = Path(root).resolve()
    manifest = Path(manifest or root / 'reproducibility/checksums.json')
    files = json.loads(manifest.read_text(encoding='utf-8'))['files']
    for name, expected in files.items():
        path = (root / name).resolve()
        if not path.is_relative_to(root):
            raise ValueError('Invalid checksum path: ' + name)
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Missing or changed archived file: ' + name)
    return len(files)


def campaign_root(path):
    path = Path(path).resolve()
    archive = ARCHIVE.resolve()
    if path.is_relative_to(archive) or archive.is_relative_to(path):
        raise ValueError('Use a separate output directory, e.g. outputs/reproduction_paper.')
    return path


def runtime_environment(device):
    env = dict(os.environ)
    env.update(PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1',
               OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
               MPLBACKEND='Agg')
    env.setdefault('CUPY_CACHE_DIR', str(Path(tempfile.gettempdir()) / 'uavbs_cupy_cache'))
    if device == 'cpu':
        env['CUDA_VISIBLE_DEVICES'] = '-1'
    return env


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', choices=['check', 'test', 'stats', 'verify', 'figures',
                                        'smoke', 'count', 'select', 'continue', 'report', 'all'])
    parser.add_argument('--device', choices=['cpu', 'cuda'], default='cpu')
    parser.add_argument('--root', type=Path, help='Archive to read, or separate campaign to run.')
    parser.add_argument('--output', type=Path, help='New directory for statistics or figures.')
    parser.add_argument('--uav-count', type=int, choices=range(5, 51, 5))
    parser.add_argument('--reason')
    parser.add_argument('--no-report', action='store_true')
    args = parser.parse_args(argv)
    try:
        if args.uav_count is not None and args.task not in ('smoke', 'select', 'all'):
            raise ValueError('--uav-count is only used by smoke, select and all.')
        if args.reason is not None and args.task not in ('select', 'all'):
            raise ValueError('--reason is only used by select and all.')
        if args.task in ('select', 'all'):
            args.uav_count = args.uav_count or 45
            if not args.reason or not args.reason.strip():
                if args.uav_count != 45:
                    raise ValueError('Provide --reason when selecting a count other than the paper setting of 45.')
                args.reason = 'Reproduce the paper comparison setting of 45 UAV-BSs.'
        count = check_files()
        print(f'Archived sources and evidence: {count} files unchanged.', flush=True)
        if args.task == 'check':
            return 0
        env = runtime_environment(args.device)

        def run(arguments):
            subprocess.run([sys.executable, '-B', *map(str, arguments)], cwd=HERE,
                           env=env, check=True)

        if args.device == 'cuda':
            run(['-c', 'import scenario; assert scenario._HAS_CUDA, "CUDA is unavailable"; '
                       'print("Backend:", scenario.gpu_name())'])
        if args.task == 'test':
            run(['tests/run_all_tests.py'])
        elif args.task in ('stats', 'verify', 'figures'):
            if args.task == 'verify' and args.device != 'cuda':
                raise ValueError('Original coordinate verification requires --device cuda. Use stats on CPU.')
            root = (args.root or ARCHIVE).resolve()
            output = (args.output or HERE / ('outputs/reproduction_' + args.task)).resolve()
            script = 'tools/export_figures.py' if args.task == 'figures' else 'tools/verify_archive.py'
            command = [script, '--root', root, '--output', output]
            if args.task in ('verify', 'figures') and args.device == 'cuda':
                command.append('--gpu')
            run(command)
        else:
            default = 'reproduction_smoke' if args.task == 'smoke' else 'reproduction_paper'
            root = campaign_root(args.root or HERE / 'outputs' / default)
            tasks = ['count', 'select', 'continue'] if args.task == 'all' else [args.task]
            for task in tasks:
                command = ['run_v5.py', task, '--root', root]
                if task == 'select':
                    command += ['--uav-count', args.uav_count, '--reason', args.reason]
                elif task == 'smoke' and args.uav_count is not None:
                    command += ['--uav-count', args.uav_count]
                if args.no_report:
                    command.append('--no-report')
                run(command)
        return 0
    except (ValueError, FileNotFoundError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except subprocess.CalledProcessError as exc:
        return exc.returncode
    except KeyboardInterrupt:
        return 130


if __name__ == '__main__':
    sys.exit(main())
