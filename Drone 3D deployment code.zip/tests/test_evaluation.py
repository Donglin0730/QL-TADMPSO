"""Strict function-evaluation count (FE) tests. Run: python tests/test_evaluation.py"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from evaluation import BudgetExceeded, ObjectiveEvaluator, update_count
from scenario import DeploymentScenario, ScenarioConfig

_FAILS = []


def check(name, fn):
    try:
        fn()
        print(f"  ok  {name}")
    except Exception as exc:
        _FAILS.append((name, repr(exc)))
        print(f"FAIL  {name}: {type(exc).__name__}: {exc}")


def t_update_count_main_budget():
    assert update_count(25000, 50) == 499


def t_update_count_rejects_partial_generation():
    try:
        update_count(25001, 50)
    except ValueError as exc:
        assert "whole populations" in str(exc)
    else:
        raise AssertionError("partial population budget must fail")


def t_update_count_requires_initial_population():
    try:
        update_count(4, 5)
    except ValueError as exc:
        assert "initialization" in str(exc)
    else:
        raise AssertionError("budget smaller than initialization must fail")


def t_evaluator_counts_and_blocks_overrun():
    calls = []

    def fake(pos, priority, mode):
        calls.append(np.asarray(pos).copy())
        return {"F": float(np.asarray(pos).sum())}

    ev = ObjectiveEvaluator(np.array([True]), "a2g", 3, evaluate_fn=fake)
    f, metrics = ev.evaluate_population(np.array([[1.0], [2.0], [3.0]]))
    assert ev.fes == 3 and f.tolist() == [1.0, 2.0, 3.0]
    assert len(metrics) == len(calls) == 3
    try:
        ev.evaluate_population(np.array([[4.0]]))
    except BudgetExceeded:
        pass
    else:
        raise AssertionError("budget overrun must fail")


def t_evaluator_uses_injected_scenario():
    """Catch the budget layer bypassing the injected scenario and still using the default 25-UAV model."""
    deployment = DeploymentScenario(ScenarioConfig(n_uav=10))
    priority = deployment.priority_mask(8)
    population = np.tile([2500.0, 2500.0, 300.0], (1, 10))
    evaluator = ObjectiveEvaluator(
        priority, "los", 1, scenario=deployment
    )
    fitness, metrics = evaluator.evaluate_population(population)
    expected = deployment.evaluate(population[0], priority, "los")
    assert evaluator.fes == 1
    assert fitness.shape == (1,)
    assert fitness[0] == expected["F"]
    assert metrics[0] == expected


if __name__ == "__main__":
    print("test_evaluation.py")
    for name, fn in sorted(globals().items()):
        if name.startswith("t_") and callable(fn):
            check(name, fn)
    print()
    if _FAILS:
        print(f"{len(_FAILS)} failed/errored")
        sys.exit(1)
    print("all passed")
