"""Algorithm-layer tests (implementation plan §2/§4.0). Run: python tests/test_algorithms.py

Coverage: init/clipping, dynamic params Eq.16-19, c3 Eq.20, DNA mechanism (Algorithm 1),
Q-learning decision semantics (reward sign/timing/Bellman/eps-greedy/clipping),
random cross-swarm pick, clustering (Algorithm 1 topological grouping), lbest,
small-budget integration smoke of the four algorithms and the matching control.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import model
import algorithms
from scenario import DeploymentScenario, ScenarioConfig
from timing import TimeProtocol
from evaluation import update_count
from algorithms import (  # (RED phase: this import should fail ImportError)
    ACTIONS,
    LB,
    UB,
    c3_series,
    clip_position,
    cluster,
    dna_codes,
    dna_xfworst,
    dynamic_params,
    init_swarm,
    lbest_positions,
    q_update,
    random_cross_swarm_member,
    run_ahdpso,
    run_ql_tadmpso,
    run_standard_pso,
    select_q_action,
)

_FAILS = []


def check(name, fn):
    try:
        fn()
        print(f"  ok  {name}")
    except AssertionError as e:
        _FAILS.append((name, str(e)))
        print(f"FAIL  {name}: {e}")
    except Exception as e:
        _FAILS.append((name, repr(e)))
        print(f"ERR   {name}: {type(e).__name__}: {e}")


def _assert_hist_nonincr(h):
    for a, b in zip(h, h[1:]):
        assert b <= a + 1e-12, f"gbest history not non-increasing: {a} -> {b}"


class _FakeClock:
    def __init__(self, values):
        self.values = iter(values)

    def __call__(self):
        return next(self.values)


# ---- pure functions ----

def t_init_swarm():
    rng = np.random.default_rng(0)
    X, V = init_swarm(rng, 10)
    assert X.shape == (10, 75) and V.shape == (10, 75)
    assert (X >= LB).all() and (X <= UB).all()
    assert (V == 0.0).all()   # matches released code: velocity initialized to 0


def t_clip_position():
    X = np.zeros((2, 75))
    X[0, 0] = -100.0          # x below lower bound
    X[0, 1] = 6000.0          # y above upper bound
    X[0, 2] = 50.0            # h below lower bound
    X[1, 2] = 900.0           # h above upper bound
    Y = clip_position(X)
    assert Y[0, 0] == 0.0 and Y[0, 1] == 5000.0
    assert Y[0, 2] == 100.0 and Y[1, 2] == 500.0
    assert Y[1, 0] == 0.0     # in-bounds value unchanged


def t_initialization_uses_scenario_dimension_and_bounds():
    """Catch init and clipping still using the default 75-dim, 5000 m global bounds."""
    deployment = DeploymentScenario(
        ScenarioConfig(area_m=7000.0, n_grid=70, n_uav=10)
    )
    X, V = init_swarm(np.random.default_rng(4), 7, scenario=deployment)
    assert X.shape == V.shape == (7, 30)
    assert np.all((0.0 <= X[:, 0::3]) & (X[:, 0::3] <= 7000.0))
    assert np.all((0.0 <= X[:, 1::3]) & (X[:, 1::3] <= 7000.0))
    assert np.all((100.0 <= X[:, 2::3]) & (X[:, 2::3] <= 500.0))
    out = X.copy()
    out[0, :3] = [-1.0, 7001.0, 501.0]
    clipped = clip_position(out, scenario=deployment)
    assert np.array_equal(clipped[0, :3], [0.0, 7000.0, 500.0])


def t_dna_codes_use_injected_cell_size():
    """Catch DNA codes still dividing by the default 100 m instead of the scenario cell size."""
    deployment = DeploymentScenario(
        ScenarioConfig(area_m=7000.0, n_grid=50, n_uav=1)
    )
    code = dna_codes(
        np.array([[139.0, 281.0, 301.0]]), scenario=deployment
    )
    assert np.array_equal(code[0], [1, 2, 1])


def t_dynamic_params():
    T = 10
    rng1 = np.random.default_rng(5)
    w, c1, c2 = dynamic_params(T, rng1)
    # recompute the chaotic sequence (Eq.16)
    rng2 = np.random.default_rng(5)
    r = [rng2.random()]
    for _ in range(1, T):
        r.append(4.0 * r[-1] * (1.0 - r[-1]))
    t = np.arange(T)
    assert np.allclose(w, 0.9 - 0.5 * t / T)
    assert np.allclose(c1, 1.2 - 1.2 * t / T + (1.0 - t / T) * r * 0.8)
    assert np.allclose(c2, 1.2 - 1.2 * (T - t - 1.0) / T
                       + (1.0 - (T - t - 1.0) / T) * r * 0.8)
    assert w[0] == 0.9 and abs(w[-1] - 0.45) < 1e-12


def t_c3_series():
    T = 10
    r = np.linspace(0.1, 0.9, T)
    c3 = c3_series(r)
    t = np.arange(T)
    exp = np.where(t < T / 2, (t / T) * (1.0 + 0.8 * r),
                   (T - t - 1.0) / T * (1.0 + 0.8 * r))
    assert np.allclose(c3, exp)
    assert c3[0] == 0.0 and c3[-1] == 0.0


def t_dna_xfworst():
    base = np.tile([0.0, 0.0, 100.0], (25, 1)).reshape(-1)
    outlier = np.tile([100.0, 100.0, 101.0], (25, 1)).reshape(-1)
    X = np.stack([base, base, base, outlier])
    assert dna_xfworst(X, np.array([1.0, 2.0, 3.0, 4.0])) == 3

    # with two per class the mean Hamming distances tie; break the tie by the worse objective.
    X2 = np.stack([base, base, outlier, outlier])
    assert dna_xfworst(X2, np.array([1.0, 2.0, 3.0, 10.0])) == 3


def t_dna_codes_use_grid_units_for_xy():
    one = np.tile([1230.0, 1830.0, 301.0], (25, 1)).reshape(1, -1)
    code = dna_codes(one).reshape(25, 3)
    assert np.array_equal(code[0], [0, 2, 1])

    shifted = one.copy()
    shifted[0, 0] += 100.0
    assert dna_codes(shifted)[0, 0] == 1


def t_dna_codes_match_original_grid_scale():
    physical = np.tile([1230.0, 1830.0, 301.0], (25, 1)).reshape(1, -1)
    expected = np.rint(np.tile([12.3, 18.3, 301.0], (25, 1))) \
        .astype(np.int64).reshape(1, -1) % 4
    assert np.array_equal(dna_codes(physical), expected)


def t_select_q_action_greedy():
    # eps=0 -> greedy argmax of the Q row; an all-zero row picks action 0 (+1), k follows
    Q = np.zeros((16, 3))
    a, k_new = select_q_action(np.random.default_rng(0), Q, state=2, k=3,
                               eps=0.0, k_max=16)
    assert a == 0 and k_new == 4
    Q[2] = [1.0, 2.0, 3.0]                 # argmax=2 (hold) -> k unchanged
    a, k_new = select_q_action(np.random.default_rng(0), Q, state=2, k=3,
                               eps=0.0, k_max=16)
    assert a == 2 and k_new == 3


def t_select_q_action_explore():
    # eps=1 -> always explore: action legal and k clipped correctly
    a, k_new = select_q_action(np.random.default_rng(0), np.zeros((16, 3)),
                               state=4, k=5, eps=1.0, k_max=16)
    assert a in (0, 1, 2)
    assert k_new == int(np.clip(5 + ACTIONS[a], 1, 16))


def t_select_q_action_clip_boundaries():
    # k=16 with greedy +1 -> clipped back to 16; k=1 with greedy -1 -> clipped back to 1
    Q = np.zeros((16, 3))
    Q[15] = [9.0, 0.0, 0.0]
    _, k_new = select_q_action(np.random.default_rng(0), Q, state=15, k=16,
                               eps=0.0, k_max=16)
    assert k_new == 16
    Q[0] = [0.0, 9.0, 0.0]
    _, k_new = select_q_action(np.random.default_rng(0), Q, state=0, k=1,
                               eps=0.0, k_max=16)
    assert k_new == 1


class _StubRng:
    def __init__(self, values):
        self.values = iter(values)

    def integers(self, high):
        value = next(self.values)
        assert 0 <= value < high
        return value


def t_cross_swarm_selects_random_group_and_random_member():
    groups = [np.array([0, 1]), np.array([2, 3, 4]), np.array([5, 6])]
    # candidate groups of source group 0 are [1,2]: first offset 1 -> group 2, then member offset 0 -> particle 5.
    assert random_cross_swarm_member(groups, 0, _StubRng([1, 0])) == 5


def t_q_terminal_update_has_no_bootstrap():
    Q = np.zeros((16, 3))
    Q[2] = [8.0, 9.0, 10.0]
    q_update(Q, state=0, action=1, reward=2.0, next_state=2,
             alpha=0.5, gamma=0.95, terminal=True)
    assert Q[0, 1] == 1.0


def t_cluster():
    X = np.vstack([np.array([[0.0, 0.0, 0.0, 0.0], [0.1, 0.1, 0.0, 0.0],
                             [0.0, 0.1, 0.1, 0.0]]),
                   np.array([[100.0, 100.0, 0.0, 0.0], [100.1, 100.0, 0.0, 0.0],
                             [100.0, 100.1, 0.0, 0.0]])])
    g = cluster(X, 2, np.random.default_rng(3))
    assert len(g) == 2
    sets = {frozenset(grp.tolist()) for grp in g}
    assert sets == {frozenset({0, 1, 2}), frozenset({3, 4, 5})}
    # deterministic under the same seed
    g2 = cluster(X, 2, np.random.default_rng(3))
    assert [grp.tolist() for grp in g] == [grp.tolist() for grp in g2]


def t_lbest():
    X = np.array([[0.0, 0.0], [1.0, 0.0], [2.0, 0.0], [9.0, 9.0], [9.0, 8.0]])
    groups = [np.array([0, 1, 2]), np.array([3, 4])]
    pF = np.array([3.0, 1.0, 2.0, 5.0, 4.0])
    lb = lbest_positions(X, X, pF, groups)
    assert len(lb) == 2
    assert np.array_equal(lb[0], X[1])     # smallest pF = particle 1
    assert np.array_equal(lb[1], X[4])     # smallest pF = particle 4


# ---- random-number shape (matching the paper wording) ----

class _ShapeRecorder:
    """Record random(*size) call shapes; all other methods delegate to the underlying Generator."""

    def __init__(self, base):
        self.base = base
        self.shapes = []

    def random(self, *size):
        self.shapes.append(size)
        return self.base.random(*size)

    def __getattr__(self, name):
        return getattr(self.base, name)


def t_ahdpso_scalar_rand():
    # AHDPSO Eq.21 "r1 is a random number between [0,1]" + released code AHDPSO1.py:
    # r1/r2/r3 are one scalar per particle per generation -> shape=(n_p,) must appear,
    # never the per-element matrix (n_p,DIM)
    rec = _ShapeRecorder(np.random.default_rng(9))
    run_ahdpso(rec, model.priority_mask(0), "los", n_p=4, max_fes=16)
    assert (4,) in rec.shapes, "missing per-particle scalar random numbers (shape=(n_p,))"
    assert not any(s == (4, 75) for s in rec.shapes), "per-element random matrix (n_p,DIM) must not appear"


def t_pso_scalar_rand():
    # released code PSO.py: r1/r2 are one scalar per particle per generation
    # -> shape=(n_p,), the matrix (n_p,DIM) must not appear
    rec = _ShapeRecorder(np.random.default_rng(11))
    run_standard_pso(rec, model.priority_mask(0), "los", n_p=4, max_fes=16)
    assert (4,) in rec.shapes, "missing per-particle scalar random numbers (shape=(n_p,))"
    assert not any(s == (4, 75) for s in rec.shapes), "per-element random matrix (n_p,DIM) must not appear"


def t_ql_k1_per_particle_rand():
    # T-ADMPSO Algorithm 2 c=1 branch: independent rand per individual j
    # (per-individual scalar), not one scalar broadcast to the whole swarm
    rec = _ShapeRecorder(np.random.default_rng(10))
    run_ql_tadmpso(rec, model.priority_mask(0), "los", n_p=5, max_fes=80,
                   G=15, k0=1)
    assert (5,) in rec.shapes, "k=1 branch missing per-particle scalar random numbers (shape=(n_p,))"
    assert not any(s == (5, 75) for s in rec.shapes), "per-element random matrix (n_p,DIM) must not appear"


# ---- integration smoke (real model, pure LoS for speed) ----

def _mask():
    return model.priority_mask(0)


def t_run_pso_smoke():
    res = run_standard_pso(np.random.default_rng(1), _mask(), "los",
                           n_p=5, max_fes=20)
    assert len(res["gF_history"]) == 4      # initial evaluation + T generations
    _assert_hist_nonincr(res["gF_history"])
    assert res["best_F"] == res["gF_history"][-1]
    assert res["best_pos"].shape == (75,)
    assert (res["best_pos"] >= LB).all() and (res["best_pos"] <= UB).all()
    assert "TC" in res["final_metrics"] and 0.0 <= res["final_metrics"]["TC"] <= 1.0


def t_pso_exact_budget_and_history():
    res = run_standard_pso(np.random.default_rng(1), _mask(), "los",
                           n_p=5, max_fes=20)
    assert res["fes"] == 20
    assert res["n_updates"] == 3
    assert len(res["gF_history"]) == 4
    assert "stop_reason" not in res


def t_timed_pso_stops_on_complete_generation_boundaries():
    """Catch checkpoints using the previous generation, or timing excluding init or running a partial population."""
    protocol = TimeProtocol(
        limit_seconds=2.0,
        checkpoints_seconds=(1.0, 2.0),
        max_fes_safety=40,
    )
    result = run_standard_pso(
        np.random.default_rng(71), _mask(), "los", n_p=4,
        time_protocol=protocol,
        clock=_FakeClock([0.0, 0.2, 0.4, 1.2, 1.3, 2.2, 2.3]),
    )
    assert result["fes"] == 12
    assert result["n_updates"] == 2
    assert [row["fes"] for row in result["checkpoints"]] == [8, 12]
    assert result["stop_reason"] == "time_limit"
    assert abs(result["overshoot_seconds"] - 0.2) < 1e-12


def t_timed_q_terminal_update_has_no_post_stop_action():
    """Catch a Q action still picked after a timed stop, or an outstanding action not receiving its single terminal reward."""
    protocol = TimeProtocol(
        limit_seconds=2.0,
        checkpoints_seconds=(1.0, 2.0),
        max_fes_safety=50,
    )
    result = run_ql_tadmpso(
        np.random.default_rng(72), _mask(), "los",
        n_p=5, G=1, k0=1, k_max=1,
        time_protocol=protocol,
        clock=_FakeClock([0.0, 0.2, 0.4, 1.2, 1.3, 2.2, 2.3]),
    )
    assert result["fes"] == 15 and result["n_updates"] == 2
    assert len(result["action_history"]) == 1
    assert len(result["reward_history"]) == 1
    assert result["reward_history"][0]["terminal"] is True
    assert int(result["q_visits"].sum()) == 1


def t_timed_q_elapsed_includes_terminal_q_update():
    """The timed endpoint must sit after the terminal Q update, not cover only particle evaluation."""
    elapsed = [0.0]
    calls = []
    original = algorithms.q_update

    def counted_q_update(*args, **kwargs):
        elapsed[0] += 0.4
        terminal = kwargs.get("terminal", args[7] if len(args) > 7 else False)
        calls.append(bool(terminal))
        return original(*args, **kwargs)

    protocol = TimeProtocol(
        limit_seconds=0.3,
        checkpoints_seconds=(0.3,),
        max_fes_safety=50,
    )
    algorithms.q_update = counted_q_update
    try:
        result = run_ql_tadmpso(
            np.random.default_rng(720), _mask(), "los",
            n_p=5, G=1, k0=1, k_max=1,
            time_protocol=protocol,
            clock=lambda: elapsed[0],
        )
    finally:
        algorithms.q_update = original

    assert calls and calls[-1] is True
    assert result["reward_history"][-1]["terminal"] is True
    assert np.isclose(result["actual_seconds"], elapsed[0])


def t_timed_safety_ceiling_stops_without_partial_population():
    """Catch the FE safety ceiling being overshot or mislabeled as time_limit."""
    protocol = TimeProtocol(
        limit_seconds=10.0,
        checkpoints_seconds=(10.0,),
        max_fes_safety=8,
    )
    result = run_standard_pso(
        np.random.default_rng(73), _mask(), "los", n_p=4,
        time_protocol=protocol,
        clock=_FakeClock([0.0, 0.1, 0.2, 0.3]),
    )
    assert result["fes"] == 8 and result["n_updates"] == 1
    assert result["stop_reason"] == "max_fes_safety"
    assert result["checkpoints"] == []


def t_other_algorithms_support_timed_protocol():
    """Catch the AHDPSO or T-ADMPSO entry missing the unified time controller."""
    protocol = TimeProtocol(
        limit_seconds=1.0,
        checkpoints_seconds=(1.0,),
        max_fes_safety=24,
    )
    runners = (
        (run_ahdpso, {}),
        (algorithms.run_tadmpso, {}),
    )
    for offset, (runner, kwargs) in enumerate(runners):
        result = runner(
            np.random.default_rng(74 + offset), _mask(), "los", n_p=6,
            time_protocol=protocol,
            clock=_FakeClock([0.0, 0.1, 0.2, 1.1]),
            **kwargs,
        )
        assert result["fes"] == 12 and result["n_updates"] == 1
        assert result["stop_reason"] == "time_limit"
        assert result["checkpoints"][0]["fes"] == 12
    assert result["schedule_label"] == "factorization_time_normalized"


def t_main_budget_is_499_updates():
    assert update_count(25000, 50) == 499


def t_factor_pairs_np50_are_literal_parent_schedule():
    """Catch factor directions flipped, illegal factorizations below 3 particles per group, or sort errors."""
    assert algorithms.factor_pairs(50, 3) == [
        (10, 5), (5, 10), (2, 25), (1, 50)
    ]


def t_factor_schedule_499_updates_has_exact_stage_lengths():
    """Catch the switch-point rounding changing the stage lengths of the formal 499 generations."""
    schedule = algorithms.factorization_schedule(499, 50, 3)
    assert len(schedule) == 499
    assert [
        (k, int((schedule == k).sum())) for k in (10, 5, 2, 1)
    ] == [(10, 99), (5, 49), (2, 19), (1, 332)]


def t_tadmpso_has_schedule_but_no_q_updates():
    """Catch the T-ADMPSO adapted baseline carrying a Q table or missing strict FE accounting."""
    result = algorithms.run_tadmpso(
        np.random.default_rng(8), _mask(), "a2g", n_p=6, max_fes=18
    )
    assert result["schedule_label"] == "factorization"
    assert result["k_schedule"] == [1, 1]
    assert "q_table" not in result
    assert "action_history" not in result
    assert result["fes"] == 18


def t_factor_schedule_control_is_deterministic_and_records_transitions():
    """Catch the external schedule not actually controlling k, seed drift on repeats, or k recorded every generation."""
    schedule = algorithms.factorization_schedule(4, 12, 3)
    assert schedule.tolist() == [4, 3, 1, 1]

    def run(seed):
        return run_ql_tadmpso(
            np.random.default_rng(seed), _mask(), "los",
            n_p=12, max_fes=60, G=5, k0=1, k_max=16, L=5,
            use_q_learning=False, k_schedule=schedule,
            schedule_label="factorization",
        )

    first = run(81)
    second = run(81)
    different = run(82)
    assert first["best_F"] == second["best_F"]
    assert first["gF_history"] == second["gF_history"]
    assert first["k_schedule"] == second["k_schedule"] == schedule.tolist()
    assert first["k_history"] == [(1, 3), (2, 1)]
    assert not np.array_equal(first["best_pos"], different["best_pos"])

    parent_1 = algorithms.run_tadmpso(
        np.random.default_rng(83), _mask(), "los", n_p=12, max_fes=60
    )
    parent_2 = algorithms.run_tadmpso(
        np.random.default_rng(83), _mask(), "los", n_p=12, max_fes=60
    )
    parent_other = algorithms.run_tadmpso(
        np.random.default_rng(84), _mask(), "los", n_p=12, max_fes=60
    )
    assert parent_1["best_F"] == parent_2["best_F"]
    assert parent_1["gF_history"] == parent_2["gF_history"]
    assert parent_1["k_schedule"] == parent_2["k_schedule"]
    assert not np.array_equal(parent_1["best_pos"], parent_other["best_pos"])


def t_ql_uses_fsw_topology_and_alignment():
    calls = {"cluster": 0, "align": 0}

    def fake_cluster(X, k, rng, directions, L, min_size=3, scenario=None):
        calls["cluster"] += 1
        return [np.array([0, 1, 2]), np.array([3, 4, 5])]

    def fake_align(reference, guide, scenario=None):
        calls["align"] += 1
        return np.asarray(guide).reshape(-1, 3).copy()

    old_cluster = algorithms.cluster_deployments
    old_align = algorithms.align_guide
    try:
        algorithms.cluster_deployments = fake_cluster
        algorithms.align_guide = fake_align
        run_ql_tadmpso(np.random.default_rng(14), _mask(), "los",
                       n_p=6, max_fes=12, G=10, k0=2, k_max=2,
                       p_exchange=1.0, L=5)
    finally:
        algorithms.cluster_deployments = old_cluster
        algorithms.align_guide = old_align
    assert calls["cluster"] == 1
    assert calls["align"] == 12  # per particle: aligned once to lbest and once to gbest


def t_run_ahdpso_smoke():
    res = run_ahdpso(np.random.default_rng(2), _mask(), "los",
                     n_p=4, max_fes=16)
    assert len(res["gF_history"]) == 4      # initial evaluation + T generations
    _assert_hist_nonincr(res["gF_history"])
    assert res["best_F"] <= res["gF_history"][0]
    assert (res["best_pos"] >= LB).all() and (res["best_pos"] <= UB).all()


def t_run_ql_smoke():
    res = run_ql_tadmpso(np.random.default_rng(3), _mask(), "los",
                         n_p=5, max_fes=155, G=15, k0=16)
    assert len(res["gF_history"]) == 31     # initial evaluation + T generations
    _assert_hist_nonincr(res["gF_history"])
    assert len(res["k_history"]) == 1       # action picked at t=15; t=30 only does the terminal reward update
    for _, k in res["k_history"]:
        assert 1 <= k <= 16
    assert res["best_F"] <= res["gF_history"][0]


def t_all_algorithms_accept_variable_scenario():
    """Catch any algorithm entry missing the scenario argument or returning a default 75-dim deployment."""
    deployment = DeploymentScenario(ScenarioConfig(n_uav=10))
    priority = deployment.priority_mask(4)
    calls = (
        (run_standard_pso, {"n_p": 4, "max_fes": 8}),
        (run_ahdpso, {"n_p": 4, "max_fes": 8}),
        (
            run_ql_tadmpso,
            {"n_p": 5, "max_fes": 10, "G": 10, "k0": 1, "k_max": 1},
        ),
    )
    lower, upper = deployment.bounds()
    for offset, (runner, kwargs) in enumerate(calls):
        result = runner(
            np.random.default_rng(90 + offset), priority, "los",
            scenario=deployment, **kwargs
        )
        assert result["best_pos"].shape == (30,)
        assert np.all(result["best_pos"] >= lower)
        assert np.all(result["best_pos"] <= upper)


def t_every_selected_action_receives_one_reward():
    res = run_ql_tadmpso(np.random.default_rng(3), _mask(), "los",
                         n_p=5, max_fes=55, G=3, k0=1, k_max=1)
    assert len(res["action_history"]) == len(res["reward_history"]) == 3
    assert res["reward_history"][-1]["terminal"] is True
    assert int(res["q_visits"].sum()) == 3
    # gbest never increases -> reward = improvement since the last decision, always non-negative
    assert all(item["reward"] >= 0 for item in res["reward_history"])


def t_ablation_flags_smoke():
    common = dict(n_p=6, max_fes=12, G=10, k0=2, k_max=2, L=5)
    variants = ({"use_fsw": False}, {"align_guides": False},
                {"use_topology": False}, {"use_q_learning": False},
                {"use_cross_swarm": False, "p_exchange": -1.0})
    for offset, flags in enumerate(variants):
        res = run_ql_tadmpso(np.random.default_rng(30 + offset), _mask(), "los",
                             **common, **flags)
        assert res["fes"] == 12 and len(res["gF_history"]) == 2


def t_run_determinism():
    # edge case: same seed rerun -> identical trajectories (prerequisite for paired fairness)
    mask = _mask()
    for fn, kw in ((run_standard_pso, dict(n_p=4, max_fes=16)),
                   (run_ahdpso, dict(n_p=4, max_fes=16))):
        r1 = fn(np.random.default_rng(77), mask, "los", **kw)
        r2 = fn(np.random.default_rng(77), mask, "los", **kw)
        assert r1["gF_history"] == r2["gF_history"]
        assert r1["best_F"] == r2["best_F"]
    kw = dict(n_p=5, max_fes=80, G=15, k0=16)
    r1 = run_ql_tadmpso(np.random.default_rng(78), mask, "los", **kw)
    r2 = run_ql_tadmpso(np.random.default_rng(78), mask, "los", **kw)
    assert r1["gF_history"] == r2["gF_history"]
    assert r1["k_history"] == r2["k_history"]


def t_run_T0():
    # edge case: max_fes=n_p (init evaluation only) -> trajectory length 1, k_history empty, no crash
    mask = _mask()
    r = run_standard_pso(np.random.default_rng(1), mask, "los", n_p=5, max_fes=5)
    assert len(r["gF_history"]) == 1
    r = run_ahdpso(np.random.default_rng(2), mask, "los", n_p=4, max_fes=4)
    assert len(r["gF_history"]) == 1
    r = run_ql_tadmpso(np.random.default_rng(3), mask, "los",
                       n_p=5, max_fes=5, G=15)
    assert len(r["gF_history"]) == 1 and r["k_history"] == []


def t_ql_G_gt_T():
    # edge case: decision interval G larger than total generations T -> no decision point, k_history empty, run completes
    r = run_ql_tadmpso(np.random.default_rng(4), _mask(), "los",
                       n_p=5, max_fes=55, G=50, k0=16)
    assert r["k_history"] == []
    assert len(r["gF_history"]) == 11


def t_cluster_c1():
    # edge case: c=1 -> one subgroup holding all particles
    X = np.array([[0.0, 0.0], [1.0, 1.0], [2.0, 2.0]])
    g = cluster(X, 1, np.random.default_rng(0))
    assert len(g) == 1
    assert sorted(g[0].tolist()) == [0, 1, 2]


def t_q_update_negative_reward():
    # edge case: Bellman update still runs with a negative reward (worse solution)
    Q = np.zeros((16, 3))
    Q[0, 1] = 5.0
    Q[2] = [1.0, 2.0, 3.0]
    q_update(Q, state=0, action=1, reward=-5.0, next_state=2)
    # Q[0,1] += 0.5*(-5 + 0.95*3 - 5) = -3.575 -> 5-3.575=1.425
    assert abs(Q[0, 1] - 1.425) < 1e-12


def t_c3_odd_T():
    # edge case: middle split for odd T (t=3 falls into the second-half form (T-t-1)/T)
    T = 7
    r = np.linspace(0.1, 0.7, T)
    c3 = c3_series(r)
    assert abs(c3[3] - 3.0 / 7.0 * (1.0 + 0.8 * r[3])) < 1e-12
    assert c3[0] == 0.0 and c3[-1] == 0.0


if __name__ == "__main__":
    print("test_algorithms.py")
    for name, fn in sorted(globals().items()):
        if name.startswith("t_") and callable(fn):
            check(name, fn)
    print()
    if _FAILS:
        print(f"{len(_FAILS)} failed/errored")
        sys.exit(1)
    print("all passed")
