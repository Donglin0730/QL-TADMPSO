"""Protect the published stochastic update while batching its arithmetic."""
import json
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import algorithms
import scenario
from run_v4 import jsonable


class MatrixTests(unittest.TestCase):
    def test_shared_terms_and_cross_mask_have_hand_checked_values(self):
        import algorithms as matrix
        x = np.zeros((2, 3))
        velocity = np.full((2, 3), 2.)
        personal = np.array([[1., 2., 3.], [3., 2., 1.]])
        local = np.ones((2, 3))
        global_guide = np.full((2, 3), 2.)
        other = np.full((2, 3), 4.)
        # Columns are personal, local, global and cross learning terms.
        randoms = np.array([[.5, .25, .5, .25], [1., .5, .25, .75]])
        actual = matrix.shared_multiswarm_velocity(
            x, velocity, personal, local, global_guide, other,
            randoms, np.array([True, False]), .5, 2., 1.)
        np.testing.assert_array_equal(actual, [[5.25, 6.25, 7.25], [8., 6., 4.]])
        np.testing.assert_array_equal(velocity, np.full((2, 3), 2.))

    def test_coordinate_wise_random_coefficients_are_rejected(self):
        import algorithms as matrix
        x = np.ones((2, 6))
        with self.assertRaises(ValueError):
            matrix.shared_multiswarm_velocity(
                x, x, x, x, x, x, np.ones((2, 6)),
                np.ones(2, dtype=bool), .5, 1., 1.)

    def test_permutation_keeps_xyz_velocity_and_physical_sets_together(self):
        import algorithms as matrix
        x = np.arange(72, dtype=float).reshape(4, 18)
        v = x + 100
        xp, vp = matrix.permute_swarm(x, v, 903)
        np.testing.assert_array_equal(vp - xp, np.full(x.shape, 100.))
        for original, permuted in zip(x.reshape(4, 6, 3), xp.reshape(4, 6, 3)):
            np.testing.assert_array_equal(
                original[np.argsort(original[:, 0])],
                permuted[np.argsort(permuted[:, 0])])
        self.assertFalse(np.array_equal(x, xp))
        orders = (xp[:, 0::3] - x[:, :1]) / 3
        self.assertGreater(len({tuple(row) for row in orders}), 1)
        np.testing.assert_array_equal(x, np.arange(72).reshape(4, 18))

    def test_initial_permutation_uses_no_optimizer_random_draws(self):
        scene = scenario.DeploymentScenario(scenario.ScenarioConfig(n_uav=5, n_grid=10))
        priority = scene.priority_mask(71)
        plain, permuted = np.random.default_rng(14), np.random.default_rng(14)
        common = dict(n_p=6, max_fes=6, scenario=scene)
        original = algorithms.run_ql_tadmpso(plain, priority, 'a2g', **common)
        changed = algorithms.run_ql_tadmpso(
            permuted, priority, 'a2g', permutation_seed=904, **common)
        self.assertEqual(plain.random(), permuted.random())
        self.assertAlmostEqual(original['best_F'], changed['best_F'], places=5)
        a, b = np.asarray(original['best_pos']).reshape(-1, 3), np.asarray(changed['best_pos']).reshape(-1, 3)
        np.testing.assert_array_equal(a[np.lexsort(a.T)], b[np.lexsort(b.T)])

    def test_random_actions_change_k_without_learning_a_q_table(self):
        scene = scenario.DeploymentScenario(scenario.ScenarioConfig(n_uav=5, n_grid=10))
        result = algorithms.run_ql_tadmpso(
            np.random.default_rng(14), scene.priority_mask(71), 'a2g',
            n_p=12, max_fes=144, G=2, L=7, k0=3, scenario=scene,
            use_q_learning=False, random_actions=True)
        self.assertTrue(result['action_history'])
        self.assertTrue(all(1 <= row['k_after'] <= 4 for row in result['action_history']))
        np.testing.assert_array_equal(result['q_table'], np.zeros((16, 3)))
        self.assertEqual(result['reward_history'], [])

    def test_prechange_trajectories_and_rng_state_are_preserved(self):
        fixture = json.loads((Path(__file__).parent / 'fixtures/pre_v5_matrix_regression.json').read_text())
        old_gpu = scenario._USE_GPU
        scenario._USE_GPU = False
        try:
            scene = scenario.DeploymentScenario(scenario.ScenarioConfig.from_dict(fixture['scenario']))
            for case in fixture['cases']:
                with self.subTest(case=case['name']):
                    rng = np.random.default_rng(488)
                    result = algorithms.run_ql_tadmpso(
                        rng, scene.priority_mask(787), 'a2g', n_p=12,
                        max_fes=144, G=2, L=7, scenario=scene, **case['options'])
                    actual = jsonable(result)
                    for key, expected in case['result'].items():
                        self.assertEqual(actual[key], expected, msg=case['name'] + ': ' + key)
                    self.assertEqual(rng.random(), case['next_random'])
        finally:
            scenario._USE_GPU = old_gpu


if __name__ == '__main__':
    unittest.main()
