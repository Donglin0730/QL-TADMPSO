"""Run both unittest files and the older standalone assertion test scripts."""
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parents[1]
    output = root / 'verification'
    output.mkdir(parents=True, exist_ok=True)
    scripts = sorted((root / 'tests').glob('test_*.py'))
    if not scripts:
        raise RuntimeError('no test scripts found')
    env = dict(os.environ, PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1',
               MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    results = []
    for script in scripts:
        log = output / (script.stem + '.log')
        with log.open('w', encoding='utf-8') as stream:
            result = subprocess.run([sys.executable, '-B', str(script)], cwd=root, env=env,
                                    stdout=stream, stderr=subprocess.STDOUT)
        results.append(dict(script=script.name, exit_code=result.returncode, log=str(log)))
        print(('PASS ' if result.returncode == 0 else 'FAIL ') + script.name, flush=True)
        if result.returncode:
            print(log.read_text(encoding='utf-8')[-5000:], flush=True)
    (output / 'test_results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    passed = sum(r['exit_code'] == 0 for r in results)
    print(f'{passed}/{len(results)} test scripts passed.', flush=True)
    return int(passed != len(results))


if __name__ == '__main__':
    sys.exit(main())
