from pathlib import Path
from copy import deepcopy
import tempfile
import sys
import unittest
from unittest.mock import patch
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class RunnerTests(unittest.TestCase):
    def valid_record(self, mod):
        from scenario import ScenarioConfig, metrics_from_summary
        config = mod.make_config("smoke")
        metrics = metrics_from_summary(.5, .6, 8., 10.)
        return config, dict(i=0, method="pso", algo="pso", seed=81000,
                            priority_seed=8100, feedback_seed=101000,
                            scenario=ScenarioConfig(n_uav=5).to_dict(),
                            best_pos=np.tile([2500., 2500., 200.], 5).tolist(),
                            best_F=metrics["F"], final_metrics=metrics,
                            fes=500, n_updates=9, runtime_seconds=1.,
                            history_fes=[50, 250, 500],
                            gF_history=[metrics["F"]+.1, metrics["F"]+.05, metrics["F"]])

    def module(self):
        try:
            import run_v4
        except ImportError:
            self.fail("Versioned experiment runner is not implemented")
        return run_v4

    def test_formal_main_matrix_and_legacy_control_are_explicit(self):
        mod = self.module()
        config = mod.make_config("main")
        self.assertEqual(len(mod.expected_keys(config)), 840)
        self.assertEqual(config["counts"], [5, 10, 15, 20, 25, 30])
        self.assertIn("legacy_coefficients", mod.VARIANTS)
        self.assertEqual(mod.VARIANTS["legacy_coefficients"]["coefficient_control"], "ahdpso")

    def test_resume_rejects_modified_protocol(self):
        mod = self.module()
        config = mod.make_config("smoke")
        with tempfile.TemporaryDirectory() as name:
            path = Path(name)/"runs.json"
            data = mod.load_or_initialize(path, config)
            mod.save_json(path, data)
            modified = deepcopy(config)
            modified["priority_seed_base"] += 1
            with self.assertRaisesRegex(ValueError, "configuration|fingerprint"):
                mod.load_or_initialize(path, modified)

    def test_changed_source_fingerprint_cannot_resume(self):
        mod = self.module()
        config = mod.make_config("smoke")
        with tempfile.TemporaryDirectory() as name:
            path = Path(name)/"runs.json"
            data = mod.load_or_initialize(path, config)
            data["provenance"]["source_sha256"]["algorithms.py"] = "tampered"
            mod.save_json(path, data)
            with self.assertRaisesRegex(ValueError, "source|fingerprint"):
                mod.load_or_initialize(path, config)

    def test_variable_fe_history_uses_step_interpolation_without_lookahead(self):
        mod = self.module()
        actual = mod.history_at_fes([50, 73, 125], [1., .8, .3], [50, 60, 100, 125])
        np.testing.assert_array_equal(actual, [1., 1., .8, .3])

    def test_incomplete_results_do_not_qualify_as_formal(self):
        mod = self.module()
        config = mod.make_config("main")
        self.assertFalse(mod.qualify({"config": config, "runs": []})["qualified"])

    def test_record_rejects_nan_archive_and_noninteger_evaluation_times(self):
        mod = self.module()
        config, record = self.valid_record(mod)
        mod.validate_record(record, config)
        for field, value in (("best_F", float("nan")),
                             ("history_fes", [50, float("nan"), 500]),
                             ("history_fes", [50, 250.5, 500]),
                             ("i", .1), ("runtime_seconds", float("inf"))):
            with self.subTest(field=field, value=value):
                corrupted = dict(record, **{field: value})
                with self.assertRaises((ValueError, TypeError)):
                    mod.validate_record(corrupted, config)

    def test_formal_gate_checks_all_fixed_parameters_and_provenance(self):
        mod = self.module()
        config, row = self.valid_record(mod)
        data = dict(config=mod.make_config("main"), runs=[row], result_kind="main",
                    schema_version=mod.SCHEMA, model_version=mod.model.MODEL_VERSION,
                    provenance={"source_sha256": mod.source_hashes(),
                                "runtime": mod.runtime_fingerprint()})
        # Isolate the formal gate from the separately tested record/matrix validator.
        with patch.object(mod, "expected_keys", return_value={mod.record_key(row)}), \
                patch.object(mod, "validate_record"):
            self.assertTrue(mod.qualify(data)["qualified"])
            for changes in ({"G": 999}, {"L": 1}, {"mode": "los"},
                            {"objective_weights": [.9, .05, .05]}):
                altered = deepcopy(data)
                altered["config"].update(changes)
                self.assertFalse(mod.qualify(altered)["qualified"])
            altered = deepcopy(data)
            altered["provenance"]["source_sha256"]["algorithms.py"] = "x"*64
            self.assertFalse(mod.qualify(altered)["qualified"])
            altered = deepcopy(data)
            del altered["provenance"]["runtime"]
            self.assertFalse(mod.qualify(altered)["qualified"])

    def test_output_directory_has_one_writer_and_lock_releases(self):
        mod = self.module()
        with tempfile.TemporaryDirectory() as name:
            with mod.directory_lock(Path(name)):
                with self.assertRaisesRegex(RuntimeError, "already|running|lock"):
                    with mod.directory_lock(Path(name)):
                        self.fail("second writer acquired the experiment directory")
            with mod.directory_lock(Path(name)):
                pass

    def test_source_snapshot_is_saved_and_never_silently_replaced(self):
        mod = self.module()
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            hashes = mod.source_hashes()
            mod.save_source_snapshot(folder, hashes)
            saved = folder/"source_snapshot"/"algorithms.py"
            self.assertEqual(saved.read_bytes(), (mod.HERE/"algorithms.py").read_bytes())
            saved.write_bytes(b"modified")
            with self.assertRaisesRegex(ValueError, "snapshot|source"):
                mod.save_source_snapshot(folder, hashes)


if __name__ == "__main__":
    unittest.main()
