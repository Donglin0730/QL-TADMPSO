"""report.py tests. Run: python tests/test_report.py

Covers: Wilcoxon direction labeling semantics - best_F/SASU/GASU are
better when smaller, TC/SAC better when larger (2026-08-19 fix: the old
implementation labeled TC/SAC as smaller-better too, reversing direction).
"""
import json
import os
import sys
import tempfile
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import report
import run_exp

_FAILS = []

_V3_SCENARIO = {
    "area_m": 5000.0,
    "n_grid": 50,
    "n_uav": 25,
    "h_min_m": 100.0,
    "h_max_m": 500.0,
    "priority_fraction": 0.30,
    "frequency_mhz": 2000.0,
    "propagation_mode": "a2g",
    "cell_size_m": 100.0,
}


def _v3_full_data(n=6, formal=False):
    data = {
        "schema_version": "uav-bs-experiment-results-v3",
        "model_version": "uav-bs-a2g-ahdpso-scenario-v3",
        "result_kind": "full",
        "config": {
            "scenario": dict(_V3_SCENARIO),
            "algorithms": ["pso", "ahdpso", "tadmpso", "ql"],
            "seed_protocol": "held_out_v1",
            "n_runs": n,
            "stop_protocol": {"kind": "fixed_fes", "max_fes": 25000},
            "source_fingerprint": run_exp.optimizer_source_fingerprint(),
            "n_p": 50, "max_fes": 25000, "mode": "a2g",
            "L": 50, "G": 5,
            "evidence_type": (
                "formal_held_out_v3" if formal else "synthetic_qa_v3"
            ),
            "formal_qualification": bool(formal),
        },
        "runs": [],
    }
    objective = {
        "pso": 0.40, "ahdpso": 0.35, "tadmpso": 0.30, "ql": 0.20,
    }
    for i in range(n):
        for algo in ("pso", "ahdpso", "tadmpso", "ql"):
            value = objective[algo] + i / 1000.0
            metrics = {
                "F": value, "TC": 0.80 + i / 10000.0,
                "SAC": 0.90 + i / 10000.0,
                "SASU": 9.0 + i / 1000.0,
                "GASU": 10.0 + i / 1000.0,
            }
            data["runs"].append({
                "i": i, "scenario_id": "default", "algo": algo,
                "seed": 3000 + i, "priority_seed": 300 + i,
                "scenario": dict(_V3_SCENARIO),
                "best_F": value, "gF_history": [value] * 500,
                "final_metrics": metrics,
                "best_pos": np.tile([2500.0, 2500.0, 200.0], 25).tolist(),
                "fes": 25000, "n_updates": 499,
                "runtime_seconds": 1.0,
            })
    return data


def _v3_time_data(n=6, formal=False):
    data = _v3_full_data(n, formal=formal)
    data["result_kind"] = "time_budget"
    data["config"]["seed_protocol"] = "time_v1"
    data["config"]["stop_protocol"] = {
        "kind": "fixed_time", "limit_seconds": 60.0,
        "checkpoints_seconds": [15.0, 30.0, 60.0],
        "max_fes_safety": 5000000,
    }
    data["config"]["max_fes"] = 5000000
    data["config"]["hardware"] = {"device": "literal-test-machine"}
    data["config"]["timing_protocol"] = "time_normalized_v1"
    data["config"]["warmup_completed"] = True
    data["config"]["order_seed_base"] = 9000
    order_index = {}
    for i in range(n):
        rng = np.random.default_rng(9000 + i)
        order = np.asarray(
            ["pso", "ahdpso", "tadmpso", "ql"]
        )[rng.permutation(4)].tolist()
        order_index[i] = {algo: index for index, algo in enumerate(order)}
    for row in data["runs"]:
        row["seed"] = 7000 + row["i"]
        row["priority_seed"] = 700 + row["i"]
        row["fes"] = 300
        row["n_updates"] = 5
        row["gF_history"] = [row["best_F"]] * 6
        row["runtime_seconds"] = 60.2
        row["checkpoints"] = []
        for target, fes in ((15.0, 100), (30.0, 200), (60.0, 300)):
            row["checkpoints"].append({
                "target_seconds": target,
                "actual_seconds": target + 0.1,
                "fes": fes,
                "best_F": row["best_F"],
                "final_metrics": dict(row["final_metrics"]),
                "best_pos": list(row["best_pos"]),
            })
        row["stop_reason"] = "time_limit"
        row["overshoot_seconds"] = 0.1
        row["actual_seconds"] = 60.1
        row["order_seed"] = 9000 + row["i"]
        row["order_index"] = order_index[row["i"]][row["algo"]]
    return data


def _v3_sweep_data(kind, n=20, formal=False):
    data = _v3_full_data(n, formal=formal)
    data["result_kind"] = kind
    data["config"]["seed_protocol"] = "robustness_v1"
    if kind == "area_sweep":
        cases = (
            ("5km", dict(_V3_SCENARIO)),
            ("7km", dict(_V3_SCENARIO, area_m=7000.0, n_grid=70,
                         cell_size_m=100.0)),
            ("10km", dict(_V3_SCENARIO, area_m=10000.0, n_grid=100,
                          cell_size_m=100.0)),
        )
    else:
        cases = tuple(
            (f"{count}uav", dict(_V3_SCENARIO, n_uav=count))
            for count in (10, 25, 50)
        )
    base_runs = list(data["runs"])
    data["runs"] = []
    data["config"]["case_registry"] = [
        {"scenario_id": scenario_id, "scenario": scenario}
        for scenario_id, scenario in cases
    ]
    for scenario_id, scenario in cases:
        for row in base_runs:
            clone = dict(row)
            clone["scenario_id"] = scenario_id
            clone["scenario"] = dict(scenario)
            clone["seed"] = 5000 + clone["i"]
            clone["priority_seed"] = 500 + clone["i"]
            clone["best_pos"] = np.tile(
                [scenario["area_m"] / 2.0,
                 scenario["area_m"] / 2.0, 200.0],
                scenario["n_uav"],
            ).tolist()
            data["runs"].append(clone)
    return data


def t_explicit_nonformal_full_is_not_called_protocol_smoke():
    data = _v3_full_data(n=20)
    data["config"]["formal_qualification"] = False
    qualification = report.formal_qualification(data)
    assert qualification["formal"] is False
    reason = " ".join(qualification["reasons"]).lower()
    assert "non-formal" in reason
    assert "protocol smoke" not in reason


def check(name, fn):
    try:
        fn()
        print(f"  ok  {name}")
    except AssertionError as e:
        _FAILS.append((name, str(e)))
        print(f"FAIL  {name}: {e}")
    except Exception as e:
        _FAILS.append((name, repr(e)))
        print(f"ERR   {name}: {type(e).__name__}: {e}")


def t_better_label_min_metrics():
    # Minimized metrics: smaller mean is better
    assert report.better_label("best_F", 0.10, 0.12, "QL-TADMPSO", "PSO") == "QL-TADMPSO better"
    assert report.better_label("SASU", 3.0, 2.0, "QL-TADMPSO", "PSO") == "PSO better"
    assert report.better_label("GASU", 2.5, 2.5, "QL-TADMPSO", "AHDPSO") == "QL-TADMPSO better"


def t_better_label_max_metrics():
    # Maximized metrics (TC/SAC): larger mean is better
    assert report.better_label("TC", 0.9995, 1.0, "QL-TADMPSO", "PSO") == "PSO better"
    assert report.better_label("SAC", 1.0, 0.99, "QL-TADMPSO", "AHDPSO") == "QL-TADMPSO better"
    assert report.better_label("TC", 0.5, 0.5, "QL-TADMPSO", "PSO") == "QL-TADMPSO better"


def t_report_rejects_old_schema():
    try:
        report.validate_results({"config": {}, "runs": []})
    except ValueError as exc:
        assert "schema_version" in str(exc)
    else:
        raise AssertionError("old schema must fail")


def t_report_uses_v2_schema():
    assert report.SCHEMA_VERSION == report.model.MODEL_VERSION
    assert report.SCHEMA_VERSION.endswith("50grid-v2")


def t_holm_adjustment_is_monotone_and_bounded():
    adjusted = report.holm_adjust([0.01, 0.04, 0.03])
    assert np.all((adjusted >= 0.0) & (adjusted <= 1.0))
    order = np.argsort([0.01, 0.04, 0.03])
    assert np.all(np.diff(adjusted[order]) >= -1e-15)


def t_paired_effect_summary():
    out = report.paired_effect_summary([1.0, 2.0, 3.0],
                                       [0.0, 1.0, 1.0], seed=4)
    assert out["median_difference"] == 1.0
    assert out["ci_low"] <= out["median_difference"] <= out["ci_high"]


def t_ablation_summary_uses_paired_run_ids():
    data = {
        "schema_version": report.SCHEMA_VERSION,
        "model_version": report.model.MODEL_VERSION,
        "runs": [],
    }
    full = [0.20, 0.22, 0.19, 0.21]
    removed = [0.23, 0.21, 0.25, 0.24]
    for i, value in enumerate(full):
        data["runs"].append({"i": i, "variant": "full", "best_F": value,
                             "runtime_seconds": 2.0})
    for i, value in reversed(list(enumerate(removed))):
        data["runs"].append({"i": i, "variant": "no_fsw", "best_F": value,
                             "runtime_seconds": 1.0})
    rows = report.ablation_summary(data)
    assert len(rows) == 1 and rows[0]["variant"] == "no_fsw"
    assert abs(rows[0]["mean_delta_F"] -
               (np.mean(removed) - np.mean(full))) < 1e-12
    assert rows[0]["full_wins"] == 3 and rows[0]["variant_wins"] == 1
    assert 0.0 <= rows[0]["p_holm"] <= 1.0


def _full_data(n=6):
    data = {
        "schema_version": report.SCHEMA_VERSION,
        "model_version": report.model.MODEL_VERSION,
        "config": {"n_p": 50, "max_fes": 25000, "mode": "a2g",
                   "L": 50, "G": 5, "n_runs": n},
        "runs": [],
    }
    for i in range(n):
        metrics = {"TC": 0.8, "SAC": 0.9, "SASU": 9.0, "GASU": 10.0}
        data["runs"].append({"i": i, "algo": "pso", "best_F": 1.0,
                             "final_metrics": dict(metrics)})
        data["runs"].append({"i": i, "algo": "ql", "best_F": 0.0,
                             "final_metrics": dict(metrics)})
    return data


def t_paired_comparison_aligns_by_run_id_and_uses_one_holm_family():
    data = _full_data()
    # Deliberately reverse QL records; pairing by JSON insertion order would be wrong.
    ql = [r for r in data["runs"] if r["algo"] == "ql"]
    pso = [r for r in data["runs"] if r["algo"] == "pso"]
    runs = {"pso": pso, "ql": list(reversed(ql))}
    rows = report.paired_comparison_rows(runs)
    f_row = next(row for row in rows if row["metric"] == "best_F")
    assert f_row["run_ids"] == list(range(6))
    assert f_row["p_raw"] < 0.05
    assert f_row["p_holm"] >= 0.05


def t_four_algorithm_family_has_fifteen_tests():
    data = _v3_full_data(n=6)
    rows = report.paired_comparison_rows(
        data["runs"], algorithms=("pso", "ahdpso", "tadmpso", "ql")
    )
    assert len(rows) == 15
    assert {row["baseline"] for row in rows} == {
        "pso", "ahdpso", "tadmpso"
    }
    assert all(row["run_ids"] == list(range(6)) for row in rows)


def t_time_families_are_separate_by_checkpoint():
    data = _v3_time_data(n=6)
    families = report.time_comparison_families(data)
    assert set(families) == {15.0, 30.0, 60.0}
    assert all(len(rows) == 15 for rows in families.values())
    assert all(
        {row["baseline"] for row in rows} == {
            "pso", "ahdpso", "tadmpso"
        }
        for rows in families.values()
    )


def t_v3_formal_status_requires_complete_four_algorithm_matrix():
    data = _v3_full_data(n=20, formal=True)
    status = report.formal_qualification(data)
    assert status["formal"] is True
    text = report.render_markdown(data, "full_results_heldout_v3.json")
    assert "formal held-out seed result" in text
    assert "T-ADMPSO" in text

    incomplete = json.loads(json.dumps(data))
    incomplete["runs"] = [
        row for row in incomplete["runs"]
        if not (row["i"] == 19 and row["algo"] == "tadmpso")
    ]
    status = report.formal_qualification(incomplete)
    assert status["formal"] is False
    assert any("matrix" in reason for reason in status["reasons"])
    assert "not valid as a formal result" in report.render_markdown(
        incomplete, "full_results_heldout_v3.json"
    )


def t_v3_formal_status_rejects_seed_mismatch():
    data = _v3_full_data(n=20, formal=True)
    data["runs"][0]["seed"] = 999
    status = report.formal_qualification(data)
    assert status["formal"] is False
    assert any("seed" in reason for reason in status["reasons"])


def t_v3_formal_status_rejects_fake_current_source_fingerprint():
    data = _v3_full_data(n=20, formal=True)
    fake = "a" * 64
    if fake == run_exp.optimizer_source_fingerprint():
        fake = "b" * 64
    data["config"]["source_fingerprint"] = fake
    status = report.formal_qualification(data)
    assert status["formal"] is False
    assert any("current source" in reason for reason in status["reasons"])


def t_v3_formal_status_requires_explicit_formal_evidence_type():
    data = _v3_full_data(n=20, formal=True)
    data["config"]["evidence_type"] = "synthetic_qa_v3"
    status = report.formal_qualification(data)
    assert status["formal"] is False
    assert any("evidence type" in reason for reason in status["reasons"])


def t_v3_formal_status_rejects_structurally_incomplete_record():
    data = _v3_full_data(n=20, formal=True)
    data["runs"][0]["gF_history"] = [data["runs"][0]["best_F"]] * 2
    status = report.formal_qualification(data)
    assert status["formal"] is False
    assert any("integrity" in reason for reason in status["reasons"])


def t_v3_sweep_formal_status_requires_all_three_cases():
    for kind in ("area_sweep", "uav_sweep"):
        data = _v3_sweep_data(kind, formal=True)
        assert report.formal_qualification(data)["formal"] is True
        data["runs"].pop()
        status = report.formal_qualification(data)
        assert status["formal"] is False
        assert any("matrix" in reason for reason in status["reasons"])


def t_v3_time_formal_status_requires_registered_order_and_time_limit():
    data = _v3_time_data(n=20, formal=True)
    assert report.formal_qualification(data)["formal"] is True
    data["runs"][0]["order_index"] = data["runs"][1]["order_index"]
    status = report.formal_qualification(data)
    assert status["formal"] is False
    assert any("order" in reason for reason in status["reasons"])
    data = _v3_time_data(n=20, formal=True)
    data["runs"][0]["stop_reason"] = "max_fes_safety"
    assert report.formal_qualification(data)["formal"] is False


def t_time_markdown_dispatches_checkpoint_and_overshoot_sections():
    data = _v3_time_data(n=6)
    text = report.render_markdown(data, "time_budget_heldout_v3.json")
    assert "Fixed time" in text
    assert "15" in text and "30" in text and "60" in text
    assert "overshoot" in text.lower()
    assert "T-ADMPSO" in text


def t_sweep_markdown_keeps_scenario_families_separate():
    data = _v3_sweep_data("area_sweep", n=6, formal=False)
    text = report.render_markdown(data, "area_sweep_heldout_v3.json")
    assert "Area-scale" in text
    assert all(scenario_id in text for scenario_id in ("5km", "7km", "10km"))
    assert text.count("Holm") >= 3


def t_markdown_report_is_persisted_and_marks_overlap_as_provisional():
    data = _full_data()
    with tempfile.TemporaryDirectory() as tmp:
        source = os.path.join(tmp, "full_results_50grid_v2.json")
        with open(source, "w", encoding="utf-8") as stream:
            json.dump(data, stream)
        output = report.write_markdown_report(source, output_dir=tmp)
        assert os.path.exists(output)
        text = open(output, encoding="utf-8").read()
    assert "interim result" in text
    assert "Holm" in text
    assert "full_results_50grid_v2.json" in text


def t_historical_v2_held_out_report_is_never_marked_formal():
    data = _full_data(20)
    data["config"]["seed_protocol"] = report.HELD_OUT_SEED_PROTOCOL
    data["config"]["source_fingerprint"] = "a" * 64
    text = report.render_markdown(data, "full_results_heldout_50grid_v2.json")
    assert "formal held-out seed result" not in text
    assert "historical" in text or "interim result" in text


def t_incomplete_held_out_report_is_not_marked_formal():
    data = _full_data(6)
    data["config"]["seed_protocol"] = report.HELD_OUT_SEED_PROTOCOL
    data["config"]["source_fingerprint"] = "a" * 64
    text = report.render_markdown(data, "full_results_heldout_50grid_v2.json")
    assert "formal held-out seed result" not in text
    assert "historical" in text or "interim result" in text


def t_percentage_metric_effect_is_reported_in_percentage_points():
    shown = report.effect_for_display("TC", 0.073, 0.056, 0.0954)
    assert np.allclose(shown, (7.3, 5.6, 9.54))
    assert report.effect_for_display("best_F", -0.06, -0.08, -0.04) == \
        (-0.06, -0.08, -0.04)


def t_gate_report_is_model_check_not_provisional_formal_result():
    data = _full_data(1)
    text = report.render_markdown(data, "gate_50grid_v2.json")
    assert "model gate" in text
    assert "interim result" not in text


if __name__ == "__main__":
    print("test_report.py")
    for name, fn in sorted(globals().items()):
        if name.startswith("t_") and callable(fn):
            check(name, fn)
    print()
    if _FAILS:
        print(f"{len(_FAILS)} failed/errored")
        sys.exit(1)
    print("all passed")
