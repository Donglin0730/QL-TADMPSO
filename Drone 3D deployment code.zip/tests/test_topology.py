"""Permutation-invariant topology representation, clustering repair and guide alignment tests."""
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from topology import (align_guide, cluster_deployments, direction_pool,
                      fsw_features)
from scenario import DeploymentScenario, ScenarioConfig

_FAILS = []


def check(name, fn):
    try:
        fn()
        print(f"  ok  {name}")
    except Exception as exc:
        _FAILS.append((name, repr(exc)))
        print(f"FAIL  {name}: {type(exc).__name__}: {exc}")


def t_fsw_is_permutation_invariant():
    rng = np.random.default_rng(1)
    x = rng.uniform([0, 0, 100], [5000, 5000, 500], size=(25, 3))
    y = x[rng.permutation(25)]
    phi = fsw_features(np.stack([x, y]), direction_pool(), L=16)
    assert np.allclose(phi[0], phi[1], atol=1e-12)


def t_direction_prefix_is_nested():
    dirs = direction_pool()
    assert dirs.shape == (100, 3)
    assert np.allclose(np.linalg.norm(dirs, axis=1), 1.0)
    x = np.tile(np.array([[1000.0, 2000.0, 300.0]]), (2, 25, 1))
    f5 = fsw_features(x, dirs, L=5).reshape(2, 5, 25)
    f10 = fsw_features(x, dirs, L=10).reshape(2, 10, 25)
    assert np.allclose(f5 * np.sqrt(5 * 25),
                       f10[:, :5] * np.sqrt(10 * 25))


def t_fsw_rejects_invalid_l():
    x = np.zeros((2, 25, 3))
    for bad in (0, 101):
        try:
            fsw_features(x, direction_pool(), L=bad)
        except ValueError:
            pass
        else:
            raise AssertionError(f"L={bad} should fail")


def t_cluster_repair_covers_every_particle_once():
    rng = np.random.default_rng(7)
    x = rng.uniform([0, 0, 100], [5000, 5000, 500], size=(50, 25, 3))
    groups = cluster_deployments(x, 16, np.random.default_rng(8),
                                 direction_pool(), L=10, min_size=3)
    flat = np.concatenate(groups)
    assert len(groups) == 16
    assert all(len(g) >= 3 for g in groups)
    assert sorted(flat.tolist()) == list(range(50))


def t_cluster_rejects_infeasible_k():
    x = np.zeros((8, 25, 3))
    try:
        cluster_deployments(x, 3, np.random.default_rng(0),
                            direction_pool(), L=5, min_size=3)
    except ValueError as exc:
        assert "n >= k * min_size" in str(exc)
    else:
        raise AssertionError("infeasible k must fail")


def t_cluster_is_deterministic_for_seed():
    rng = np.random.default_rng(12)
    x = rng.uniform([0, 0, 100], [5000, 5000, 500], size=(50, 25, 3))
    args = (x, 8, direction_pool(), 16)
    g1 = cluster_deployments(args[0], args[1], np.random.default_rng(9),
                             args[2], args[3])
    g2 = cluster_deployments(args[0], args[1], np.random.default_rng(9),
                             args[2], args[3])
    assert [g.tolist() for g in g1] == [g.tolist() for g in g2]


def t_align_guide_recovers_permutation():
    rng = np.random.default_rng(9)
    ref = rng.uniform([0, 0, 100], [5000, 5000, 500], size=(25, 3))
    guide = ref[rng.permutation(25)]
    aligned = align_guide(ref, guide)
    assert np.allclose(aligned, ref)


def t_align_guide_does_not_mutate():
    ref = np.array([[0.0, 0.0, 100.0], [5000.0, 5000.0, 500.0]])
    guide = ref[::-1].copy()
    before = guide.copy()
    _ = align_guide(ref, guide)
    assert np.array_equal(guide, before)


def t_topology_runtime_smoke():
    rng = np.random.default_rng(99)
    x = rng.uniform([0, 0, 100], [5000, 5000, 500], size=(50, 25, 3))
    t0 = time.perf_counter()
    _ = fsw_features(x, direction_pool(), 100)
    groups = cluster_deployments(x, 16, np.random.default_rng(1),
                                 direction_pool(), 100)
    elapsed = time.perf_counter() - t0
    assert len(groups) == 16 and elapsed < 10.0


def t_fsw_and_alignment_accept_variable_uav_count():
    """Catch topology representation or guide alignment still reshaping to 25 UAVs."""
    deployment = DeploymentScenario(ScenarioConfig(n_uav=10))
    rng = np.random.default_rng(5)
    population = rng.uniform(
        np.tile([0.0, 0.0, 100.0], 10),
        np.tile([5000.0, 5000.0, 500.0], 10),
        size=(6, 30),
    )
    features = fsw_features(
        population, direction_pool(10), 10, scenario=deployment
    )
    assert features.shape == (6, 100)
    aligned = align_guide(
        population[0].reshape(10, 3),
        population[1].reshape(10, 3),
        scenario=deployment,
    )
    assert aligned.shape == (10, 3)
    groups = cluster_deployments(
        population, 2, np.random.default_rng(6), direction_pool(10), 10,
        scenario=deployment,
    )
    assert sorted(np.concatenate(groups).tolist()) == list(range(6))


if __name__ == "__main__":
    print("test_topology.py")
    for name, fn in sorted(globals().items()):
        if name.startswith("t_") and callable(fn):
            check(name, fn)
    print()
    if _FAILS:
        print(f"{len(_FAILS)} failed/errored")
        sys.exit(1)
    print("all passed")
