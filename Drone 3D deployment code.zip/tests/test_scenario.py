"""Scenario configuration and geometry tests. Run: python tests/test_scenario.py"""
import dataclasses
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import scenario
import model


_FAILS = []


def check(name, fn):
    try:
        fn()
        print(f"  ok  {name}")
    except AssertionError as exc:
        _FAILS.append((name, str(exc)))
        print(f"FAIL  {name}: {exc}")
    except Exception as exc:
        _FAILS.append((name, repr(exc)))
        print(f"ERR   {name}: {type(exc).__name__}: {exc}")


def t_default_geometry_and_bounds():
    """Catch the default area, grid centers, UAV dimension or height bounds being changed by mistake."""
    cfg = scenario.ScenarioConfig()
    deployment = scenario.DeploymentScenario(cfg)
    assert cfg.to_dict()["area_m"] == 5000.0
    assert deployment.grid_xy.shape == (2500, 2)
    assert np.allclose(deployment.grid_axis[[0, -1]], [50.0, 4950.0])
    lower, upper = deployment.bounds()
    assert lower.shape == upper.shape == (75,)
    assert np.allclose(lower[:3], [0.0, 0.0, 100.0])
    assert np.allclose(upper[:3], [5000.0, 5000.0, 500.0])


def t_scale_cases_preserve_cell_size_and_priority_count():
    """Catch scale sweeps changing the 100 m resolution or the priority area no longer being exactly 30%."""
    cases = (
        (5000.0, 50, 2500, 750),
        (7000.0, 70, 4900, 1470),
        (10000.0, 100, 10000, 3000),
    )
    for area_m, n_grid, n_points, n_priority in cases:
        deployment = scenario.DeploymentScenario(
            scenario.ScenarioConfig(area_m=area_m, n_grid=n_grid)
        )
        assert deployment.config.cell_size_m == 100.0
        assert deployment.grid_xy.shape == (n_points, 2)
        mask = deployment.priority_mask(23)
        assert mask.shape == (n_points,)
        assert mask.dtype == np.bool_
        assert int(mask.sum()) == n_priority


def t_dynamic_uav_count_controls_bounds_dimension():
    """Catch the search space still being locked to the default 25-UAV, 75-dimension constants."""
    for n_uav, dimension in ((10, 30), (25, 75), (50, 150)):
        deployment = scenario.DeploymentScenario(
            scenario.ScenarioConfig(n_uav=n_uav)
        )
        lower, upper = deployment.bounds()
        assert lower.shape == upper.shape == (dimension,)


def t_invalid_configuration_is_rejected():
    """Catch non-integer priority cell counts, inverted heights and unknown propagation modes being silently accepted."""
    invalid_cases = (
        ({"area_m": 7500.0, "n_grid": 75}, "integer priority-cell count"),
        ({"h_min_m": 500.0, "h_max_m": 100.0}, "h_min_m"),
        ({"propagation_mode": "unknown"}, "propagation_mode"),
        ({"n_uav": 0}, "positive"),
    )
    for kwargs, expected in invalid_cases:
        try:
            scenario.ScenarioConfig(**kwargs)
        except ValueError as exc:
            assert expected in str(exc)
        else:
            raise AssertionError(f"invalid configuration accepted: {kwargs}")


def t_config_round_trip_ignores_derived_cell_size():
    """Catch a serialized derived value overriding the cell size uniquely determined by area/grid."""
    original = scenario.ScenarioConfig(area_m=7000.0, n_grid=70, n_uav=50)
    data = original.to_dict()
    assert data["cell_size_m"] == 100.0
    data["cell_size_m"] = -1.0
    restored = scenario.ScenarioConfig.from_dict(data)
    assert restored == original
    assert restored.cell_size_m == 100.0


def t_config_is_immutable():
    """Catch mutable scenario parameters mixing several geometries into the same results."""
    cfg = scenario.ScenarioConfig()
    try:
        cfg.n_uav = 10
    except dataclasses.FrozenInstanceError:
        pass
    else:
        raise AssertionError("ScenarioConfig is mutable")


def t_priority_mask_is_seed_deterministic():
    """Catch the same priority-area seed failing to reproduce the same scenario."""
    deployment = scenario.DeploymentScenario(scenario.ScenarioConfig())
    first = deployment.priority_mask(41)
    second = deployment.priority_mask(41)
    third = deployment.priority_mask(42)
    assert np.array_equal(first, second)
    assert not np.array_equal(first, third)


def t_prepare_for_evaluation_validates_and_primes_current_priority_mask():
    """The fixed-time protocol explicitly prepares scenario-related compute caches before starting the timer."""
    deployment = scenario.DeploymentScenario(scenario.ScenarioConfig())
    priority = deployment.priority_mask(44)
    deployment.prepare_for_evaluation(priority)
    if scenario._USE_GPU:
        assert deployment._gpu_grid_cache is not None
        assert deployment._gpu_priority_owner is priority
    try:
        deployment.prepare_for_evaluation(priority[:-1])
    except ValueError as exc:
        assert "priority mask" in str(exc)
    else:
        raise AssertionError("invalid priority mask was accepted")


def t_default_scenario_matches_model_wrapper():
    """Catch the compatibility layer and the default v2 scenario using different formulas, grids or backends."""
    priority = model.priority_mask(17)
    position = np.tile([2500.0, 2500.0, 300.0], model.N_UAV)
    direct = scenario.DEFAULT_SCENARIO.evaluate(position, priority, "a2g")
    wrapped = model.evaluate(position, priority, "a2g")
    for key in ("F", "f1", "f2", "f3", "TC", "SAC", "SASU", "GASU"):
        assert np.isclose(direct[key], wrapped[key], rtol=1e-12, atol=1e-12)
    assert np.array_equal(scenario.DEFAULT_SCENARIO.grid_xy, model.GRID_XY)
    assert np.array_equal(scenario.DEFAULT_SCENARIO.priority_mask(17), priority)


def t_variable_uav_evaluation_is_finite():
    """Catch the evaluator still forcing positions to reshape into a fixed 25 UAVs."""
    for n_uav in (10, 25, 50):
        deployment = scenario.DeploymentScenario(
            scenario.ScenarioConfig(n_uav=n_uav)
        )
        position = np.tile([2500.0, 2500.0, 300.0], n_uav)
        metrics = deployment.evaluate(
            position, deployment.priority_mask(3), "a2g"
        )
        assert {
            "F", "f1", "f2", "f3", "TC", "SAC", "SASU", "GASU"
        }.issubset(metrics)
        assert np.isfinite(list(metrics.values())).all()


def t_variable_area_and_grid_evaluation_uses_own_geometry():
    """Catch non-default scenarios still reading the 2500-point default grid from the model module."""
    deployment = scenario.DeploymentScenario(
        scenario.ScenarioConfig(area_m=7000.0, n_grid=70, n_uav=10)
    )
    position = np.tile([3500.0, 3500.0, 300.0], 10)
    snr, covered = deployment.snr_field(position, "los")
    assert snr.shape == covered.shape == (4900,)
    assert np.isfinite(snr).all()
    metrics = deployment.evaluate(position, deployment.priority_mask(9), "los")
    assert 0.0 <= metrics["TC"] <= 1.0
    assert 0.0 <= metrics["SAC"] <= 1.0


def t_point_signal_respects_scenario_frequency():
    """Catch the propagation formula still reading the default 2 GHz constant and ignoring the scenario frequency."""
    point = np.array([[100.0, 0.0]])
    uav = np.array([[0.0, 0.0, 100.0]])
    one_ghz = scenario.DeploymentScenario(
        scenario.ScenarioConfig(frequency_mhz=1000.0, n_uav=1)
    )
    two_ghz = scenario.DeploymentScenario(
        scenario.ScenarioConfig(frequency_mhz=2000.0, n_uav=1)
    )
    signal_1, covered_1 = one_ghz.point_signal_and_coverage(point, uav, "los")
    signal_2, covered_2 = two_ghz.point_signal_and_coverage(point, uav, "los")
    assert covered_1.tolist() == covered_2.tolist() == [True]
    assert np.isclose(signal_1[0] - signal_2[0], 6.020141879623516, atol=1e-9)


if __name__ == "__main__":
    print("test_scenario.py")
    for name, fn in sorted(globals().items()):
        if name.startswith("t_") and callable(fn):
            check(name, fn)
    print()
    if _FAILS:
        print(f"{len(_FAILS)} failed/errored")
        sys.exit(1)
    print("all passed")
