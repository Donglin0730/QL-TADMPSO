from pathlib import Path
import sys
import unittest
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class Sphere:
    def bounds(self):
        return np.full(3, -10.0), np.full(3, 10.0)

    def evaluate(self, x, priority, mode):
        return {"F": float(np.dot(x, x)), "TC": 0.0}


class SupportTests(unittest.TestCase):
    def make(self, max_fes=5):
        try:
            from baseline_support import SearchBudget
        except ImportError:
            self.fail("SearchBudget is not implemented")
        return SearchBudget(np.random.default_rng(3), None, "test", 2, max_fes, Sphere())

    def test_counts_trials_and_keeps_archive_after_worse_trials(self):
        budget = self.make()
        budget.evaluate(np.array([[2., 0, 0], [3., 0, 0]]))
        budget.evaluate_one(np.array([1., 0, 0]))
        budget.evaluate(np.array([[4., 0, 0], [5., 0, 0]]))
        result = budget.result(2)
        self.assertEqual(result["fes"], 5)
        self.assertEqual(result["best_F"], 1)
        self.assertEqual(result["history_fes"], [2, 3, 5])
        self.assertEqual(result["gF_history"], [4., 1., 1.])
        self.assertEqual(budget.remaining, 0)

    def test_rejects_overrun_before_any_new_call(self):
        budget = self.make(2)
        budget.evaluate(np.ones((2, 3)))
        with self.assertRaises(RuntimeError):
            budget.evaluate_one(np.zeros(3))
        self.assertEqual(budget.result(0)["fes"], 2)

    def test_rejects_unbounded_candidate(self):
        budget = self.make()
        with self.assertRaises(ValueError):
            budget.evaluate_one(np.array([11., 0, 0]))


if __name__ == "__main__":
    unittest.main()
