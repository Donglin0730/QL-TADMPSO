"""Versioned experiment entry point and paired seed protocol tests."""
import json
import os
import sys
import tempfile

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import run_exp
from scenario import ScenarioConfig

_FAILS = []


def _v3_config(n_uav=25, stop_protocol=None):
    return {
        "scenario": ScenarioConfig(n_uav=n_uav).to_dict(),
        "algorithms": ["ql"],
        "seed_protocol": run_exp.HELD_OUT_SEED_PROTOCOL,
        "n_runs": 1,
        "max_fes": 25000,
        "n_p": 50,
        "mode": "a2g",
        "L": 50,
        "G": 5,
        "source_fingerprint": run_exp.optimizer_source_fingerprint(),
        "evidence_type": "formal_held_out_v3",
        "formal_qualification": True,
        "stop_protocol": (
            {"kind": "fixed_fes", "max_fes": 25000}
            if stop_protocol is None else stop_protocol
        ),
    }


def _valid_position(n_uav=25, area_m=5000.0, height_m=200.0):
    return np.tile([area_m / 2.0, area_m / 2.0, height_m], n_uav).tolist()


def _valid_record(best_pos, fes=25000, n_p=50):
    history_points = int(fes) // int(n_p)
    return {
        "i": 0,
        "scenario_id": "default",
        "scenario": ScenarioConfig().to_dict(),
        "algo": "ql",
        "seed": 3000,
        "priority_seed": 300,
        "best_F": 0.2,
        "gF_history": [0.2] * history_points,
        "final_metrics": {
            "F": 0.2,
            "TC": 0.9,
            "SAC": 0.92,
            "SASU": 7.0,
            "GASU": 8.0,
        },
        "best_pos": best_pos,
        "fes": int(fes),
        "n_updates": history_points - 1,
        "runtime_seconds": 1.0,
    }


def _assert_raises_contains(fn, expected):
    try:
        fn()
    except ValueError as exc:
        assert expected in str(exc)
    else:
        raise AssertionError(f"expected ValueError containing {expected!r}")


def check(name, fn):
    try:
        fn()
        print(f"  ok  {name}")
    except Exception as exc:
        _FAILS.append((name, repr(exc)))
        print(f"FAIL  {name}: {type(exc).__name__}: {exc}")


def t_main_config_has_strict_budget():
    assert run_exp.MAIN_CONFIG["n_p"] == 50
    assert run_exp.MAIN_CONFIG["max_fes"] == 25000
    assert "T" not in run_exp.MAIN_CONFIG


def t_v2_schema_and_output_names():
    expected = "uav-bs-a2g-ahdpso-50grid-v2"
    assert run_exp.SCHEMA_VERSION == expected
    assert run_exp.model.MODEL_VERSION == expected
    legacy = ("gate", "smoke", "l_repr", "l_opt", "g_sensitivity",
              "full", "ablation")
    assert all("50grid_v2" in run_exp.OUTPUT_FILES[key] for key in legacy)


def t_run_record_uses_priority_seed_only():
    result = {
        "best_F": 0.2,
        "gF_history": [0.3, 0.2],
        "final_metrics": {"F": 0.2},
        "best_pos": np.zeros(75),
        "fes": 100,
        "n_updates": 1,
        "runtime_seconds": 0.1,
    }
    row = run_exp._run_record(0, "pso", 1000, 100, result)
    assert row["priority_seed"] == 100
    assert "area_seed" not in row


def t_resume_rejects_old_schema():
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "old.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"config": {"n_p": 50, "T": 300}, "runs": []}, f)
        try:
            run_exp.load_or_initialize(path, run_exp.MAIN_CONFIG)
        except ValueError as exc:
            assert "schema_version" in str(exc)
        else:
            raise AssertionError("old results must not be resumed")


def t_resume_accepts_exact_current_config():
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "new.json")
        first = run_exp.load_or_initialize(path, run_exp.MAIN_CONFIG)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(first, f)
        second = run_exp.load_or_initialize(path, dict(run_exp.MAIN_CONFIG))
        assert second == first


def t_resume_rejects_incomplete_current_record():
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "broken.json")
        data = {
            "schema_version": run_exp.SCHEMA_VERSION,
            "model_version": run_exp.model.MODEL_VERSION,
            "config": dict(run_exp.MAIN_CONFIG),
            "runs": [{"i": 0, "algo": "pso"}],
        }
        with open(path, "w", encoding="utf-8") as stream:
            json.dump(data, stream)
        try:
            run_exp.load_or_initialize(path, run_exp.MAIN_CONFIG)
        except ValueError as exc:
            assert "record" in str(exc)
        else:
            raise AssertionError("incomplete resumed record must fail")


def t_paired_seed_protocol():
    assert run_exp.PRIORITY_SEED_BASE == 100
    assert not hasattr(run_exp, "AREA_SEED_BASE")
    assert run_exp.paired_seeds(0) == (1000, 100)
    assert run_exp.paired_seeds(7) == (1007, 107)
    assert run_exp.L_VALUES == [5, 10, 16, 32, 50, 100]
    assert run_exp.G_VALUES == [5, 10, 15, 25]


def t_final_seed_protocol_is_disjoint_from_selection():
    selection = {run_exp.paired_seeds(i) for i in range(20)}
    held_out = {
        run_exp.paired_seeds(i, run_exp.HELD_OUT_SEED_PROTOCOL)
        for i in range(20)
    }
    assert selection.isdisjoint(held_out)
    assert run_exp.paired_seeds(0, run_exp.HELD_OUT_SEED_PROTOCOL) == (3000, 300)
    assert run_exp.paired_seeds(19, run_exp.HELD_OUT_SEED_PROTOCOL) == (3019, 319)


def t_final_tasks_use_new_non_overwriting_output_files():
    assert run_exp.OUTPUT_FILES["full_final"] == "full_results_heldout_v3.json"
    assert run_exp.OUTPUT_FILES["ablation_final"] == "ablation_heldout_v3.json"
    assert run_exp.OUTPUT_FILES["full"] != run_exp.OUTPUT_FILES["full_final"]
    assert run_exp.OUTPUT_FILES["ablation"] != \
        run_exp.OUTPUT_FILES["ablation_final"]


def t_v3_schema_and_output_names_are_explicit():
    """Catch v3 formal tasks reusing v2 version numbers or overwriting historical files."""
    assert run_exp.V3_SCHEMA_VERSION == "uav-bs-experiment-results-v3"
    assert run_exp.V3_MODEL_VERSION == "uav-bs-a2g-ahdpso-scenario-v3"
    assert run_exp.OUTPUT_FILES["area_sweep_final"] == \
        "area_sweep_heldout_v3.json"
    assert run_exp.OUTPUT_FILES["uav_sweep_final"] == \
        "uav_sweep_heldout_v3.json"
    assert run_exp.OUTPUT_FILES["time_final"] == "time_budget_heldout_v3.json"
    assert run_exp.OUTPUT_FILES["protocol_smoke"] == "protocol_smoke_v3.json"


def t_record_length_comes_from_scenario_not_default_model():
    """Catch v3 record validation still pinning every deployment to 75 dimensions."""
    config = _v3_config(n_uav=10)
    record = _valid_record(best_pos=_valid_position(10))
    record["scenario"] = ScenarioConfig(n_uav=10).to_dict()
    run_exp._validate_v3_run_record(record, config)
    record["best_pos"].append(0.0)
    _assert_raises_contains(
        lambda: run_exp._validate_v3_run_record(record, config),
        "best_pos length mismatch",
    )


def t_v3_timed_record_uses_safety_ceiling_not_fixed_fes():
    """Catch timed records wrongly rejected by fixed-FE validation, or allowed past the safety ceiling."""
    stop = {
        "kind": "fixed_time",
        "limit_seconds": 60.0,
        "checkpoints_seconds": [15.0, 30.0, 60.0],
        "max_fes_safety": 5000000,
    }
    config = _v3_config(stop_protocol=stop)
    record = _valid_record(best_pos=_valid_position(), fes=1250)
    record.update(
        runtime_seconds=60.2,
        order_seed=9000,
        order_index=run_exp.algorithm_order(0).index("ql"),
        checkpoints=[
            {"target_seconds": value, "actual_seconds": value + 0.1,
             "fes": 50 + 400 * index, "best_F": 0.2,
             "final_metrics": dict(record["final_metrics"]),
             "best_pos": list(record["best_pos"])}
            for index, value in enumerate((15.0, 30.0, 60.0))
        ],
        stop_reason="time_limit",
        overshoot_seconds=0.1,
        actual_seconds=60.1,
    )
    run_exp._validate_v3_run_record(record, config)
    record["fes"] = 5000050
    _assert_raises_contains(
        lambda: run_exp._validate_v3_run_record(record, config),
        "safety ceiling",
    )


def t_v3_fixed_fes_record_rejects_truncated_history():
    """Whole generations, FEs and history length must be mutually consistent."""
    record = _valid_record(_valid_position())
    record["gF_history"] = [0.2, 0.2]
    _assert_raises_contains(
        lambda: run_exp._validate_v3_run_record(record, _v3_config()),
        "history length",
    )


def t_v3_timed_record_rejects_nonmonotone_checkpoint_evidence():
    stop = {
        "kind": "fixed_time",
        "limit_seconds": 60.0,
        "checkpoints_seconds": [15.0, 30.0, 60.0],
        "max_fes_safety": 5000000,
    }
    config = _v3_config(stop_protocol=stop)
    record = _valid_record(_valid_position(), fes=1250)
    record.update(
        runtime_seconds=60.2,
        order_seed=9000,
        order_index=run_exp.algorithm_order(0).index("ql"),
        checkpoints=[
            {
                "target_seconds": target,
                "actual_seconds": target + 0.1,
                "fes": fes,
                "best_F": value,
                "final_metrics": {
                    "F": value, "TC": 0.9, "SAC": 0.92,
                    "SASU": 7.0, "GASU": 8.0,
                },
                "best_pos": list(record["best_pos"]),
            }
            for target, fes, value in (
                (15.0, 50, 0.2),
                (30.0, 450, 0.25),
                (60.0, 850, 0.2),
            )
        ],
        stop_reason="time_limit",
        overshoot_seconds=0.1,
        actual_seconds=60.1,
    )
    _assert_raises_contains(
        lambda: run_exp._validate_v3_run_record(record, config),
        "checkpoint best_F",
    )


def t_v3_root_requires_complete_reproducibility_config():
    """Catch v3 root records missing scenario, algorithms, seeds, stop protocol or source fingerprint."""
    config = _v3_config()
    config.update(
        algorithms=["pso", "ahdpso", "tadmpso", "ql"],
        seed_protocol="held_out_v1",
        n_runs=20,
        source_fingerprint="a" * 64,
        evidence_type="formal_held_out_v3",
        formal_qualification=True,
    )
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "v3.json")
        root = run_exp.load_or_initialize_v3(path, "full", config)
    assert root == {
        "schema_version": run_exp.V3_SCHEMA_VERSION,
        "model_version": run_exp.V3_MODEL_VERSION,
        "result_kind": "full",
        "config": run_exp._normalized(config),
        "runs": [],
    }
    bad = dict(config)
    bad.pop("source_fingerprint")
    _assert_raises_contains(
        lambda: run_exp.load_or_initialize_v3("unused.json", "full", bad),
        "source_fingerprint",
    )


def t_v3_resume_rejects_duplicate_keys_and_wrong_seeds():
    config = run_exp._v3_formal_config(
        "full", ("ql",), n_runs=1, L=50, G=5,
        stop_protocol={"kind": "fixed_fes", "max_fes": 100},
    )
    record = _valid_record(_valid_position(), fes=100)
    root = {
        "schema_version": run_exp.V3_SCHEMA_VERSION,
        "model_version": run_exp.V3_MODEL_VERSION,
        "result_kind": "full",
        "config": run_exp._normalized(config),
        "runs": [record, dict(record)],
    }
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "duplicate.json")
        with open(path, "w", encoding="utf-8") as stream:
            json.dump(root, stream)
        _assert_raises_contains(
            lambda: run_exp.load_or_initialize_v3(path, "full", config),
            "duplicate",
        )
        root["runs"] = [dict(record, seed=9999)]
        with open(path, "w", encoding="utf-8") as stream:
            json.dump(root, stream)
        _assert_raises_contains(
            lambda: run_exp.load_or_initialize_v3(path, "full", config),
            "seed",
        )


def t_v3_fingerprint_covers_scenario_and_timing_sources():
    assert "scenario.py" in run_exp.OPTIMIZER_SOURCE_FILES
    assert "timing.py" in run_exp.OPTIMIZER_SOURCE_FILES
    deployment = run_exp.scenario_from_config(_v3_config(n_uav=10))
    assert deployment.config.n_uav == 10


def t_legacy_selection_bridge_reads_only_valid_v2_evidence():
    """The legacy reader must not depend on retained scientific result files."""
    old_out = run_exp.OUT_DIR
    try:
        with tempfile.TemporaryDirectory() as tmp:
            run_exp.OUT_DIR = tmp
            for parameter, task, candidates, fixed in (
                ("L", "l_opt", [50, 100], {"G": 15}),
                ("G", "g_sensitivity", [5, 10, 15, 25], {"L": 50}),
            ):
                runs = []
                for i in range(10):
                    seed, priority_seed = run_exp.paired_seeds(i)
                    for value in candidates:
                        row = _valid_record(_valid_position())
                        row.update(i=i, seed=seed, priority_seed=priority_seed,
                                   best_F=0.25, gF_history=[0.25] * 500,
                                   **{parameter: value})
                        row["final_metrics"]["F"] = 0.25
                        runs.append(row)
                data = {
                    "schema_version": run_exp.SCHEMA_VERSION,
                    "model_version": run_exp.model.MODEL_VERSION,
                    "config": dict(run_exp.MAIN_CONFIG, n_runs=10,
                                   **fixed, **{"candidate_" + parameter: candidates}),
                    "runs": runs,
                    "summary": [{parameter: value, "mean_F": 0.25, "std_F": 0.,
                                 "se_F": 0., "runtime_seconds_mean": 1.}
                                for value in candidates],
                    "one_se_limit": 0.25,
                    "recommended_" + parameter: candidates[0],
                }
                path = os.path.join(tmp, run_exp.OUTPUT_FILES[task])
                with open(path, "w", encoding="utf-8") as stream:
                    json.dump(data, stream)
            assert run_exp._legacy_recommended_l() == 50
            assert run_exp._legacy_recommended_g() == 5
            data["runs"].pop()
            with open(path, "w", encoding="utf-8") as stream:
                json.dump(data, stream)
            _assert_raises_contains(run_exp._legacy_recommended_g, "incomplete")
    finally:
        run_exp.OUT_DIR = old_out


def t_formal_comparison_has_four_algorithms():
    """Catch the formal comparison dropping the paper's parent algorithm T-ADMPSO."""
    assert run_exp.FORMAL_ALGORITHMS == (
        "pso", "ahdpso", "tadmpso", "ql"
    )


def t_ablation_has_factor_schedule_control():
    """Catch an ablation matrix that cannot compare Q-learning and the parent factor schedule separately."""
    variants = dict(
        (name, kwargs) for _, name, kwargs in run_exp.ABLATION_VARIANTS
    )
    assert len(variants) == 7
    assert "factor_schedule" in variants
    assert variants["factor_schedule"]["use_q_learning"] is False
    assert variants["factor_schedule"]["schedule_label"] == "factorization"


def t_area_cases_have_exact_priority_counts():
    assert run_exp.AREA_CASES == (
        ("5km", 5000.0, 50),
        ("7km", 7000.0, 70),
        ("10km", 10000.0, 100),
    )
    assert [
        int(0.3 * grid * grid) for _, _, grid in run_exp.AREA_CASES
    ] == [750, 1470, 3000]


def t_uav_cases_are_exact_and_keep_default_area():
    assert run_exp.UAV_CASES == (
        ("10uav", 10), ("25uav", 25), ("50uav", 50)
    )


def t_sweep_completion_key_includes_scenario():
    run = {"i": 2, "scenario_id": "7km", "algo": "ql"}
    assert run_exp._run_key(run) == (2, "7km", "ql", None)


def t_v3_case_registry_controls_record_dimension():
    """Catch sweep experiments still pinning records to the root default scenario's 75 dimensions."""
    default = ScenarioConfig().to_dict()
    ten_uav = ScenarioConfig(n_uav=10).to_dict()
    config = _v3_config()
    config.update(
        algorithms=list(run_exp.FORMAL_ALGORITHMS),
        seed_protocol="robustness_v1",
        n_runs=1,
        source_fingerprint="b" * 64,
        case_registry=[{"scenario_id": "10uav", "scenario": ten_uav}],
    )
    assert config["scenario"] == default
    record = _valid_record(best_pos=_valid_position(10))
    record.update(
        scenario_id="10uav", scenario=ten_uav,
        seed=5000, priority_seed=500,
    )
    run_exp._validate_v3_run_record(record, config)


def t_public_sweeps_lock_formal_matrix_and_build_all_cases():
    assert hasattr(run_exp, "cmd_area_sweep_final")
    assert hasattr(run_exp, "cmd_uav_sweep_final")
    original = (
        run_exp._legacy_recommended_l,
        run_exp._legacy_recommended_g,
        run_exp._cmd_sweep,
    )
    captured = []
    try:
        run_exp._legacy_recommended_l = lambda: 50
        run_exp._legacy_recommended_g = lambda: 5
        run_exp._cmd_sweep = lambda *args, **kwargs: (
            captured.append((args, kwargs)) or {}
        )
        run_exp.cmd_area_sweep_final(20)
        run_exp.cmd_uav_sweep_final(20)
        for command in (
            run_exp.cmd_area_sweep_final, run_exp.cmd_uav_sweep_final
        ):
            _assert_raises_contains(lambda command=command: command(1), "final")
    finally:
        run_exp._legacy_recommended_l = original[0]
        run_exp._legacy_recommended_g = original[1]
        run_exp._cmd_sweep = original[2]
    assert [call[0][1] for call in captured] == [
        "area_sweep", "uav_sweep"
    ]
    assert all(len(call[0][2]) == 3 for call in captured)
    assert all(call[1]["max_fes"] == 25000 for call in captured)


def t_internal_sweep_persists_dynamic_dimensions_and_resumes():
    assert hasattr(run_exp, "_cmd_sweep")
    old_out = run_exp.OUT_DIR
    original_run_one = run_exp._run_one
    registry = [
        {"scenario_id": "10uav", "scenario": ScenarioConfig(n_uav=10).to_dict()},
        {"scenario_id": "50uav", "scenario": ScenarioConfig(n_uav=50).to_dict()},
    ]
    try:
        def fake_run_one(algo, seed, priority, config, scenario=None):
            n_dim = scenario.config.n_uav * 3
            return {
                "best_F": 0.2,
                "gF_history": [0.3, 0.2],
                "final_metrics": {
                    "F": 0.2, "TC": 0.9, "SAC": 0.92,
                    "SASU": 7.0, "GASU": 8.0,
                },
                "best_pos": _valid_position(
                    scenario.config.n_uav, scenario.config.area_m
                ),
                "fes": 100,
                "n_updates": 1,
                "runtime_seconds": 0.01,
            }

        run_exp._run_one = fake_run_one
        with tempfile.TemporaryDirectory() as tmp:
            run_exp.OUT_DIR = tmp
            first = run_exp._cmd_sweep(
                "uav_sweep_final", "uav_sweep", registry, 1,
                L=50, G=5, max_fes=100,
            )
            second = run_exp._cmd_sweep(
                "uav_sweep_final", "uav_sweep", registry, 1,
                L=50, G=5, max_fes=100,
            )
    finally:
        run_exp._run_one = original_run_one
        run_exp.OUT_DIR = old_out
    assert len(first["runs"]) == len(second["runs"]) == 8
    assert {(row["seed"], row["priority_seed"]) for row in first["runs"]} == {
        (5000, 500)
    }
    lengths = {
        scenario_id: {len(row["best_pos"]) for row in first["runs"]
                      if row["scenario_id"] == scenario_id}
        for scenario_id in ("10uav", "50uav")
    }
    assert lengths == {"10uav": {30}, "50uav": {150}}


def t_time_order_is_permutation_and_deterministic():
    first = run_exp.algorithm_order(0)
    assert tuple(sorted(first)) == tuple(sorted(run_exp.FORMAL_ALGORITHMS))
    assert first == run_exp.algorithm_order(0)
    assert any(run_exp.algorithm_order(i) != first for i in range(1, 10))


def t_run_one_converts_timed_config_to_time_protocol():
    called = {}
    original = run_exp.algorithms.run_standard_pso
    try:
        def fake(rng, priority, mode, **kwargs):
            called.update(kwargs)
            return {
                "best_F": 0.2,
                "gF_history": [0.3, 0.2],
                "final_metrics": {
                    "F": 0.2, "TC": 0.9, "SAC": 0.92,
                    "SASU": 7.0, "GASU": 8.0,
                },
                "best_pos": np.zeros(75), "fes": 100,
                "n_updates": 1, "checkpoints": [],
                "stop_reason": "max_fes_safety",
                "overshoot_seconds": 0.0, "actual_seconds": 0.01,
            }

        run_exp.algorithms.run_standard_pso = fake
        stop = {
            "kind": "fixed_time", "limit_seconds": 60.0,
            "checkpoints_seconds": [15.0, 30.0, 60.0],
            "max_fes_safety": 100,
        }
        config = _v3_config(stop_protocol=stop)
        config.update(mode="a2g", max_fes=100)
        run_exp._run_one(
            "pso", 7, run_exp.model.priority_mask(9), config
        )
    finally:
        run_exp.algorithms.run_standard_pso = original
    assert isinstance(called["time_protocol"], run_exp.TimeProtocol)
    assert called["time_protocol"].checkpoints_seconds == (15.0, 30.0, 60.0)
    assert called["max_fes"] == 100


def t_time_final_locks_formal_budget_and_metadata():
    assert hasattr(run_exp, "cmd_time_final")
    original = (
        run_exp._legacy_recommended_l,
        run_exp._legacy_recommended_g,
        run_exp._warmup_algorithms,
        run_exp._cmd_time,
    )
    captured = {}
    try:
        run_exp._legacy_recommended_l = lambda: 50
        run_exp._legacy_recommended_g = lambda: 5
        run_exp._warmup_algorithms = lambda *args, **kwargs: None
        run_exp._cmd_time = lambda config, n_runs: (
            captured.update(config=config, n_runs=n_runs) or {}
        )
        run_exp.cmd_time_final(20, 60.0)
        _assert_raises_contains(lambda: run_exp.cmd_time_final(1, 60.0), "final")
        _assert_raises_contains(lambda: run_exp.cmd_time_final(20, 1.0), "60")
    finally:
        run_exp._legacy_recommended_l = original[0]
        run_exp._legacy_recommended_g = original[1]
        run_exp._warmup_algorithms = original[2]
        run_exp._cmd_time = original[3]
    config = captured["config"]
    assert captured["n_runs"] == 20
    assert config["timing_protocol"] == "time_normalized_v1"
    assert config["warmup_completed"] is True
    assert config["order_seed_base"] == 9000
    assert config["stop_protocol"] == {
        "kind": "fixed_time",
        "limit_seconds": 60.0,
        "checkpoints_seconds": [15.0, 30.0, 60.0],
        "max_fes_safety": 5000000,
    }
    assert config["hardware"] == run_exp.hardware_fingerprint()


def t_v3_resume_rejects_hardware_mismatch_explicitly():
    config = _v3_config()
    config.update(
        algorithms=list(run_exp.FORMAL_ALGORITHMS),
        seed_protocol="time_v1", n_runs=20,
        source_fingerprint="c" * 64,
        evidence_type="formal_held_out_v3",
        formal_qualification=True,
        hardware={"device": "machine-a"},
    )
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "timed.json")
        root = run_exp.load_or_initialize_v3(path, "time_budget", config)
        with open(path, "w", encoding="utf-8") as stream:
            json.dump(root, stream)
        changed = dict(config, hardware={"device": "machine-b"})
        _assert_raises_contains(
            lambda: run_exp.load_or_initialize_v3(
                path, "time_budget", changed
            ),
            "hardware mismatch",
        )


def t_internal_timed_runner_uses_randomized_order_and_resumes():
    old_out = run_exp.OUT_DIR
    original_run_one = run_exp._run_one
    original_scenario_from_config = run_exp.scenario_from_config
    stop = {
        "kind": "fixed_time", "limit_seconds": 0.05,
        "checkpoints_seconds": [0.01, 0.025, 0.05],
        "max_fes_safety": 100,
    }
    config = run_exp._v3_formal_config(
        "time_budget", run_exp.FORMAL_ALGORITHMS, n_runs=1,
        L=50, G=5, seed_protocol=run_exp.TIME_SEED_PROTOCOL,
        stop_protocol=stop, timing_protocol="time_normalized_v1",
        hardware={"device": "test-device"}, order_seed_base=9000,
        warmup_completed=True,
    )
    created_scenarios = []

    class PreparedScenario:
        def __init__(self):
            self.config = ScenarioConfig()
            self.prepared = False
            created_scenarios.append(self)

        def priority_mask(self, seed):
            return np.zeros(self.config.n_grid ** 2, dtype=bool)

        def prepare_for_evaluation(self, priority):
            assert priority.shape == (self.config.n_grid ** 2,)
            self.prepared = True

    try:
        def fake_run_one(algo, seed, priority, config, scenario=None):
            assert scenario.prepared, "timed scenario cache was not prepared"
            metrics = {
                "F": 0.2, "TC": 0.9, "SAC": 0.92,
                "SASU": 7.0, "GASU": 8.0,
            }
            return {
                "best_F": 0.2, "gF_history": [0.3, 0.2],
                "final_metrics": metrics,
                "best_pos": _valid_position(), "fes": 100,
                "n_updates": 1, "runtime_seconds": 0.051,
                "checkpoints": [
                    {
                        "target_seconds": target,
                        "actual_seconds": 0.051,
                        "fes": 100,
                        "best_F": 0.2,
                        "final_metrics": dict(metrics),
                        "best_pos": _valid_position(),
                    }
                    for target in (0.01, 0.025, 0.05)
                ],
                "stop_reason": "time_limit",
                "overshoot_seconds": 0.001,
                "actual_seconds": 0.051,
            }

        run_exp._run_one = fake_run_one
        run_exp.scenario_from_config = lambda config: PreparedScenario()
        with tempfile.TemporaryDirectory() as tmp:
            run_exp.OUT_DIR = tmp
            first = run_exp._cmd_time(config, 1)
            second = run_exp._cmd_time(config, 1)
    finally:
        run_exp._run_one = original_run_one
        run_exp.scenario_from_config = original_scenario_from_config
        run_exp.OUT_DIR = old_out
    assert len(first["runs"]) == len(second["runs"]) == 4
    persisted_order = tuple(
        row["algo"] for row in sorted(
            first["runs"], key=lambda row: row["order_index"]
        )
    )
    assert persisted_order == run_exp.algorithm_order(0)
    assert {row["order_seed"] for row in first["runs"]} == {9000}
    assert len({id(scenario) for scenario in created_scenarios[:4]}) == 4


def t_protocol_smoke_is_explicitly_nonformal_and_separate():
    assert hasattr(run_exp, "cmd_protocol_smoke")
    original = (
        run_exp._legacy_recommended_l,
        run_exp._legacy_recommended_g,
        run_exp._warmup_algorithms,
        run_exp._cmd_protocol_smoke,
    )
    captured = {}
    try:
        run_exp._legacy_recommended_l = lambda: 50
        run_exp._legacy_recommended_g = lambda: 5
        run_exp._warmup_algorithms = lambda *args, **kwargs: None
        run_exp._cmd_protocol_smoke = lambda config: (
            captured.update(config=config) or {}
        )
        run_exp.cmd_protocol_smoke()
    finally:
        run_exp._legacy_recommended_l = original[0]
        run_exp._legacy_recommended_g = original[1]
        run_exp._warmup_algorithms = original[2]
        run_exp._cmd_protocol_smoke = original[3]
    config = captured["config"]
    assert config["seed_protocol"] == run_exp.SMOKE_SEED_PROTOCOL
    assert config["formal_qualification"] is False
    assert config["evidence_type"] == "protocol_smoke_v3"
    assert config["stop_protocol"]["kind"] == "protocol_smoke"
    assert len(config["case_registry"]) == 8
    assert run_exp.OUTPUT_FILES["protocol_smoke"] not in {
        run_exp.OUTPUT_FILES["full_final"],
        run_exp.OUTPUT_FILES["area_sweep_final"],
        run_exp.OUTPUT_FILES["uav_sweep_final"],
        run_exp.OUTPUT_FILES["time_final"],
    }


def t_internal_protocol_smoke_covers_every_registered_path_and_resumes():
    old_out = run_exp.OUT_DIR
    original_run_one = run_exp._run_one
    timed = {
        "limit_seconds": 0.05,
        "checkpoints_seconds": [0.0125, 0.025, 0.05],
        "max_fes_safety": 100,
    }
    config = run_exp._v3_formal_config(
        "protocol_smoke", run_exp.FORMAL_ALGORITHMS, n_runs=1,
        L=50, G=5, seed_protocol=run_exp.SMOKE_SEED_PROTOCOL,
        stop_protocol={
            "kind": "protocol_smoke", "fixed_fes": 100,
            "fixed_time": timed,
        },
        case_registry=run_exp._smoke_case_registry(),
        variants=["factor_schedule"], formal_qualification=False,
        evidence_type="protocol_smoke_v3",
        hardware={"device": "test-device"}, warmup_completed=True,
        timing_protocol="time_normalized_v1-smoke", order_seed_base=9000,
        expected_record_count=33,
    )
    try:
        def fake_run_one(algo, seed, priority, local, scenario=None):
            metrics = {
                "F": 0.2, "TC": 0.9, "SAC": 0.92,
                "SASU": 7.0, "GASU": 8.0,
            }
            result = {
                "best_F": 0.2, "gF_history": [0.3, 0.2],
                "final_metrics": metrics,
                "best_pos": _valid_position(
                    scenario.config.n_uav, scenario.config.area_m
                ),
                "fes": 100, "n_updates": 1,
                "runtime_seconds": 0.001,
            }
            if local["stop_protocol"]["kind"] == "fixed_time":
                result.update(
                    checkpoints=[{
                        "target_seconds": target,
                        "actual_seconds": 0.051,
                        "fes": 100,
                        "best_F": 0.2,
                        "final_metrics": dict(metrics),
                        "best_pos": _valid_position(
                            scenario.config.n_uav, scenario.config.area_m
                        ),
                    } for target in (0.0125, 0.025, 0.05)],
                    stop_reason="time_limit",
                    overshoot_seconds=0.001,
                    actual_seconds=0.051,
                    runtime_seconds=0.052,
                )
            return result

        run_exp._run_one = fake_run_one
        with tempfile.TemporaryDirectory() as tmp:
            run_exp.OUT_DIR = tmp
            first = run_exp._cmd_protocol_smoke(config)
            second = run_exp._cmd_protocol_smoke(config)
    finally:
        run_exp._run_one = original_run_one
        run_exp.OUT_DIR = old_out
    assert len(first["runs"]) == len(second["runs"]) == 33
    assert {row["suite"] for row in first["runs"]} == {
        "comparison", "factor_control", "area_sweep",
        "uav_sweep", "time_budget",
    }
    assert sum(row["protocol_kind"] == "fixed_time"
               for row in first["runs"]) == 4
    assert sum(row.get("variant") == "factor_schedule"
               for row in first["runs"]) == 1


def t_optimizer_source_fingerprint_is_sha256():
    fingerprint = run_exp.optimizer_source_fingerprint()
    assert len(fingerprint) == 64
    assert all(char in "0123456789abcdef" for char in fingerprint)


def t_full_final_records_held_out_protocol_and_source_fingerprint():
    assert hasattr(run_exp, "_v3_algorithm_runs")
    original = (
        run_exp._legacy_recommended_l,
        run_exp._legacy_recommended_g,
        getattr(run_exp, "_v3_algorithm_runs", None),
    )
    captured = {}
    try:
        run_exp._legacy_recommended_l = lambda: 50
        run_exp._legacy_recommended_g = lambda: 5
        run_exp._v3_algorithm_runs = (
            lambda task, result_kind, algos, config, n_runs, **kwargs:
            captured.update(
                task=task, result_kind=result_kind, algos=algos,
                config=config, kwargs=kwargs,
            ) or {}
        )
        run_exp.cmd_full_final(n_runs=20)
    finally:
        run_exp._legacy_recommended_l = original[0]
        run_exp._legacy_recommended_g = original[1]
        if original[2] is None:
            del run_exp._v3_algorithm_runs
        else:
            run_exp._v3_algorithm_runs = original[2]
    assert captured["task"] == "full_final"
    assert captured["result_kind"] == "full"
    assert tuple(captured["algos"]) == run_exp.FORMAL_ALGORITHMS
    assert captured["config"]["seed_protocol"] == \
        run_exp.HELD_OUT_SEED_PROTOCOL
    assert captured["config"]["stop_protocol"] == {
        "kind": "fixed_fes", "max_fes": 25000,
    }
    assert captured["config"]["source_fingerprint"] == \
        run_exp.optimizer_source_fingerprint()


def t_final_tasks_reject_short_run_count_and_budget_override():
    original = (
        run_exp._legacy_recommended_l,
        run_exp._legacy_recommended_g,
        getattr(run_exp, "_v3_algorithm_runs", None),
    )
    try:
        run_exp._legacy_recommended_l = lambda: 50
        run_exp._legacy_recommended_g = lambda: 5
        run_exp._v3_algorithm_runs = lambda *args, **kwargs: {}
        for kwargs in ({"n_runs": 1}, {"max_fes": 500},
                       {"L": 100}, {"G": 10}):
            try:
                run_exp.cmd_full_final(**kwargs)
            except ValueError as exc:
                assert "final" in str(exc)
            else:
                raise AssertionError(f"invalid final args accepted: {kwargs}")
    finally:
        run_exp._legacy_recommended_l = original[0]
        run_exp._legacy_recommended_g = original[1]
        if original[2] is None:
            del run_exp._v3_algorithm_runs
        else:
            run_exp._v3_algorithm_runs = original[2]


def t_run_one_dispatches_tadmpso_with_nondefault_scenario():
    """Catch the runner losing the scenario injection when calling the parent algorithm."""
    called = {}
    original = run_exp.algorithms.run_tadmpso
    try:
        def fake(rng, priority, mode, **kwargs):
            called.update(mode=mode, kwargs=kwargs, priority=priority.copy())
            return {
                "best_F": 0.2,
                "gF_history": [0.3, 0.2],
                "final_metrics": {
                    "F": 0.2, "TC": 0.9, "SAC": 0.92,
                    "SASU": 7.0, "GASU": 8.0,
                },
                "best_pos": np.zeros(30),
                "fes": 100,
                "n_updates": 1,
            }

        run_exp.algorithms.run_tadmpso = fake
        config = _v3_config(n_uav=10)
        config.update(mode="a2g", n_p=50, max_fes=100)
        scenario = run_exp.scenario_from_config(config)
        priority = scenario.priority_mask(123)
        run_exp._run_one("tadmpso", 999, priority, config, scenario=scenario)
    finally:
        run_exp.algorithms.run_tadmpso = original
    assert called["mode"] == "a2g"
    assert called["kwargs"]["scenario"].config.n_uav == 10
    assert called["kwargs"]["max_fes"] == 100


def t_ablation_final_dispatches_seven_v3_settings():
    assert hasattr(run_exp, "_cmd_ablation_v3")
    original = (
        run_exp._legacy_recommended_l,
        run_exp._legacy_recommended_g,
        getattr(run_exp, "_cmd_ablation_v3", None),
    )
    captured = {}
    try:
        run_exp._legacy_recommended_l = lambda: 50
        run_exp._legacy_recommended_g = lambda: 5
        run_exp._cmd_ablation_v3 = lambda config, n_runs: (
            captured.update(config=config, n_runs=n_runs) or {}
        )
        run_exp.cmd_ablation_final(n_runs=20)
    finally:
        run_exp._legacy_recommended_l = original[0]
        run_exp._legacy_recommended_g = original[1]
        if original[2] is None:
            del run_exp._cmd_ablation_v3
        else:
            run_exp._cmd_ablation_v3 = original[2]
    assert captured["n_runs"] == 20
    assert captured["config"]["variants"] == [
        item[1] for item in run_exp.ABLATION_VARIANTS
    ]
    assert captured["config"]["algorithms"] == ["ql"]


def t_recommended_l_rejects_wrong_model_or_non_full_budget():
    old_out = run_exp.OUT_DIR
    try:
        with tempfile.TemporaryDirectory() as tmp:
            run_exp.OUT_DIR = tmp
            path = os.path.join(tmp, run_exp.OUTPUT_FILES["l_opt"])
            base = {
                "schema_version": run_exp.SCHEMA_VERSION,
                "model_version": "wrong-model",
                "config": dict(run_exp.MAIN_CONFIG, candidate_L=[50, 100],
                               G=15, n_runs=10),
                "runs": [], "recommended_L": 50,
            }
            with open(path, "w", encoding="utf-8") as stream:
                json.dump(base, stream)
            try:
                run_exp._recommended_l()
            except ValueError as exc:
                assert "model_version" in str(exc)
            else:
                raise AssertionError("wrong model selection must fail")

            base["model_version"] = run_exp.model.MODEL_VERSION
            base["config"]["max_fes"] = 500
            with open(path, "w", encoding="utf-8") as stream:
                json.dump(base, stream)
            try:
                run_exp._recommended_l()
            except ValueError as exc:
                assert "full-budget" in str(exc)
            else:
                raise AssertionError("short-budget selection must fail")
    finally:
        run_exp.OUT_DIR = old_out


def t_reuse_full_variant_requires_exact_protocol():
    config = dict(run_exp.MAIN_CONFIG, L=100, G=5, n_runs=2)
    full = {
        "schema_version": run_exp.SCHEMA_VERSION,
        "model_version": run_exp.model.MODEL_VERSION,
        "config": dict(config),
        "runs": [
            {"i": i, "algo": algo, "seed": 1000 + i,
             "priority_seed": 100 + i, "best_F": 0.2}
            for i in range(2) for algo in ("pso", "ahdpso", "ql")
        ],
    }
    ablation = {"runs": []}
    run_exp.reuse_full_variant(ablation, full, config, 2)
    assert len(ablation["runs"]) == 2
    assert all(r["algo"] == "ql" and r["variant"] == "full"
               for r in ablation["runs"])

    bad = dict(full)
    bad["config"] = dict(config, G=10)
    try:
        run_exp.reuse_full_variant({"runs": []}, bad, config, 2)
    except ValueError as exc:
        assert "config" in str(exc)
    else:
        raise AssertionError("mismatched full results must not be reused")


if __name__ == "__main__":
    print("test_run_exp.py")
    for name, fn in sorted(globals().items()):
        if name.startswith("t_") and callable(fn):
            check(name, fn)
    print()
    if _FAILS:
        print(f"{len(_FAILS)} failed/errored")
        sys.exit(1)
    print("all passed")
