"""L-representation sensitivity tool tests."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sensitivity import adjusted_rand_index, representation_sensitivity

_FAILS = []


def check(name, fn):
    try:
        fn()
        print(f"  ok  {name}")
    except Exception as exc:
        _FAILS.append((name, repr(exc)))
        print(f"FAIL  {name}: {type(exc).__name__}: {exc}")


def t_l_representation_uses_nested_pool():
    rng = np.random.default_rng(1)
    X = rng.uniform([0, 0, 100], [5000, 5000, 500], size=(20, 25, 3))
    out = representation_sensitivity(X, [5, 10, 100], seed=2)
    assert [row["L"] for row in out] == [5, 10, 100]
    assert out[-1]["rank_correlation_to_L100"] == 1.0
    assert out[-1]["ari_to_L100"] == 1.0
    assert all(row["feature_seconds"] >= 0.0 for row in out)
    assert all(row["clustering_seconds"] >= 0.0 for row in out)


def t_representation_is_deterministic_except_timing():
    rng = np.random.default_rng(3)
    X = rng.uniform([0, 0, 100], [5000, 5000, 500], size=(20, 25, 3))
    a = representation_sensitivity(X, [5, 16, 100], seed=4)
    b = representation_sensitivity(X, [5, 16, 100], seed=4)
    for ra, rb in zip(a, b):
        for key in ("L", "rank_correlation_to_L100", "ari_to_L100",
                    "cluster_sizes"):
            assert ra[key] == rb[key], key


def t_adjusted_rand_known_partitions():
    assert adjusted_rand_index([0, 0, 1, 1], [1, 1, 0, 0]) == 1.0
    assert adjusted_rand_index([0, 0, 0], [0, 0, 0]) == 1.0
    assert -1.0 <= adjusted_rand_index([0, 0, 1, 1], [0, 1, 0, 1]) <= 1.0


if __name__ == "__main__":
    print("test_sensitivity.py")
    for name, fn in sorted(globals().items()):
        if name.startswith("t_") and callable(fn):
            check(name, fn)
    print()
    if _FAILS:
        print(f"{len(_FAILS)} failed/errored")
        sys.exit(1)
    print("all passed")
