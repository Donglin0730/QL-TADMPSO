# Regression-test fixtures

These files are for automated tests only: not paper experiment results and not formal experiment entry points.

- `pre_v4_algorithms.py`: frozen source baseline for regression-checking the default learning-factor control.
- `pre_v5_matrix_regression.json`: frozen small-scale test record for regression-checking trajectory and RNG-state consistency before and after matrixization.

Formal experiments all run through the project-root `run_v5_count.cmd`, `run_v5_select.cmd` and `run_v5_continue.cmd`.
