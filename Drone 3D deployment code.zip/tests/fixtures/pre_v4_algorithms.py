"""Unified implementation of the four formal algorithms and the matching control.

- Standard PSO: linear w 0.9->0.4, c1=1.6, c2=1.8, matching the PSO row of
  Table IV in the DNA paper and the released code PSO.py; r1/r2 share one
  scalar per particle per generation, velocity initialized to 0.
- AHDPSO: dynamic parameters Eq.16-20 (logistic chaos + linear/oscillating
  coefficients) + update Eq.21-24 (one scalar each for r1/r2/r3 per particle
  per generation) + DNA mechanism Algorithm 1 (round->mod4 encoding,
  mean Hamming distance, xfworst).
- T-ADMPSO: deployment-adapted baseline that shrinks the subgroup count by
  legal factor pairs, keeping topological clustering and p_exchange
  cross-swarm interaction; a mechanism adaptation, not a line-by-line port
  of the authors' code.
- QL-TADMPSO: Q-learning over subgroup count k + FSW topological clustering
  + p_exchange cross-swarm interaction; swap targets follow the T-ADMPSO
  paper rule "random other subgroup + random particle".

All four algorithms share one initialization/evaluation/clipping protocol
for paired fairness; RNG is injected by the run layer.
"""
import time

import numpy as np

import model
from evaluation import ObjectiveEvaluator, update_count
from scenario import DEFAULT_SCENARIO
from timing import TimingController
from topology import (align_guide, cluster_deployments, cluster_features,
                      direction_pool)

DIM = 3 * model.N_UAV
_LB3 = np.array([0.0, 0.0, model.H_MIN])
_UB3 = np.array([model.AREA, model.AREA, model.H_MAX])
LB = np.tile(_LB3, model.N_UAV)
UB = np.tile(_UB3, model.N_UAV)
ACTIONS = np.array([1, -1, 0])   # {increase, decrease, hold} [QLDPSO A]
FSW_DIRECTIONS = direction_pool(max_l=100, seed=20260829)


def init_swarm(rng, n, scenario=DEFAULT_SCENARIO):
    """Swarm init: positions uniform in the search space, velocity 0 (matches released code)."""
    lower, upper = scenario.bounds()
    X = rng.uniform(lower, upper, size=(n, len(lower)))
    V = np.zeros_like(X)   # released code PSO.py / AHDPSO1.py both use v = zeros
    return X, V


def clip_position(X, scenario=DEFAULT_SCENARIO):
    lower, upper = scenario.bounds()
    return np.clip(X, lower, upper)


def chaotic_r(T, rng):
    """Logistic chaotic sequence [AHDPSO Eq.16], r[0]~U(0,1)."""
    r = np.empty(T)
    if T == 0:            # edge case: T=0 -> empty sequence, no r[0] drawn
        return r
    r[0] = rng.random()
    for t in range(1, T):
        r[t] = 4.0 * r[t - 1] * (1.0 - r[t - 1])
    return r


def _params_from_r(T, r):
    if T == 0:            # edge case: empty sequence, avoid division by 0
        return np.empty(0), np.empty(0), np.empty(0)
    t = np.arange(T, dtype=np.float64)
    w = 0.9 - 0.5 * t / T                                   # Eq.17
    c1 = 1.2 - 1.2 * t / T + (1.0 - t / T) * r * 0.8        # Eq.18
    c2 = (1.2 - 1.2 * (T - t - 1.0) / T
          + (1.0 - (T - t - 1.0) / T) * r * 0.8)            # Eq.19
    return w, c1, c2


def dynamic_params(T, rng):
    return _params_from_r(T, chaotic_r(T, rng))


def timed_pso_params(progress):
    p = float(np.clip(progress, 0.0, 1.0))
    return 0.9 - 0.5 * p, 1.6, 1.8


def timed_dynamic_params(progress, chaotic_value):
    p = float(np.clip(progress, 0.0, 1.0))
    r = float(chaotic_value)
    w = 0.9 - 0.5 * p
    c1 = 1.2 * (1.0 - p) + 0.8 * r * (1.0 - p)
    c2 = 1.2 * p + 0.8 * r * p
    phase = p if p < 0.5 else 1.0 - p
    c3 = phase * (1.0 + 0.8 * r)
    return w, c1, c2, c3


def c3_series(r):
    """Exploration guide coefficient [AHDPSO Eq.20]: t/T form for t<T/2, else (T-t-1)/T."""
    T = len(r)
    if T == 0:            # edge case: empty sequence, avoid division by 0
        return np.empty(0)
    t = np.arange(T, dtype=np.float64)
    first = t < T / 2.0
    c3 = np.empty(T)
    c3[first] = (t[first] / T) * (1.0 + 0.8 * r[first])
    c3[~first] = (T - t[~first] - 1.0) / T * (1.0 + 0.8 * r[~first])
    return c3


def dna_codes(X, scenario=DEFAULT_SCENARIO):
    """Quaternary DNA codes on the 50-cell plane scale used by the reference code."""
    points = np.asarray(X, dtype=np.float64).reshape(
        -1, scenario.config.n_uav, 3
    ).copy()
    points[:, :, :2] /= scenario.config.cell_size_m
    return np.rint(points).astype(np.int64).reshape(len(points), -1) % 4


def dna_xfworst(X, F, scenario=DEFAULT_SCENARIO):
    """[AHDPSO Algorithm 1]: round->mod 4 codes, mean HD (Eq.15);
    max mean HD = xfworst; ties broken by max F (paper Algorithm 1 lines 10-14)."""
    codes = dna_codes(X, scenario=scenario)
    n = len(X)
    hd = (codes[:, None, :] != codes[None, :, :]).sum(axis=2)
    avg = hd.sum(axis=1) / (n - 1.0)
    cand = np.flatnonzero(avg == avg.max())
    return int(cand[np.argmax(F[cand])])


def cluster(X, c, rng, max_iter=100):
    """[T-ADMPSO Algorithm 1]: centers mu(0)~Uniform(P), hard assignment (Eq.7-8),
    center update (Eq.9), reseed empty clusters (non-empty constraint),
    iterate until assignment stops changing. Returns global index arrays per subgroup."""
    n = len(X)
    centers = X[rng.choice(n, c, replace=False)].copy()
    assign = np.zeros(n, dtype=np.int64)
    for _ in range(max_iter):
        d2 = ((X[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
        new = d2.argmin(axis=1)
        if (new == assign).all():
            break
        assign = new
        for k in range(c):
            m = np.flatnonzero(assign == k)
            if len(m) == 0:
                centers[k] = X[rng.integers(n)]
            else:
                centers[k] = X[m].mean(axis=0)
    return [np.flatnonzero(assign == k) for k in range(c)]


def lbest_positions(X, pbest, pF, groups):
    """lbest of each subgroup = pbest of the member with the smallest pF in the group."""
    return [pbest[g[np.argmin(pF[g])]] for g in groups]


def random_cross_swarm_member(groups, source_group, rng):
    """T-ADMPSO original cross-swarm rule: pick another subgroup at random, then one random particle in it."""
    other_groups = [i for i in range(len(groups)) if i != source_group]
    if not other_groups:
        raise ValueError("cross-swarm selection requires at least two groups")
    target = other_groups[int(rng.integers(len(other_groups)))]
    members = groups[target]
    if len(members) == 0:
        raise ValueError("target group must not be empty")
    return int(members[int(rng.integers(len(members)))])


def random_partition(n, k, rng, min_size=3):
    """Random-partition ablation: keeps the per-group minimum size, but uses no topological distance."""
    if n < k * min_size:
        raise ValueError("random partition requires n >= k * min_size")
    order = rng.permutation(n)
    sizes = np.full(k, min_size, dtype=np.int64)
    for i in range(n - k * min_size):
        sizes[i % k] += 1
    cuts = np.cumsum(sizes)[:-1]
    return [np.sort(group) for group in np.split(order, cuts)]


def factor_pairs(n_p, min_group_size=3):
    """Return parent-schedule pairs as ``(group_count, group_size)``."""
    n_p = int(n_p)
    min_group_size = int(min_group_size)
    if n_p <= 0 or min_group_size <= 0:
        raise ValueError("n_p and min_group_size must be positive")
    pairs = [
        (group_count, n_p // group_count)
        for group_count in range(1, n_p + 1)
        if n_p % group_count == 0
        and n_p // group_count >= min_group_size
    ]
    if not pairs:
        raise ValueError("no factor pair satisfies min_group_size")
    return sorted(pairs, reverse=True)


def factorization_schedule(total_updates, n_p, min_group_size=3):
    """Expand the factorization switching rule to one group count per update."""
    total_updates = int(total_updates)
    if total_updates < 0:
        raise ValueError("total_updates must be non-negative")
    pairs = factor_pairs(n_p, min_group_size)
    result = []
    for group_count, group_size in pairs[:-1]:
        remaining = total_updates - len(result)
        stage_length = min(remaining, total_updates // group_size)
        result.extend([group_count] * stage_length)
        if len(result) == total_updates:
            break
    if len(result) < total_updates:
        result.extend([pairs[-1][0]] * (total_updates - len(result)))
    return np.asarray(result, dtype=np.int64)


def timed_factorization_boundaries(n_p, min_group_size=3):
    pairs = factor_pairs(n_p, min_group_size)
    durations = [1.0 / group_size for _, group_size in pairs[:-1]]
    return np.cumsum(durations, dtype=np.float64)


def timed_factorization_k(progress, n_p, min_group_size=3):
    p = float(np.clip(progress, 0.0, 1.0))
    pairs = factor_pairs(n_p, min_group_size)
    for (group_count, _), boundary in zip(
        pairs[:-1], timed_factorization_boundaries(n_p, min_group_size)
    ):
        if p < boundary and not np.isclose(
            p, boundary, rtol=0.0, atol=1e-12
        ):
            return group_count
    return pairs[-1][0]


def q_update(Q, state, action, reward, next_state, alpha=0.5, gamma=0.95,
             terminal=False):
    """One Q-learning update; terminal reward does not bootstrap from a nonexistent next state."""
    target = float(reward)
    if not terminal:
        target += gamma * float(np.max(Q[next_state]))
    Q[state, action] += alpha * (target - Q[state, action])
    return Q


def select_q_action(rng, Q, state, k, eps, k_max):
    """eps-greedy action from {increase, decrease, hold}, subgroup count clipped to [1,k_max];
    returns (action, k_new) [QLDPSO Eq.22 exploration rate + our k clipping]."""
    if rng.random() < eps:
        action = int(rng.integers(0, 3))
    else:
        action = int(np.argmax(Q[state]))
    return action, int(np.clip(k + ACTIONS[action], 1, k_max))


def _execution_limit(max_fes, n_p, time_protocol):
    if time_protocol is None:
        return update_count(max_fes, n_p), int(max_fes)
    safety = int(time_protocol.max_fes_safety)
    return update_count(safety, n_p), safety


def _finalize(gbest, gF, hist, gbest_metrics, evaluator, n_updates,
              timing_controller=None):
    """Finish with cached metrics from the search; costs no extra uncounted FE."""
    result = {
        "best_pos": gbest,
        "best_F": float(gF),
        "gF_history": hist,
        "final_metrics": dict(gbest_metrics),
        "fes": evaluator.fes,
        "n_updates": int(n_updates),
    }
    if timing_controller is not None:
        result.update(timing_controller.result())
    return result


def run_standard_pso(rng, priority, mode, n_p=50, max_fes=25000,
                     scenario=DEFAULT_SCENARIO, time_protocol=None,
                     clock=time.perf_counter):
    T, evaluation_limit = _execution_limit(max_fes, n_p, time_protocol)
    evaluator = ObjectiveEvaluator(
        priority, mode, evaluation_limit, scenario=scenario
    )
    controller = None
    if time_protocol is not None:
        controller = TimingController(time_protocol, clock)
        controller.start()
    X, V = init_swarm(rng, n_p, scenario=scenario)
    F, metrics = evaluator.evaluate_population(X)
    pbest, pF = X.copy(), F.copy()
    pbest_metrics = list(metrics)
    g = int(np.argmin(pF))
    gbest, gF = pbest[g].copy(), pF[g]
    gbest_metrics = dict(pbest_metrics[g])
    hist = [gF]
    completed_updates = 0
    if controller is not None and controller.after_initialization(
        evaluator.fes, gF, gbest_metrics, gbest
    ):
        return _finalize(
            gbest, gF, hist, gbest_metrics, evaluator, completed_updates,
            controller,
        )
    for t in range(T):
        if controller is None:
            w, c1, c2 = 0.9 - 0.5 * t / T, 1.6, 1.8
        else:
            w, c1, c2 = timed_pso_params(controller.progress())
        # matches released code PSO.py: one shared r1 and one shared r2 per particle per generation
        r1 = rng.random(n_p)[:, None]
        r2 = rng.random(n_p)[:, None]
        V = (w * V
             + c1 * r1 * (pbest - X)
             + c2 * r2 * (gbest - X))
        X = clip_position(X + V, scenario=scenario)
        F, metrics = evaluator.evaluate_population(X)
        upd = F < pF            # update pbest only when F improves (minimization)
        pbest[upd], pF[upd] = X[upd], F[upd]
        for i in np.flatnonzero(upd):
            pbest_metrics[i] = metrics[i]
        g = int(np.argmin(pF))
        gbest, gF = pbest[g].copy(), pF[g]
        gbest_metrics = dict(pbest_metrics[g])
        hist.append(gF)
        completed_updates = t + 1
        if controller is not None and controller.after_generation(
            evaluator.fes, gF, gbest_metrics, gbest
        ):
            break
    return _finalize(
        gbest, gF, hist, gbest_metrics, evaluator, completed_updates,
        controller,
    )


def run_ahdpso(rng, priority, mode, n_p=50, max_fes=25000,
               scenario=DEFAULT_SCENARIO, time_protocol=None,
               clock=time.perf_counter):
    T, evaluation_limit = _execution_limit(max_fes, n_p, time_protocol)
    evaluator = ObjectiveEvaluator(
        priority, mode, evaluation_limit, scenario=scenario
    )
    controller = None
    if time_protocol is not None:
        controller = TimingController(time_protocol, clock)
        controller.start()
    X, V = init_swarm(rng, n_p, scenario=scenario)
    F, metrics = evaluator.evaluate_population(X)
    pbest, pF = X.copy(), F.copy()
    pbest_metrics = list(metrics)
    g = int(np.argmin(pF))
    gbest, gF = pbest[g].copy(), pF[g]
    gbest_metrics = dict(pbest_metrics[g])
    if controller is None:
        r = chaotic_r(T, rng)
        w, c1, c2 = _params_from_r(T, r)
        c3 = c3_series(r)
        chaotic_value = None
    else:
        chaotic_value = float(rng.random())
    hist = [gF]
    completed_updates = 0
    if controller is not None and controller.after_initialization(
        evaluator.fes, gF, gbest_metrics, gbest
    ):
        return _finalize(
            gbest, gF, hist, gbest_metrics, evaluator, completed_updates,
            controller,
        )
    for t in range(T):
        if controller is None:
            wt, c1t, c2t, c3t = w[t], c1[t], c2[t], c3[t]
        else:
            wt, c1t, c2t, c3t = timed_dynamic_params(
                controller.progress(), chaotic_value
            )
        xf = X[dna_xfworst(X, F, scenario=scenario)]
        # AHDPSO Eq.21: r1, r2, r3 sampled per particle
        r1 = rng.random(n_p)[:, None]
        r2 = rng.random(n_p)[:, None]
        r3 = rng.random(n_p)[:, None]
        V = (wt * V
             + c1t * r1 * (pbest - X)
             + c2t * r2 * (gbest - X)
             + c3t * r3 * (xf - X))
        X = clip_position(X + V, scenario=scenario)
        F, metrics = evaluator.evaluate_population(X)
        upd = F < pF
        pbest[upd], pF[upd] = X[upd], F[upd]
        for i in np.flatnonzero(upd):
            pbest_metrics[i] = metrics[i]
        g = int(np.argmin(pF))
        gbest, gF = pbest[g].copy(), pF[g]
        gbest_metrics = dict(pbest_metrics[g])
        hist.append(gF)
        completed_updates = t + 1
        if controller is not None:
            chaotic_value = 4.0 * chaotic_value * (1.0 - chaotic_value)
            stopped = controller.after_generation(
                evaluator.fes, gF, gbest_metrics, gbest
            )
            if stopped:
                break
    return _finalize(
        gbest, gF, hist, gbest_metrics, evaluator, completed_updates,
        controller,
    )


def run_ql_tadmpso(rng, priority, mode, n_p=50, max_fes=25000, G=15, k0=16,
                   p_exchange=0.8, alpha=0.5, gamma=0.95, k_max=16, L=16,
                   use_fsw=True, align_guides=True, use_topology=True,
                   use_q_learning=True, use_cross_swarm=True,
                   k_schedule=None, schedule_label=None,
                   scenario=DEFAULT_SCENARIO, time_protocol=None,
                   clock=time.perf_counter):
    if G <= 0:
        raise ValueError("G must be positive")
    if k_max < 1:
        raise ValueError("k_max must be positive")
    T, evaluation_limit = _execution_limit(max_fes, n_p, time_protocol)
    schedule = None
    schedule_fn = None
    if k_schedule is not None:
        if use_q_learning:
            raise ValueError("k_schedule requires use_q_learning=False")
        if callable(k_schedule):
            if time_protocol is None:
                raise ValueError("callable k_schedule requires a time protocol")
            schedule_fn = k_schedule
        else:
            raw_schedule = np.asarray(k_schedule)
            if raw_schedule.shape != (T,):
                raise ValueError(f"k_schedule must have length {T}")
            schedule = raw_schedule.astype(np.int64)
            if not np.array_equal(schedule, raw_schedule):
                raise ValueError("k_schedule values must be integers")
    evaluator = ObjectiveEvaluator(
        priority, mode, evaluation_limit, scenario=scenario
    )
    controller = None
    if time_protocol is not None:
        controller = TimingController(time_protocol, clock)
        controller.start()
    X, V = init_swarm(rng, n_p, scenario=scenario)
    F, metrics = evaluator.evaluate_population(X)
    pbest, pF = X.copy(), F.copy()
    pbest_metrics = list(metrics)
    g = int(np.argmin(pF))
    gbest, gF = pbest[g].copy(), pF[g]
    gbest_metrics = dict(pbest_metrics[g])
    if controller is None:
        w, c1, c2 = dynamic_params(T, rng)
        chaotic_value = None
    else:
        chaotic_value = float(rng.random())
    Q = np.zeros((k_max, 3))   # Q table: k_max states x 3 actions {+1,-1,0}
    # FSW subgroups need at least 3 particles; n_p<3 forces a single group
    k_max_eff = min(k_max, max(1, n_p // 3))
    if schedule is not None and len(schedule):
        if np.any((schedule < 1) | (schedule > k_max_eff)):
            raise ValueError(f"k_schedule values must be within [1,{k_max_eff}]")
        k = int(schedule[0])
    else:
        k = int(np.clip(k0, 1, k_max_eff))
    q_visits = np.zeros_like(Q, dtype=np.int64)
    outstanding = None
    hist = [gF]
    k_hist = []
    action_hist = []
    reward_hist = []
    completed_updates = 0

    def aligned(reference_flat, guide_flat):
        if not align_guides:
            return np.asarray(guide_flat).copy()
        return align_guide(
            np.asarray(reference_flat).reshape(scenario.config.n_uav, 3),
            np.asarray(guide_flat).reshape(scenario.config.n_uav, 3),
            scenario=scenario,
        ).reshape(-1)

    initialization_stopped = (
        controller is not None
        and controller.after_initialization(
            evaluator.fes, gF, gbest_metrics, gbest
        )
    )

    for t in range(0 if initialization_stopped else T):
        if controller is None:
            wt, c1t, c2t = w[t], c1[t], c2[t]
            progress = None
        else:
            progress = controller.progress()
            wt, c1t, c2t, _ = timed_dynamic_params(
                progress, chaotic_value
            )
        if schedule is not None:
            scheduled_k = int(schedule[t])
            if scheduled_k != k:
                k = scheduled_k
                k_hist.append((t, k))
        elif schedule_fn is not None:
            scheduled_k = int(schedule_fn(progress))
            if not 1 <= scheduled_k <= k_max_eff:
                raise ValueError(
                    f"scheduled k must be within [1,{k_max_eff}]"
                )
            if scheduled_k != k:
                k = scheduled_k
                k_hist.append((t, k))
        if k == 1:
            # Algorithm 2 c=1 branch: standard PSO form, independent scalar rand per individual
            # (pseudocode draws rand inside "for each individual j")
            aligned_gbest = np.stack([
                aligned(X[j], gbest)
                for j in range(n_p)
            ])
            V = (wt * V
                 + c1t * rng.random(n_p)[:, None] * (pbest - X)
                 + c2t * rng.random(n_p)[:, None] * (aligned_gbest - X))
        else:
            if not use_topology:
                groups = random_partition(n_p, k, rng, min_size=3)
            elif use_fsw:
                groups = cluster_deployments(
                    X, k, rng, FSW_DIRECTIONS, L=L, min_size=3,
                    scenario=scenario,
                )
            else:
                config = scenario.config
                minimum = np.array([0.0, 0.0, config.h_min_m])
                maximum = np.array(
                    [config.area_m, config.area_m, config.h_max_m]
                )
                raw_min = np.tile(minimum, config.n_uav)
                raw_span = np.tile(maximum - minimum, config.n_uav)
                groups = cluster_features((X - raw_min) / raw_span, k, rng,
                                          min_size=3)
            lbs = lbest_positions(X, pbest, pF, groups)
            for gi, grp in enumerate(groups):
                for jj in grp:
                    reference = X[jj]
                    aligned_lbest = aligned(reference, lbs[gi])
                    aligned_gbest = aligned(reference, gbest)
                    vj = (wt * V[jj]
                          + c1t * rng.random() * (pbest[jj] - X[jj])
                          + c2t * rng.random() * (aligned_lbest - X[jj])
                          + c2t * rng.random() * (aligned_gbest - X[jj]))
                    if use_cross_swarm and rng.random() > p_exchange:
                        xq = X[random_cross_swarm_member(groups, gi, rng)]
                        aligned_xq = aligned(reference, xq)
                        vj = vj + c1t * rng.random() * (aligned_xq - X[jj])
                    V[jj] = vj
        X = clip_position(X + V, scenario=scenario)
        F, metrics = evaluator.evaluate_population(X)
        upd = F < pF
        pbest[upd], pF[upd] = X[upd], F[upd]
        for i in np.flatnonzero(upd):
            pbest_metrics[i] = metrics[i]
        g = int(np.argmin(pF))
        gbest, gF = pbest[g].copy(), pF[g]
        gbest_metrics = dict(pbest_metrics[g])
        hist.append(gF)
        completed = t + 1
        completed_updates = completed
        at_boundary = completed % G == 0
        static_end = completed == T
        transition_update = None
        selected_action = None

        # reward must come from the full search interval after the action; terminal update does not bootstrap
        if use_q_learning and (
            at_boundary or (static_end and outstanding is not None)
        ):
            if outstanding is not None:
                reward = float(outstanding["start_gF"] - gF)
                terminal = bool(static_end)
                old_q = float(Q[outstanding["state"], outstanding["action"]])
                next_state = k - 1
                q_update(Q, outstanding["state"], outstanding["action"],
                         reward, next_state, alpha, gamma, terminal)
                reward_row = {
                    "update": completed,
                    "state": outstanding["state"],
                    "action": outstanding["action"],
                    "next_state": next_state,
                    "reward": reward,
                    "terminal": terminal,
                }
                reward_hist.append(reward_row)
                transition_update = {
                    "state": outstanding["state"],
                    "action": outstanding["action"],
                    "next_state": next_state,
                    "reward": reward,
                    "old_q": old_q,
                    "row": reward_row,
                }
                outstanding = None

            # after the last generation, do not pick an action that would never run and never earn a reward
            if at_boundary and not static_end:
                if controller is None:
                    epsilon = 0.9 - 0.5 * (completed / T)
                else:
                    epsilon = 0.9 - 0.5 * controller.last_progress
                state = k - 1
                k_before = k
                action, k = select_q_action(rng, Q, state, k, epsilon,
                                            k_max_eff)
                q_visits[state, action] += 1
                action_hist.append({
                    "update": completed,
                    "state": state,
                    "k_before": k_before,
                    "action": action,
                    "k_after": k,
                    "epsilon": float(epsilon),
                })
                k_hist.append((completed, k))
                outstanding = {
                    "state": state,
                    "action": action,
                    "start_gF": float(gF),
                }
                selected_action = {
                    "state": state,
                    "action": action,
                    "k_before": k_before,
                }
        if controller is not None:
            chaotic_value = 4.0 * chaotic_value * (1.0 - chaotic_value)
            timed_stop = controller.after_generation(
                evaluator.fes, gF, gbest_metrics, gbest
            )
            if timed_stop:
                refresh_needed = False
                if selected_action is not None:
                    q_visits[
                        selected_action["state"], selected_action["action"]
                    ] -= 1
                    action_hist.pop()
                    k_hist.pop()
                    k = selected_action["k_before"]
                    outstanding = None
                    refresh_needed = True
                if transition_update is not None and not transition_update["row"]["terminal"]:
                    state = transition_update["state"]
                    action = transition_update["action"]
                    Q[state, action] = transition_update["old_q"]
                    q_update(
                        Q, state, action, transition_update["reward"],
                        transition_update["next_state"], alpha, gamma, True,
                    )
                    transition_update["row"]["terminal"] = True
                    refresh_needed = True
                elif use_q_learning and outstanding is not None:
                    reward = float(outstanding["start_gF"] - gF)
                    q_update(
                        Q, outstanding["state"], outstanding["action"],
                        reward, k - 1, alpha, gamma, True,
                    )
                    reward_hist.append({
                        "update": completed,
                        "state": outstanding["state"],
                        "action": outstanding["action"],
                        "next_state": k - 1,
                        "reward": reward,
                        "terminal": True,
                    })
                    outstanding = None
                    refresh_needed = True
                if refresh_needed:
                    controller.refresh_boundary(evaluator.fes)
                break
    res = _finalize(
        gbest, gF, hist, gbest_metrics, evaluator, completed_updates,
        controller,
    )
    res["k_history"] = k_hist
    res["q_table"] = Q.copy()
    res["q_visits"] = q_visits
    res["action_history"] = action_hist
    res["reward_history"] = reward_hist
    if schedule is not None:
        res["k_schedule"] = schedule.tolist()
        res["schedule_label"] = (
            "external" if schedule_label is None else str(schedule_label)
        )
    elif schedule_fn is not None:
        res["schedule_label"] = (
            "external_time_normalized"
            if schedule_label is None else str(schedule_label)
        )
    return res


def run_tadmpso(rng, priority, mode, n_p=50, max_fes=25000,
                p_exchange=0.8, scenario=DEFAULT_SCENARIO,
                time_protocol=None, clock=time.perf_counter):
    """Deployment adaptation of the parent factorization-scheduled T-ADMPSO."""
    if time_protocol is None:
        schedule = factorization_schedule(update_count(max_fes, n_p), n_p, 3)
        label = "factorization"
    else:
        schedule = lambda progress: timed_factorization_k(progress, n_p, 3)
        label = "factorization_time_normalized"
    result = run_ql_tadmpso(
        rng,
        priority,
        mode,
        n_p=n_p,
        max_fes=max_fes,
        p_exchange=p_exchange,
        scenario=scenario,
        time_protocol=time_protocol,
        clock=clock,
        use_fsw=False,
        align_guides=False,
        use_topology=True,
        use_q_learning=False,
        use_cross_swarm=True,
        k_schedule=schedule,
        schedule_label=label,
    )
    for key in ("q_table", "q_visits", "action_history", "reward_history"):
        result.pop(key, None)
    result["factor_pairs"] = factor_pairs(n_p, 3)
    if time_protocol is not None:
        result["factor_boundaries"] = timed_factorization_boundaries(
            n_p, 3
        ).tolist()
    return result
