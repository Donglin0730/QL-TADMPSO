"""Full-FE SOFTWARE VALIDATION, never a formal repeated-run experiment."""
import argparse
import os
from pathlib import Path
import sys

for name in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(name, '1')
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import protocol_v5 as protocol
from count_selection import select_count
from permutation_probe import run_probe
import run_v5


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    root = args.output_dir.resolve()
    config = protocol.make_config('count', smoke=True)
    config.update(counts=[5, 25, 40], n_p=50, max_fes=25000,
                  optimization_seed_base=3100000, priority_seed_base=3110000,
                  feedback_seed_base=3120000, order_seed_base=3130000, permutation_seed_base=3140000)
    run_v5.run_suite(config, root/'count', make_report=False)
    choice = select_count(root/'count/results.json', root/'selection.json', 25,
                          'Full-budget software validation only; not a scientific choice of m.', allow_smoke=True)
    run_probe(root/'selection.json', root/'mechanism', allow_smoke=True, make_report=False)
    config = protocol.make_config('ablation', choice, smoke=True)
    config.update(n_p=50, max_fes=25000, algorithms=['full_permuted', 'random_actions'])
    run_v5.run_suite(config, root/'ablation', make_report=False)
    config = protocol.make_config('comparison', choice, smoke=True)
    config.update(n_p=50, max_fes=25000)
    run_v5.run_suite(config, root/'comparison', make_report=False)
    print('Full-budget validation complete; all results remain NONFORMAL.', flush=True)


if __name__ == '__main__':
    main()
