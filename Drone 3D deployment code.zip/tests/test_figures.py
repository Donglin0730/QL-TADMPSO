"""figures.py tests. Run: python tests/test_figures.py

Covers: plot_deployment runs and produces 3 figures under the tetromino
priority service area model; plot_deployment_3d (side-by-side multi-algorithm
3D deployment figures) and plot_distribution, plus v3 four-algorithm,
area/UAV-scale and fixed-time figure routing. The old three-algorithm
fixtures verify v2 backward compatibility.
"""
import os
import shutil
import sys
import tempfile
import warnings

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import figures
import model
from scenario import ScenarioConfig

_FAILS = []


def check(name, fn):
    try:
        fn()
        print(f"  ok  {name}")
    except AssertionError as e:
        _FAILS.append((name, str(e)))
        print(f"FAIL  {name}: {e}")
    except Exception as e:
        _FAILS.append((name, repr(e)))
        print(f"ERR   {name}: {type(e).__name__}: {e}")


def _synthetic_runs(n=1):
    rng = np.random.default_rng(0)
    runs = {}
    for ai, algo in enumerate(("pso", "ahdpso", "ql")):
        pos = np.stack([rng.uniform(0, 5000, 25), rng.uniform(0, 5000, 25),
                        rng.uniform(100, 500, 25)], axis=1)
        runs[algo] = []
        for ri in range(n):
            runs[algo].append({
                "i": ri,
                "seed": 1000 + ri,
                "best_pos": pos.ravel().tolist(),
                "best_F": 0.08 + 0.010 * ai + rng.normal(0, 0.004),
                # v2-compatible fixture: the three historical algorithms of the same i share the optimization seed and priority-area seed.
                "priority_seed": 100 + ri,
                "final_metrics": {
                    "TC": min(0.999, 0.995 - 0.004 * ai + rng.normal(0, 0.0015)),
                    "SAC": min(0.999, 0.995 - 0.004 * ai + rng.normal(0, 0.0015)),
                    "SASU": 0.20 + 0.05 * ai + rng.normal(0, 0.015),
                    "GASU": 0.35 + 0.05 * ai + rng.normal(0, 0.015),
                },
            })
        if algo == "ql":
            for r in runs[algo]:
                r["k_history"] = [[15 * (j + 1), int(rng.integers(13, 17))]
                                  for j in range(20)]
                r["q_table"] = rng.normal(size=(16, 3)).tolist()
                r["q_visits"] = rng.integers(0, 8, size=(16, 3)).tolist()
                r["action_history"] = [
                    {"update": 15 * (j + 1), "action": int(rng.integers(0, 3))}
                    for j in range(20)
                ]
                r["reward_history"] = [
                    {"update": 15 * (j + 2), "reward": float(rng.uniform(0, 0.02)),
                     "terminal": j == 19}
                    for j in range(20)
                ]
    return runs


def _dynamic_runs(n_uav=10):
    rng = np.random.default_rng(19)
    scenario = ScenarioConfig(n_uav=n_uav).to_dict()
    runs = {}
    for ai, algo in enumerate(("pso", "ahdpso", "tadmpso", "ql")):
        pos = np.stack([
            rng.uniform(0, 5000, n_uav),
            rng.uniform(0, 5000, n_uav),
            rng.uniform(100, 500, n_uav),
        ], axis=1)
        runs[algo] = [{
            "i": 0, "algo": algo, "seed": 5000,
            "priority_seed": 500, "scenario_id": "10uav",
            "scenario": dict(scenario), "best_pos": pos.ravel().tolist(),
            "best_F": 0.20 + ai * 0.01,
            "final_metrics": {
                "TC": 0.80, "SAC": 0.90,
                "SASU": 8.0, "GASU": 9.0,
            },
        }]
    return runs


def _sweep_data(kind):
    scenario_ids = (
        ("5km", "7km", "10km")
        if kind == "area_sweep" else ("10uav", "25uav", "50uav")
    )
    runs = []
    for si, scenario_id in enumerate(scenario_ids):
        for i in range(3):
            for ai, algo in enumerate(("pso", "ahdpso", "tadmpso", "ql")):
                value = 0.3 + 0.02 * ai + 0.01 * si + i / 1000
                runs.append({
                    "i": i, "scenario_id": scenario_id, "algo": algo,
                    "best_F": value,
                    "final_metrics": {
                        "TC": 0.80 + 0.01 * ai,
                        "SAC": 0.85 + 0.01 * ai,
                        "SASU": 8.0, "GASU": 9.0,
                    },
                })
    if kind == "area_sweep":
        registry = [
            {
                "scenario_id": scenario_id,
                "scenario": ScenarioConfig(
                    area_m=area_m, n_grid=n_grid, n_uav=25
                ).to_dict(),
            }
            for scenario_id, area_m, n_grid in (
                ("5km", 5000.0, 50),
                ("7km", 7000.0, 70),
                ("10km", 10000.0, 100),
            )
        ]
    elif kind == "uav_sweep":
        registry = [
            {
                "scenario_id": f"{count}uav",
                "scenario": ScenarioConfig(n_uav=count).to_dict(),
            }
            for count in (10, 25, 50)
        ]
    else:
        registry = []
    return {
        "result_kind": kind,
        "config": {
            "algorithms": ["pso", "ahdpso", "tadmpso", "ql"],
            "case_registry": registry,
        },
        "runs": runs,
    }


def _time_data():
    data = _sweep_data("time_budget")
    data["runs"] = []
    data["config"]["stop_protocol"] = {
        "checkpoints_seconds": [15.0, 30.0, 60.0]
    }
    data["config"]["hardware"] = {
        "backend": "CUDA", "device": "literal-test-device"
    }
    for i in range(3):
        for ai, algo in enumerate(("pso", "ahdpso", "tadmpso", "ql")):
            checkpoints = []
            for ci, target in enumerate((15.0, 30.0, 60.0), start=1):
                checkpoints.append({
                    "target_seconds": target, "fes": 100 * ci,
                    "best_F": 0.4 - 0.03 * ci + 0.01 * ai,
                    "final_metrics": {
                        "TC": 0.80 + 0.02 * ci,
                        "SAC": 0.82 + 0.02 * ci,
                        "SASU": 8.0, "GASU": 9.0,
                    },
                })
            data["runs"].append({
                "i": i, "scenario_id": "default", "algo": algo,
                "checkpoints": checkpoints,
                "overshoot_seconds": 0.01 * (ai + 1),
            })
    return data


def t_plot_deployment_smoke():
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_deployment(_synthetic_runs(), tag="t")
        for algo in ("pso", "ahdpso", "ql"):
            assert os.path.exists(os.path.join(tmp, f"deployment_t_{algo}.png")), \
                f"missing {algo} deployment figure"
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_plot_deployment_3d_smoke():
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_deployment_3d(_synthetic_runs(), tag="t")
        assert os.path.exists(os.path.join(tmp, "deployment_3d_t.png")), \
            "missing 3D deployment figure"
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_deployment_2d_uses_one_paired_representative_run():
    """The 2D comparison, like the 3D one, must use the same paired run."""
    runs = _synthetic_runs(3)
    seen = []

    def fake_mask(seed):
        seen.append(seed)
        return np.zeros(model.N_GRID * model.N_GRID, dtype=bool)

    orig = figures.model.priority_mask
    figures.model.priority_mask = fake_mask
    try:
        tmp = tempfile.mkdtemp()
        old = figures.FIG_DIR
        try:
            figures.FIG_DIR = tmp
            figures.plot_deployment(runs, tag="t")
        finally:
            figures.FIG_DIR = old
            shutil.rmtree(tmp, ignore_errors=True)
    finally:
        figures.model.priority_mask = orig

    selected = figures._paired_representative_runs(runs)
    want_seed = next(iter(selected.values()))["priority_seed"]
    assert seen == [want_seed] * len(selected), (
        f"priority-area seeds {seen}, should all be the paired representative run's {want_seed}"
    )


def t_comparative_3d_uses_one_paired_representative_run():
    """Side-by-side comparison must not stitch three different scenarios; it should pick one paired run."""
    runs = {
        "pso": [
            {"i": 0, "best_F": 0.10, "priority_seed": 100},
            {"i": 1, "best_F": 0.20, "priority_seed": 101},
            {"i": 2, "best_F": 0.30, "priority_seed": 102},
        ],
        "ahdpso": [
            {"i": 0, "best_F": 0.30, "priority_seed": 100},
            {"i": 1, "best_F": 0.20, "priority_seed": 101},
            {"i": 2, "best_F": 0.10, "priority_seed": 102},
        ],
        "ql": [
            {"i": 0, "best_F": 0.10, "priority_seed": 100},
            {"i": 1, "best_F": 0.20, "priority_seed": 101},
            {"i": 2, "best_F": 0.30, "priority_seed": 102},
        ],
    }
    selected = figures._paired_representative_runs(runs)
    assert {run["i"] for run in selected.values()} == {1}
    assert {run["priority_seed"] for run in selected.values()} == {101}


def t_grid_for_imshow_matches_model_xy_coordinates():
    """The model flat index is [x,y]; the imshow array must be converted to [row=y,col=x]."""
    flat = np.arange(model.N_GRID * model.N_GRID)
    image = figures._grid_for_imshow(flat)
    x_index, y_index = 0, 5
    assert image[y_index, x_index] == flat[x_index * model.N_GRID + y_index]


def t_planar_domain_stays_at_5000m_after_coverage_circles():
    fig, ax = plt.subplots()
    try:
        ax.add_patch(plt.Circle((0, 0), 1000, fill=False))
        figures._set_planar_domain(ax)
        assert ax.get_xlim() == (0.0, 5000.0)
        assert ax.get_ylim() == (0.0, 5000.0)
        assert ax.get_aspect() in (1.0, "equal")
    finally:
        plt.close(fig)


def t_priority_overlay_points_follow_xy_grid():
    mask = np.zeros((model.N_GRID, model.N_GRID), dtype=bool)
    mask[0, 5] = True  # [x-index=0, y-index=5]
    xs, ys = figures._priority_overlay_points(mask, model.GRID_AXIS)
    assert np.allclose(xs, [model.GRID_AXIS[0]])
    assert np.allclose(ys, [model.GRID_AXIS[5]])


def t_result_kind_and_sensitivity_dispatch():
    cases = [
        ({"snapshots": [], "summary": [], "shortlist": []}, "l_repr"),
        ({"summary": [], "recommended_L": 50}, "l_opt"),
        ({"summary": [], "recommended_G": 5}, "g_sensitivity"),
        ({"runs": [{"variant": "full"}]}, "ablation"),
        ({"runs": [{"algo": "ql"}]}, "full"),
    ]
    for data, expected in cases:
        assert figures.result_kind(data) == expected

    called = []
    original = figures.plot_l_representation
    try:
        figures.plot_l_representation = (
            lambda data, tag="v1": called.append((data, tag))
        )
        data = {"snapshots": [], "summary": [], "shortlist": []}
        figures.generate_figures(data, "l_representation_50grid_v2")
    finally:
        figures.plot_l_representation = original
    assert called == [(data, "50grid_v2")]


def t_v3_result_kinds_dispatch_to_new_plots():
    assert figures.result_kind({"result_kind": "area_sweep"}) == "area_sweep"
    assert figures.result_kind({"result_kind": "uav_sweep"}) == "uav_sweep"
    assert figures.result_kind({"result_kind": "time_budget"}) == "time_budget"


def t_scenario_for_10uav_run_has_dynamic_shape():
    scenario = figures.scenario_for_run(
        {"scenario": ScenarioConfig(n_uav=10).to_dict()}, {}
    )
    assert scenario.config.n_uav == 10
    assert scenario.grid_xy.shape == (2500, 2)


def t_invalid_embedded_v3_scenario_does_not_silently_fallback():
    try:
        figures.scenario_for_run({"scenario": {"n_uav": -1}}, {})
    except ValueError:
        pass
    else:
        raise AssertionError("invalid embedded scenario must be rejected")


def t_dynamic_four_algorithm_deployment_smoke():
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        runs = _dynamic_runs(10)
        figures.plot_deployment(runs, tag="dynamic")
        figures.plot_deployment_3d(runs, tag="dynamic")
        for algo in ("pso", "ahdpso", "tadmpso", "ql"):
            assert os.path.exists(
                os.path.join(tmp, f"deployment_dynamic_{algo}.png")
            )
        assert os.path.exists(
            os.path.join(tmp, "deployment_3d_dynamic.png")
        )
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_area_uav_and_time_plot_smoke():
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_area_sweep(_sweep_data("area_sweep"), "t")
        figures.plot_uav_sweep(_sweep_data("uav_sweep"), "t")
        figures.plot_time_budget(_time_data(), "t")
        assert os.path.exists(os.path.join(tmp, "area_sweep_t.png"))
        assert os.path.exists(os.path.join(tmp, "uav_sweep_t.png"))
        assert os.path.exists(os.path.join(tmp, "time_budget_t.png"))
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_time_plot_labels_every_registered_checkpoint():
    tmp = tempfile.mkdtemp()
    old_dir = figures.FIG_DIR
    old_close = figures.plt.close
    captured = []
    try:
        figures.FIG_DIR = tmp
        figures.plt.close = lambda fig: captured.append(fig)
        figures.plot_time_budget(_time_data(), "ticks")
        assert len(captured) == 1
        ticks = captured[0].axes[0].get_xticks()
        assert np.array_equal(ticks, np.array([15.0, 30.0, 60.0])), ticks
    finally:
        figures.plt.close = old_close
        figures.FIG_DIR = old_dir
        for fig in captured:
            plt.close(fig)
        shutil.rmtree(tmp, ignore_errors=True)


def t_generate_figures_dispatches_sweep_without_legacy_plots():
    called = []
    original = getattr(figures, "plot_area_sweep", None)
    try:
        figures.plot_area_sweep = lambda data, tag: called.append((data, tag))
        data = _sweep_data("area_sweep")
        assert figures.generate_figures(data, "area") == "area_sweep"
    finally:
        if original is None:
            del figures.plot_area_sweep
        else:
            figures.plot_area_sweep = original
    assert called and called[0][1] == "area"


def t_distribution_uses_holm_adjusted_family():
    """When one raw p<0.05 but Holm is not significant, the figure must not draw significance brackets."""
    runs = _synthetic_runs(6)
    for i in range(6):
        runs["ql"][i]["best_F"] = 0.0
        runs["pso"][i]["best_F"] = 1.0
        # The other four metrics are equal, so only F has a small raw p in the five-test family.
        runs["ql"][i]["final_metrics"] = dict(runs["pso"][i]["final_metrics"])
    tests = figures._distribution_test_map(runs)
    row = tests[("best_F", "ql", "pso")]
    assert row["p_raw"] < 0.05
    assert row["p_holm"] >= 0.05


def t_priority_label_is_current_term():
    assert figures.PRIORITY_LABEL == "priority service area"


def t_plot_distribution_smoke():
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_distribution(_synthetic_runs(20), tag="t")
        assert os.path.exists(os.path.join(tmp, "distribution_t.png")), \
            "missing distribution comparison figure"
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_panel_ylim():
    # With four algorithms producing three tiers of QL-vs-baseline brackets, the top margin must clear the last bracket.
    lo, hi = figures._panel_ylim(
        99.5, 100.0, 2.0, 100.0, n_brackets=3
    )
    last_bracket_top = 100.0 + (0.10 + 0.15 * 2 + 0.03) * 2.0
    assert abs(lo - 99.3) < 1e-12 and hi > last_bracket_top
    lo, hi = figures._panel_ylim(0.105, 0.145, 0.04, 1.0)
    assert abs(lo - 0.101) < 1e-12 and abs(hi - 0.165) < 1e-12


def t_sweep_and_time_captions_expose_frozen_protocol_context():
    area = figures._sweep_context_label(_sweep_data("area_sweep"), "area_sweep")
    uav = figures._sweep_context_label(_sweep_data("uav_sweep"), "uav_sweep")
    timed = figures._time_context_label(_time_data())
    assert "25 UAV" in area and "100 m" in area
    assert "5 km" in uav and "100 m" in uav
    assert "CUDA" in timed and "literal-test-device" in timed
    assert "complete-generation" in timed and "one generation" in timed


def t_sweep_protocol_subtitle_does_not_overlap_algorithm_legend():
    tmp = tempfile.mkdtemp()
    old_dir = figures.FIG_DIR
    original_close = figures.plt.close
    try:
        figures.FIG_DIR = tmp
        figures.plt.close = lambda *args, **kwargs: None
        figures.plot_area_sweep(_sweep_data("area_sweep"), "layout")
        fig = plt.gcf()
        fig.canvas.draw()
        title_box = fig._suptitle.get_window_extent(fig.canvas.get_renderer())
        legend_box = fig.legends[0].get_window_extent(fig.canvas.get_renderer())
        axes_top = max(
            ax.get_window_extent(fig.canvas.get_renderer()).y1
            for ax in fig.axes
        )
        assert legend_box.y1 + 2.0 <= title_box.y0, (
            f"legend top {legend_box.y1:.1f} overlaps title bottom "
            f"{title_box.y0:.1f}"
        )
        assert axes_top + 2.0 <= legend_box.y0, (
            f"axes top {axes_top:.1f} overlaps legend bottom "
            f"{legend_box.y0:.1f}"
        )
    finally:
        figures.plt.close = original_close
        plt.close("all")
        figures.FIG_DIR = old_dir
        shutil.rmtree(tmp, ignore_errors=True)


def t_fes_axis_includes_initialization_and_final_budget():
    axis = figures.fes_axis(history_length=500, n_p=50)
    assert axis[0] == 50
    assert axis[-1] == 25000


def t_k_frequency():
    runs = [{"k_history": [[15, 16], [30, 15]]},
            {"k_history": [[15, 16], [30, 14]]}]
    its, counts = figures._k_frequency(runs)
    assert its == [15, 30]
    assert counts[15] == {16: 2}
    assert counts[30] == {15: 1, 14: 1}


def t_plot_k_trajectory_smoke():
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_k_trajectory(_synthetic_runs(20), tag="t")
        assert os.path.exists(os.path.join(tmp, "k_trajectory_t.png")), \
            "missing k trajectory figure"
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_plot_k_trajectory_empty_hist():
    # Edge case: empty k_history (e.g. G>T produced no decision points) must not crash or produce a figure
    runs = _synthetic_runs(1)
    runs["ql"][0]["k_history"] = []
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_k_trajectory(runs, tag="empty")
        assert not os.path.exists(os.path.join(tmp, "k_trajectory_empty.png")), \
            "empty k_history must not produce a figure file"
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_plot_q_diagnostics_smoke():
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_q_diagnostics(_synthetic_runs(3), tag="t")
        assert os.path.exists(os.path.join(tmp, "q_diagnostics_t.png"))
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_plot_l_representation_smoke():
    data = {"summary": [
        {"L": 5, "rank_mean": 0.91, "rank_std": 0.01,
         "ari_mean": 0.75, "ari_std": 0.04,
         "feature_seconds_mean": 0.001, "clustering_seconds_mean": 0.004},
        {"L": 100, "rank_mean": 1.0, "rank_std": 0.0,
         "ari_mean": 1.0, "ari_std": 0.0,
         "feature_seconds_mean": 0.01, "clustering_seconds_mean": 0.04},
    ], "shortlist": [5, 100]}
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_l_representation(data, tag="t")
        assert os.path.exists(os.path.join(tmp, "l_representation_t.png"))
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_plot_l_optimization_smoke():
    data = {"summary": [
        {"L": 50, "mean_F": 0.257, "se_F": 0.0035,
         "runtime_seconds_mean": 33.2},
        {"L": 100, "mean_F": 0.249, "se_F": 0.0032,
         "runtime_seconds_mean": 48.4},
    ], "recommended_L": 100, "one_se_limit": 0.2522}
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_l_optimization(data, tag="t")
        assert os.path.exists(os.path.join(tmp, "l_optimization_t.png"))
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_plot_g_sensitivity_smoke():
    data = {"summary": [
        {"G": 5, "mean_F": 0.251, "se_F": 0.0028,
         "runtime_seconds_mean": 44.4, "actions_mean": 99.0,
         "visited_state_actions_mean": 16.6},
        {"G": 15, "mean_F": 0.249, "se_F": 0.0032,
         "runtime_seconds_mean": 45.7, "actions_mean": 33.0,
         "visited_state_actions_mean": 8.3},
    ], "recommended_G": 5, "one_se_limit": 0.2522}
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_g_sensitivity(data, tag="t")
        assert os.path.exists(os.path.join(tmp, "g_sensitivity_t.png"))
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_plot_ablation_smoke():
    data = {
        "schema_version": figures.SCHEMA_VERSION,
        "model_version": model.MODEL_VERSION,
        "runs": [],
    }
    for i, value in enumerate((0.20, 0.22, 0.19, 0.21)):
        data["runs"].append({"i": i, "variant": "full", "best_F": value,
                             "runtime_seconds": 2.0})
        data["runs"].append({"i": i, "variant": "no_fsw",
                             "best_F": value + 0.02, "runtime_seconds": 1.0})
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        figures.plot_ablation(data, tag="t")
        assert os.path.exists(os.path.join(tmp, "ablation_t.png"))
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


def t_no_missing_glyph_warnings():
    """Titles must render without missing glyphs: catch missing-glyph warnings during plotting and assert zero."""
    tmp = tempfile.mkdtemp()
    old = figures.FIG_DIR
    try:
        figures.FIG_DIR = tmp
        with warnings.catch_warnings(record=True) as ws:
            warnings.simplefilter("always")
            figures.plot_distribution(_synthetic_runs(20), tag="t")
        bad = [str(w.message) for w in ws
               if "missing from font" in str(w.message)]
        assert not bad, f"missing glyphs in rendered text (tofu blocks): {bad[:3]}"
    finally:
        figures.FIG_DIR = old
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    print("test_figures.py")
    for name, fn in sorted(globals().items()):
        if name.startswith("t_") and callable(fn):
            check(name, fn)
    print()
    if _FAILS:
        print(f"{len(_FAILS)} failed/errored")
        sys.exit(1)
    print("all passed")
