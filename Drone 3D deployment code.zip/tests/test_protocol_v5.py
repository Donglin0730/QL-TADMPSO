"""Exercise real checkpoints and the count-selection boundary with tiny runs."""
from copy import deepcopy
import importlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class ProtocolTests(unittest.TestCase):
    def modules(self):
        return tuple(importlib.import_module(name) for name in
                     ('protocol_v5', 'count_selection', 'run_v5'))

    def tiny_count(self, folder):
        protocol, selection, runner = self.modules()
        config = protocol.make_config('count', smoke=True)
        config.update(counts=[5, 10], n_p=6, max_fes=18, L=4, G=2)
        config['scenario_base'].update(n_grid=10, area_m=1000.)
        data = runner.run_suite(config, folder / 'count', make_report=False)
        return data, folder / 'count/results.json'

    def test_count_stage_enumerates_only_full_method_at_all_ten_counts(self):
        protocol, _, _ = self.modules()
        keys = protocol.expected_keys(protocol.make_config('count'))
        self.assertEqual(len(keys), 200)
        self.assertEqual({m for m, _, _ in keys}, {5, 10, 15, 20, 25, 30, 35, 40, 45, 50})
        self.assertEqual({a for _, a, _ in keys}, {'full'})

    def test_followup_stage_refuses_to_guess_m(self):
        protocol, _, _ = self.modules()
        for stage in ('ablation', 'comparison'):
            with self.subTest(stage=stage), self.assertRaisesRegex(ValueError, 'selection'):
                protocol.make_config(stage)

    def test_resume_retains_exact_records_without_duplicates(self):
        protocol, _, runner = self.modules()
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            data, path = self.tiny_count(folder)
            before = path.read_bytes()
            resumed = runner.run_suite(data['config'], path.parent, make_report=False)
            self.assertEqual(data['runs'], resumed['runs'])
            self.assertEqual(before, path.read_bytes())
            self.assertTrue(protocol.qualify(resumed)['complete'])
            self.assertFalse(protocol.qualify(resumed)['qualified'])

    def test_interrupted_stage_resumes_without_losing_its_completed_run(self):
        protocol, _, runner = self.modules()
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            config = protocol.make_config('count', smoke=True)
            config.update(counts=[5, 10], n_p=6, max_fes=18, L=4, G=2)
            config['scenario_base'].update(n_grid=10, area_m=1000.)
            original = runner.run_single
            calls = 0

            def interrupted(*args, **kwargs):
                nonlocal calls
                # i=999 is the isolated warm-up, not an experiment cell.
                if args[1] != 999:
                    calls += 1
                    if calls == 2:
                        raise KeyboardInterrupt('simulated interruption')
                return original(*args, **kwargs)

            with patch.object(runner, 'run_single', side_effect=interrupted):
                with self.assertRaises(KeyboardInterrupt):
                    runner.run_suite(config, folder/'count', make_report=False)
            saved = protocol.load_data(folder/'count/results.json')['runs']
            self.assertEqual(len(saved), 1)
            result = runner.run_suite(config, folder/'count', make_report=False)
            self.assertEqual(len(result['runs']), 2)
            self.assertEqual(result['runs'][0], saved[0])
            self.assertTrue(protocol.qualify(result)['complete'])

    def test_smoke_choice_cannot_start_formal_experiments(self):
        protocol, selection, _ = self.modules()
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            _, source = self.tiny_count(folder)
            with self.assertRaises(ValueError):
                selection.select_count(source, folder/'selection.json', 10, 'test-only choice')
            choice = selection.select_count(source, folder/'selection.json', 10,
                                            'test-only choice', allow_smoke=True)
            with self.assertRaises(ValueError):
                protocol.make_config('ablation', choice)
            config = protocol.make_config('ablation', choice, smoke=True)
            self.assertEqual(config['counts'], [10])
            self.assertIn('no_fsw_no_alignment_permuted', config['algorithms'])
            self.assertIn('random_actions', config['algorithms'])
            original = protocol.optimizer_options('full', config, 0)
            permuted = protocol.optimizer_options('full_permuted', config, 0)
            self.assertEqual(original['coefficient_control'], 'ahdpso')
            self.assertEqual(original, {k:v for k,v in permuted.items() if k != 'permutation_seed'})

    def test_incomplete_count_and_outside_count_are_rejected(self):
        protocol, selection, _ = self.modules()
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            data, source = self.tiny_count(folder)
            with self.assertRaises(ValueError):
                selection.select_count(source, folder/'selection.json', 25, 'not measured', allow_smoke=True)
            data['runs'].pop()
            protocol.save_json(source, data)
            with self.assertRaises(ValueError):
                selection.select_count(source, folder/'selection.json', 10, 'incomplete', allow_smoke=True)

    def test_choice_and_source_tampering_are_detected(self):
        _, selection, _ = self.modules()
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            _, source = self.tiny_count(folder)
            target = folder/'selection.json'
            selection.select_count(source, target, 10, 'test-only choice', allow_smoke=True)
            payload = target.read_bytes()
            data = json.loads(payload)
            data['selected_count'] = 5
            target.write_text(json.dumps(data), encoding='utf-8')
            with self.assertRaises(ValueError):
                selection.load_selection(target, allow_smoke=True)
            target.write_bytes(payload)
            source.write_bytes(source.read_bytes() + b' ')
            with self.assertRaises(ValueError):
                selection.load_selection(target, allow_smoke=True)

    def test_downstream_records_cannot_relabel_a_changed_selection_as_valid(self):
        protocol, selection, _ = self.modules()
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            _, source = self.tiny_count(folder)
            choice = selection.select_count(source, folder/'selection.json', 10,
                                            'test-only choice', allow_smoke=True)
            config = protocol.make_config('ablation', choice, smoke=True)
            config['selection']['reason'] = 'changed after selection'
            with self.assertRaises(ValueError):
                protocol.validate_config(config)

    def test_bad_budget_duplicates_and_changed_config_are_rejected(self):
        protocol, _, runner = self.modules()
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            data, source = self.tiny_count(folder)
            corrupt = deepcopy(data)
            corrupt['runs'][0]['fes'] -= 1
            with self.assertRaises(ValueError):
                protocol.validate_results(corrupt)
            corrupt = deepcopy(data)
            corrupt['runs'].append(corrupt['runs'][0])
            with self.assertRaises(ValueError):
                protocol.validate_results(corrupt)
            before = source.read_bytes()
            changed = deepcopy(data['config'])
            changed['L'] += 1
            with self.assertRaises(ValueError):
                runner.run_suite(changed, source.parent, make_report=False)
            self.assertEqual(before, source.read_bytes())

    def test_in_bounds_coordinates_must_reconstruct_the_recorded_metrics(self):
        protocol, _, _ = self.modules()
        from scenario import DeploymentScenario, ScenarioConfig
        with tempfile.TemporaryDirectory() as name:
            data, _ = self.tiny_count(Path(name))
            record = deepcopy(data['runs'][0])
            scene = DeploymentScenario(ScenarioConfig.from_dict(record['scenario']))
            record['best_pos'] = scene.bounds()[0].tolist()
            with self.assertRaisesRegex(ValueError, 'reconstruct'):
                protocol.validate_record(record, data['config'])

    def test_history_cannot_drop_updates_between_valid_endpoints(self):
        protocol, _, _ = self.modules()
        with tempfile.TemporaryDirectory() as name:
            data, _ = self.tiny_count(Path(name))
            record = deepcopy(data['runs'][0])
            record['history_fes'] = [record['history_fes'][0], record['history_fes'][-1]]
            record['gF_history'] = [record['gF_history'][0], record['gF_history'][-1]]
            record['n_updates'] = 0
            with self.assertRaisesRegex(ValueError, 'ledger'):
                protocol.validate_record(record, data['config'])

    def test_deleted_checkpoint_cell_is_corruption_not_unfinished_work(self):
        protocol, _, runner = self.modules()
        with tempfile.TemporaryDirectory() as name:
            data, path = self.tiny_count(Path(name))
            data['runs'].pop()
            protocol.save_json(path, data)
            before = path.read_bytes()
            with self.assertRaisesRegex(ValueError, 'integrity'):
                runner.run_suite(data['config'], path.parent, make_report=False)
            self.assertEqual(before, path.read_bytes())

    def test_baseline_ledgers_account_for_extra_candidate_evaluations(self):
        protocol, selection, runner = self.modules()
        from scenario import DeploymentScenario, ScenarioConfig
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            _, source = self.tiny_count(folder)
            choice = selection.select_count(source, folder/'selection.json', 10,
                                            'ledger test only', allow_smoke=True)
            config = protocol.make_config('comparison', choice, smoke=True)
            config.update(n_p=6, max_fes=180)
            config['scenario_base'].update(n_grid=10, area_m=1000.)
            scene = DeploymentScenario(ScenarioConfig.from_dict(dict(config['scenario_base'], n_uav=10)))
            priority = scene.priority_mask(config['priority_seed_base'])
            for method in ('amsepso', 'sdpso', 'saompso'):
                with self.subTest(method=method):
                    record = runner.run_single(method, 0, priority, scene, config)
                    protocol.validate_record(record, config)
                    record['n_updates'] = 0
                    with self.assertRaisesRegex(ValueError, 'ledger'):
                        protocol.validate_record(record, config)


if __name__ == '__main__':
    unittest.main()
