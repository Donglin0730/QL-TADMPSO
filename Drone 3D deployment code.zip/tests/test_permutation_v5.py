import importlib
from copy import deepcopy
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scenario import DeploymentScenario, ScenarioConfig


class PermutationTests(unittest.TestCase):
    def tiny_campaign(self, folder):
        import protocol_v5 as protocol
        import run_v5
        from count_selection import select_count
        config = protocol.make_config('count', smoke=True)
        config.update(counts=[5], n_p=6, max_fes=18, L=4, G=2)
        config['scenario_base'].update(n_grid=10, area_m=1000.)
        data = run_v5.run_suite(config, folder/'count', make_report=False)
        choice = select_count(folder/'count/results.json', folder/'selection.json', 5,
                              'test-only choice', allow_smoke=True)
        return data, choice

    def test_same_physical_deployment_has_zero_set_and_matched_distances(self):
        probe = importlib.import_module('permutation_probe')
        scene = DeploymentScenario(ScenarioConfig(n_uav=5, area_m=1000., n_grid=10))
        positions = np.array([[50, 50, 120], [850, 90, 180], [220, 730, 240],
                              [950, 950, 400], [510, 510, 320]], dtype=float)
        row = probe.probe_deployment(positions, scene, scene.priority_mask(45), 777, 7, 8)
        self.assertTrue(row['passed'])
        self.assertEqual(row['n_permutations'], 7)
        self.assertEqual(row['independent_deployments'], 1)
        self.assertGreater(row['coordinate_distance_max'], .1)
        self.assertLess(row['fsw_distance_max'], 1e-12)
        self.assertLess(row['matched_residual_max'], 1e-12)
        self.assertEqual(row['metric_error_max']['TC'], 0.)
        self.assertEqual(row['metric_error_max']['SAC'], 0.)

    def test_duplicate_locations_do_not_require_different_assignment_indices(self):
        probe = importlib.import_module('permutation_probe')
        scene = DeploymentScenario(ScenarioConfig(n_uav=5, n_grid=10))
        positions = np.tile([200., 300., 140.], (5, 1))
        row = probe.probe_deployment(positions, scene, scene.priority_mask(45), 777, 5, 8)
        self.assertTrue(row['passed'])
        self.assertEqual(row['coordinate_distance_max'], 0.)
        self.assertEqual(row['matched_residual_max'], 0.)

    def test_probe_checkpoint_is_complete_reproducible_and_bound_to_selection(self):
        import protocol_v5 as protocol
        import run_v5
        from count_selection import select_count
        probe = importlib.import_module('permutation_probe')
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            config = protocol.make_config('count', smoke=True)
            config.update(counts=[5], n_p=6, max_fes=18, L=4, G=2)
            config['scenario_base'].update(n_grid=10, area_m=1000.)
            run_v5.run_suite(config, folder/'count', make_report=False)
            choice = select_count(folder/'count/results.json', folder/'selection.json', 5,
                                  'test-only choice', allow_smoke=True)
            result = probe.run_probe(folder/'selection.json', folder/'mechanism',
                                     allow_smoke=True, make_report=False)
            self.assertEqual(len(result['runs']), 2)
            self.assertEqual({r['source_kind'] for r in result['runs']}, {'initial', 'final'})
            path = folder/'mechanism/results.json'
            before = path.read_bytes()
            probe.run_probe(folder/'selection.json', folder/'mechanism',
                            allow_smoke=True, make_report=False)
            self.assertEqual(before, path.read_bytes())
            probe.load_probe(path, choice)
            result['runs'].pop()
            protocol.save_json(path, result)
            with self.assertRaises(ValueError):
                probe.load_probe(path, choice)

    def test_smoke_permission_does_not_shorten_formal_diagnostics(self):
        probe = importlib.import_module('permutation_probe')
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            source, choice = self.tiny_campaign(folder)
            # Exercise the protocol boundary without claiming this tiny count
            # run is formal evidence. Only its upstream validation is replaced;
            # all probe computations, serialization and loading remain real.
            choice = dict(choice, formal=True)
            with patch.object(probe, 'load_selection', return_value=choice), \
                    patch.object(probe, 'validate_selection', return_value=source):
                result = probe.run_probe(folder/'selection.json', folder/'mechanism',
                                         allow_smoke=True, make_report=False)
                self.assertTrue(result['formal'])
                self.assertEqual(result['config']['n_permutations'], 20)
                self.assertEqual(result['config']['seed_base'], 1400000)
                self.assertTrue(all(len(r['trials']) == 20 for r in result['runs']))
                probe.load_probe(folder/'mechanism/results.json', choice)

    def test_loader_checks_protocol_against_selection_not_its_own_labels(self):
        probe = importlib.import_module('permutation_probe')
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            _, choice = self.tiny_campaign(folder)
            result = probe.run_probe(folder/'selection.json', folder/'mechanism',
                                     allow_smoke=True, make_report=False)
            path = folder/'mechanism/results.json'
            for field, value in [('formal', True), ('n_permutations', 1),
                                 ('run_ids', []), ('seed_base', 0), ('L', 1)]:
                with self.subTest(field=field):
                    altered = deepcopy(result)
                    if field == 'formal':
                        altered[field] = value
                    else:
                        altered['config'][field] = value
                    if field == 'n_permutations':
                        for row in altered['runs']:
                            row['trials'] = row['trials'][:1]
                    if field == 'run_ids':
                        altered['runs'] = []
                    # Reproduce a logically wrong but correctly sealed record,
                    # as the original permission-flag bug could create.
                    probe._write_probe(path, altered)
                    with self.assertRaisesRegex(ValueError, 'protocol|qualification'):
                        probe.load_probe(path, choice)


if __name__ == '__main__':
    unittest.main()
