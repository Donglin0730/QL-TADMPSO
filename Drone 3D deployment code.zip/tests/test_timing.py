"""Fixed wall-clock time protocol tests. Run: python tests/test_timing.py"""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import algorithms
import timing


_FAILS = []


def check(name, fn):
    try:
        fn()
        print(f"  ok  {name}")
    except AssertionError as exc:
        _FAILS.append((name, str(exc)))
        print(f"FAIL  {name}: {exc}")
    except Exception as exc:
        _FAILS.append((name, repr(exc)))
        print(f"ERR   {name}: {type(exc).__name__}: {exc}")


class FakeClock:
    def __init__(self, values):
        self.values = iter(values)

    def __call__(self):
        return next(self.values)


def _metrics(value):
    return {
        "F": value,
        "TC": 0.8,
        "SAC": 0.85,
        "SASU": 8.0,
        "GASU": 9.0,
    }


def t_checkpoints_capture_first_complete_generation_after_target():
    """Catch checkpoints wrongly using the generation before the target or failing to record actual FEs after whole generations."""
    protocol = timing.TimeProtocol(
        limit_seconds=3.0,
        checkpoints_seconds=(1.0, 2.0, 3.0),
        max_fes_safety=1000,
    )
    clock = FakeClock([0.0, 0.4, 1.2, 2.4, 3.3])
    controller = timing.TimingController(protocol, clock)
    controller.start()
    controller.after_initialization(50, 0.8, _metrics(0.8))
    for fes, value in ((100, 0.7), (150, 0.6), (200, 0.5)):
        controller.after_generation(fes, value, _metrics(value))
    result = controller.result()
    assert [row["target_seconds"] for row in result["checkpoints"]] == [
        1.0, 2.0, 3.0
    ]
    assert [row["fes"] for row in result["checkpoints"]] == [100, 150, 200]
    assert [row["best_F"] for row in result["checkpoints"]] == [0.7, 0.6, 0.5]
    assert result["stop_reason"] == "time_limit"
    assert math.isclose(result["overshoot_seconds"], 0.3)
    assert math.isclose(result["actual_seconds"], 3.3)


def t_safety_ceiling_is_not_mislabeled_as_time_limit():
    """Catch the safety FE cap hitting first while still masquerading as a completed wall-clock protocol."""
    protocol = timing.TimeProtocol(
        limit_seconds=10.0,
        checkpoints_seconds=(10.0,),
        max_fes_safety=100,
    )
    controller = timing.TimingController(protocol, FakeClock([0.0, 0.5, 0.8]))
    controller.start()
    assert not controller.after_initialization(50, 0.8, _metrics(0.8))
    assert controller.after_generation(100, 0.7, _metrics(0.7))
    result = controller.result()
    assert result["stop_reason"] == "max_fes_safety"
    assert result["checkpoints"] == []
    assert result["overshoot_seconds"] == 0.0


def t_protocol_rejects_ambiguous_checkpoints():
    """Catch out-of-order, duplicate, non-positive checkpoints or a last point not equal to the time limit."""
    invalid = (
        {"limit_seconds": 3.0, "checkpoints_seconds": (2.0, 1.0, 3.0)},
        {"limit_seconds": 3.0, "checkpoints_seconds": (1.0, 1.0, 3.0)},
        {"limit_seconds": 3.0, "checkpoints_seconds": (0.0, 3.0)},
        {"limit_seconds": 3.0, "checkpoints_seconds": (1.0, 2.0)},
    )
    for kwargs in invalid:
        try:
            timing.TimeProtocol(max_fes_safety=100, **kwargs)
        except ValueError:
            pass
        else:
            raise AssertionError(f"invalid protocol accepted: {kwargs}")


def t_time_normalized_coefficients_have_literal_endpoints():
    """Catch fixed-time parameters still depending on an unknown total generation count, or wrong endpoint formulas."""
    assert algorithms.timed_pso_params(0.0) == (0.9, 1.6, 1.8)
    assert algorithms.timed_pso_params(1.0) == (0.4, 1.6, 1.8)
    w, c1, c2, c3 = algorithms.timed_dynamic_params(0.25, 0.5)
    assert np.allclose([w, c1, c2, c3], [0.775, 1.2, 0.4, 0.35])


def t_timed_factorization_has_literal_np50_boundaries():
    """Catch the timed factor schedule writing stage-duration fractions as generation switch points."""
    boundaries = algorithms.timed_factorization_boundaries(50, 3)
    assert np.allclose(boundaries, [0.20, 0.30, 0.34])
    probes = ((0.0, 10), (0.199, 10), (0.20, 5), (0.299, 5),
              (0.30, 2), (0.339, 2), (0.34, 1), (1.0, 1))
    for progress, expected in probes:
        assert algorithms.timed_factorization_k(progress, 50, 3) == expected


def t_hardware_fingerprint_has_required_fields():
    meta = timing.hardware_fingerprint()
    required = {
        "python", "numpy", "cupy", "platform", "processor",
        "backend", "device",
    }
    assert required.issubset(meta)
    assert meta["backend"] in {"CPU", "CUDA"}
    assert all(isinstance(meta[key], str) and meta[key] for key in required)


if __name__ == "__main__":
    print("test_timing.py")
    for name, fn in sorted(globals().items()):
        if name.startswith("t_") and callable(fn):
            check(name, fn)
    print()
    if _FAILS:
        print(f"{len(_FAILS)} failed/errored")
        sys.exit(1)
    print("all passed")
