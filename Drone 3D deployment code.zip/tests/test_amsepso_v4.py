"""AMSEPSO equations and strict FE-budget regressions (stdlib unittest)."""
import os
import sys
import unittest

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import baseline_amsepso as amsepso


class AMSEPSOMechanismTests(unittest.TestCase):
    def test_singer_multiplier_applies_to_the_whole_quartic(self):
        self.assertAlmostEqual(amsepso.singer_step(0.5, 1.02), 0.8823)
        self.assertAlmostEqual(amsepso.singer_step(0.2, 1.05), 0.890736)

    def test_equation_acceleration_coefficients_use_fe_progress(self):
        np.testing.assert_allclose(amsepso.parameters(0.4, 0.75), [0.7, 2.2, 0.8])
        np.testing.assert_allclose(amsepso.parameters(0.0, 0.75), [0.9, 2.5, 0.5])
        np.testing.assert_allclose(amsepso.parameters(1.0, 0.75), [0.4, 1.75, 1.25])

    def test_snr_is_variance_ratio_instead_of_euclidean_distance(self):
        positions = np.array([[10.0, 12.0, 14.0], [0.0, 4.0, 8.0]])
        actual = amsepso.snr_distances(positions, np.array([0.0, 2.0, 4.0]))
        np.testing.assert_allclose(actual, [0.0, 1.0])

    def test_zero_variance_references_have_defined_limiting_distances(self):
        actual = amsepso.snr_distances(
            np.array([[2.0, 2.0, 2.0], [1.0, 2.0, 3.0]]), np.ones(3)
        )
        self.assertEqual(actual[0], 0.0)
        self.assertTrue(np.isposinf(actual[1]))

    @staticmethod
    def _state_population(n_gw, n_gb):
        positions = np.array([[0.0, 1.0]] + [[1.0, 0.0]] * n_gw
                             + [[0.0, 1.0]] * n_gb + [[1.0, 0.0]])
        return positions, np.arange(len(positions), dtype=float)

    def test_state_counts_exclude_two_extremes_and_select_all_three_states(self):
        for n_gw, n_gb, expected in [(7, 1, "exploration"), (4, 4, "balance"),
                                     (1, 7, "exploitation")]:
            with self.subTest(expected=expected):
                positions, values = self._state_population(n_gw, n_gb)
                state, counts = amsepso.estimate_state(positions, values, positions[0])
                self.assertEqual(state, expected)
                self.assertEqual(counts["n_gw"], n_gw)
                self.assertEqual(counts["n_gb"], n_gb)
                self.assertEqual(counts["n_gw"] + counts["n_gb"], len(positions) - 2)

    def test_state_boundary_is_balance_and_equal_distance_belongs_to_best(self):
        positions, values = self._state_population(12, 6)
        self.assertEqual(amsepso.estimate_state(positions, values, positions[0])[0], "balance")
        positions = np.array([[0.0, 1.0], [0.5, 0.5], [1.0, 0.0]])
        state, counts = amsepso.estimate_state(positions, np.arange(3.0), positions[0])
        self.assertEqual(state, "exploitation")
        self.assertEqual(counts["n_gb"], 1)
        self.assertEqual(counts["n_gw"], 0)

    def test_ring_best_uses_only_wrapped_left_and_right_neighbors(self):
        positions = np.arange(8.0).reshape(4, 2)
        actual = amsepso.ring_neighbor_bests(positions, np.array([0.0, 3.0, 2.0, 1.0]))
        np.testing.assert_array_equal(actual, positions[[3, 0, 3, 0]])

    def test_elite_tournament_uses_two_distinct_members_and_keeps_personal_best(self):
        positions = np.arange(20.0).reshape(10, 2)
        # Only rows 7 and 3 are in the top 20%; a distinct two-member tournament
        # must choose row 7, so learning from row 3 exposes replacement sampling.
        values = np.array([8.0, 7.0, 6.0, 1.0, 5.0, 4.0, 3.0, 0.0, 2.0, 9.0])
        actual = amsepso.elite_exemplars(np.random.default_rng(23), positions, values)
        np.testing.assert_array_equal(actual, np.repeat(positions[[7]], 10, axis=0))

    def test_strategy_exemplars_keep_mean_information_and_ring_information_separate(self):
        positions = np.arange(20.0).reshape(10, 2)
        values = np.arange(10.0)
        for state in ("exploration", "balance", "exploitation"):
            cognitive, social = amsepso.learning_exemplars(
                state, positions, values, np.random.default_rng(2)
            )
            if state == "exploitation":
                np.testing.assert_array_equal(cognitive, np.zeros_like(positions) + [0.0, 1.0])
            else:
                np.testing.assert_array_equal(cognitive, positions)
            if state == "exploration":
                np.testing.assert_array_equal(social[[0, 5, 9]], positions[[1, 4, 0]])
            else:
                np.testing.assert_array_equal(social, np.zeros_like(positions) + [9.0, 10.0])

    def test_velocity_uses_dimensionwise_random_terms(self):
        actual = amsepso.velocity_step(
            np.array([[2.0, 4.0], [6.0, 8.0]]),
            np.array([[1.0, -2.0], [3.0, -4.0]]),
            np.array([[1.0, 6.0], [7.0, 5.0]]),
            np.array([[3.0, 9.0], [8.0, 10.0]]),
            0.5, 2.0, 1.0,
            np.array([[0.0, 0.25], [0.5, 1.0]]),
            np.array([[1.0, 0.5], [0.25, 0.0]]),
        )
        np.testing.assert_allclose(actual, [[1.5, 2.5], [3.0, -8.0]])

    def test_gbpm_changes_one_dimension_and_clips_to_that_dimensions_bound(self):
        class FixedPerturbation:
            def integers(self, high):
                return 1

            def standard_normal(self):
                return 2.0

        original = np.array([3.0, 5.0, 7.0])
        actual, dimension = amsepso.perturb_gbest(
            FixedPerturbation(), original, np.array([0.0, 2.0, 4.0]),
            np.array([10.0, 8.0, 12.0]),
        )
        self.assertEqual(dimension, 1)
        np.testing.assert_array_equal(actual, [3.0, 8.0, 7.0])
        np.testing.assert_array_equal(original, [3.0, 5.0, 7.0])

    def test_singer_out_of_domain_restarts_instead_of_diverging(self):
        class FixedRestart:
            def random(self):
                return 0.4

        value, restarted = amsepso.bounded_singer_step(FixedRestart(), 0.324, 1.08)
        self.assertEqual(value, 0.4)
        self.assertTrue(restarted)
        value, restarted = amsepso.bounded_singer_step(FixedRestart(), 0.5, 1.02)
        self.assertAlmostEqual(value, 0.8823)
        self.assertFalse(restarted)

    def test_singer_endpoint_restart_never_seeds_an_absorbing_endpoint(self):
        class EndpointRestart:
            def random(self):
                return 0.0

        value, restarted = amsepso.bounded_singer_step(EndpointRestart(), 0.0, 1.02)
        self.assertGreater(value, 0.0)
        self.assertLess(value, 1.0)
        self.assertTrue(restarted)


class RecordingScenario:
    """Cheap objective at the real SearchBudget boundary, retaining every call."""

    def __init__(self, improve_on=None, sphere=False):
        self.calls = []
        self.improve_on = improve_on
        self.sphere = sphere

    def bounds(self):
        return np.array([-5.0, 0.0, 2.0]), np.array([5.0, 10.0, 6.0])

    def evaluate(self, position, priority, mode):
        lower, upper = self.bounds()
        if np.shape(position) != (3,) or not np.isfinite(position).all():
            raise AssertionError("invalid candidate")
        if np.any(position < lower) or np.any(position > upper):
            raise AssertionError("candidate outside search bounds")
        self.calls.append(np.asarray(position).copy())
        value = float(np.dot(position, position)) if self.sphere else 10.0
        if len(self.calls) == self.improve_on:
            value = -1.0
        return {"F": value, "objective_call": len(self.calls)}


class AMSEPSOBudgetTests(unittest.TestCase):
    @staticmethod
    def _run(limit, scenario=None, n=10):
        scenario = RecordingScenario() if scenario is None else scenario
        result = amsepso.run_amsepso(
            np.random.default_rng(132), None, "los", n_p=n,
            max_fes=limit, scenario=scenario,
        )
        return result, scenario

    def test_initialization_only_budget_does_not_update_or_reevaluate(self):
        result, scenario = self._run(10)
        self.assertEqual(len(scenario.calls), 10)
        self.assertEqual(result["fes"], 10)
        self.assertEqual(result["n_updates"], 0)
        self.assertEqual(result["history_fes"], [10])
        self.assertEqual(result["final_metrics"]["objective_call"], 1)
        np.testing.assert_array_equal(result["best_pos"], scenario.calls[0])

    def test_gbpm_starts_only_after_six_failed_generations(self):
        result, scenario = self._run(85)
        diag = result["diagnostics"]
        self.assertEqual(len(scenario.calls), 85)
        self.assertEqual(result["fes"], 85)
        self.assertEqual(result["n_updates"], 8)
        self.assertEqual(diag["gbpm_attempts"], 2)
        self.assertEqual(diag["gbpm_accepts"], 0)
        self.assertEqual([event["before_fes"] for event in diag["gbpm_events"]], [70, 81])
        self.assertEqual(diag["state_estimation_count"], 3)
        self.assertEqual(diag["population_update_fes"], 73)
        self.assertEqual(diag["partial_update_size"], 3)
        self.assertEqual(sum(diag["strategy_evaluations"].values()), 73)
        self.assertEqual(sum(diag["strategy_generations"].values()), 8)
        np.testing.assert_array_equal(result["history_fes"],
                                      [10, 20, 30, 40, 50, 60, 70, 71, 81, 82, 85])

    def test_one_remaining_fe_is_used_for_gbpm_without_a_hidden_swarm_evaluation(self):
        result, scenario = self._run(71)
        self.assertEqual(result["fes"], 71)
        self.assertEqual(len(scenario.calls), 71)
        self.assertEqual(result["n_updates"], 6)
        self.assertEqual(result["diagnostics"]["gbpm_attempts"], 1)
        self.assertEqual(result["diagnostics"]["population_update_fes"], 60)

    def test_accepted_gbpm_is_archived_with_its_metrics_and_resets_stagnation(self):
        result, scenario = self._run(85, RecordingScenario(improve_on=71))
        self.assertEqual(result["best_F"], -1.0)
        self.assertEqual(result["final_metrics"], {"F": -1.0, "objective_call": 71})
        np.testing.assert_array_equal(result["best_pos"], scenario.calls[70])
        self.assertEqual(len(scenario.calls), 85)
        self.assertEqual(result["diagnostics"]["gbpm_accepts"], 1)
        self.assertEqual(result["diagnostics"]["gbpm_attempts"], 1)
        self.assertEqual(result["diagnostics"]["stagnation_final"], 1)
        self.assertTrue(np.all(np.diff(result["gF_history"]) <= 0.0))

    def test_parameter_schedule_includes_gbpm_evaluations(self):
        result, _ = self._run(85)
        first = result["diagnostics"]["first_parameters"]
        last = result["diagnostics"]["last_parameters"]
        self.assertEqual(first["before_fes"], 10)
        self.assertEqual(first["progress"], 0.0)
        self.assertEqual(first["inertia"], 0.9)
        self.assertEqual(last["before_fes"], 82)
        self.assertAlmostEqual(last["progress"], 0.96)
        self.assertAlmostEqual(last["inertia"], 0.42)

    def test_identical_seeds_reproduce_the_complete_search(self):
        first, first_scenario = self._run(91, RecordingScenario(sphere=True))
        second, second_scenario = self._run(91, RecordingScenario(sphere=True))
        np.testing.assert_array_equal(first_scenario.calls, second_scenario.calls)
        np.testing.assert_array_equal(first["best_pos"], second["best_pos"])
        self.assertEqual(first["gF_history"], second["gF_history"])
        self.assertEqual(first["diagnostics"], second["diagnostics"])
        self.assertEqual(first["fes"], 91)

    def test_tiny_populations_and_partial_generations_respect_budget(self):
        for n, limit in [(1, 10), (2, 19), (3, 29), (10, 11), (10, 72)]:
            with self.subTest(n=n, limit=limit):
                result, scenario = self._run(limit, n=n)
                self.assertEqual(result["fes"], limit)
                self.assertEqual(len(scenario.calls), limit)
                self.assertTrue(np.isfinite(result["best_pos"]).all())

    def test_small_real_uav_scenario_returns_cached_objective_metrics(self):
        from scenario import DeploymentScenario, ScenarioConfig

        scenario = DeploymentScenario(ScenarioConfig(
            area_m=1000.0, n_grid=10, n_uav=2, priority_fraction=0.3,
        ))
        priority = np.arange(100) < 30
        result = amsepso.run_amsepso(
            np.random.default_rng(8), priority, "los", n_p=5,
            max_fes=32, scenario=scenario,
        )
        self.assertEqual(result["fes"], 32)
        self.assertEqual(result["best_pos"].shape, (6,))
        self.assertEqual(result["best_F"], result["final_metrics"]["F"])
        self.assertTrue(np.isfinite(result["best_F"]))
        self.assertTrue(np.all(np.diff(result["gF_history"]) <= 0.0))


if __name__ == "__main__":
    unittest.main()
