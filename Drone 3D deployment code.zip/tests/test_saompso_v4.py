"""Focused equation, state-identity and actual-FE tests for SAO-MPSO.

Run with ``python experiments/tests/test_saompso_v4.py``.
"""
import importlib.util
import pathlib
import sys
import unittest

import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

if importlib.util.find_spec("baseline_saompso") is not None:
    import baseline_saompso as sao
else:
    sao = None


class RecordingSphere:
    """A real deterministic objective which also records evaluated candidates."""

    def __init__(self, dimension=4):
        self.dimension = dimension
        self.calls = []

    def bounds(self):
        return np.full(self.dimension, -10.0), np.full(self.dimension, 10.0)

    def evaluate(self, position, priority, mode):
        position = np.asarray(position).copy()
        self.calls.append(position)
        return {"F": float(np.dot(position, position)), "call": len(self.calls)}


class SAOMPSOTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(sao, "SAO-MPSO implementation is missing")

    def test_cubic_sequence_follows_recurrence_instead_of_independent_draws(self):
        seeds = np.array([0.5, 0.25])
        sequence = sao.cubic_sequence(seeds, 2)
        np.testing.assert_allclose(sequence, [[0.5, 0.25], [0.97125, 0.60703125]])
        np.testing.assert_array_equal(seeds, [0.5, 0.25])

    def test_initialization_maps_cubic_chain_to_each_dimension(self):
        lower, upper = np.array([-2.0, 100.0]), np.array([6.0, 500.0])
        x, v = sao.initialize_population(np.random.default_rng(31), 5, lower, upper)
        z = (x - lower) / (upper - lower)
        np.testing.assert_allclose(z[1:], 2.59 * z[:-1] * (1 - z[:-1] ** 2))
        self.assertEqual(x.shape, (5, 2))
        self.assertTrue(np.all(x >= lower) and np.all(x <= upper))
        np.testing.assert_array_equal(v, np.zeros((5, 2)))

    def test_parameter_endpoints_use_decimal_log_and_correct_sqrt_placement(self):
        p0, ph, p1 = [sao.saompso_parameters(p) for p in (0.0, 0.5, 1.0)]
        self.assertAlmostEqual(p0["c1"], 1.5)
        self.assertAlmostEqual(p0["c2"], 2.5)
        self.assertAlmostEqual(p0["F"], 0.7686217868402407)
        self.assertAlmostEqual(ph["c1"], 0.5)
        self.assertAlmostEqual(ph["c2"], 1.5)
        self.assertAlmostEqual(ph["w"], 0.6)
        self.assertAlmostEqual(ph["velocity_scale"], 0.3010299956639812)
        self.assertAlmostEqual(p1["velocity_scale"], 0.04575749056067513)
        self.assertAlmostEqual(p0["M"], 0.35)
        self.assertAlmostEqual(p1["M"], 0.2207276647028654)

    def test_brownian_velocity_uses_all_three_attraction_terms(self):
        x, v = sao.pso_step(
            np.array([1.0, 2.0]), np.array([0.5, -0.5]),
            np.array([2.0, 2.0]), np.array([3.0, 0.0]),
            np.array([2.0, 3.0]), 0.25,
            {"w": 0.6, "F": 0.8}, np.array([10.0, 10.0]),
        )
        np.testing.assert_allclose(v, [1.4, -1.7])
        np.testing.assert_allclose(x, [2.4, 0.3])

    def test_velocity_cap_is_symmetric_per_coordinate(self):
        x, v = sao.pso_step(
            np.array([1.0, 2.0]), np.array([0.5, -0.5]),
            np.array([2.0, 2.0]), np.array([3.0, 0.0]),
            np.array([2.0, 3.0]), 0.25,
            {"w": 0.6, "F": 0.8}, np.array([1.0, 0.5]),
        )
        np.testing.assert_allclose(v, [1.0, -0.5])
        np.testing.assert_allclose(x, [2.0, 1.5])

    def test_snow_step_uses_elite_and_population_centroid(self):
        x = sao.snow_step(
            np.array([1.0, 2.0]), np.array([3.0, 0.0]),
            np.array([2.0, 4.0]), np.array([4.0, 5.0]),
            np.array([2.0, -1.0]), -0.5,
        )
        np.testing.assert_allclose(x, [5.0, 1.0])

    def test_memory_mixes_snow_and_melting_without_brownian_on_velocity(self):
        x, v = sao.memory_step(
            np.array([[1.0, 2.0], [1.0, 2.0]]),
            np.array([[0.5, -0.5], [0.5, -0.5]]),
            np.array([[2.0, 2.0], [2.0, 2.0]]), np.array([3.0, 0.0]),
            np.array([2.0, 4.0]), np.array([[4.0, 5.0], [4.0, 5.0]]),
            np.array([[2.0, -1.0], [2.0, -1.0]]),
            np.full((2, 1), 0.25), np.full((2, 1), -0.5),
            np.array([True, False]), {"w": 0.6, "M": 0.4},
            np.array([10.0, 10.0]),
        )
        np.testing.assert_allclose(x, [[5.0, 1.0], [1.7, 1.3]])
        np.testing.assert_allclose(v, [[0.5, -0.5], [0.7, -0.7]])

    def test_elite_pool_ranks_current_population_without_reordering_identity(self):
        x = np.array([[40.0, 4.0], [10.0, 1.0], [30.0, 3.0], [20.0, 2.0]])
        before = x.copy()
        elite = sao.elite_pool(x, np.array([4.0, 1.0, 3.0, 2.0]), [-10.0, -1.0])
        np.testing.assert_allclose(elite, [[-10.0, -1.0], [20.0, 2.0],
                                          [30.0, 3.0], [15.0, 1.5]])
        np.testing.assert_array_equal(x, before)

    def test_phase_commit_preserves_personal_best_identity(self):
        from baseline_support import SearchBudget

        scenario = RecordingSphere(1)
        budget = SearchBudget(np.random.default_rng(0), None, "sphere", 3, 6, scenario)
        x = np.array([[4.0], [3.0], [2.0]])
        v = np.zeros_like(x)
        fitness, _ = budget.evaluate(x)
        pbest, pfitness = x.copy(), fitness.copy()
        count = sao._evaluate_phase(
            budget, x, v, fitness, pbest, pfitness,
            np.array([[5.0], [1.0], [4.0]]), np.ones_like(x),
        )
        self.assertEqual(count, 3)
        np.testing.assert_array_equal(pbest, [[4.0], [1.0], [2.0]])
        np.testing.assert_array_equal(pfitness, [16.0, 1.0, 4.0])
        np.testing.assert_array_equal(x, [[5.0], [1.0], [4.0]])

    def test_transition_and_second_phase_are_charged_at_actual_calls(self):
        scenario = RecordingSphere()
        result = sao.run_saompso(np.random.default_rng(24), None, "sphere",
                                 n_p=6, max_fes=47, scenario=scenario)
        diagnostics = result["diagnostics"]
        groups = diagnostics["group_counts"]
        self.assertEqual([(g["na_before"], g["nb_before"]) for g in groups],
                         [(3, 3), (4, 2), (5, 1), (6, 0), (6, 0)])
        self.assertEqual([(g["zone1_planned"], g["zone2_planned"]) for g in groups],
                         [(3, 2), (4, 1), (5, 0), (6, 0), (6, 0)])
        self.assertEqual(result["history_fes"], [6, 12, 18, 24, 30, 36, 42, 47])
        phases = diagnostics["phase_history"]
        self.assertEqual([p["phase"] for p in phases],
                         ["dual_species", "dual_species", "dual_species", "memory",
                          "pso", "memory", "pso"])
        self.assertEqual(diagnostics["phase_counts"]["memory"], 2)
        self.assertGreater(diagnostics["memory_snow_candidates"], 0)
        self.assertGreater(diagnostics["memory_melting_candidates"], 0)
        for phase in phases:
            self.assertAlmostEqual(phase["progress"], (phase["fes_before"] - 6) / 41)

    def test_odd_population_and_all_tail_budgets_keep_best_archive(self):
        for n_p in (5, 6):
            for extra in (0, 1, n_p - 1, n_p, n_p + 1, 4 * n_p + 1, 7 * n_p):
                with self.subTest(n_p=n_p, extra=extra):
                    scenario = RecordingSphere()
                    result = sao.run_saompso(np.random.default_rng(7), None, "sphere",
                                             n_p=n_p, max_fes=n_p + extra,
                                             scenario=scenario)
                    self.assertEqual(result["fes"], n_p + extra)
                    self.assertEqual(len(scenario.calls), n_p + extra)
                    values = [float(np.dot(x, x)) for x in scenario.calls]
                    self.assertEqual(result["best_F"], min(values))
                    np.testing.assert_array_equal(result["best_pos"],
                                                  scenario.calls[int(np.argmin(values))])
                    self.assertEqual(result["final_metrics"]["F"], min(values))
                    self.assertEqual(result["history_fes"][-1], n_p + extra)
                    self.assertTrue(np.all(np.diff(result["gF_history"]) <= 0))
                    self.assertEqual(sum(p["evaluated"] for p in
                                         result["diagnostics"]["phase_history"]), extra)
                    for x in scenario.calls:
                        self.assertTrue(np.isfinite(x).all())
                        self.assertTrue(np.all(x >= -10.0) and np.all(x <= 10.0))

    def test_reproducibility_and_real_variable_uav_scenarios(self):
        from scenario import DeploymentScenario, ScenarioConfig

        for n_uav in (10, 20, 30):
            with self.subTest(n_uav=n_uav):
                scenario = DeploymentScenario(ScenarioConfig(n_uav=n_uav, n_grid=10))
                priority = scenario.priority_mask(8)
                outputs = [sao.run_saompso(np.random.default_rng(8), priority, "los",
                                          n_p=5, max_fes=29, scenario=scenario)
                           for _ in range(2)]
                first, second = outputs
                self.assertEqual(first["best_pos"].shape, (3 * n_uav,))
                self.assertEqual(first["fes"], 29)
                self.assertEqual(first["best_F"], second["best_F"])
                np.testing.assert_array_equal(first["best_pos"], second["best_pos"])
                self.assertEqual(first["gF_history"], second["gF_history"])
                self.assertEqual(first["diagnostics"], second["diagnostics"])

    def test_population_too_small_for_three_ranked_elites_is_rejected(self):
        for n_p in (1, 2):
            with self.assertRaises(ValueError):
                sao.run_saompso(np.random.default_rng(0), None, "sphere", n_p=n_p,
                                 max_fes=10, scenario=RecordingSphere())


if __name__ == "__main__":
    unittest.main(verbosity=2)
