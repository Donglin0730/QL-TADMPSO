"""Reporting checks: ten counts, stage contrasts, and no inference from smoke."""
import importlib
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import protocol_v5 as protocol
import run_v5


class ReportTests(unittest.TestCase):
    def test_paired_inference_has_known_signed_rank_probability(self):
        report = importlib.import_module('report_v5')
        result = report.contrast_summary(np.arange(1., 21.), inferential=True, n_boot=1000)
        self.assertEqual(result['median_difference'], 10.5)
        self.assertAlmostEqual(result['p_raw'], 2. / 2**20)
        self.assertLess(result['ci_low'], 10.5)
        self.assertGreater(result['ci_high'], 10.5)
        zero = report.contrast_summary(np.zeros(20), inferential=True, n_boot=100)
        self.assertEqual(zero['p_raw'], 1.)
        self.assertEqual(zero['ci_low'], zero['ci_high'])

    def test_holm_correction_is_monotone_and_bounded(self):
        report = importlib.import_module('report_v5')
        np.testing.assert_allclose(report.holm_adjust([.04, .01, .2]), [.08, .03, .2])

    def test_ablation_pairs_separate_permutation_and_mechanism_questions(self):
        report = importlib.import_module('report_v5')
        pairs = report.comparison_pairs('ablation')
        self.assertIn(('full_permuted', 'full', 'permutation'), pairs)
        self.assertIn(('no_alignment', 'no_fsw_no_alignment', 'factorial'), pairs)
        self.assertIn(('no_fsw', 'no_fsw_no_alignment', 'factorial'), pairs)
        self.assertIn(('full', 'factor_schedule', 'mechanism'), pairs)
        self.assertNotIn(('full', 'full_permuted', 'mechanism'), pairs)
        self.assertEqual(len(pairs), len(set(pairs)))

    def test_count_gain_signs_and_units_are_not_reversed(self):
        from count_selection import count_summary
        with tempfile.TemporaryDirectory() as name:
            config = protocol.make_config('count', smoke=True)
            config.update(counts=[5, 10], n_p=6, max_fes=18, L=4, G=2)
            config['scenario_base'].update(n_grid=10, area_m=1000.)
            data = run_v5.run_suite(config, Path(name), make_report=False)
            rows = count_summary(data)
            self.assertAlmostEqual(rows[1]['F_improvement'], rows[0]['F_mean'] - rows[1]['F_mean'])
            self.assertAlmostEqual(rows[1]['TC_gain_pp'], rows[1]['TC_mean'] - rows[0]['TC_mean'])
            self.assertAlmostEqual(rows[1]['runtime_increase_percent'],
                                   100 * (rows[1]['runtime_seconds_mean'] / rows[0]['runtime_seconds_mean'] - 1))
            self.assertIsNone(rows[0]['F_sd'])

    def test_complete_ten_count_smoke_produces_validated_nonformal_pdf_atlas(self):
        report = importlib.import_module('report_v5')
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            config = protocol.make_config('count', smoke=True)
            config.update(n_p=6, max_fes=18, L=4, G=2)
            config['scenario_base'].update(n_grid=10, area_m=1000.)
            data = run_v5.run_suite(config, folder/'count', make_report=False)
            result = report.generate_report(folder/'count/results.json')
            self.assertFalse(result['formal'])
            self.assertEqual(result['inferential_comparisons'], 0)
            self.assertEqual(result['layout_counts'], [5, 10, 15, 20, 25, 30, 35, 40, 45, 50])
            for filename in ('metrics_vs_uav_count.pdf', 'uav_count_layouts_2d.pdf', 'uav_count_layouts_3d.pdf'):
                self.assertEqual((folder/'count/report'/filename).read_bytes()[:4], b'%PDF')
            text = (folder/'count/report/report.md').read_text(encoding='utf-8')
            self.assertIn('NONFORMAL', text)
            self.assertIn('selection record', text)
            with self.assertRaises(ValueError):
                report.paired_rows(data, inferential=True)

    def test_partial_count_report_has_no_inherited_layout_or_significance(self):
        report = importlib.import_module('report_v5')
        with tempfile.TemporaryDirectory() as name:
            folder = Path(name)
            config = protocol.make_config('count', smoke=True)
            config.update(counts=[5, 10], n_p=6, max_fes=18, L=4, G=2)
            config['scenario_base'].update(n_grid=10, area_m=1000.)
            data = run_v5.run_suite(config, folder/'count', make_report=False)
            data['runs'].pop()
            # Construct a deliberately partial, but internally valid checkpoint.
            protocol.save_results(folder/'count/results.json', data)
            result = report.generate_report(folder/'count/results.json')
            self.assertFalse(result['formal'])
            self.assertEqual(result['layout_counts'], [])
            self.assertEqual(result['inferential_comparisons'], 0)


if __name__ == '__main__':
    unittest.main()
