from pathlib import Path
import importlib.util
import sys
import unittest
import numpy as np

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))


class FeedbackTests(unittest.TestCase):
    def module(self):
        try:
            import apso_feedback
        except ImportError:
            self.fail("APSO learning-factor controller is not implemented")
        return apso_feedback

    def test_current_best_distance_has_known_factor(self):
        f = self.module().evolutionary_factor(np.array([[0.], [1.], [3.]]), [0, 1, 2])
        self.assertAlmostEqual(f, .5)

    def test_four_unambiguous_states(self):
        mod = self.module()
        self.assertEqual([mod.classify_state(f, None) for f in [.65, .35, .05, .95]], [1, 2, 3, 4])

    def test_overlap_follows_paper_example_not_largest_membership(self):
        mod = self.module()
        self.assertEqual([mod.classify_state(.45, s) for s in [1, 2, 3, 4]], [1, 2, 2, 1])

    def test_equal_distances_do_not_assert_convergence(self):
        controller = self.module().APSOFeedback(np.random.default_rng(9))
        row = controller.update(np.zeros((5, 4)), np.arange(5))
        self.assertTrue(row["degenerate"])
        self.assertIsNone(row["factor"])
        self.assertEqual((row["c1"], row["c2"], row["state"]), (2., 2., 0))

    def test_coefficients_stay_in_source_constraints(self):
        controller = self.module().APSOFeedback(np.random.default_rng(19))
        for factor in np.tile([.65, .35, .05, .95], 500):
            row = controller.step_factor(float(factor))
            self.assertTrue(1.5 <= row["c1"] <= 2.5)
            self.assertTrue(1.5 <= row["c2"] <= 2.5)
            self.assertLessEqual(row["c1"] + row["c2"], 4. + 1e-12)

    def test_nonfinite_step_limits_fail_at_configuration(self):
        with self.assertRaises(ValueError):
            self.module().APSOFeedback(np.random.default_rng(1), step_max=float("inf"))

    def test_legacy_default_still_matches_source_snapshot(self):
        import algorithms
        from scenario import DeploymentScenario, ScenarioConfig
        spec = importlib.util.spec_from_file_location("v3_snapshot", HERE / "tests/fixtures/pre_v4_algorithms.py")
        legacy = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(legacy)
        scene = DeploymentScenario(ScenarioConfig(n_uav=5))
        kw = dict(n_p=12, max_fes=120, G=3, L=8, scenario=scene)
        priority = scene.priority_mask(81)
        old_rng, new_rng = np.random.default_rng(82), np.random.default_rng(82)
        old = legacy.run_ql_tadmpso(old_rng, priority, "a2g", **kw)
        new = algorithms.run_ql_tadmpso(new_rng, priority, "a2g", **kw)
        np.testing.assert_array_equal(old["best_pos"], new["best_pos"])
        np.testing.assert_array_equal(old["gF_history"], new["gF_history"])
        self.assertEqual(old_rng.bit_generator.state, new_rng.bit_generator.state)

    def test_feedback_run_repeats_with_the_two_recorded_seeds(self):
        import algorithms
        from scenario import DeploymentScenario, ScenarioConfig
        scene = DeploymentScenario(ScenarioConfig(n_uav=5))
        priority = scene.priority_mask(21)
        kw = dict(n_p=12, max_fes=120, G=3, L=8, scenario=scene,
                  coefficient_control="apso", feedback_seed=23)
        first = algorithms.run_ql_tadmpso(np.random.default_rng(22), priority, "a2g", **kw)
        second = algorithms.run_ql_tadmpso(np.random.default_rng(22), priority, "a2g", **kw)
        np.testing.assert_array_equal(first["best_pos"], second["best_pos"])
        self.assertEqual(first["feedback_history"], second["feedback_history"])
        self.assertEqual(first["gF_history"], second["gF_history"])

    def test_integrated_feedback_has_no_extra_fes(self):
        import algorithms
        from scenario import DeploymentScenario, ScenarioConfig
        scene = DeploymentScenario(ScenarioConfig(n_uav=5))
        try:
            result = algorithms.run_ql_tadmpso(
                np.random.default_rng(22), scene.priority_mask(21), "a2g",
                n_p=12, max_fes=120, G=3, L=8, scenario=scene,
                coefficient_control="apso", feedback_seed=23)
        except TypeError as exc:
            self.fail(str(exc))
        self.assertEqual(result["fes"], 120)
        self.assertEqual(len(result["feedback_history"]), 9)
        self.assertTrue(all(row["w"] == .9-.5*t/9 for t, row in enumerate(result["feedback_history"])))


if __name__ == "__main__":
    unittest.main()
