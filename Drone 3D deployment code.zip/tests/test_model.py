"""Model-layer tests (implementation plan §4.0). Run: python tests/test_model.py

Expected values are hardcoded constants derived independently by analysis/
geometry (computed with the math library on 2026-08-15), not by calling the
code under test - if the model formulas change, this file should fail.
"""
import math
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import model
from model import (
    CELL_SIZE,
    F_MHZ,    # carrier frequency (MHz)
    GRID_AXIS,
    GRID_XY,
    N_GRID,
    N_UAV,    # UAV count (25)
    evaluate,     # main evaluation function: fitness F and the metrics
    freespace_loss,   # free-space path loss
    plos_prob,       # line-of-sight (LoS) probability
    coverage_radius,  # coverage radius
    point_coverage,   # point coverage check
    point_snr,     # point SNR calculation
    snr_field,    # whole-field SNR calculation
    priority_mask,
    RX_THRESHOLD_DBM,
    SNR_THRESHOLD_DB,
    NOISE_DBM,
    dbm_to_mw,
    mw_to_dbm,
    aggregate_signal_dbm,
    link_validity,
    point_signal_and_coverage,
    metrics_from_field,
)

# ---- Hardcoded reference constants (independently derived) ----
FSPL_1000 = 98.47059991327963
FSPL_100 = 78.47059991327963
FSPL_1 = 38.47059991327963
PLOS_90 = 0.9647348991637159
PLOS_25 = 0.7729497310158804
PLOS_15_001 = 0.2806410847723018
CR_100 = 214.45069205095587
CR_500 = 1072.2534602547794
EDGE_D3 = 1183.1007915762493
EDGE_SNR_A2G = -5.0  # raw link SNR=9.755<15, so the dual threshold marks it invalid and drops to -100 dBm
EDGE_SNR_LOS = 15.111501442379833
# Point (100,0), UAV (0,0,100): 3D distance d3=sqrt(100^2+100^2), theta=45 deg
SNR_100M_A2G = 30.092950785722195
SNR_100M_LOS = 33.51971085235756

_FAILS = []


def check(name, fn):
    try:
        fn()
        print(f"  ok  {name}")
    except AssertionError as e:
        _FAILS.append((name, str(e)))
        print(f"FAIL  {name}: {e}")
    except Exception as e:
        _FAILS.append((name, repr(e)))
        print(f"ERR   {name}: {type(e).__name__}: {e}")


def t_freespace_loss():
    assert math.isclose(freespace_loss(1000.0, 2000.0), FSPL_1000, rel_tol=1e-12)
    assert math.isclose(freespace_loss(100.0, 2000.0), FSPL_100, rel_tol=1e-12)
    assert math.isclose(freespace_loss(1.0, 2000.0), FSPL_1, rel_tol=1e-12)


def t_dbm_mw_round_trip():
    """Catch reversed dBm/mW formulas or a wrongly kept -30 offset."""
    x = np.array([-100.0, -80.0, -65.5])
    assert np.allclose(mw_to_dbm(dbm_to_mw(x)), x, atol=1e-12)


def t_aggregate_two_valid_links_and_floor():
    """Catch adding dBm directly, adding invalid links into total power, or dropping the numeric noise floor."""
    received = np.array([[-80.0, -70.0], [-80.0, -60.0]])
    valid = np.array([[True, False], [True, False]])
    got = aggregate_signal_dbm(received, valid)
    assert np.allclose(got, [-76.96803942579511, -100.0], atol=1e-10)


def t_link_validity_combines_geometry_and_power():
    """Catch regressions that judge coverage by geometry alone or received power alone."""
    radius = CR_100
    d2 = np.array([[radius, radius, radius + 1e-6]])
    h = np.array([[100.0]])
    pr = np.array([[-80.0, -80.000001, -70.0]])
    valid = link_validity(d2, h, pr)
    assert valid.tolist() == [[True, False, False]]
    assert RX_THRESHOLD_DBM - NOISE_DBM == SNR_THRESHOLD_DB == 15.0


def t_point_signal_rejects_outside_beam():
    """Catch out-of-beam power still entering the signal field as valid received power."""
    uav = np.array([[0.0, 0.0, 100.0]])
    points = np.array([[CR_100 - 1e-3, 0.0], [CR_100 + 1e-3, 0.0]])
    signal, covered = point_signal_and_coverage(points, uav, mode="los")
    assert covered.tolist() == [True, False]
    assert signal[0] > -80.0
    assert math.isclose(signal[1], -100.0, abs_tol=1e-10)


def t_metrics_from_field_hand_calculation():
    """Catch dropped uncovered grids, misuse of sample std, or raw std used directly as f2/f3."""
    signal = np.array([-100.0, -80.0, -70.0, -90.0])
    covered = np.array([False, True, True, False])
    special = np.array([True, True, False, False])
    m = metrics_from_field(signal, covered, special)
    assert m["TC"] == 0.5
    assert m["SAC"] == 0.5
    assert m["f1"] == 0.5
    assert m["SASU"] == 10.0
    assert m["GASU"] == 10.0
    assert math.isclose(m["f2"], 0.5206963425791125, rel_tol=1e-12)
    assert math.isclose(m["f3"], 0.3471308950527417, rel_tol=1e-12)
    assert math.isclose(m["F"], 0.47563508178428204, rel_tol=1e-12)


def t_plos_clip():
    assert math.isclose(plos_prob(90.0), PLOS_90, rel_tol=1e-12)
    assert math.isclose(plos_prob(25.0), PLOS_25, rel_tol=1e-12)
    assert math.isclose(plos_prob(15.001), PLOS_15_001, rel_tol=1e-12)
    # theta<=15 clipped to 0 (Eq.12 valid range)
    for th in (15.0, 14.999, 10.0, 0.0, -5.0):
        assert plos_prob(th) == 0.0, f"theta={th}"


def t_coverage_radius():
    assert math.isclose(coverage_radius(100.0), CR_100, rel_tol=1e-12)
    assert math.isclose(coverage_radius(500.0), CR_500, rel_tol=1e-12)


def t_coverage_boundary_h100():
    uav = np.array([[0.0, 0.0, 100.0]])
    pts = np.array([[214.4, 0.0], [214.5, 0.0], [0.0, 214.5], [214.45, 0.0], [200.0, 0.0]])
    cov = point_coverage(pts, uav)
    assert cov[0], "214.4 < ri=214.4507 should be covered"
    assert not cov[1], "214.5 > ri should not be covered"
    assert not cov[2], "same in the y direction"
    assert cov[3], "214.45 < ri should be covered"
    assert cov[4], "200 is clearly inside"


def t_point_snr_edge_a2g():
    # h=500, horizontal distance exactly ri: the raw A2G link only has 9.755 dB, below the 15 dB threshold.
    ri = CR_500
    uav = np.array([[0.0, 0.0, 500.0]])
    snr = point_snr(np.array([[ri, 0.0]]), uav, mode="a2g")
    assert math.isclose(float(snr[0]), EDGE_SNR_A2G, rel_tol=1e-12)


def t_point_snr_edge_los():
    # Pure LoS link receives -79.931 dBm, valid; then added linearly with the -100 dBm numeric floor.
    uav = np.array([[0.0, 0.0, 500.0]])
    snr = point_snr(np.array([[CR_500, 0.0]]), uav, mode="los")
    assert math.isclose(float(snr[0]), EDGE_SNR_LOS, rel_tol=1e-12)


def t_point_snr_100m_modes():
    uav = np.array([[0.0, 0.0, 100.0]])
    pt = np.array([[100.0, 0.0]])
    assert math.isclose(float(point_snr(pt, uav, "a2g")[0]), SNR_100M_A2G, rel_tol=1e-12)
    assert math.isclose(float(point_snr(pt, uav, "los")[0]), SNR_100M_LOS, rel_tol=1e-12)


def t_evaluate_centered():
    # All 25 UAVs stacked at the center: actual coverage is the intersection
    # of the geometric footprint and the -80 dBm power threshold, so it is
    # clearly below the purely geometric coverage 0.14448 from pi*ri^2/25e6.
    pos = np.tile([2500.0, 2500.0, 500.0], (N_UAV, 1))
    res = evaluate(pos, priority_mask(0), mode="a2g")
    assert 0.043 < res["TC"] < 0.045, f"dual-threshold TC={res['TC']} outside the independent grid count range"
    assert abs(res["f1"] + res["TC"] - 1.0) < 1e-12, "f1=1−TC"
    # The signal field varies radially from the center, so the area std is strictly positive
    assert res["f2"] > 0.0
    assert res["f3"] > 0.0
    # f2/f3 are already the log transforms of SASU/GASU; do not log again.
    assert math.isclose(res["F"], 0.5 * res["f1"] + 0.3 * res["f2"]
                        + 0.2 * res["f3"], rel_tol=1e-12)
    assert 0.0 <= res["SAC"] <= 1.0


def t_evaluate_composition_random():
    rng = np.random.default_rng(7)
    pos = np.stack([rng.uniform(0, 5000, N_UAV), rng.uniform(0, 5000, N_UAV),
                    rng.uniform(100, 500, N_UAV)], axis=1)
    res = evaluate(pos, priority_mask(0), mode="a2g")
    assert math.isclose(res["F"], 0.5 * res["f1"] + 0.3 * res["f2"]
                        + 0.2 * res["f3"], rel_tol=1e-12)
    assert abs(res["f1"] + res["TC"] - 1.0) < 1e-12
    assert math.isclose(res["f2"], math.log1p(res["SASU"]) / math.log(100), rel_tol=1e-12)
    assert math.isclose(res["f3"], math.log1p(res["GASU"]) / math.log(1000), rel_tol=1e-12)
    assert abs(res["TC"] - res["SAC"]) < 1.0  # trivial bound


def t_permutation_invariance():
    rng = np.random.default_rng(11)
    pos = np.stack([rng.uniform(0, 5000, N_UAV), rng.uniform(0, 5000, N_UAV),
                    rng.uniform(100, 500, N_UAV)], axis=1)
    perm = rng.permutation(N_UAV)
    r1 = evaluate(pos, priority_mask(0), mode="a2g")
    r2 = evaluate(pos[perm], priority_mask(0), mode="a2g")
    for k in ("F", "f1", "f2", "f3", "TC", "SAC"):
        assert math.isclose(r1[k], r2[k], rel_tol=0.0, abs_tol=1e-9), \
            f"key {k}: {r1[k]} != {r2[k]}"


def t_priority_mask_tetromino():
    for seed in range(20):
        mask = priority_mask(seed)
        grid = mask.reshape(50, 50)
        assert mask.shape == (2500,)
        assert mask.dtype == bool
        assert int(mask.sum()) == 750

        up = np.zeros_like(grid); up[:-1] = grid[1:]
        down = np.zeros_like(grid); down[1:] = grid[:-1]
        left = np.zeros_like(grid); left[:, 1:] = grid[:, :-1]
        right = np.zeros_like(grid); right[:, :-1] = grid[:, 1:]
        assert np.all(~grid | up | down | left | right), "isolated cell in the priority service area"

    assert np.array_equal(priority_mask(3), priority_mask(3))
    assert not np.array_equal(priority_mask(3), priority_mask(4))


def t_gpu_cpu_equivalence():
    if not model._HAS_CUDA:
        print("  skip (no CUDA environment)")
        return
    rng = np.random.default_rng(42)
    pos = np.stack([rng.uniform(0, 5000, N_UAV), rng.uniform(0, 5000, N_UAV),
                    rng.uniform(100, 500, N_UAV)], axis=1)
    mask = priority_mask(0)
    old = model._USE_GPU
    try:
        model._USE_GPU = False
        rc = evaluate(pos, mask, "a2g")
        b_c, c_c = snr_field(pos, "a2g")
        model._USE_GPU = True
        rg = evaluate(pos, mask, "a2g")
        b_g, c_g = snr_field(pos, "a2g")
    finally:
        model._USE_GPU = old
    assert (c_g == c_c).all(), "coverage masks GPU/CPU must match pointwise"
    d = np.abs(b_g - b_c)
    assert d.max() < 5e-3, f"SNR field max error {d.max()} exceeds bound (float ulp amplification limit)"
    # Points with error >1e-3 must all sit on the p_LoS cliff (some UAV with
    # theta in 15 deg +/- 0.05 deg: the p_LoS derivative is infinite, so the
    # last-bit ulp of the two float32 log/arctan implementations gets amplified),
    # and there must be fewer than 0.01% of them (the rest should match
    # bit-for-bit or differ by only ~1e-5 dB)
    off = np.flatnonzero(d > 1e-3)
    assert len(off) < 0.0001 * len(d), f"too many off points: {len(off)}"
    if len(off):
        uavs = pos.astype(np.float64)
        for i in off:
            h = uavs[:, 2]
            d2 = np.hypot(GRID_XY[i, 0] - uavs[:, 0], GRID_XY[i, 1] - uavs[:, 1])
            th = np.degrees(np.arctan2(h, d2))
            assert np.abs(th - 15.0).min() < 0.05, \
                f"point {i} exceeds the bound without a cliff UAV: {d[i]}"
    for k in ("F", "f1", "f2", "f3", "TC", "SAC"):
        assert abs(rg[k] - rc[k]) < 1e-4, f"{k}: GPU {rg[k]} vs CPU {rc[k]}"


def t_gpu_kernel_latency_budget():
    """One deployment field evaluation on an RTX-class GPU should avoid per-UAV multi-kernel launch overhead."""
    if not model._HAS_CUDA:
        print("  skip (no CUDA environment)")
        return
    rng = np.random.default_rng(20260830)
    pos = rng.uniform([0, 0, 100], [5000, 5000, 500], size=(N_UAV, 3))
    model._signal_and_coverage(pos.astype(np.float32), "a2g")  # compile and warm-up are not timed
    repeats = 8
    t0 = time.perf_counter()
    for _ in range(repeats):
        model._signal_and_coverage(pos.astype(np.float32), "a2g")
    per_eval = (time.perf_counter() - t0) / repeats
    assert per_eval < 0.012, f"CUDA field evaluation {per_eval * 1000:.2f} ms, still a multi-kernel bottleneck"


def t_gpu_full_evaluate_latency_budget():
    """The full objective evaluation should not copy 250k signal values back to the CPU before computing the std."""
    if not model._HAS_CUDA:
        print("  skip (no CUDA environment)")
        return
    rng = np.random.default_rng(20260830)
    pos = rng.uniform([0, 0, 100], [5000, 5000, 500], size=(N_UAV, 3))
    mask = priority_mask(0)
    evaluate(pos, mask, "a2g")
    repeats = 12
    t0 = time.perf_counter()
    for _ in range(repeats):
        evaluate(pos, mask, "a2g")
    per_eval = (time.perf_counter() - t0) / repeats
    assert per_eval < 0.0035, \
        f"full CUDA objective evaluation {per_eval * 1000:.2f} ms, statistics/copy-back still a bottleneck"


def t_priority_mask():
    m0a = priority_mask(0)
    m0b = priority_mask(0)
    assert m0a.shape == (N_GRID * N_GRID,)
    assert m0a.dtype == bool
    assert (m0a == m0b).all(), "same seed must be deterministic"
    frac = m0a.mean()
    assert 0.29 < frac < 0.31, f"priority service area fraction {frac} deviates from 30%"
    m1 = priority_mask(1)
    assert (m0a != m1).any(), "different seeds should differ"


def t_snr_field():
    rng = np.random.default_rng(13)
    pos = np.stack([rng.uniform(0, 5000, N_UAV), rng.uniform(0, 5000, N_UAV),
                    rng.uniform(100, 500, N_UAV)], axis=1)
    best, covered = snr_field(pos, mode="a2g")
    assert best.shape == (N_GRID * N_GRID,) and covered.shape == (N_GRID * N_GRID,)
    assert covered.dtype == bool
    res = evaluate(pos, priority_mask(0), mode="a2g")
    assert abs(float(covered.mean()) - res["TC"]) < 1e-9
    # Matches point_snr at the sampled grid points
    idx = [0, 123, 999, 2499]
    ref = point_snr(GRID_XY[idx], pos, mode="a2g")
    assert np.allclose(best[idx], ref, rtol=1e-6, atol=1e-4)


def t_grid_geometry():
    assert N_GRID == 50
    assert CELL_SIZE == 100.0
    assert GRID_XY.shape == (N_GRID * N_GRID, 2)
    assert np.array_equal(GRID_AXIS, np.arange(50.0, 5000.0, 100.0))
    assert np.array_equal(GRID_XY[0], [50.0, 50.0])
    assert np.array_equal(GRID_XY[-1], [4950.0, 4950.0])
    assert F_MHZ == 2000.0


def t_evaluate_bad_mode():
    # Error path: invalid mode must raise ValueError, not silently compute with some mode
    pos = np.tile([2500.0, 2500.0, 300.0], (N_UAV, 1))
    try:
        evaluate(pos, priority_mask(0), mode="xxx")
    except ValueError:
        pass
    else:
        raise AssertionError("evaluate: invalid mode must raise ValueError")
    try:
        snr_field(pos, mode="xxx")
    except ValueError:
        pass
    else:
        raise AssertionError("snr_field: invalid mode must raise ValueError")


def t_evaluate_flat_pos():
    # Edge case: flat 75-dim input equals (25,3) (reshape inside evaluate)
    pos3 = np.tile([2500.0, 2500.0, 300.0], (N_UAV, 1))
    r1 = evaluate(pos3, priority_mask(0), mode="a2g")
    r2 = evaluate(pos3.ravel(), priority_mask(0), mode="a2g")
    for k in ("F", "f1", "f2", "f3", "TC", "SAC"):
        assert r1[k] == r2[k], k


def t_corner_uavs_finite():
    # Edge case: UAVs at the area corners (0,0,100) and (5000,5000,500); all metrics must be finite
    pos = np.vstack([[[0.0, 0.0, 100.0], [5000.0, 5000.0, 500.0]],
                     np.tile([2500.0, 2500.0, 300.0], (N_UAV - 2, 1))])
    r = evaluate(pos, priority_mask(0), mode="a2g")
    for k in ("F", "f1", "f2", "f3", "TC", "SAC"):
        assert np.isfinite(r[k]), f"{k} not finite: {r[k]}"
    assert 0.0 <= r["TC"] <= 1.0 and 0.0 <= r["SAC"] <= 1.0


def t_priority_mask_extremes():
    # Edge case: empty priority area gives f2=0; whole-field priority gives f3=0 and SAC=TC.
    pos = np.tile([2500.0, 2500.0, 500.0], (N_UAV, 1))
    n = N_GRID * N_GRID
    r_full = evaluate(pos, np.ones(n, dtype=bool), mode="a2g")
    r_empty = evaluate(pos, np.zeros(n, dtype=bool), mode="a2g")
    assert r_full["f3"] == 0.0 and r_full["GASU"] == 0.0
    assert r_full["SAC"] == r_full["TC"]
    assert r_empty["f2"] == 0.0 and r_empty["SASU"] == 0.0


def t_plos_prob_array():
    # Edge case: array input matches per-element scalar results (incl. theta<=15 clipping)
    th = np.array([-5.0, 10.0, 15.0, 15.001, 25.0, 90.0])
    out = plos_prob(th)
    assert out.shape == th.shape
    for i, v in enumerate(th):
        assert float(out[i]) == plos_prob(float(v)), f"theta={v}"


def t_point_coverage_empty():
    # Edge case: no UAVs -> all uncovered (all-False with the same length as the points)
    pts = np.array([[100.0, 100.0], [2500.0, 2500.0]])
    cov = point_coverage(pts, np.empty((0, 3)))
    assert cov.shape == (2,)
    assert not cov.any()


if __name__ == "__main__":
    print("test_model.py")
    for name, fn in sorted(globals().items()):
        if name.startswith("t_") and callable(fn):
            check(name, fn)
    print()
    if _FAILS:
        print(f"{len(_FAILS)} failed/errored")
        sys.exit(1)
    print("all passed")
