"""Mechanism and FE-accounting checks for the explicitly adapted SDPSO.

Run directly with ``python experiments/tests/test_sdpso_v4.py``.
"""
import importlib
import importlib.util
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class CountingObjective:
    """A bounded numerical objective, independent of the optimizer."""

    def __init__(self, objective, dimension=3, max_fes=3):
        self.objective = objective
        self.lower = np.zeros(dimension)
        self.upper = np.ones(dimension)
        self.remaining = max_fes
        self.positions = []

    def evaluate_one(self, position):
        if not self.remaining:
            raise AssertionError("optimizer exceeded the objective budget")
        self.remaining -= 1
        self.positions.append(np.asarray(position).copy())
        value = float(self.objective(position))
        return value, {"F": value}


class FixedRandom:
    def __init__(self, uniform):
        self.uniform = uniform

    def integers(self, high):
        return high - 1

    def random(self):
        return self.uniform


class RecordingScenario:
    """A real deterministic objective with anisotropic deployment bounds."""

    def __init__(self, n_uav=1, plateau=False):
        self.lower = np.tile([0.0, 0.0, 100.0], n_uav)
        self.upper = np.tile([500.0, 500.0, 200.0], n_uav)
        self.calls = []
        self.plateau = plateau

    def bounds(self):
        return self.lower.copy(), self.upper.copy()

    def evaluate(self, position, priority, mode):
        scaled = (position - self.lower) / (self.upper - self.lower)
        value = 1.0 if self.plateau else float(np.mean((scaled - 0.3) ** 2))
        metrics = {"F": value, "evaluation_id": len(self.calls) + 1}
        self.calls.append((np.asarray(position).copy(), dict(metrics)))
        return metrics


class SDPsoMechanismTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(
            importlib.util.find_spec("baseline_sdpso"),
            "SDPSO implementation has not been added yet",
        )
        self.algorithm = importlib.import_module("baseline_sdpso")

    def test_dimensional_trials_compare_with_latest_accepted_particle(self):
        # Comparing with the original value 10 would incorrectly keep [1,1,0].
        costs = {(1, 0, 0): 5.0, (1, 1, 0): 7.0, (1, 0, 1): 2.0}
        budget = CountingObjective(lambda x: costs[tuple(x.astype(int))])
        position, value, trials, accepted = self.algorithm.dimensional_learning(
            np.zeros(3), 10.0, np.ones(3), budget
        )
        np.testing.assert_array_equal(position, [1.0, 0.0, 1.0])
        self.assertEqual(value, 2.0)
        self.assertEqual((trials, accepted, budget.remaining), (3, 2, 0))
        np.testing.assert_array_equal(budget.positions[-1], [1.0, 0.0, 1.0])

    def test_dimensional_search_stops_mid_particle_without_unscored_change(self):
        budget = CountingObjective(lambda x: 10.0 - np.sum(x), max_fes=2)
        position, value, trials, accepted = self.algorithm.dimensional_learning(
            np.zeros(3), 10.0, np.ones(3), budget
        )
        np.testing.assert_array_equal(position, [1.0, 1.0, 0.0])
        self.assertEqual((value, trials, accepted), (8.0, 2, 2))
        self.assertEqual(len(budget.positions), 2)

    def test_dimensional_search_counts_unchanged_coordinate_trials(self):
        budget = CountingObjective(lambda x: 1.0, max_fes=3)
        position, value, trials, accepted = self.algorithm.dimensional_learning(
            np.zeros(3), 1.0, np.zeros(3), budget
        )
        np.testing.assert_array_equal(position, [0.0, 0.0, 0.0])
        self.assertEqual((value, trials, accepted), (1.0, 3, 0))

    def test_consecutive_stall_resets_only_the_improving_particle(self):
        counts = np.array([4, 3, 2])
        updated = self.algorithm.update_stall_counts(
            counts, np.array([2.0, 3.0, 1.0]), np.array([2.0, 2.0, 2.0])
        )
        np.testing.assert_array_equal(updated, [5, 4, 0])
        np.testing.assert_array_equal(counts, [4, 3, 2])

    def test_recursive_cooling_and_zero_temperature_reject_uphill(self):
        first = self.algorithm.cool_temperature(1.0, 0.25)
        second = self.algorithm.cool_temperature(first, 0.5)
        self.assertEqual((first, second), (0.75, 0.375))
        underflow = self.algorithm.cool_temperature(float.fromhex("0x0.0000000000001p-1022"), 0.75)
        self.assertEqual(underflow, 0.0)
        self.assertFalse(self.algorithm.metropolis_accept(0.0, 1.0, underflow, 0.0))
        self.assertTrue(self.algorithm.metropolis_accept(1.0, 0.0, underflow, 0.9))

    def test_metropolis_probability_uses_cost_difference(self):
        self.assertTrue(self.algorithm.metropolis_accept(1.0, 2.0, 1.0, 0.2))
        self.assertFalse(self.algorithm.metropolis_accept(1.0, 2.0, 1.0, 0.8))
        self.assertFalse(self.algorithm.metropolis_accept(0.0, 1.0, 1e-300, 0.5))

    def test_annealing_guide_can_accept_a_worse_current_particle(self):
        guide, value, proposed, accepted = self.algorithm.update_annealing_guide(
            np.zeros(2), 0.0, np.array([[1.0, 0.0], [2.0, 0.0]]),
            np.array([1.0, 2.0]), 1000.0, 1.0, FixedRandom(0.2),
        )
        np.testing.assert_array_equal(guide, [2.0, 0.0])
        self.assertEqual(value, 2.0)
        self.assertTrue(proposed and accepted)

    def test_annealing_acceptance_scores_selected_rank_not_best_rank(self):
        # exp(-1) > 0.2 > exp(-2); confusing the two costs accepts wrongly.
        guide, value, proposed, accepted = self.algorithm.update_annealing_guide(
            np.zeros(2), 0.0, np.array([[1.0, 0.0], [2.0, 0.0]]),
            np.array([1.0, 2.0]), 1.0, 1.0, FixedRandom(0.2),
        )
        np.testing.assert_array_equal(guide, [0.0, 0.0])
        self.assertEqual(value, 0.0)
        self.assertTrue(proposed)
        self.assertFalse(accepted)

    def test_better_current_particle_replaces_the_guide_without_random_draw(self):
        guide, value, proposed, accepted = self.algorithm.update_annealing_guide(
            np.ones(2), 2.0, np.array([[0.0, 0.0], [1.0, 0.0]]),
            np.array([0.0, 1.0]), 0.0, 0.0, None,
        )
        np.testing.assert_array_equal(guide, [0.0, 0.0])
        self.assertEqual(value, 0.0)
        self.assertFalse(proposed or accepted)


class SDPsoBudgetTests(unittest.TestCase):
    def setUp(self):
        self.algorithm = importlib.import_module("baseline_sdpso")
        self.assertTrue(
            hasattr(self.algorithm, "run_sdpso"),
            "budgeted SDPSO runner has not been implemented yet",
        )

    def run_algorithm(self, scenario, max_fes, seed=8, n_p=4):
        return self.algorithm.run_sdpso(
            np.random.default_rng(seed), np.array([True]), "los", n_p=n_p,
            max_fes=max_fes, scenario=scenario,
        )

    def test_exact_budget_includes_mid_pso_and_mid_dls_tails(self):
        for max_fes in (4, 5, 6, 9, 20, 21, 63):
            with self.subTest(max_fes=max_fes):
                scenario = RecordingScenario(plateau=True)
                result = self.run_algorithm(scenario, max_fes)
                self.assertEqual(result["fes"], max_fes)
                self.assertEqual(len(scenario.calls), max_fes)
                diagnostics = result["diagnostics"]
                self.assertEqual(
                    4 + diagnostics["pso_evaluations"] + diagnostics["dls_trials"],
                    max_fes,
                )
                self.assertEqual(result["history_fes"][-1], max_fes)
                self.assertEqual(result["n_updates"] == 0, max_fes == 4)

    def test_first_stalled_pass_performs_a_full_greedy_scan_per_particle(self):
        scenario = RecordingScenario(plateau=True)
        result = self.run_algorithm(scenario, 20)
        diagnostics = result["diagnostics"]
        self.assertEqual(diagnostics["pso_evaluations"], 4)
        self.assertEqual(diagnostics["dls_calls"], 4)
        self.assertEqual(diagnostics["dls_trials"], 12)
        self.assertEqual(diagnostics["dls_accepts"], 0)

    def test_best_metrics_are_cached_from_the_best_evaluation(self):
        scenario = RecordingScenario()
        result = self.run_algorithm(scenario, 139)
        recorded_fitness = np.array([metrics["F"] for _, metrics in scenario.calls])
        best_index = int(np.argmin(recorded_fitness))
        np.testing.assert_array_equal(result["best_pos"], scenario.calls[best_index][0])
        self.assertEqual(result["final_metrics"], scenario.calls[best_index][1])
        self.assertEqual(result["best_F"], recorded_fitness[best_index])
        self.assertTrue(np.all(np.diff(result["gF_history"]) <= 0.0))
        self.assertTrue(np.all(np.diff(result["history_fes"]) > 0))
        self.assertEqual(len(scenario.calls), 139)

    def test_variable_uav_counts_keep_every_evaluated_position_finite_and_bounded(self):
        for n_uav in (1, 3, 7):
            with self.subTest(n_uav=n_uav):
                scenario = RecordingScenario(n_uav=n_uav)
                result = self.run_algorithm(scenario, 157)
                self.assertEqual(result["best_pos"].shape, (3 * n_uav,))
                evaluated = np.stack([position for position, _ in scenario.calls])
                self.assertTrue(np.isfinite(evaluated).all())
                self.assertTrue(np.all(evaluated >= scenario.lower))
                self.assertTrue(np.all(evaluated <= scenario.upper))
                self.assertTrue(np.isfinite(result["diagnostics"]["final_temperature"]))

    def test_repeated_seed_reproduces_candidates_and_history(self):
        first, second = RecordingScenario(), RecordingScenario()
        result1 = self.run_algorithm(first, 173)
        result2 = self.run_algorithm(second, 173)
        np.testing.assert_array_equal(
            np.stack([x for x, _ in first.calls]), np.stack([x for x, _ in second.calls])
        )
        self.assertEqual(result1["gF_history"], result2["gF_history"])
        self.assertEqual(result1["diagnostics"], result2["diagnostics"])

    def test_complete_loop_accepts_uphill_moves_without_degrading_archive(self):
        result = self.run_algorithm(RecordingScenario(), 173)
        diagnostics = result["diagnostics"]
        self.assertGreater(diagnostics["uphill_guide_moves"], 0)
        self.assertGreaterEqual(
            diagnostics["uphill_guide_proposals"], diagnostics["uphill_guide_moves"]
        )
        self.assertLessEqual(result["best_F"], diagnostics["final_guide_F"])
        self.assertTrue(np.all(np.diff(result["gF_history"]) <= 0.0))

    def test_uphill_guide_does_not_overwrite_or_alias_best_archive(self):
        from baseline_support import SearchBudget

        scenario = RecordingScenario()
        archive = SearchBudget(np.random.default_rng(2), None, "los", 1, 3, scenario)
        optimum = scenario.lower + 0.3 * (scenario.upper - scenario.lower)
        worse = np.stack([scenario.lower, scenario.upper])
        archive.evaluate_one(optimum)
        fitness, _ = archive.evaluate(worse)
        guide, guide_f, proposed, accepted = self.algorithm.update_annealing_guide(
            optimum, 0.0, worse, fitness, 1000.0, 1.0, FixedRandom(0.2)
        )
        self.assertTrue(proposed and accepted)
        self.assertGreater(guide_f, archive.best_F)
        guide[:] = -999.0
        result = archive.result(1)
        np.testing.assert_array_equal(result["best_pos"], optimum)
        self.assertEqual(result["best_F"], 0.0)
        self.assertEqual(result["final_metrics"]["evaluation_id"], 1)
        self.assertEqual(len(scenario.calls), 3)


if __name__ == "__main__":
    unittest.main()
