"""Descriptive/inferential separation and FE-axis tests for the v4 report."""
import csv
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import model
from scenario import ScenarioConfig, metrics_from_summary


def synthetic_data(n_runs=2, counts=(5, 10), methods=("pso", "ql_apso")):
    """In-memory QA fixture; any artifact is written under a temporary folder."""
    data = {
        "schema_version": "uav-bs-experiments-v4",
        "model_version": model.MODEL_VERSION,
        "result_kind": "smoke",
        "config": {
            "n_p": 2, "max_fes": 10, "mode": "a2g", "L": 50, "G": 5,
            "counts": list(counts), "algorithms": list(methods),
            "n_runs": n_runs, "device": "CPU", "experiment_kind": "smoke",
            "optimization_seed_base": 100, "feedback_seed_base": 200,
            "priority_seed_base": 300, "scenario_base": ScenarioConfig().to_dict(),
        },
        "runs": [],
    }
    for count in counts:
        for j, method in enumerate(methods):
            for i in range(n_runs):
                metrics = metrics_from_summary(.45 + .01 * j + .002 * i,
                                               .5 + .01 * j, 8.0 - j, 10.0 - j)
                data["runs"].append({
                    "i": i, "method": method, "algo": method,
                    "seed": 100 + i, "feedback_seed": 200 + i,
                    "priority_seed": 300 + i,
                    "scenario": ScenarioConfig(n_uav=count).to_dict(),
                    "scenario_id": f"{count}uav", "best_F": metrics["F"],
                    "final_metrics": metrics,
                    "best_pos": np.tile([2500.0, 2500.0, 200.0], count).tolist(),
                    "fes": 10, "n_updates": 3, "runtime_seconds": 0.1,
                    "history_fes": [2, 5, 10],
                    "gF_history": [metrics["F"] + .1, metrics["F"] + .05, metrics["F"]],
                })
    return data


class ReportV4Tests(unittest.TestCase):
    def module(self):
        try:
            import report_v4
        except ImportError:
            self.fail("The v4 report module is not implemented")
        return report_v4

    def test_summary_uses_sample_sd_and_percentage_units(self):
        report = self.module()
        data = synthetic_data()
        selected = [r for r in data["runs"] if r["method"] == "pso"
                    and r["scenario"]["n_uav"] == 5]
        for row, objective, coverage in zip(selected, [.2, .4], [.6, .8]):
            row["best_F"] = row["final_metrics"]["F"] = objective
            row["final_metrics"]["TC"] = coverage
        rows = report.summary_rows(data)
        row = next(r for r in rows if r["n_uav"] == 5 and r["method"] == "pso"
                   and r["metric"] == "F")
        self.assertEqual(row["n"], 2)
        self.assertAlmostEqual(row["mean"], .3)
        self.assertAlmostEqual(row["sd"], 0.1414213562373095)
        tc = next(r for r in rows if r["n_uav"] == 5 and r["method"] == "pso"
                  and r["metric"] == "TC")
        self.assertAlmostEqual(tc["mean"], 70.0)
        self.assertEqual(tc["unit"], "%")

    def test_single_and_missing_runs_do_not_invent_zero_sd(self):
        report = self.module()
        data = synthetic_data(n_runs=1)
        data["runs"] = data["runs"][:1]
        rows = report.summary_rows(data)
        single = [row for row in rows if row["n"] == 1]
        missing = [row for row in rows if row["n"] == 0]
        self.assertEqual(len(single), 5)
        self.assertTrue(missing)
        self.assertTrue(all(row["sd"] is None for row in rows))
        self.assertTrue(all(row["mean"] is None for row in missing))

    def test_effect_is_signed_raw_difference_and_fixed_seed_bootstrap(self):
        report = self.module()
        first = report.paired_effect([1., 2., 3.], [2., 3., 4.], n_boot=100)
        second = report.paired_effect([1., 2., 3.], [2., 3., 4.], n_boot=100)
        self.assertEqual(first, second)
        self.assertEqual(first["median_difference"], -1.0)
        self.assertEqual(first["abs_median_difference"], 1.0)
        self.assertEqual((first["ci_low"], first["ci_high"]), (-1.0, -1.0))

    def test_holm_is_one_family_across_all_counts_comparators_and_metrics(self):
        report = self.module()
        data = synthetic_data(n_runs=20, methods=("pso", "ahdpso", "ql_apso"))
        tests = report.paired_test_rows(data, n_boot=100)
        self.assertEqual(len(tests), 20)
        self.assertTrue(all(row["family_size"] == 20 for row in tests))
        p_values = np.array([row["p_raw"] for row in tests])
        order = np.argsort(p_values)
        expected = np.empty(20)
        expected[order] = np.minimum(1.0, np.maximum.accumulate(
            p_values[order] * np.arange(20, 0, -1)))
        np.testing.assert_allclose([row["p_holm"] for row in tests], expected)
        self.assertEqual({row["reference"] for row in tests}, {"ql_apso"})
        # Correcting only five tests in each subgroup would give the wrong result.
        self.assertGreater(tests[0]["p_holm"], tests[0]["p_raw"] * 5)

    def test_paired_comparisons_reject_mismatched_seed_or_run_identity(self):
        report = self.module()
        data = synthetic_data(n_runs=20)
        data["runs"][0]["priority_seed"] += 1
        with self.assertRaisesRegex(ValueError, "pair|seed"):
            report.paired_test_rows(data, n_boot=10)
        data = synthetic_data(n_runs=20)
        data["runs"].pop(0)
        with self.assertRaisesRegex(ValueError, "pair|run"):
            report.paired_test_rows(data, n_boot=10)

    def test_common_deployment_run_is_selected_once_across_all_six_counts(self):
        report = self.module()
        data = synthetic_data(n_runs=3, counts=(5, 10, 15, 20, 25, 30),
                              methods=("ql_apso",))
        objectives = {5: [1, 2, 3], 10: [2, 1, 3], 15: [3, 2, 1],
                      20: [1, 3, 2], 25: [2, 1, 3], 30: [1, 2, 3]}
        for run in data["runs"]:
            run["best_F"] = objectives[run["scenario"]["n_uav"]][run["i"]]
        self.assertEqual(report.select_common_run_id(data, "ql_apso"), 1)

    def test_wrong_model_or_schema_is_rejected(self):
        report = self.module()
        data = synthetic_data()
        data["model_version"] = "old-objective"
        with self.assertRaisesRegex(ValueError, "model_version"):
            report.validate_results(data)
        data = synthetic_data()
        data["schema_version"] = "v3"
        with self.assertRaisesRegex(ValueError, "schema_version"):
            report.validate_results(data)

    def test_invalid_nonformal_records_are_rejected(self):
        report = self.module()
        valid = synthetic_data()
        for field, value in (("seed", 999), ("best_F", float("nan")),
                             ("best_pos", [-1.] * 15), ("i", 100)):
            with self.subTest(field=field):
                data = deepcopy(valid)
                data["runs"][0][field] = value
                with self.assertRaises(ValueError):
                    report.validate_results(data)
        for value in (-.5, 1.5):
            with self.subTest(coverage=value):
                data = deepcopy(valid)
                data["runs"][0]["final_metrics"]["TC"] = value
                with self.assertRaisesRegex(ValueError, "metric"):
                    report.validate_results(data)

    def test_bad_history_does_not_replace_or_delete_existing_report(self):
        report = self.module()
        data = synthetic_data(n_runs=1)
        data["runs"].pop()
        data["runs"][0]["history_fes"] = [2, 2, 10]
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory)/"input.json"
            source.write_text(json.dumps(data), encoding="utf-8")
            output = Path(directory)/"report"
            output.mkdir()
            names = ("summary.csv", "paired_tests.csv", "report.md",
                     "metrics_vs_uav_count.pdf", "convergence_by_fes.pdf",
                     "uav_count_layouts_2d.pdf", "uav_count_layouts_3d.pdf")
            expected = {name: ("existing " + name).encode() for name in names}
            for name, content in expected.items():
                (output/name).write_bytes(content)
            with self.assertRaisesRegex(ValueError, "history"):
                report.generate_report(source, output)
            self.assertEqual({p.name: p.read_bytes() for p in output.iterdir()}, expected)

    def test_render_failure_preserves_complete_previous_report(self):
        report = self.module()
        data = synthetic_data(n_runs=1)
        data["runs"].pop()
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory)/"input.json"
            source.write_text(json.dumps(data), encoding="utf-8")
            output = Path(directory)/"report"
            output.mkdir()
            expected = {name: ("previous " + name).encode() for name in (
                "summary.csv", "paired_tests.csv", "report.md", "notes.txt",
                "metrics_vs_uav_count.pdf", "convergence_by_fes.pdf")}
            for name, content in expected.items():
                (output/name).write_bytes(content)
            original_save = report._save_pdf
            def interrupted_save(figure, path, title, formal):
                if path.name == "convergence_by_fes.pdf":
                    import matplotlib.pyplot as plt
                    plt.close(figure)
                    raise OSError("simulated renderer failure")
                return original_save(figure, path, title, formal)
            with patch.object(report, "_save_pdf", side_effect=interrupted_save):
                with self.assertRaisesRegex(OSError, "renderer failure"):
                    report.generate_report(source, output)
            self.assertEqual({p.name: p.read_bytes() for p in output.iterdir()}, expected)

    def test_publish_failure_restores_replaced_files_and_preserves_unrelated_file(self):
        report = self.module()
        with tempfile.TemporaryDirectory() as directory:
            output, stage = Path(directory)/"report", Path(directory)/"stage"
            output.mkdir()
            stage.mkdir()
            expected = {name: ("old " + name).encode() for name in (
                "summary.csv", "report.md", "convergence_by_fes.pdf", "notes.txt")}
            for name, content in expected.items():
                (output/name).write_bytes(content)
            for name in ("summary.csv", "report.md", "convergence_by_fes.pdf"):
                (stage/name).write_text("new " + name, encoding="utf-8")
            replace = Path.replace
            def locked_file(path, target):
                if path == stage/"convergence_by_fes.pdf":
                    raise PermissionError("simulated viewer lock")
                return replace(path, target)
            with patch.object(Path, "replace", new=locked_file):
                with self.assertRaisesRegex(PermissionError, "viewer lock"):
                    report._publish_report(stage, output)
            self.assertEqual({p.name: p.read_bytes() for p in output.iterdir()
                              if p.name != ".run.lock"}, expected)

    def test_publication_refuses_a_concurrent_writer_without_changing_artifacts(self):
        from run_v4 import directory_lock
        report = self.module()
        with tempfile.TemporaryDirectory() as directory:
            output, stage = Path(directory)/"report", Path(directory)/"stage"
            output.mkdir()
            stage.mkdir()
            (output/"summary.csv").write_text("prior report", encoding="utf-8")
            (stage/"summary.csv").write_text("another report", encoding="utf-8")
            with directory_lock(output):
                with self.assertRaisesRegex(RuntimeError, "already|lock"):
                    report._publish_report(stage, output)
            self.assertEqual((output/"summary.csv").read_text(), "prior report")
            self.assertTrue((stage/"summary.csv").exists())

    def test_complete_formal_fixture_exports_one_180_comparison_family(self):
        # This is a constructed report fixture, not optimizer performance data.
        # Identical method values give the independently known p=1 for all pairs.
        import run_v4
        from scenario import DeploymentScenario
        config = run_v4.make_config("main")
        data = dict(schema_version=run_v4.SCHEMA, model_version=model.MODEL_VERSION,
                    result_kind="main", config=config,
                    provenance={"source_sha256": run_v4.source_hashes(),
                                "runtime": run_v4.runtime_fingerprint()}, runs=[])
        for count in config["counts"]:
            scene = DeploymentScenario(ScenarioConfig(n_uav=count))
            position = np.tile([2500., 2500., 200.], count).tolist()
            for i in range(20):
                priority_seed = config["priority_seed_base"]+i
                metrics = scene.evaluate(position, scene.priority_mask(priority_seed), "a2g")
                for method in config["algorithms"]:
                    data["runs"].append(dict(
                        i=i, method=method, algo=method,
                        seed=config["optimization_seed_base"]+i,
                        feedback_seed=config["feedback_seed_base"]+i,
                        priority_seed=priority_seed, scenario=scene.config.to_dict(),
                        scenario_id=f"{count}uav", best_pos=position,
                        best_F=metrics["F"], final_metrics=metrics, fes=25000,
                        n_updates=499, runtime_seconds=.1,
                        history_fes=[50, 25000], gF_history=[metrics["F"]+.1, metrics["F"]]))
        report = self.module()
        with tempfile.TemporaryDirectory(prefix="synthetic_report_fixture_") as directory:
            source = Path(directory)/"synthetic_fixture_only.json"
            source.write_text(json.dumps(data), encoding="utf-8")
            result = report.generate_report(source)
            self.assertTrue(result["formal"])
            with Path(result["paired_tests_csv"]).open(encoding="utf-8", newline="") as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(len(rows), 180)
            self.assertTrue(all(int(r["family_size"]) == 180 for r in rows))
            self.assertTrue(all(float(r["p_holm"]) == 1. for r in rows))
            for key in ("metrics_pdf", "convergence_pdf", "atlas_2d_pdf", "atlas_3d_pdf"):
                self.assertTrue(Path(result[key]).is_file(), key)
            self.assertIn("FORMAL: qualified", Path(result["report_md"]).read_text(encoding="utf-8"))
            self.assertEqual(list(Path(directory).glob(".report-*")), [])

    def test_convergence_uses_actual_fes_and_never_looks_ahead(self):
        report = self.module()
        data = synthetic_data(n_runs=1, counts=(5,), methods=("ql_apso",))
        data["runs"][0]["gF_history"] = [1.0, .8, .3]
        series = report.convergence_series(data, grid=[2, 3, 5, 7, 10])
        self.assertEqual(len(series), 1)
        np.testing.assert_array_equal(series[0]["fes"], [2, 3, 5, 7, 10])
        np.testing.assert_allclose(series[0]["mean"], [1., 1., .8, .8, .3])
        self.assertIsNone(series[0]["sd"])
        figure = report.convergence_figure(data, formal=False)
        try:
            self.assertEqual(figure.axes[0].get_xlabel(), "Objective evaluations (FEs)")
            self.assertEqual(figure.axes[0].lines[0].get_drawstyle(), "steps-post")
            self.assertEqual(figure.axes[0].lines[0].get_xdata()[-1], 10)
            figure.canvas.draw()
            self.assertEqual(figure.axes[0].xaxis.get_offset_text().get_text(), "")
        finally:
            import matplotlib.pyplot as plt
            plt.close(figure)

    def test_single_panel_convergence_legend_does_not_overlap_axis_label(self):
        report = self.module()
        data = synthetic_data(n_runs=1, counts=(25,),
                              methods=("pso", "ahdpso", "tadmpso", "amsepso",
                                       "sdpso", "saompso", "ql_apso"))
        figure = report.convergence_figure(data, formal=False)
        try:
            figure.canvas.draw()
            renderer = figure.canvas.get_renderer()
            label_box = figure.axes[0].xaxis.label.get_window_extent(renderer)
            legend_box = figure.legends[0].get_window_extent(renderer)
            self.assertFalse(label_box.overlaps(legend_box))
        finally:
            import matplotlib.pyplot as plt
            plt.close(figure)

    def test_ablation_metric_legend_keeps_a_page_margin(self):
        report = self.module()
        data = synthetic_data(n_runs=1, counts=(25,),
                              methods=("full", "legacy_coefficients", "no_fsw",
                                       "no_alignment", "random_topology",
                                       "no_cross_swarm", "fixed_k", "factor_schedule"))
        figure = report.metrics_figure(data, formal=False)
        try:
            figure.canvas.draw()
            box = figure.axes[5].get_legend().get_window_extent(figure.canvas.get_renderer())
            self.assertLessEqual(box.x1, figure.bbox.x1 - 10)
        finally:
            import matplotlib.pyplot as plt
            plt.close(figure)

    def test_convergence_does_not_extrapolate_unfinished_histories(self):
        report = self.module()
        data = synthetic_data(n_runs=2, counts=(5,), methods=("ql_apso",))
        data["runs"][0]["fes"] = 5
        data["runs"][0]["history_fes"] = [2, 5]
        data["runs"][0]["gF_history"] = [1., .8]
        result = report.convergence_series(data, grid=[2, 3, 5, 7, 10])[0]
        np.testing.assert_array_equal(result["fes"], [2, 3, 5])
        self.assertEqual(result["n"], 2)

    def test_partial_output_is_nonformal_and_removes_stale_inferential_file(self):
        report = self.module()
        data = synthetic_data(n_runs=1)
        data["runs"].pop()
        with tempfile.TemporaryDirectory(prefix="nonformal_report_v4_") as directory:
            source = Path(directory) / "synthetic_validation_only.json"
            source.write_text(json.dumps(data), encoding="utf-8")
            output = Path(directory) / "report"
            output.mkdir()
            (output / "paired_tests.csv").write_text("stale inference", encoding="utf-8")
            result = report.generate_report(source, output)
            self.assertFalse(result["formal"])
            self.assertFalse(result["complete"])
            text = Path(result["report_md"]).read_text(encoding="utf-8")
            self.assertIn("NONFORMAL", text)
            self.assertIn("SD unavailable", text)
            self.assertIn("fixed-weight", text)
            self.assertFalse((output / "paired_tests.csv").exists())
            self.assertEqual(result["paired_tests_csv"], None)
            self.assertEqual(result["atlas_status"], "skipped: incomplete experiment matrix")
            for key in ("metrics_pdf", "convergence_pdf", "summary_csv"):
                self.assertTrue(Path(result[key]).is_file())
            with Path(result["summary_csv"]).open(encoding="utf-8", newline="") as stream:
                rows = list(csv.DictReader(stream))
            self.assertTrue(all(row["sd"] == "" for row in rows))
            self.assertTrue(all(row["evidence_status"] == "NONFORMAL" for row in rows))

    def test_complete_six_count_nonformal_data_prepares_atlas_but_bad_metrics_raise(self):
        report = self.module()
        data = synthetic_data(n_runs=1, counts=(5, 10, 15, 20, 25, 30),
                              methods=("ql_apso",))
        with self.assertRaisesRegex(ValueError, "metric|layout"):
            report.prepare_deployment_panels(data, complete=True)
        panels, status, run_id = report.prepare_deployment_panels(data, complete=False)
        self.assertIsNone(panels)
        self.assertIsNone(run_id)
        self.assertEqual(status, "skipped: incomplete experiment matrix")

    def test_atlas_watermark_is_exported_and_default_remains_unmarked(self):
        try:
            import pymupdf
        except ImportError:
            self.skipTest("PyMuPDF is used only to inspect the rendered PDF")
        import deployment_atlas as atlas
        import matplotlib.pyplot as plt

        with tempfile.TemporaryDirectory(prefix="nonformal_atlas_pdf_") as directory:
            output = Path(directory)
            for name, watermark in [("validation", "NONFORMAL / validation only"),
                                     ("normal", None)]:
                figure, axis = plt.subplots(figsize=(4, 3))
                axis.plot([0, 1], [0, 1])
                atlas.save_figure(figure, output, name, watermark=watermark)
                with pymupdf.open(output / f"{name}.pdf") as pdf:
                    text = "".join(page.get_text() for page in pdf)
                self.assertEqual("NONFORMAL" in text, watermark is not None)

    def test_six_panel_atlas_watermark_does_not_cover_panel_titles(self):
        try:
            import pymupdf
        except ImportError:
            self.skipTest("PyMuPDF is used only to inspect the rendered PDF")
        import deployment_atlas as atlas
        from scenario import DeploymentScenario

        data = synthetic_data(n_runs=1, counts=(5, 10, 15, 20, 25, 30),
                              methods=("ql_apso",))
        for run in data["runs"]:
            scene = DeploymentScenario(ScenarioConfig.from_dict(run["scenario"]))
            metrics = scene._evaluate(run["best_pos"], scene.priority_mask(run["priority_seed"]),
                                      "a2g", use_gpu=False)
            run["best_F"] = metrics["F"]
            run["final_metrics"] = metrics
        panels = atlas.prepare_panels(data, algo="ql_apso", run_id=0)
        with tempfile.TemporaryDirectory(prefix="nonformal_atlas_layout_") as directory:
            output = Path(directory)
            atlas.render_atlas(panels, output, watermark="NONFORMAL / validation only")
            for filename in ("uav_count_layouts_2d.pdf", "uav_count_layouts_3d.pdf"):
                with pymupdf.open(output / filename) as pdf:
                    spans = [span for block in pdf[0].get_text("dict")["blocks"]
                             if "lines" in block for line in block["lines"] for span in line["spans"]]
                    banner = next(pymupdf.Rect(span["bbox"]) for span in spans
                                  if "NONFORMAL" in span["text"])
                    titles = [pymupdf.Rect(span["bbox"]) for span in spans
                              if "UAV-BSs" in span["text"]]
                    self.assertEqual(len(titles), 6)
                    self.assertTrue(all(not banner.intersects(box) for box in titles), filename)


if __name__ == "__main__":
    unittest.main()
