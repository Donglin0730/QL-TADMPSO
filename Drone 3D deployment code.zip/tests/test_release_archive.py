"""Portable archive checks use copies and never alter the published evidence."""
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
SOURCE = HERE / 'outputs/rebuild_v5/formal_5_to_50'
SCRIPT = HERE / 'tools/verify_archive.py'


class ReleaseArchiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not SCRIPT.is_file():
            return
        spec = importlib.util.spec_from_file_location('verify_archive', SCRIPT)
        cls.module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.module)

    def setUp(self):
        self.assertTrue(SCRIPT.is_file(), 'the portable archive verifier is missing')
        base = HERE.parent / 'tmp'
        base.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix='release_archive_', dir=base)
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.root = self.folder / 'moved_archive'
        shutil.copytree(SOURCE, self.root)

    def write_json(self, path, data):
        path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')

    def reseal(self, path, data):
        data['content_sha256'] = self.module.protocol.result_digest(data)
        self.write_json(path, data)

    def test_relocated_archive_reproduces_statistics_without_coordinate_evaluation(self):
        before = {str(p.relative_to(self.root)): self.module.protocol.file_digest(p)
                  for p in self.root.rglob('*') if p.is_file()}
        with patch('scenario.DeploymentScenario._evaluate', side_effect=AssertionError('CPU statistics must not evaluate coordinates')):
            result = self.module.verify_archive(self.root, self.folder / 'verified')
        self.assertEqual(result['records'], 620)
        self.assertEqual(result['summary_rows'], 186)
        self.assertEqual(result['paired_rows'], 132)
        self.assertEqual(result['coordinate_reconstruction'], 'not_run')
        self.assertEqual(result['statistics'], 'passed')
        after = {str(p.relative_to(self.root)): self.module.protocol.file_digest(p)
                 for p in self.root.rglob('*') if p.is_file()}
        self.assertEqual(before, after)

    def test_changed_selection_is_rejected(self):
        path = self.root / 'selection.json'
        data = json.loads(path.read_text(encoding='utf-8'))
        data['selected_count'] = 40
        self.write_json(path, data)
        with self.assertRaisesRegex(ValueError, 'selection'):
            self.module.read_archive(self.root)

    def test_missing_original_absolute_paths_are_resolved_by_evidence_hash(self):
        path = self.root / 'selection.json'
        choice = json.loads(path.read_text(encoding='utf-8'))
        choice['count_result_path'] = str(self.folder / 'deleted_machine/count/results.json')
        choice['selection_sha256'] = self.module.protocol.digest({k: v for k, v in choice.items() if k != 'selection_sha256'})
        self.write_json(path, choice)
        for stage in ('ablation', 'comparison'):
            path = self.root / stage / 'results.json'
            data = json.loads(path.read_text(encoding='utf-8'))
            data['config']['selection'] = choice
            self.reseal(path, data)
        path = self.root / 'mechanism/results.json'
        data = json.loads(path.read_text(encoding='utf-8'))
        data['selection_path'] = str(self.folder / 'deleted_machine/selection.json')
        data['selection_sha256'] = choice['selection_sha256']
        self.reseal(path, data)
        archive = self.module.read_archive(self.root)
        self.assertEqual(archive['selection']['selected_count'], 45)
        self.assertFalse(Path(choice['count_result_path']).exists())

    def test_resealed_incomplete_matrix_is_rejected(self):
        path = self.root / 'ablation/results.json'
        data = json.loads(path.read_text(encoding='utf-8'))
        data['runs'].pop()
        data['status']['completed'] -= 1
        self.reseal(path, data)
        with self.assertRaisesRegex(ValueError, 'matrix'):
            self.module.read_archive(self.root)

    def test_resealed_bad_seed_is_rejected(self):
        path = self.root / 'comparison/results.json'
        data = json.loads(path.read_text(encoding='utf-8'))
        data['runs'][0]['seed'] += 1
        self.reseal(path, data)
        with self.assertRaisesRegex(ValueError, 'seed'):
            self.module.read_archive(self.root)

    def test_modified_snapshot_is_rejected(self):
        path = self.root / 'comparison/source_snapshot/scenario.py'
        path.write_bytes(path.read_bytes() + b'\n# changed\n')
        with self.assertRaisesRegex(ValueError, 'snapshot'):
            self.module.read_archive(self.root)

    def test_resealed_invalid_coordinates_are_rejected_without_evaluation(self):
        path = self.root / 'comparison/results.json'
        data = json.loads(path.read_text(encoding='utf-8'))
        data['runs'][0]['best_pos'][0] = -1
        self.reseal(path, data)
        with self.assertRaisesRegex(ValueError, 'deployment'):
            self.module.read_archive(self.root)

    def test_modified_saved_csv_is_rejected(self):
        path = self.root / 'comparison/report/summary.csv'
        lines = path.read_text(encoding='utf-8').splitlines()
        values = lines[1].split(',')
        values[-1] = str(float(values[-1]) + .01)
        lines[1] = ','.join(values)
        path.write_text('\n'.join(lines), encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'CSV'):
            self.module.verify_archive(self.root, self.folder / 'bad_csv')

    def test_existing_output_and_output_inside_evidence_are_rejected(self):
        output = self.folder / 'existing'
        output.mkdir()
        (output / 'keep.txt').write_text('keep', encoding='utf-8')
        for path in (output, self.root / 'new_report'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                self.module.verify_archive(self.root, path)
        self.assertEqual((output / 'keep.txt').read_text(encoding='utf-8'), 'keep')
        self.assertFalse((self.root / 'new_report').exists())


if __name__ == '__main__':
    unittest.main()
