"""Scientific-integrity checks for the publication deployment atlas."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scenario import DeploymentScenario, ScenarioConfig


class DeploymentAtlasTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = {"config": {"mode": "a2g", "max_fes": 25000}, "runs": []}
        for count in (5, 10):
            scene = DeploymentScenario(ScenarioConfig(n_uav=count))
            low, high = scene.bounds()
            pos = np.random.default_rng(9100).uniform(low, high)
            metrics = scene._evaluate(pos, scene.priority_mask(910), "a2g", use_gpu=False)
            cls.data["runs"].append({
                "algo": "ql", "i": 0, "seed": 9100, "priority_seed": 910,
                "scenario": scene.config.to_dict(), "best_pos": pos.tolist(),
                "best_F": metrics["F"], "final_metrics": metrics, "fes": 25000,
            })

    def atlas(self):
        try:
            import deployment_atlas
        except ImportError:
            self.fail("The validated deployment-atlas module is not implemented")
        return deployment_atlas

    def test_accepts_paired_real_positions_and_preserves_actual_coverage(self):
        panels = self.atlas().prepare_panels(self.data, counts=(5, 10), run_id=0)
        self.assertEqual([p["positions"].shape for p in panels], [(5, 3), (10, 3)])
        for p in panels:
            self.assertAlmostEqual(p["covered"].mean(), p["metrics"]["TC"])
            self.assertAlmostEqual(sum(p["components"]), p["metrics"]["F"])
        np.testing.assert_array_equal(panels[0]["priority"], panels[1]["priority"])

    def test_rejects_different_maps_in_comparable_panels(self):
        data = deepcopy(self.data)
        data["runs"][1]["priority_seed"] += 1
        with self.assertRaisesRegex(ValueError, "priority|map"):
            self.atlas().prepare_panels(data, counts=(5, 10), run_id=0)

    def test_rejects_stale_or_invented_metrics(self):
        data = deepcopy(self.data)
        data["runs"][0]["final_metrics"]["TC"] = 1.0
        with self.assertRaisesRegex(ValueError, "metric|TC"):
            self.atlas().prepare_panels(data, counts=(5, 10), run_id=0)

    def test_rejects_missing_requested_uav_count(self):
        with self.assertRaisesRegex(ValueError, "15|missing"):
            self.atlas().prepare_panels(self.data, counts=(5, 10, 15), run_id=0)

    def test_rejects_unequal_evaluation_budgets(self):
        data = deepcopy(self.data)
        data["runs"][1]["fes"] = 500
        with self.assertRaisesRegex(ValueError, "budget|FEs"):
            self.atlas().prepare_panels(data, counts=(5, 10), run_id=0)


if __name__ == "__main__":
    unittest.main()
