from pathlib import Path
import importlib.util
import json
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


class ReleaseEntryTests(unittest.TestCase):
    def setUp(self):
        path = ROOT / 'reproduce.py'
        self.assertTrue(path.is_file(), 'portable entry point is missing')
        spec = importlib.util.spec_from_file_location('release_entry', path)
        self.entry = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.entry)

    def test_archived_results_cannot_be_used_as_new_output(self):
        for path in (self.entry.ARCHIVE, self.entry.ARCHIVE / 'count'):
            with self.assertRaises(ValueError):
                self.entry.campaign_root(path)
        self.assertEqual(self.entry.campaign_root(ROOT / 'outputs/reproduction_test'),
                         ROOT / 'outputs/reproduction_test')

    def test_checksums_detect_changed_files(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'sample.py').write_bytes(b'original')
            manifest = root / 'checksums.json'
            import hashlib
            manifest.write_text(json.dumps({'files': {
                'sample.py': hashlib.sha256(b'original').hexdigest()}}))
            self.assertEqual(self.entry.check_files(root, manifest), 1)
            (root / 'sample.py').write_bytes(b'changed')
            with self.assertRaises(ValueError):
                self.entry.check_files(root, manifest)

    def test_cpu_environment_limits_threads(self):
        env = self.entry.runtime_environment('cpu')
        self.assertEqual(env['CUDA_VISIBLE_DEVICES'], '-1')
        self.assertEqual(env['OPENBLAS_NUM_THREADS'], '1')

    def test_custom_count_requires_a_reason_before_running(self):
        with patch.object(self.entry.subprocess, 'run') as run:
            self.assertEqual(self.entry.main(['all', '--uav-count', '40']), 2)
            run.assert_not_called()

    def test_smoke_forwards_an_explicit_count(self):
        with patch.object(self.entry.subprocess, 'run') as run:
            self.assertEqual(self.entry.main(['smoke', '--uav-count', '45']), 0)
            command = run.call_args.args[0]
            self.assertEqual(command[command.index('--uav-count') + 1], '45')


if __name__ == '__main__':
    unittest.main()
