# QL-TADMPSO: UAV-BS 3D deployment experiments

This directory contains the algorithms, simulation model, comparison methods, raw data and reproduction tools. Formal results live in `outputs/rebuild_v5/formal_5_to_50/`. The public license awaits confirmation from the author and advisor; no LICENSE is included yet.

## Installation

The verified environment is Windows 11 x64, Python 3.12.10. Run in this directory:

```text
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements-lock-cpu.txt
```

On Linux the activation command is `source .venv/bin/activate`; that platform has not been tested yet. The original `requirements.txt` keeps lower bounds; for reproduction use the pinned version file.

The original paper results used a GPU. On Windows, put the project and the virtual environment in a path without Chinese characters (for example `D:\uavbs\experiments`) before creating the environment; this review found that installing CuPy under a Chinese path makes CUDA header compilation fail. When you need to re-check the original records from coordinates or rerun experiments with CUDA, also install:

```text
python -m pip install -r requirements-lock-cuda.txt
```

The matching CUDA stack is CuPy 14.1.1 / CUDA 12.9; an NVIDIA GPU and a compatible driver are required, and these packages do not install the driver. The pinned dependencies were installed in a fresh virtual environment and passed the dependency check on an RTX 4060 Laptop GPU; bitwise or timing equality across hardware is not guaranteed.

If the system temp directory is not writable or contains Chinese characters, point TEMP/TMP at a writable English directory for the run in PowerShell:

```powershell
New-Item -ItemType Directory -Force .\cuda_tmp | Out-Null
$env:TEMP = (Resolve-Path .\cuda_tmp).Path
$env:TMP = $env:TEMP
```

## Check the saved results

```text
python reproduce.py check
python reproduce.py stats
```

`check` verifies the SHA-256 of the frozen source and data. `stats` recomputes means, standard deviations, two-sided Wilcoxon tests, Holm correction and bootstrap intervals from the saved metrics on CPU, and cross-checks them item by item against the original CSVs. Output goes to `outputs/reproduction_stats/`; a rerun needs a new directory via `--output`.

With a GPU, you can go further and recompute the metrics from the final coordinates of the 620 optimizations:

```text
python reproduce.py verify --device cuda
```

It uses the original evaluation function and tolerances and does not rerun the optimization search. A successful CPU statistics check does not mean the physical metric recomputation is done. Absolute paths in the old JSON are kept; the new tool locates files by the current directory and verifies the source digests.

## Run the experiments from scratch

First check the tests and the small-scale pipeline:

```text
python -m pip install -r requirements-test.txt
python reproduce.py test
python reproduce.py smoke
```

CPU is the default. `smoke` uses 12 particles, 120 evaluations and 1 repetition, and only validates the pipeline. Add `--device cuda` to use the GPU; the GPU tests also keep the original time thresholds, which a different GPU may not meet.

Full paper protocol:

```text
python reproduce.py all --device cuda --root outputs/reproduction_paper
```

This runs the count experiment, records the 45-UAV selection, the numbering diagnostics, the ablation and the algorithm comparison in order. Each condition has 20 runs, 50 particles and 25,000 objective evaluations. Without a GPU you can drop `--device cuda`, but fresh CPU results are not a bitwise reproduction of the original GPU records. For staged runs replace `all` with `count`, `select` or `continue`. After an interruption, resume with the same environment and command; use a new directory if the environment changed.

The new entry points refuse to use a formal archive directory for new experiments. The three `.cmd` files use the same new entry points and the current virtual environment, defaulting to CPU and `outputs/reproduction_paper/`.

## Figures

```text
python reproduce.py figures
python reproduce.py figures --device cuda --output outputs/reproduction_figures_cuda
```

CPU generates the performance, convergence and numbering-diagnosis figures; GPU also generates the 2D/3D deployment and aggregate-power figures. [paper_figures](paper_figures/README.md) keeps the 7 final experiment figures used in the paper plus their source table. The original figures have manual layout adjustments; the redrawn script versions keep the data sources but do not guarantee pixel-identical output.

## Files and protocol

| Content | File |
| --- | --- |
| QL-TADMPSO, PSO, AHDPSO, T-ADMPSO | `algorithms.py` |
| FSW grouping, guide matching | `topology.py` |
| Scenario, channel, objective evaluation | `scenario.py`, `model.py`, `evaluation.py` |
| Other baselines | `baseline_amsepso.py`, `baseline_sdpso.py`, `baseline_saompso.py` |
| Frozen experiment entry, statistics | `run_v5.py`, `report_v5.py` |
| Release tooling | `reproduce.py`, `tools/` |

Count, ablation and comparison save 200, 280 and 140 optimizations respectively; the numbering diagnostics are 40 deployment snapshots. Different stages must not be mixed into one run group. Old-version-numbered files are still used by the current code; do not delete them by name.

The detailed protocol is in [README_v5.md](README_v5.md), the implementation basis in [SOURCES.md](SOURCES.md) and [docs](docs/), and the delivery status in [RELEASE_READINESS.md](RELEASE_READINESS.md). The additions in this release are limited to the run entry points, read-only re-checking and figure export; the original algorithms, experiment parameters and data are unchanged.
