@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "UAV_PYTHON=python"
if not defined VIRTUAL_ENV if exist ".venv\Scripts\python.exe" set "UAV_PYTHON=.venv\Scripts\python.exe"
"%UAV_PYTHON%" -B -u reproduce.py count --root outputs/reproduction_paper
set "UAV_EXIT_CODE=%ERRORLEVEL%"
if errorlevel 1 echo Stopped. See the error above.
pause
exit /b %UAV_EXIT_CODE%
