"""Actual candidate-evaluation budget and immutable best archive for the v4 baselines."""
import numpy as np

from evaluation import ObjectiveEvaluator


class SearchBudget:
    def __init__(self, rng, priority, mode, n_p, max_fes, scenario):
        if int(n_p) != n_p or int(max_fes) != max_fes or n_p < 1 or max_fes < n_p:
            raise ValueError("max_fes must include a positive integer initialization population")
        self.rng, self.scenario = rng, scenario
        self.n_p, self.max_fes = int(n_p), int(max_fes)
        self.lower, self.upper = (np.asarray(x, dtype=float) for x in scenario.bounds())
        self.dimension = len(self.lower)
        self.evaluator = ObjectiveEvaluator(priority, mode, self.max_fes, scenario=scenario)
        self.best_pos, self.best_metrics, self.best_F = None, None, float("inf")
        self.history_fes, self.gF_history = [], []

    @property
    def fes(self):
        return self.evaluator.fes

    @property
    def remaining(self):
        return self.max_fes - self.fes

    @property
    def progress(self):
        denominator = self.max_fes - self.n_p
        return float(np.clip((self.fes - self.n_p) / denominator, 0, 1)) if denominator else 1.0

    def evaluate(self, X):
        X = np.asarray(X, dtype=float)
        if X.ndim != 2 or X.shape[1] != self.dimension or not len(X):
            raise ValueError("candidate batch has invalid shape")
        if not np.isfinite(X).all() or np.any(X < self.lower) or np.any(X > self.upper):
            raise ValueError("candidate coordinates must be finite and within bounds")
        fitness, metrics = self.evaluator.evaluate_population(X)
        if not np.isfinite(fitness).all():
            raise ValueError("objective returned nonfinite fitness")
        index = int(np.argmin(fitness))
        if fitness[index] < self.best_F:
            self.best_F = float(fitness[index])
            self.best_pos = X[index].copy()
            self.best_metrics = dict(metrics[index])
        self.history_fes.append(self.fes)
        self.gF_history.append(self.best_F)
        return fitness, metrics

    def evaluate_one(self, x):
        fitness, metrics = self.evaluate(np.asarray(x).reshape(1, -1))
        return float(fitness[0]), metrics[0]

    def result(self, n_updates, diagnostics=None):
        if self.best_pos is None:
            raise ValueError("no evaluated candidate to report")
        return {
            "best_pos": self.best_pos.copy(), "best_F": self.best_F,
            "final_metrics": dict(self.best_metrics), "fes": self.fes,
            "gF_history": list(self.gF_history), "history_fes": list(self.history_fes),
            "n_updates": int(n_updates), "diagnostics": diagnostics or {},
        }
