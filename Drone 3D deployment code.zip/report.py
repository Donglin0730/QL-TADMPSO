"""Statistics and Markdown report generator for versioned experiment results.

For the formal comparison, all paired tests are first aligned by ``run i``,
then the 3x5 tests of QL-TADMPSO vs PSO/AHDPSO/T-ADMPSO are Holm-corrected
as one test family. Command-line use prints the report to the terminal and
persists it under ``reports/``.

Usage: python report.py [results.json]
"""
import json
import os
import sys

import numpy as np
from scipy import stats

import model
import run_exp
from scenario import ScenarioConfig

HERE = os.path.dirname(os.path.abspath(__file__))
REPORT_DIR = os.path.join(HERE, "reports")
METRICS = ["best_F", "TC", "SAC", "SASU", "GASU"]
METRIC_LABEL = {
    "best_F": "F",
    "TC": "TC (%)",
    "SAC": "SAC (%)",
    "SASU": "SASU (dB)",
    "GASU": "GASU (dB)",
}
ALGO_LABEL = {
    "pso": "PSO",
    "ahdpso": "AHDPSO",
    "tadmpso": "T-ADMPSO (deployment-adapted)",
    "ql": "QL-TADMPSO",
}
VARIANT_LABEL = {
    "full": "Full algorithm",
    "no_fsw": "No FSW",
    "no_alignment": "No alignment",
    "random_topology": "Random partition",
    "no_cross_swarm": "No cross-swarm exchange",
    "fixed_k": "Fixed k",
    "factor_schedule": "Factor schedule",
}
VARIANT_ORDER = ["no_fsw", "no_alignment", "random_topology",
                 "no_cross_swarm", "fixed_k", "factor_schedule"]
SCHEMA_VERSION = model.MODEL_VERSION
V3_SCHEMA_VERSION = "uav-bs-experiment-results-v3"
V3_MODEL_VERSION = "uav-bs-a2g-ahdpso-scenario-v3"
HELD_OUT_SEED_PROTOCOL = "held_out_v1"
FORMAL_ALGORITHMS = ("pso", "ahdpso", "tadmpso", "ql")


def result_kind(data):
    """Identify the experiment kind from root fields so sensitivity JSON is not mistaken for formal results."""
    explicit = data.get("result_kind")
    if explicit is not None:
        allowed = {
            "full", "ablation", "area_sweep", "uav_sweep",
            "time_budget", "protocol_smoke",
        }
        if explicit not in allowed:
            raise ValueError(f"unrecognized result_kind: {explicit}")
        return explicit
    if "recommended_L" in data:
        return "l_opt"
    if "recommended_G" in data:
        return "g_sensitivity"
    if "snapshots" in data and "shortlist" in data:
        return "l_repr"
    runs = data.get("runs")
    if isinstance(runs, list) and any(run.get("variant") for run in runs):
        return "ablation"
    if isinstance(runs, list):
        return "full"
    raise ValueError("unrecognized result structure")


def validate_results(data):
    """Reject historical JSON with the old objective from current paper statistics."""
    schema = data.get("schema_version")
    if schema not in {SCHEMA_VERSION, V3_SCHEMA_VERSION}:
        raise ValueError("schema_version mismatch or missing")
    expected_model = (
        model.MODEL_VERSION if schema == SCHEMA_VERSION else V3_MODEL_VERSION
    )
    if data.get("model_version") != expected_model:
        raise ValueError("model_version mismatch or missing")
    kind = result_kind(data)
    if kind in {
        "full", "ablation", "area_sweep", "uav_sweep",
        "time_budget", "protocol_smoke",
    } and not isinstance(data.get("runs"), list):
        raise ValueError("runs must be a list")
    if schema == V3_SCHEMA_VERSION:
        run_exp.validate_v3_result_data(data)
    return data


def holm_adjust(p_values):
    """Holm step-down family-wise error correction."""
    p = np.asarray(p_values, dtype=np.float64)
    if p.ndim != 1:
        raise ValueError("p_values must be one-dimensional")
    order = np.argsort(p)
    adjusted = np.empty_like(p)
    running = 0.0
    m = len(p)
    for rank, index in enumerate(order):
        running = max(running, (m - rank) * p[index])
        adjusted[index] = min(1.0, running)
    return adjusted


def paired_effect_summary(a, b, seed=20260830, n_boot=5000):
    """Median paired difference with fixed-seed bootstrap 95% CI."""
    diff = np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64)
    if diff.ndim != 1 or len(diff) == 0:
        raise ValueError("paired samples must be non-empty one-dimensional arrays")
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(diff), size=(int(n_boot), len(diff)))
    boot = np.median(diff[indices], axis=1)
    low, high = np.quantile(boot, [0.025, 0.975])
    return {"median_difference": float(np.median(diff)),
            "ci_low": float(low), "ci_high": float(high)}


def group_runs(data):
    runs = {}
    for run in data.get("runs", []):
        runs.setdefault(run["algo"], []).append(run)
    return runs


def load(path):
    with open(path, encoding="utf-8") as stream:
        data = validate_results(json.load(stream))
    return group_runs(data)


def metric_of(run, metric):
    if metric == "best_F":
        return float(run["best_F"])
    return float(run["final_metrics"][metric])


def better_label(metric, va_mean, vb_mean, a_label, b_label):
    """TC/SAC: larger is better; other metrics: smaller is better."""
    if metric in ("TC", "SAC"):
        winner = a_label if va_mean >= vb_mean else b_label
    else:
        winner = a_label if va_mean <= vb_mean else b_label
    return f"{winner} better"


def _runs_by_id(runs, algo):
    by_id = {int(run["i"]): run for run in runs.get(algo, [])}
    if len(by_id) != len(runs.get(algo, [])):
        raise ValueError(f"duplicate run ids for {algo}")
    return by_id


def _comparison_run_list(runs):
    if isinstance(runs, dict):
        flattened = []
        for algo, rows in runs.items():
            for run in rows:
                row = dict(run)
                row.setdefault("algo", algo)
                flattened.append(row)
        return flattened
    if isinstance(runs, list):
        return list(runs)
    raise TypeError("runs must be a list or algorithm-group dictionary")


def _checkpoint_view(run, checkpoint):
    if checkpoint is None:
        return run
    matches = [
        row for row in run.get("checkpoints", [])
        if np.isclose(
            float(row.get("target_seconds", np.nan)), float(checkpoint),
            rtol=0.0, atol=1e-12,
        )
    ]
    if len(matches) != 1:
        raise ValueError(
            f"run {run.get('i')} {run.get('algo')} requires one "
            f"checkpoint at {checkpoint}"
        )
    checkpoint_row = matches[0]
    return {
        "i": run["i"],
        "best_F": checkpoint_row["best_F"],
        "final_metrics": checkpoint_row["final_metrics"],
    }


def paired_comparison_rows(runs, algorithms=None, scenario_id=None,
                           checkpoint=None):
    """Build one QL-vs-baselines Wilcoxon-Holm family with strict pairing."""
    run_list = _comparison_run_list(runs)
    if scenario_id is not None:
        run_list = [
            run for run in run_list
            if run.get("scenario_id", "default") == scenario_id
        ]
    scenario_ids = {
        run.get("scenario_id", "default") for run in run_list
    }
    if scenario_id is None and len(scenario_ids) > 1:
        raise ValueError("comparison family must contain exactly one scenario")
    present = {run.get("algo") for run in run_list}
    if algorithms is None:
        algorithms = tuple(algo for algo in ALGO_LABEL if algo in present)
    else:
        algorithms = tuple(algorithms)
        missing = [algo for algo in algorithms if algo not in present]
        if missing:
            raise ValueError(f"comparison is missing algorithms: {missing}")
    if "ql" not in algorithms:
        raise ValueError("comparison algorithms must include ql")
    grouped = {
        algo: [run for run in run_list if run.get("algo") == algo]
        for algo in algorithms
    }
    tests = []
    for baseline in (algo for algo in algorithms if algo != "ql"):
        a, b = "ql", baseline
        a_by_id = _runs_by_id(grouped, a)
        b_by_id = _runs_by_id(grouped, b)
        if set(a_by_id) != set(b_by_id):
            raise ValueError(f"unpaired run ids for {a} vs {b}")
        run_ids = sorted(a_by_id)
        for metric in METRICS:
            va = np.asarray([
                metric_of(_checkpoint_view(a_by_id[i], checkpoint), metric)
                for i in run_ids
            ])
            vb = np.asarray([
                metric_of(_checkpoint_view(b_by_id[i], checkpoint), metric)
                for i in run_ids
            ])
            if np.allclose(va, vb, rtol=0.0, atol=0.0):
                p_raw = 1.0
            else:
                p_raw = float(stats.wilcoxon(va, vb).pvalue)
            tests.append({
                "a": a, "b": b, "baseline": baseline,
                "metric": metric, "run_ids": run_ids,
                "values_a": va, "values_b": vb, "p_raw": p_raw,
            })
    adjusted = holm_adjust([row["p_raw"] for row in tests]) if tests else []
    for row, p_holm in zip(tests, adjusted):
        va, vb = row.pop("values_a"), row.pop("values_b")
        effect = paired_effect_summary(va, vb)
        row.update({
            "p_holm": float(p_holm),
            "mean_a": float(va.mean()),
            "mean_b": float(vb.mean()),
            "median_difference": effect["median_difference"],
            "ci_low": effect["ci_low"],
            "ci_high": effect["ci_high"],
            "better": better_label(
                row["metric"], va.mean(), vb.mean(),
                ALGO_LABEL[row["a"]], ALGO_LABEL[row["b"]],
            ),
        })
    return tests


def time_comparison_families(data):
    validate_results(data)
    if result_kind(data) != "time_budget":
        raise ValueError("time comparison families require time_budget data")
    config = data["config"]
    checkpoints = [
        float(value)
        for value in config["stop_protocol"]["checkpoints_seconds"]
    ]
    algorithms = tuple(config.get("algorithms", FORMAL_ALGORITHMS))
    return {
        checkpoint: paired_comparison_rows(
            data["runs"], algorithms=algorithms,
            scenario_id="default", checkpoint=checkpoint,
        )
        for checkpoint in checkpoints
    }


def _sample_std(values):
    values = np.asarray(values, dtype=np.float64)
    return float(values.std(ddof=1)) if len(values) > 1 else 0.0


def ablation_summary(data):
    """Paired statistics for the ablation main metric F; difference = variant F minus full-algorithm F."""
    validate_results(data)
    groups = {}
    for run in data["runs"]:
        variant = run.get("variant")
        if variant:
            groups.setdefault(variant, []).append(run)
    if "full" not in groups:
        raise ValueError("ablation results require a full variant")
    full_by_i = {int(run["i"]): run for run in groups["full"]}
    if len(full_by_i) != len(groups["full"]):
        raise ValueError("duplicate run ids in full variant")

    rows = []
    for variant in VARIANT_ORDER:
        if variant not in groups:
            continue
        variant_by_i = {int(run["i"]): run for run in groups[variant]}
        if len(variant_by_i) != len(groups[variant]):
            raise ValueError(f"duplicate run ids in {variant}")
        if set(variant_by_i) != set(full_by_i):
            raise ValueError(f"unpaired run ids for {variant}")
        ids = sorted(full_by_i)
        full = np.asarray([full_by_i[i]["best_F"] for i in ids])
        changed = np.asarray([variant_by_i[i]["best_F"] for i in ids])
        delta = changed - full
        p_raw = (1.0 if np.allclose(delta, 0.0, rtol=0.0, atol=0.0)
                 else float(stats.wilcoxon(delta).pvalue))
        effect = paired_effect_summary(changed, full)
        rows.append({
            "variant": variant,
            "n": len(ids),
            "mean_F": float(changed.mean()),
            "std_F": _sample_std(changed),
            "mean_delta_F": float(delta.mean()),
            "median_delta_F": effect["median_difference"],
            "ci_low": effect["ci_low"],
            "ci_high": effect["ci_high"],
            "full_wins": int(np.count_nonzero(full < changed)),
            "variant_wins": int(np.count_nonzero(full > changed)),
            "ties": int(np.count_nonzero(full == changed)),
            "p_raw": p_raw,
        })
    adjusted = holm_adjust([row["p_raw"] for row in rows]) if rows else []
    for row, p_holm in zip(rows, adjusted):
        row["p_holm"] = float(p_holm)
    return rows


def _fmt_p(value):
    return f"{value:.2e}" if value < 1e-4 else f"{value:.4f}"


def _normalized(value):
    return json.loads(json.dumps(value, sort_keys=True))


def _valid_fingerprint(value):
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(char in "0123456789abcdef" for char in value)
    )


def _expected_formal_matrix(kind, n_runs):
    if kind == "full":
        return {
            (i, "default", algo, None)
            for i in range(n_runs) for algo in FORMAL_ALGORITHMS
        }
    if kind == "ablation":
        variants = ("full", *VARIANT_ORDER)
        return {
            (i, "default", "ql", variant)
            for i in range(n_runs) for variant in variants
        }
    if kind == "area_sweep":
        return {
            (i, scenario_id, algo, None)
            for i in range(n_runs)
            for scenario_id in ("5km", "7km", "10km")
            for algo in FORMAL_ALGORITHMS
        }
    if kind == "uav_sweep":
        return {
            (i, scenario_id, algo, None)
            for i in range(n_runs)
            for scenario_id in ("10uav", "25uav", "50uav")
            for algo in FORMAL_ALGORITHMS
        }
    if kind == "time_budget":
        return {
            (i, "default", algo, None)
            for i in range(n_runs) for algo in FORMAL_ALGORITHMS
        }
    return set()


def formal_qualification(data):
    """Audit whether a v3 result is complete enough for paper inference."""
    try:
        validate_results(data)
    except (KeyError, TypeError, ValueError) as exc:
        return {
            "formal": False,
            "reasons": [f"v3 record integrity failure: {exc}"],
        }
    reasons = []
    if data.get("schema_version") != V3_SCHEMA_VERSION:
        return {"formal": False, "reasons": ["historical v2 result"]}
    kind = result_kind(data)
    if kind == "protocol_smoke":
        return {"formal": False, "reasons": ["protocol smoke is non-formal"]}
    if data.get("config", {}).get("formal_qualification") is False:
        return {
            "formal": False,
            "reasons": ["result is explicitly marked non-formal"],
        }
    if kind not in {
        "full", "ablation", "area_sweep", "uav_sweep", "time_budget"
    }:
        return {"formal": False, "reasons": ["unsupported formal result kind"]}

    config = data["config"]
    if config.get("evidence_type") != "formal_held_out_v3":
        reasons.append("evidence type must equal formal_held_out_v3")
    if config.get("formal_qualification") is not True:
        reasons.append("formal qualification flag must be explicitly true")
    if int(config.get("n_runs", -1)) != 20:
        reasons.append("n_runs must equal 20")
    if int(config.get("n_p", -1)) != 50:
        reasons.append("population size must equal 50")
    if config.get("mode") != "a2g":
        reasons.append("propagation mode must be a2g")
    if int(config.get("L", -1)) != 50 or int(config.get("G", -1)) != 5:
        reasons.append("selected L/G must equal 50/5")
    if not _valid_fingerprint(config.get("source_fingerprint")):
        reasons.append("source fingerprint is invalid")
    elif config.get("source_fingerprint") != run_exp.optimizer_source_fingerprint():
        reasons.append("source fingerprint does not match current source")
    default_scenario = ScenarioConfig().to_dict()
    if _normalized(config.get("scenario")) != _normalized(default_scenario):
        reasons.append("root scenario is not the registered default")

    expected_algorithms = (
        ("ql",) if kind == "ablation" else FORMAL_ALGORITHMS
    )
    if tuple(config.get("algorithms", ())) != expected_algorithms:
        reasons.append("algorithm registry mismatch")
    expected_protocol = (
        "time_v1" if kind == "time_budget"
        else "robustness_v1" if kind in {"area_sweep", "uav_sweep"}
        else HELD_OUT_SEED_PROTOCOL
    )
    if config.get("seed_protocol") != expected_protocol:
        reasons.append("seed protocol mismatch")

    stop = config.get("stop_protocol", {})
    if kind == "time_budget":
        expected_stop = {
            "kind": "fixed_time", "limit_seconds": 60.0,
            "checkpoints_seconds": [15.0, 30.0, 60.0],
            "max_fes_safety": 5_000_000,
        }
        if _normalized(stop) != _normalized(expected_stop):
            reasons.append("fixed-time stop protocol mismatch")
        if int(config.get("max_fes", -1)) != expected_stop["max_fes_safety"]:
            reasons.append("fixed-time safety FE ceiling mismatch")
        if config.get("timing_protocol") != "time_normalized_v1":
            reasons.append("time-normalized parameter protocol mismatch")
        if not isinstance(config.get("hardware"), dict) or not config["hardware"]:
            reasons.append("hardware fingerprint is missing")
        if config.get("warmup_completed") is not True:
            reasons.append("timing warm-up is incomplete")
    else:
        if _normalized(stop) != {
            "kind": "fixed_fes", "max_fes": 25000
        }:
            reasons.append("fixed-FE stop protocol mismatch")
        if int(config.get("max_fes", -1)) != 25000:
            reasons.append("root fixed-FE budget mismatch")

    runs = data["runs"]
    actual_keys = [
        (
            int(run.get("i", -1)), run.get("scenario_id", "default"),
            run.get("algo"), run.get("variant"),
        )
        for run in runs
    ]
    expected_keys = _expected_formal_matrix(kind, 20)
    if len(actual_keys) != len(set(actual_keys)):
        reasons.append("result matrix contains duplicate keys")
    if set(actual_keys) != expected_keys:
        reasons.append("result matrix is incomplete or has extra rows")

    seed_bases = {
        "held_out_v1": (3000, 300),
        "robustness_v1": (5000, 500),
        "time_v1": (7000, 700),
    }
    optimization_base, priority_base = seed_bases[expected_protocol]
    for run in runs:
        i = int(run.get("i", -1))
        if (
            int(run.get("seed", -1)) != optimization_base + i
            or int(run.get("priority_seed", -1)) != priority_base + i
        ):
            reasons.append("run seed mismatch")
            break
    if kind != "time_budget" and any(
        int(run.get("fes", -1)) != 25000 for run in runs
    ):
        reasons.append("run FE budget mismatch")

    if kind == "time_budget":
        for run in runs:
            targets = [
                float(row.get("target_seconds", np.nan))
                for row in run.get("checkpoints", [])
            ]
            if run.get("stop_reason") != "time_limit":
                reasons.append("timed run did not reach time_limit")
                break
            if targets != [15.0, 30.0, 60.0]:
                reasons.append("timed run checkpoints are incomplete")
                break
        if int(config.get("order_seed_base", -1)) != 9000:
            reasons.append("timed algorithm order seed base mismatch")
        else:
            for i in range(20):
                selected = [run for run in runs if int(run.get("i", -1)) == i]
                if len(selected) != len(FORMAL_ALGORITHMS):
                    continue
                try:
                    observed = tuple(
                        run["algo"] for run in sorted(
                            selected, key=lambda row: int(row["order_index"])
                        )
                    )
                    indices = sorted(int(run["order_index"]) for run in selected)
                    order_seeds = {int(run["order_seed"]) for run in selected}
                except (KeyError, TypeError, ValueError):
                    reasons.append("timed algorithm order metadata is incomplete")
                    break
                rng = np.random.default_rng(9000 + i)
                expected = tuple(
                    np.asarray(FORMAL_ALGORITHMS)[
                        rng.permutation(len(FORMAL_ALGORITHMS))
                    ].tolist()
                )
                if (
                    indices != list(range(len(FORMAL_ALGORITHMS)))
                    or order_seeds != {9000 + i}
                    or observed != expected
                ):
                    reasons.append("timed algorithm order mismatch")
                    break

    scenario_expectations = {
        "area_sweep": {
            "5km": ScenarioConfig(area_m=5000.0, n_grid=50).to_dict(),
            "7km": ScenarioConfig(area_m=7000.0, n_grid=70).to_dict(),
            "10km": ScenarioConfig(area_m=10000.0, n_grid=100).to_dict(),
        },
        "uav_sweep": {
            "10uav": ScenarioConfig(n_uav=10).to_dict(),
            "25uav": ScenarioConfig(n_uav=25).to_dict(),
            "50uav": ScenarioConfig(n_uav=50).to_dict(),
        },
    }
    if kind in scenario_expectations:
        expected = scenario_expectations[kind]
        for run in runs:
            scenario_id = run.get("scenario_id")
            if scenario_id not in expected or _normalized(
                run.get("scenario")
            ) != _normalized(expected[scenario_id]):
                reasons.append("run scenario registry mismatch")
                break
    elif any(
        run.get("scenario_id", "default") != "default"
        or _normalized(run.get("scenario", default_scenario))
        != _normalized(default_scenario)
        for run in runs
    ):
        reasons.append("run default scenario mismatch")

    return {"formal": not reasons, "reasons": list(dict.fromkeys(reasons))}


def _status_lines(data, kind, source_basename):
    if source_basename.startswith("gate_"):
        return ["> Status: model gate result, used to cross-check the reference LoS scenario, not part of the formal comparison."]
    if source_basename.startswith("smoke_"):
        return ["> Status: smoke-test result, only for checking pipeline integrity."]
    if data.get("schema_version") != V3_SCHEMA_VERSION:
        if kind in ("full", "ablation"):
            return [
                "> Status: **historical v2 interim result**, only for layout and trend checks,",
                "> not valid for final statistical inference; formal status is granted only to complete v3 results.",
            ]
        return ["> Status: parameter-selection or model-verification result, not part of the formal held-out test set."]
    if data.get("schema_version") == V3_SCHEMA_VERSION:
        qualification = formal_qualification(data)
        if qualification["formal"]:
            return ["> Status: formal held-out seed result, valid for final statistical inference."]
        reason_text = "; ".join(qualification["reasons"])
        return [
            "> Status: **incomplete or non-formal v3 result**, not valid as a formal result.",
            f"> Reasons: {reason_text}.",
        ]
    raise ValueError("unreachable result status branch")


def effect_for_display(metric, median, low, high):
    """Convert TC/SAC effects to percentage points; other metrics keep their units."""
    scale = 100.0 if metric in ("TC", "SAC") else 1.0
    return median * scale, low * scale, high * scale


def _config_table(config):
    lines = ["## Experiment configuration", "", "| Parameter | Value |", "|---|---:|"]
    for key in sorted(config):
        value = config[key]
        if isinstance(value, (dict, list)):
            value = json.dumps(value, ensure_ascii=False, sort_keys=True)
        lines.append(f"| `{key}` | {value} |")
    return lines


def _algorithm_summary_lines(run_rows, algorithms):
    groups = {}
    for run in run_rows:
        groups.setdefault(run["algo"], []).append(run)
    algorithms = [algo for algo in algorithms if algo in groups]
    lines = [
        "| Metric | " + " | ".join(ALGO_LABEL[algo] for algo in algorithms) + " |",
        "|---|" + "---:|" * len(algorithms),
    ]
    for metric in METRICS:
        cells = []
        for algo in algorithms:
            values = np.asarray([
                metric_of(run, metric) for run in groups[algo]
            ])
            scale = 100.0 if metric in ("TC", "SAC") else 1.0
            suffix = "%" if scale == 100.0 else ""
            cells.append(
                f"{values.mean() * scale:.4f} ± "
                f"{_sample_std(values) * scale:.4f}{suffix}"
            )
        lines.append(f"| {METRIC_LABEL[metric]} | " + " | ".join(cells) + " |")
    return lines


def _comparison_markdown_lines(comparisons, title="Paired significance tests"):
    if not comparisons:
        return []
    lines = [
        f"## {title}", "",
        "All raw p values are computed first, then Holm-corrected within the complete test family of this scenario/checkpoint;"
        "differences are defined as QL-TADMPSO minus baseline.", "",
        "| Comparison | Metric | raw p | Holm p | Paired median difference [95% CI] | Direction |",
        "|---|---|---:|---:|---:|---|",
    ]
    for row in comparisons:
        median, low, high = effect_for_display(
            row["metric"], row["median_difference"],
            row["ci_low"], row["ci_high"],
        )
        lines.append(
            f"| {ALGO_LABEL[row['a']]} vs {ALGO_LABEL[row['b']]} | "
            f"{METRIC_LABEL[row['metric']]} | {_fmt_p(row['p_raw'])} | "
            f"{_fmt_p(row['p_holm'])} | {median:.6g} "
            f"[{low:.6g}, {high:.6g}] | {row['better']} |"
        )
    return lines


def _full_markdown(data):
    runs = group_runs(data)
    lines = ["## Algorithm results", ""]
    algos = [algo for algo in FORMAL_ALGORITHMS if algo in runs]
    algos.extend(algo for algo in runs if algo not in algos)
    lines.extend(_algorithm_summary_lines(data["runs"], algos))

    comparison_error = None
    try:
        comparisons = paired_comparison_rows(runs, algorithms=algos)
    except ValueError as exc:
        comparisons = []
        comparison_error = str(exc)
    if comparisons:
        lines.extend([""] + _comparison_markdown_lines(comparisons))
    elif comparison_error is not None:
        lines.extend([
            "", "> Paired inference unavailable: the result matrix is incomplete ("
            f"{comparison_error}).",
        ])

    ql = [run for run in runs.get("ql", []) if "q_visits" in run]
    if ql:
        visits = np.sum([np.asarray(run["q_visits"], dtype=int) for run in ql], axis=0)
        rewards = [float(item["reward"]) for run in ql
                   for item in run.get("reward_history", [])]
        decisions = sum(len(run.get("action_history", [])) for run in ql)
        lines.extend([
            "", "## Q-learning diagnostics", "",
            f"- Number of runs: {len(ql)}",
            f"- Total decision actions: {decisions}",
            f"- Visited states: {int(np.count_nonzero(visits.sum(axis=1)))} / {visits.shape[0]}",
            f"- Visited state-action pairs: {int(np.count_nonzero(visits))} / {visits.size}",
            f"- Positive rewards: {sum(value > 0 for value in rewards)} / {len(rewards)}",
        ])
    return lines


def _ablation_markdown(data):
    rows = ablation_summary(data)
    full = [run for run in data["runs"] if run.get("variant") == "full"]
    full_values = np.asarray([run["best_F"] for run in full])
    lines = [
        "## Mechanism ablation", "",
        f"Full algorithm: F = {full_values.mean():.6f} ± {_sample_std(full_values):.6f}.",
        "Difference = variant F minus full-algorithm F; positive means worse after removing the mechanism.", "",
        "| Variant | F (mean ± SD) | Paired median difference [95% CI] | Full wins / variant wins / ties | raw p | Holm p |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"| {VARIANT_LABEL[row['variant']]} | {row['mean_F']:.6f} ± "
            f"{row['std_F']:.6f} | {row['median_delta_F']:.6f} "
            f"[{row['ci_low']:.6f}, {row['ci_high']:.6f}] | "
            f"{row['full_wins']}/{row['variant_wins']}/{row['ties']} | "
            f"{_fmt_p(row['p_raw'])} | {_fmt_p(row['p_holm'])} |"
        )
    lines.extend([
        "", "> Wall-clock time is affected by run order, GPU temperature and background load, so this table does not use historical run times",
        "> as evidence about mechanism complexity; to compare computational cost, run a separate randomly interleaved timing experiment.",
    ])
    return lines


def _scenario_order(data):
    registry = data.get("config", {}).get("case_registry", [])
    registered = [str(entry["scenario_id"]) for entry in registry]
    observed = [str(run.get("scenario_id", "default")) for run in data["runs"]]
    order = []
    for scenario_id in registered + observed:
        if scenario_id not in order:
            order.append(scenario_id)
    return order


def _sweep_markdown(data, kind):
    title = "Area-scale robustness" if kind == "area_sweep" else "UAV-count robustness"
    lines = [f"## {title}", ""]
    algorithms = tuple(data["config"].get("algorithms", FORMAL_ALGORITHMS))
    for scenario_id in _scenario_order(data):
        selected = [
            run for run in data["runs"]
            if str(run.get("scenario_id", "default")) == scenario_id
        ]
        if not selected:
            continue
        lines.extend([f"### Scenario `{scenario_id}`", ""])
        lines.extend(_algorithm_summary_lines(selected, algorithms))
        comparisons = paired_comparison_rows(
            selected, algorithms=algorithms, scenario_id=scenario_id
        )
        lines.extend([""] + _comparison_markdown_lines(
            comparisons, title=f"{scenario_id} paired Wilcoxon-Holm tests"
        ) + [""])
    return lines


def _time_markdown(data):
    algorithms = tuple(data["config"].get("algorithms", FORMAL_ALGORITHMS))
    families = time_comparison_families(data)
    lines = [
        "## Fixed time budget results", "",
        "Each checkpoint uses the first full population boundary after the target time; FEs are the function evaluations actually completed.",
        "",
    ]
    for checkpoint, comparisons in families.items():
        lines.extend([
            f"### {checkpoint:g} s checkpoint", "",
            "| Algorithm | F (mean ± SD) | Actual FEs (mean ± SD) | "
            "TC (mean ± SD) | SAC (mean ± SD) |",
            "|---|---:|---:|---:|---:|",
        ])
        for algo in algorithms:
            selected = [run for run in data["runs"] if run["algo"] == algo]
            views = [
                _checkpoint_view(run, checkpoint) for run in selected
            ]
            checkpoint_rows = [
                next(row for row in run["checkpoints"] if np.isclose(
                    float(row["target_seconds"]), checkpoint,
                    rtol=0.0, atol=1e-12,
                ))
                for run in selected
            ]
            f_values = np.asarray([view["best_F"] for view in views])
            fes_values = np.asarray([row["fes"] for row in checkpoint_rows])
            tc_values = np.asarray([
                view["final_metrics"]["TC"] * 100.0 for view in views
            ])
            sac_values = np.asarray([
                view["final_metrics"]["SAC"] * 100.0 for view in views
            ])
            lines.append(
                f"| {ALGO_LABEL[algo]} | {f_values.mean():.6f} ± "
                f"{_sample_std(f_values):.6f} | {fes_values.mean():.1f} ± "
                f"{_sample_std(fes_values):.1f} | {tc_values.mean():.4f} ± "
                f"{_sample_std(tc_values):.4f}% | {sac_values.mean():.4f} ± "
                f"{_sample_std(sac_values):.4f}% |"
            )
        lines.extend([""] + _comparison_markdown_lines(
            comparisons,
            title=f"{checkpoint:g} s paired Wilcoxon-Holm tests",
        ) + [""])

    lines.extend([
        "## Timing overshoot", "",
        "| Algorithm | overshoot (mean ± SD, s) | Actual stop time (mean ± SD, s) |",
        "|---|---:|---:|",
    ])
    for algo in algorithms:
        selected = [run for run in data["runs"] if run["algo"] == algo]
        overshoot = np.asarray([run["overshoot_seconds"] for run in selected])
        actual = np.asarray([run["actual_seconds"] for run in selected])
        lines.append(
            f"| {ALGO_LABEL[algo]} | {overshoot.mean():.6f} ± "
            f"{_sample_std(overshoot):.6f} | {actual.mean():.6f} ± "
            f"{_sample_std(actual):.6f} |"
        )
    return lines


def _protocol_smoke_markdown(data):
    suites = {}
    for run in data.get("runs", []):
        suites[run.get("suite", "unspecified")] = (
            suites.get(run.get("suite", "unspecified"), 0) + 1
        )
    lines = [
        "## v3 protocol smoke coverage", "",
        "> This file only proves the code paths are executable; it has no formal statistical status.", "",
        "| Path | Completed records |", "|---|---:|",
    ]
    for suite, count in sorted(suites.items()):
        lines.append(f"| `{suite}` | {count} |")
    lines.append(f"| **Total** | **{len(data.get('runs', []))}** |")
    return lines


def _selection_markdown(data, kind):
    if kind == "l_repr":
        lines = [
            "## L representation sensitivity", "", f"Shortlisted values: {data.get('shortlist', [])}", "",
            "| L | Distance rank correlation | ARI | FSW time (ms) | Clustering time (ms) |",
            "|---:|---:|---:|---:|---:|",
        ]
        for row in data.get("summary", []):
            lines.append(
                f"| {row['L']} | {row['rank_mean']:.6f} ± {row.get('rank_std', 0):.6f} | "
                f"{row['ari_mean']:.6f} ± {row.get('ari_std', 0):.6f} | "
                f"{1000 * row['feature_seconds_mean']:.4f} | "
                f"{1000 * row['clustering_seconds_mean']:.4f} |"
            )
        return lines
    parameter = "L" if kind == "l_opt" else "G"
    recommended = data[f"recommended_{parameter}"]
    lines = [
        f"## {parameter} optimization sensitivity", "",
        f"one-SE rule recommends `{parameter}={recommended}` with threshold "
        f"{data['one_se_limit']:.6f}.", "",
        f"| {parameter} | F (mean ± SD) | SE | Mean run time (s, diagnostic) |",
        "|---:|---:|---:|---:|",
    ]
    for row in data.get("summary", []):
        lines.append(
            f"| {row[parameter]} | {row['mean_F']:.6f} ± {row['std_F']:.6f} | "
            f"{row['se_F']:.6f} | {row['runtime_seconds_mean']:.3f} |"
        )
    if kind == "g_sensitivity":
        lines.extend(["", "Action counts and state-action visits are in the source JSON; the final recommendation is `G=5`."])
    return lines


def render_markdown(data, source_name):
    """Render any current-version result as persistable Markdown."""
    validate_results(data)
    kind = result_kind(data)
    source_basename = os.path.basename(source_name)
    lines = [f"# Experiment report: {source_basename}", ""]
    lines.extend(_status_lines(data, kind, source_basename))
    lines.extend(["", f"- Result kind: `{kind}`", f"- Model version: `{data['model_version']}`",
                  f"- Source file: `{source_basename}`", ""])
    lines.extend(_config_table(data.get("config", {})))
    lines.append("")
    if kind == "full":
        lines.extend(_full_markdown(data))
    elif kind == "ablation":
        lines.extend(_ablation_markdown(data))
    elif kind in ("area_sweep", "uav_sweep"):
        lines.extend(_sweep_markdown(data, kind))
    elif kind == "time_budget":
        lines.extend(_time_markdown(data))
    elif kind == "protocol_smoke":
        lines.extend(_protocol_smoke_markdown(data))
    else:
        lines.extend(_selection_markdown(data, kind))
    lines.extend(["", "---", "", "This report was generated automatically by `experiments/report.py` from versioned JSON.", ""])
    return "\n".join(lines)


def write_markdown_report(path, output_dir=None):
    """Read a JSON and write the same-named Markdown report to reports/."""
    with open(path, encoding="utf-8") as stream:
        data = json.load(stream)
    markdown = render_markdown(data, path)
    destination_dir = REPORT_DIR if output_dir is None else output_dir
    os.makedirs(destination_dir, exist_ok=True)
    stem = os.path.splitext(os.path.basename(path))[0]
    destination = os.path.join(destination_dir, f"{stem}.md")
    with open(destination, "w", encoding="utf-8", newline="\n") as stream:
        stream.write(markdown)
    return destination


def main(argv=None):
    argv = sys.argv[1:] if argv is None else list(argv)
    path = argv[0] if argv else os.path.join(
        HERE, "outputs", "full_results_50grid_v2.json")
    destination = write_markdown_report(path)
    with open(destination, encoding="utf-8") as stream:
        print(stream.read())
    print(f"saved {destination}")


if __name__ == "__main__":
    main()
