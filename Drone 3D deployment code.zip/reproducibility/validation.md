# Delivery verification record (2026-10-18)

The verification platform is Windows 11, Python 3.12.10, NVIDIA GeForce RTX 4060 Laptop GPU. Records are kept in [verification/release_20261018](../verification/release_20261018/).

| Check | Result |
| --- | --- |
| Original implementation and evidence preservation | the SHA-256 of all 146 frozen files match, including the original 23 root Python modules, tests and formal data. The manifest is [checksums.json](checksums.json). |
| CPU independent environment | pinned dependencies installed in a fresh virtual environment that inherits no system packages and has no CuPy; the package dependency check passed. |
| GPU independent environment | fresh virtual environment on an ASCII path with the locked CUDA dependencies installed; the package dependency check passed; original wheels from the cache were installed offline, and wheel digests match PyPI. |
| Tests | all 24 test scripts passed, including 9 new archive re-check tests and 5 entry-point tests. |
| Small-scale re-experiments | on CPU, 10 count, 14 ablation and 7 algorithm-comparison runs plus the numbering diagnostics of 2 snapshots and report generation. 12 particles, 120 evaluations, 1 repetition. |
| Statistics recomputation | from the 620 formal records, recomputed the 186 summary rows, 132 paired tests, and the count-selection and numbering-diagnosis tables; 8 CSVs match the original tables item by item with absolute and relative tolerances of 1e-13. |
| GPU coordinate re-check | in the new GPU environment with an empty CuPy cache, metrics recomputed from the final coordinates of the 620 records using the original evaluation function; passed the original program's verification criteria. |
| Relocation and Git | the release files passed through Git staging and checkout with Windows line-ending conversion enabled; all 146 frozen files still match. After relocation the statistics recomputation was completed in an independent CPU environment. |
| Figures | GPU mode exported 7 experiment figures and CPU mode 4; PDFs and data sources were checked; the final manually typeset versions are kept separately. |

Statistics recomputation and coordinate re-checking do not equal rerunning the 620 full optimizations. This round ran the small-scale full pipeline and did not rerun the whole formal experiment set; the original run times are also historical measurements. Different hardware or CPU/GPU backends do not guarantee bitwise-identical search results or identical run times.

The GitHub auto-check configuration is added but has not run online; Linux and other GPUs are untested. The license awaits advisor confirmation; nothing has been uploaded publicly.

A Chinese-character virtual-environment path on Windows makes CuPy fail to find the CUDA headers even though the files exist. The GPU environment needs an ASCII path and a writable temp directory; the README gives the setup steps.
