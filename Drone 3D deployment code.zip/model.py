"""Backward-compatible module interface for the default UAV-BS scenario."""
import scenario as _scenario

from scenario import (
    COV_ANGLE_DEG,
    C_LOS,
    D_LOS,
    MU1,
    MU2,
    NOISE_DBM,
    POWER_FLOOR_MW,
    PT_DBM,
    RX_THRESHOLD_DBM,
    SNR_THRESHOLD_DB,
    TETROMINO_SHAPES,
    W1,
    W2,
    W3,
    aggregate_signal_dbm,
    coverage_radius,
    dbm_to_mw,
    freespace_loss,
    link_validity,
    metrics_from_field,
    metrics_from_summary,
    mw_to_dbm,
    plos_prob,
)


DEFAULT_CONFIG = _scenario.DEFAULT_CONFIG
DEFAULT_SCENARIO = _scenario.DEFAULT_SCENARIO
AREA = DEFAULT_CONFIG.area_m
N_GRID = DEFAULT_CONFIG.n_grid
CELL_SIZE = DEFAULT_CONFIG.cell_size_m
N_UAV = DEFAULT_CONFIG.n_uav
H_MIN = DEFAULT_CONFIG.h_min_m
H_MAX = DEFAULT_CONFIG.h_max_m
F_MHZ = DEFAULT_CONFIG.frequency_mhz
PRIORITY_FRACTION = DEFAULT_CONFIG.priority_fraction
MODEL_VERSION = "uav-bs-a2g-ahdpso-50grid-v2"
GRID_AXIS = DEFAULT_SCENARIO.grid_axis
GRID_XY = DEFAULT_SCENARIO.grid_xy
tetromino_shapes = TETROMINO_SHAPES

cp = _scenario.cp
_HAS_CUDA = _scenario._HAS_CUDA
_USE_GPU = _scenario._USE_GPU


def gpu_name():
    return _scenario.gpu_name(_USE_GPU)


def _gpu_grid():
    return DEFAULT_SCENARIO._gpu_grid()


def _gpu_area_masks(priority):
    return DEFAULT_SCENARIO._gpu_area_masks(priority)


def _gpu_signal_kernel():
    return _scenario._gpu_signal_kernel()


def _signal_and_coverage_gpu_device(uavs, mode):
    return DEFAULT_SCENARIO._signal_and_coverage_gpu_device(uavs, mode)


def _signal_and_coverage_gpu(uavs, mode):
    return DEFAULT_SCENARIO._signal_and_coverage_gpu(uavs, mode)


def _d2(points, uavs):
    return _scenario._d2(points, uavs)


def _fields(points, uavs, mode):
    return DEFAULT_SCENARIO._fields(points, uavs, mode)


def point_coverage(points, uavs):
    return DEFAULT_SCENARIO.point_coverage(points, uavs)


def point_snr(points, uavs, mode="a2g"):
    return DEFAULT_SCENARIO.point_snr(points, uavs, mode)


def point_signal_and_coverage(points, uavs, mode="a2g"):
    return DEFAULT_SCENARIO.point_signal_and_coverage(points, uavs, mode)


def _signal_and_coverage(uavs, mode):
    return DEFAULT_SCENARIO._signal_and_coverage(uavs, mode, _USE_GPU)


def snr_field(position, mode="a2g"):
    return DEFAULT_SCENARIO._snr_field(position, mode, _USE_GPU)


def _evaluate_gpu(position, priority, mode):
    return DEFAULT_SCENARIO._evaluate_gpu(position, priority, mode)


def evaluate(position, priority, mode="a2g"):
    return DEFAULT_SCENARIO._evaluate(position, priority, mode, _USE_GPU)


def _priority_cells(seed=0, max_attempts=100_000):
    return DEFAULT_SCENARIO._priority_cells(seed, max_attempts)


def priority_mask(seed=0):
    return DEFAULT_SCENARIO.priority_mask(seed)
